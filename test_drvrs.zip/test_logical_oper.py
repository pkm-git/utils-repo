csv_mode = True

found_sensor = True

sensor_plotted = False

if (found_sensor and not csv_mode):
   print(' ********* found_sensor and not csv_mode **** ')

if (found_sensor and not sensor_plotted):
   print(' ********* found_sensor and not sensor_plotted **** ')
   

