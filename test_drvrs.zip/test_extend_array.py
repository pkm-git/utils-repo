import numpy
import math

alt_amb_pr_list = []

alt_amb_pr_list.extend([1973, 678.65])
alt_amb_pr_list.extend([1975, 435.91])
alt_amb_pr_list.extend([1977, 802.42])

# alt_amb_pr_list.append([1973, 678.65])
# alt_amb_pr_list.append([1975, 435.91])
# alt_amb_pr_list.append([1977, 802.42])

# BIG_FILE_SIZE_THRESHOLD = 1e7
BIG_FILE_SIZE_THRESHOLD = 1.5e7

print(' **** big size threshold = ' + str(BIG_FILE_SIZE_THRESHOLD) + ', int(math.ceil(BIG_FILE_SIZE_THRESHOLD)) = ' + str(int(math.ceil(BIG_FILE_SIZE_THRESHOLD))))

file_size = 18365000

nbr_of_loops = int(math.ceil(numpy.float(file_size)/BIG_FILE_SIZE_THRESHOLD))

print(' ***** nbr_of_loops = ' + str(nbr_of_loops))

print(' ***** len(alt_amb_pr_list) = ' + str(len(alt_amb_pr_list)) )

x = range(5)

for m in x:
  print(' ***** m = ' + str(m))
  
i = 0

for c in alt_amb_pr_list:
   print(' **** i = ' + str(i) + ', c = ' + str(c))
   i = i + 1
   # print(' *********** c[0] = ' + str(c[0]) + ', c[1] = ' + str(c[1]))


