import os
from PyQt4 import QtCore, QtGui

print(' ***** Hello World! ****** ')

print(' ****** os.getcwd() = ' + str(os.getcwd()))

# addr = QtCore.QString("file:///" + os.getcwd() + "/Inertial Sensor Utils (8500-0079).pdf")

# tempArray = QtCore.QByteArray(addr.toUtf8())
# addrW    = tempArray.data()

# qd = QtGui.QDesktopServices()
# qurl = QtCore.QUrl(addrW)
# qd.openUrl(qurl.fromLocalFile(addrW))

qd = QtGui.QDesktopServices()
path = QtCore.QString("file:///" + os.getcwd() + "/Inertial Sensor Utils (8500-0079).pdf")

tempArray = QtCore.QByteArray(path.toUtf8())
addrW    = tempArray.data()

pathUrl = QtCore.QUrl(addrW)
qd.openUrl(pathUrl);
# qd.openUrl(pathUrl.fromLocalFile(addrW));

