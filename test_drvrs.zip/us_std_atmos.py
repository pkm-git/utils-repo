import sys
import math

US1976_MODEL_LAYERS = 8
US1976_T_0 = 273.15 + 15.0
US1976_p_0 = 1013.250
US1976_rho_0 =  1.225
US1976_g_0 = 9.80665
US1976_R_Earth = 6356766.0
US1976_R = 287.053

layer_height_m = []
layer_lapse_rate = []
layer_temperature = []
layer_pressure = []
layer_density = []

def get_data_at_geopotential_altitude(geopotential_height_m):
   # unsigned i;
   # float T, P, rho, h, h_n, Tn, Pn, rho_n, lapse_rate;

   # Short name for height
   h = geopotential_height_m
   
   # print(' *********** in get_data_at_geopotential_altitude: h = ' + str(h))
   
   # Reset Outputs
   temperature = 0.0
   pressure    = 0.0
   density     = 0.0

   # Loop through the layers and calculate the outputs
   for i in range(US1976_MODEL_LAYERS):
      # If we are less than the current layer altitude, we are in the previous layer
      if (h <= layer_height_m[i]):
         # print( ' ********** i = ' + str(i) + ' h <= layer_height_m[i] = ' + str(layer_height_m[i]))
         
         # Get Inputs
         h_n        = layer_height_m[i-1]
         Tn         = layer_temperature[i-1]
         Pn         = layer_pressure[i-1]
         rho_n      = layer_density[i-1]
         lapse_rate = layer_lapse_rate[i-1]

         # Calculate outputs
         
         # Linear Layer
         if (lapse_rate != 0.0):
            T   = Tn + (h - h_n)*lapse_rate
            P   = Pn*((T/Tn)**(-US1976_g_0/(US1976_R*lapse_rate)))
            rho = rho_n*((T/Tn)**(-(1 + US1976_g_0/(US1976_R*lapse_rate))))
         # Iso-thermal Layer
         else:
            T   = Tn
            P   = Pn*math.exp(-US1976_g_0*(h - h_n)/(US1976_R*Tn))
            rho = rho_n*math.exp(-US1976_g_0*(h - h_n)/(US1976_R*Tn))

         # Set the outputs
         temperature = T
         pressure    = P
         density     = rho
         
         print(' ********* MSL Ht = ' + str(h) + ' m, lapse_rate = ' + str(lapse_rate) + ' T = ' + str(T) + ' K, P = ' + str(P) + ' mBar, rho = ' + str(rho) + ' kg/m^3')
         
         layer_temperature.append(T)
         layer_pressure.append(P)
         layer_density.append(rho)
         
         print(' -------------------------------------------------------------------------------------------------------------')
         
         return temperature, pressure, density
         
      # } if (h <= layer_height_m[i])..
   # } for i in range(US1976_MODEL_LAYERS).. 

   # return temperature, pressure, density
   
def get_pressure_altitude_m(pressure):
   # unsigned i;
   # float T, P, rho, h_n, Tn, Pn, lapse_rate;
   
   # Initialize the output
   pressure_altitude = 0.0;

   # Loop through the layers and calculate the outputs
   for i in range(1, US1976_MODEL_LAYERS):
      # If we are less than the current layer altitude, we are in the previous layer
      if (pressure >= layer_pressure[i]):
         # print(' ********* i = ' + str(i) + ' pressure >= layer_pressure[i] = ' + str(layer_pressure[i]))
         
         # Get Inputs
         h_n        = layer_height_m[i-1]
         Tn         = layer_temperature[i-1]
         Pn         = layer_pressure[i-1]
         lapse_rate = layer_lapse_rate[i-1]

         # Calculate outputs

         # Linear Layer
         if (lapse_rate != 0.0):
            # print(' ********** lapse_rate = ' + str(lapse_rate))
            
            # Calculate the pressure altitude
            pressure_altitude = h_n - (Tn/lapse_rate)*(1 - (pressure/Pn)**(-US1976_R*lapse_rate/US1976_g_0))
            # print(' ************ pressure_altitude = ' + str(pressure_altitude))
            
         # Iso-thermal Layer
         else:
            # Calculate the pressure altitude
            pressure_altitude = h_n - (US1976_R*Tn/US1976_g_0)*math.log(pressure/Pn)

         return pressure_altitude
      # } if (pressure >= layer_pressure[i])..
   # } for i in range(1, US1976_MODEL_LAYERS)..
         
   return pressure_altitude

def main_line(argv):
   """Main line program"""
   
   layer_height_m_init = [0.0, 11000.0, 20000.0, 32000.0, 47000.0, 51000.0, 71000.0, 84852.0]
   layer_lapse_rate_init = [-6.5/1000.0, 0.0, 1.0/1000.0, 2.8/1000.0, 0.0, -2.8/1000.0, -2.0/1000.0, 0.0]
   
   for i in range(US1976_MODEL_LAYERS):
      layer_height_m.append(layer_height_m_init[i])
      layer_lapse_rate.append(layer_lapse_rate_init[i])
   
   # Set the initial conditions
   layer_temperature.append(US1976_T_0)
   layer_pressure.append(US1976_p_0)
   layer_density.append(US1976_rho_0)

   for i in range(1, US1976_MODEL_LAYERS):
      layer_temperature_out, layer_pressure_out, layer_density_out = get_data_at_geopotential_altitude(layer_height_m[i])
      # print('{:-d}\t{:-9.1f}\t{:-14.8f}\t{:-14.8f}\t{:-14.8f}'.format(i,layer_height_m[i], layer_temperature_out, layer_pressure_out, layer_density_out))
   
   # Get pressure at MSL ht = 157.573 m

   layer_temperature_out, layer_pressure_out, layer_density_out = get_data_at_geopotential_altitude(157.573)
   # print(' -------------------------------------------------------------------------')
   
   # 124.81
   layer_temperature_out, layer_pressure_out, layer_density_out = get_data_at_geopotential_altitude(124.81)
   
   # print(' -------------------------------------------------------------------------')
   pr_alt = get_pressure_altitude_m(994.46)
   
   print(' *************** pr alt at pressure of 994.46 mBar is = ' + str(pr_alt) + ' m')
   
   print(' -------------------------------------------------------------------------')
   
   pr_alt = get_pressure_altitude_m(998.345)
   
   print(' *************** pr alt at pressure of 998.345 mBar is = ' + str(pr_alt) + ' m')
   print(' -------------------------------------------------------------------------')
   
if(__name__ == "__main__"):
  main_line(sys.argv)


