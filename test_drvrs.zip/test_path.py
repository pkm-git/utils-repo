import os
import sys

try:
    # user_paths = os.environ['PYTHONPATH'].split(os.pathsep)
    # print(' ************ user_paths = ' + str(user_paths))
    print('********** sys.path = ' + str(sys.path))
    print('********** sys.platform = ' + str(sys.platform))
except KeyError as err:
    # user_paths = []
    print(' ******** KeyError: Error Msg: {0}'.format(err))

