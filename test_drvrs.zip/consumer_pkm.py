import threading       #import thread library
from time import time  #import time library
from time import clock  #import time library
from time import sleep           #sleep
from gsg_imu import *

class Consumer_PKM(threading.Thread):
    def __init__(self, done, gsg_imu_obj, condition):
        # Constructor

        threading.Thread.__init__(self)
        self.done = done
        self.condition = condition
        self.cnt = 0
        self.gsg_imu_obj = gsg_imu_obj
        print (' *********** in Consumer PKM constr')
        
    def run(self):
        # Thread run method
        while (self.cnt < 100):
            # print ('\n ------------------------------ \n *********** in Consumer PKM run')
            self.cnt = self.cnt + 1

            self.condition.acquire()
            # print '\n condition acquired by Consumer_PKM'
        
            current_time = clock()
            while (True):
                # print 'in Consumer, self.cnt = %d, current_time = %14.8f, self.gsg_imu_obj.imu_tow = %14.8f\n' % (self.cnt, current_time, self.gsg_imu_obj.imu_tow)
                print 'Consumer: cnt = %d, Switch time: %14.8f\n' % (self.cnt, (current_time - self.gsg_imu_obj.imu_tow))
                
                if (0):
                   if self.done:
                       # print(' in Consumer, current_time = %14.8f, self.cnt = %d, Done is TRUE\n', current_time, self.cnt)
                       # print('{:-14.8f},{:4d}'.format(current_time, self.cnt)
                       print 'in Consumer, self.cnt = %d, current_time = %14.8f, Done is TRUE\n' % (self.cnt, current_time)
                   else:
                       # print(' in Consumer, current_time = %14.8f, self.cnt = %d, Done is FALSE\n', current_time, self.cnt)
                       print 'in Consumer, self.cnt = %d, current_time = %14.8f, Done is FALSE\n' % (self.cnt, current_time)
                break
        
                # print '\n condition wait by Consumer_PKM'
                self.condition.wait()

            # print '\n condition released by Consumer_PKM'
            self.condition.release()

