import math
import numpy

# old = 350.0
# old = 710.0
# new = 10.0

old = 10.0
new = 350.0

orig_new = new

diff = new - old

multiple_360 = int(math.ceil(numpy.float(old)/360.0))

if (diff < 0 and abs(diff) >= 340.0):
   new = new + 360.0 * multiple_360

print(' ***** old: ' + str(old) + ', orig_new: ' + str(orig_new) + ', multiple_360: ' + str(multiple_360) + ', modified new: ' + str(new))

# nbr_of_loops = int(math.ceil(numpy.float(file_size)/avail_mem))


