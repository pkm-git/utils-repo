from PyQt4 import QtGui
import sys

def main():

    app     = QtGui.QApplication(sys.argv)
    tabW    = QtGui.QTabWidget()
    tabW.setStyleSheet("QTabBar::tab:disabled {"+\
                        "width: 300px;"+\
                        "color: transparent;"+\
                        "background: transparent;}")
    pushButton1 = QtGui.QPushButton("QPushButton 1")
    pushButton2 = QtGui.QPushButton("QPushButton 2")

    tab1    = QtGui.QWidget()
    tab2    = QtGui.QWidget()
    emptySpace = QtGui.QWidget()
    tab3    = QtGui.QWidget()

    vBoxlayout    = QtGui.QVBoxLayout()
    vBoxlayout.addWidget(pushButton1)
    vBoxlayout.addWidget(pushButton2)

    #Resize width and height
    tabW.resize(500, 500)


    #Set Layout for Third Tab Page
    tab3.setLayout(vBoxlayout)

    tabW.addTab(tab1,"Tab 1")
    tabW.addTab(tab2,"Tab 2")
    tabW.addTab(emptySpace,"ES")
    tabW.setTabEnabled(2,False)
    tabW.addTab(tab3,"Tab 3")

    tabW.setWindowTitle('PyQt QTabWidget Add Tabs and Widgets Inside Tab')
    tabW.show()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
