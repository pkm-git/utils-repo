import sys
from PyQt4.QtCore import * 
from PyQt4.QtGui import * 

class comp_port_data_struct:
   def __init__(self):
      self.model_name = ''
      self.serial_nbr = ''
      self.fw_version = ''
      self.model_nbr = ''
      self.options = ''
      self.port_name = ''
   
   def toString(self):
      # return self.model_name + '  ' + self.serial_nbr + '  ' + self.fw_version + '  ' + self.model_nbr + '  ' + self.options + '  ' + self.port_name
      return self.model_name + '\t' + self.serial_nbr + '\t' + self.fw_version + '\t' + self.model_nbr + '\t' + self.options + '\t' + self.port_name

#################################################################### 
def main(): 
    app = QApplication(sys.argv) 
    w = MyWindow() 
    w.show() 
    sys.exit(app.exec_()) 

#################################################################### 
class MyWindow(QWidget): 
   def __init__(self, *args): 
      QWidget.__init__(self, *args) 

      # create table
      # list_data = [1,2,3,4]
      
      list_data = []

      port_obj = comp_port_data_struct()
      
      port_obj.model_name = 'GX5-45'
      port_obj.serial_nbr = '134324'
      port_obj.fw_version = '1128'
      port_obj.model_nbr = '324532'
      port_obj.options = '30g'
      port_obj.port_name = 'COM5'

      list_data.append(port_obj.toString())
      
      port_obj = comp_port_data_struct()
      
      port_obj.model_name = 'GX5-25'
      port_obj.serial_nbr = '134657'
      port_obj.fw_version = '1129'
      port_obj.model_nbr = '786782'
      port_obj.options = '40g'
      port_obj.port_name = 'COM12'

      list_data.append(port_obj.toString())
      
      # list_data = [1,2,3,4]
      
      lm = MyListModel(list_data, self)
      lv = QListView()
      lv.setModel(lm)

      # layout
      layout = QVBoxLayout()
      layout.addWidget(lv) 
      self.setLayout(layout)

#################################################################### 
class MyListModel(QAbstractListModel): 
   def __init__(self, datain, parent=None, *args): 
      """ datain: a list where each item is a row
      """
      QAbstractListModel.__init__(self, parent, *args) 
      self.listdata = datain

   def rowCount(self, parent=QModelIndex()): 
      return len(self.listdata) 

   def data(self, index, role): 
      if index.isValid() and role == Qt.DisplayRole:
          return QVariant(self.listdata[index.row()])
      else: 
          return QVariant()
      # } if index.isValid()..
       
####################################################################
if __name__ == "__main__": 
    main()
