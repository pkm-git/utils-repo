import numpy as np

rq1_gps_tow = [1.0, 2.0, 3.0, 4.0, 5.0]
rq1_gps_horiz_acc = [0.567, 0.689, 0.352, 0.982, 0.468]

# gx4_gps_tow = [1.3, 1.6, 2.4, 3.8]
gx4_gps_tow = [0.4, 1.3, 1.6, 2.4, 3.8, 6.9]

gx4_gps_horiz_acc_interp = np.interp(np.array(gx4_gps_tow), np.array(rq1_gps_tow), np.array(rq1_gps_horiz_acc))

for index in range(len(rq1_gps_tow)):
   print(' *********** index = ' + str(index) + ' rq1 tow = ' + str(rq1_gps_tow[index]) + ' rq1_horiz_acc = ' + str(rq1_gps_horiz_acc[index]))

print('\n')

for index in range(len(gx4_gps_tow)):
   print(' *********** index = ' + str(index) + ' gx4 tow = ' + str(gx4_gps_tow[index]) + ' gx4_horiz_acc = ' + str(gx4_gps_horiz_acc_interp[index]))

 # Python results:

 # gx4 tow = 0.4 gx4_horiz_acc = 0.567
 # gx4 tow = 1.3 gx4_horiz_acc = 0.6036
 # gx4 tow = 1.6 gx4_horiz_acc = 0.6402
 # gx4 tow = 2.4 gx4_horiz_acc = 0.5542
 # gx4 tow = 3.8 gx4_horiz_acc = 0.856
 # gx4 tow = 6.9 gx4_horiz_acc = 0.468

 # *********** index = 0 rq1 tow = 1.0 rq1_horiz_acc = 0.567
 # *********** index = 1 rq1 tow = 2.0 rq1_horiz_acc = 0.689
 # *********** index = 2 rq1 tow = 3.0 rq1_horiz_acc = 0.352
 # *********** index = 3 rq1 tow = 4.0 rq1_horiz_acc = 0.982
 # *********** index = 4 rq1 tow = 5.0 rq1_horiz_acc = 0.468

 # *********** index = 0 gx4 tow = 0.4 gx4_horiz_acc = 0.567
 # *********** index = 1 gx4 tow = 1.3 gx4_horiz_acc = 0.6036
 # *********** index = 2 gx4 tow = 1.6 gx4_horiz_acc = 0.6402
 # *********** index = 3 gx4 tow = 2.4 gx4_horiz_acc = 0.5542
 # *********** index = 4 gx4 tow = 3.8 gx4_horiz_acc = 0.856
 # *********** index = 5 gx4 tow = 6.9 gx4_horiz_acc = 0.468

 # Matlab:
 # rq1_gps_tow = [1.0, 2.0, 3.0, 4.0, 5.0];
 # rq1_gps_horiz_acc = [0.567, 0.689, 0.352, 0.982, 0.468];
 # gx4_gps_tow = [1.3, 1.6, 2.4, 3.8];
 # gx4_gps_horiz_acc_interp = interp1(rq1_gps_tow, rq1_gps_horiz_acc, gx4_gps_tow)

 # Matlab results:

 # gx4_gps_horiz_acc_interp = [ 0.6036  0.6402  0.5542   0.856 ]
 # plot(rq1_gps_tow, rq1_gps_horiz_acc, '-x', gx4_gps_tow, gx4_horiz_acc, '-o');grid;xlabel('GPS TOW (s)','interpreter','none');ylabel('Horiz Acc (m)', 'interpreter','none');l = legend('GPS Horiz Acc: RQ1', 'GPS Horiz Acc: GX4');set(l, 'Interpreter', 'none');

