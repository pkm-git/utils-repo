# gps_default_cols_dict = {"8109":"1", "8108":"2", "8103":"3", "8105":"4", "8104":"5", "8106":"6", "8107":"7", "810A":"8", "810D":"9", "810B":"10" }
gps_default_cols_dict = {"8109":1, "8103":2, "8105":3, "8104":4, "8106":5, "8107":6, "810A":7, "810D":8, "810B":9, "8108":10 }

tmp_str = "810D"
desc_set = '81'
field_desc = '04'

packet_field_descr = desc_set + field_desc.upper()

if ('8106' in gps_default_cols_dict):
   print(' ********* 8106 is in gps_default_cols_dict ')
else:
   print(' ********* 8106 is NOT in gps_default_cols_dict ')

if (tmp_str in gps_default_cols_dict):
  print(' *********** tmp_str IS in gps_default_cols_dict ** ')
else:
  print(' *********** tmp_str IS NOT in gps_default_cols_dict ** ')

SECONDS_IN_A_WEEK = 604800

sec_from_epoch = 1900 * SECONDS_IN_A_WEEK

print(' *********** sec_from_epoch = ' + str(sec_from_epoch))

# aDict = {}
# aDict[key] = value

if (1):
    # Test string array sort
    gps_output_order = []

    gps_output_order.append("8103")
    gps_output_order.append("8109")
    gps_output_order.append("8105")

    print(' ********* BEFORE SORT: ' )
    for i in range(len(gps_output_order)):
       print(' *** gps_output_order[i] = ' + gps_output_order[i])

    # for g in gps_output_order:
      # print(' *** g = ' + g)

    gps_output_order.sort()

    print(' ********* AFTER SORT: ' )

    # for g in gps_output_order:
      # print(' *** g = ' + g)

    for i in range(len(gps_output_order)):
       print(' *** gps_output_order[i] = ' + gps_output_order[i])
       # print(' *** g = ' + g)
   
    # Test numeric array sort
    gps_output_order_num = []

    gps_output_order_num.append(5)
    gps_output_order_num.append(1)
    gps_output_order_num.append(8)
    gps_output_order_num.append(3)

    print(' ********* BEFORE SORT: ' )
    for g in gps_output_order_num:
      print(' *** g = ' + str(g))

    gps_output_order_num.sort()
   
    print(' ********* AFTER SORT: ' )
    for g in gps_output_order_num:
      print(' *** g = ' + str(g))
   
    # Test an array of arrays
    gps_output_order_array = []
    gps_output_order_array.append(gps_output_order)

    gps_output_order2 = []

    gps_output_order2.append("8201")
    gps_output_order2.append("8204")
    gps_output_order2.append("8206")
    gps_output_order2.append("8210")

    gps_output_order_array.append(gps_output_order2)

    tmp_gps_output_order = gps_output_order_array[0]

    print('********* gps_output_order_array[0]: ' )
    for c in tmp_gps_output_order:
       print(' ******** c = ' + c)

    tmp_gps_output_order = gps_output_order_array[1]

    print('********* gps_output_order_array[1]: ' )
    for c in tmp_gps_output_order:
       print(' ******** c = ' + c)

gps_output_order = []

# gps_output_order.append(gps_default_cols_dict["8103"])
# gps_output_order.append(gps_default_cols_dict["8109"])
# gps_output_order.append(gps_default_cols_dict["8105"])

gps_output_order.append(gps_default_cols_dict["8105"])
gps_output_order.append(gps_default_cols_dict["8106"])
gps_output_order.append(gps_default_cols_dict["8103"])
gps_output_order.append(gps_default_cols_dict["8104"])
gps_output_order.append(gps_default_cols_dict["8109"])

print(' ********* USING DICT: BEFORE SORT: ' )

if (0):
   for g in gps_output_order:
     print(' *** g = ' + g)

   gps_output_order.sort()

   print(' ********* AFTER SORT: ' )

   for g in gps_output_order:
     print(' *** g = ' + g)

gps_output_order_minus_d = []

gps_output_order_minus_d.append("4")
# gps_output_order_minus_d.append("6")
# gps_output_order_minus_d.append("3")
# gps_output_order_minus_d.append("5")
gps_output_order_minus_d.append("1")

gps_output_order_in_log = []

gps_output_order_in_log.append("3")
gps_output_order_in_log.append("1")
gps_output_order_in_log.append("4")

print(' ********* IN LOG FILE:' )

for g in gps_output_order_in_log:
  print(' *** g = ' + g)

# print(' ********* USING MIP MON SELECTIONS: BEFORE SORT: ' )
# print(' ********* USING MINUS D: BEFORE SORT: ' )

if (0):
   gps_output_order_final = []

   for g in gps_output_order_minus_d:
     print(' *** g = ' + g)
     if (g in gps_output_order_in_log):
        gps_output_order_final.append(g)

gps_output_order_final = gps_output_order_in_log

print(' ********* FINAL: BEFORE SORT: ' )

for g in gps_output_order_final:
  print(' *** g = ' + g)

gps_output_order_final.sort()

print(' ********* FINAL: AFTER SORT: ' )

for g in gps_output_order_final:
  print(' *** g = ' + g)

# gps_default_cols_dict = {"8109":"1", "8108":"2", "8103":"3", "8105":"4", "8104":"5", "8106":"6", "8107":"7", "810A":"8", "810D":"9", "810B":"10" }

print (' ************ gps_default_cols_dict[8105] = ' + str(gps_default_cols_dict["8105"]))

my_dict = {"errorcode": "404-001", "message": "A Sensor name was used that doesn't exist (Sensor: GX4-45-2)."}

print (' ************ my_dict[errorcode] = ' + my_dict["errorcode"])

