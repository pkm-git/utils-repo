

# byte = ord(bytestring[0])

# extract the desired bit:

flag_82_10 = 8192

tmp1 = flag_82_10 >> 1

print(' ********** AFTER shifting by 1, flag_82_10 = ' + str(flag_82_10), ' tmp1 = ' + str(tmp1))

tmp2 = flag_82_10 >> 2

print(' ********** AFTER shifting by 2, flag_82_10 = ' + str(flag_82_10), ' tmp2 = ' + str(tmp2))


# for i in range(16):
   # print(' ********* i = ' + str(i) + ', (flag_82_10 >> i) & 1 = ' + str((flag_82_10 >> i) & 1))
