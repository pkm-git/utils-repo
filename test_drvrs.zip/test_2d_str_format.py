msg_id_array = [3, 4, 6, 7, 8, 9, 36]

for id in msg_id_array:
   str_msg_id = '{:02d}'.format(id)
   print(' ****** str_msg_id = ' + str_msg_id)

