import os, sys, sysconfig, ConfigParser

# print ('******* os.path = ' + str(os.path))
# print ('\n******* BEFORE: sys.path = ' + str(sys.path))

# sys.path.insert(0, 'C:\MP')

# print ('\n******* AFTER: sys.path = ' + str(sys.path))

# print str(os.environ)

# print ('******* sysconfig.get_config_h_filename() = ' + str(sysconfig.get_config_h_filename()))

config = ConfigParser.ConfigParser()

# config.add_section('section')
# config['section']['setting_1'] = "hello"
# config['section']['setting_2'] = "goodbye"

if not config.has_section("dirs"):
   print(' *********** config does not have section dirs, adding new one')
   config.add_section("dirs")    
config.set("dirs", "inputdir", 'U:\Lord\Python_HIL_Sim_From_File')

with open("inertial_sensor.cfg", 'w') as f:
    config.write(f)
   
# user_config_dir = os.path.expanduser("~") + "/.config/Nick_H"
user_config_dir = '.'
user_config = user_config_dir + "/inertial_sensor.cfg"

# if not os.path.isfile(user_config):
    # os.makedirs(user_config_dir, exist_ok=True)
    # shutil.copyfile("default_config.ini", user_config)

# config = configparser.ConfigParser()
config.read(user_config)

if config.has_section("dirs"):                  
   # if an entry exists then add the value to the form      
   if config.has_option("dirs", "inputdir"):          
      theInputDir = config.get("dirs", "inputdir")

print(' ********* theInputDir = ' + theInputDir)

# print(config['section']['setting_1'])
# print(config['section']['setting_2'])
