import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

class Radiodemo(QWidget):

   def __init__(self, parent = None):
      super(Radiodemo, self).__init__(parent)
      
      if (0):
         layout = QHBoxLayout()
         self.b1 = QRadioButton("Button1")
         self.b1.setChecked(True)
         self.b1.toggled.connect(lambda:self.btnstate(self.b1))
         layout.addWidget(self.b1)
         
         self.b2 = QRadioButton("Button2")
         self.b2.toggled.connect(lambda:self.btnstate2(self.b2))

         layout.addWidget(self.b2)
         self.setLayout(layout)
         self.setWindowTitle("RadioButton demo")

      layout = QHBoxLayout()  # layout for the central widget
      widget = QWidget(self)  # central widget
      widget.setLayout(layout)
      
      # ********* Number Group **************
      # number_group = QButtonGroup(widget) # Number group
      number_group = QButtonGroup() # Number group
      
      r0 = QRadioButton("0")
      number_group.addButton(r0)
      
      r1 = QRadioButton("1")
      number_group.addButton(r1)
      
      # layout.addWidget(r0)
      # layout.addWidget(r1)
      layout.addWidget(number_group)

   def btnstate(self,b):
   
      if b.text() == "Button1":
         if b.isChecked() == True:
            print "btstate 1" + b.text() + " is selected"
         else:
            print "btstate 1" + b.text() + " is deselected"
            
      if b.text() == "Button2":
         if b.isChecked() == True:
            print "btstate 1" + b.text() + " is selected"
         else:
            print "btstate 1" + b.text() + " is deselected"
            
   def btnstate2(self,b):
   
      if b.text() == "Button1":
         if b.isChecked() == True:
            print "btstate 2" + b.text() + " is selected"
         else:
            print "btstate 2" + b.text() + " is deselected"
            
      if b.text() == "Button2":
         if b.isChecked() == True:
            print "btstate 2" + b.text() + " is selected"
         else:
            print "btstate 2" + b.text() + " is deselected"

def main():

   app = QApplication(sys.argv)
   ex = Radiodemo()
   ex.show()
   sys.exit(app.exec_())
   
if __name__ == '__main__':
   main()
