import os
import sys
import inspect
# import configparser
import imp

# print('os.path: ' + str(os.path))
# print('sys.path: ' + str(sys.path))

if ('PYTHONPATH' in sorted(os.environ)):
  print(os.environ['PYTHONPATH'])
else:  
  print('PYTHONPATH is not defined')
  
# sys.path.append('C:\\python34\\lib\\site-packages')

# print('AFTER APPEND, sys.path: ' + str(sys.path))

print 'inspect.getfile(os) is:', inspect.getfile(os)
# print 'inspect.getfile(binascii) is:', inspect.getfile(binascii)
# print 'inspect.getfile(configparser) is:', inspect.getfile(configparser)

imp.find_module("os")
