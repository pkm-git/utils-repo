import threading       #import thread library
from consumer_pkm import *
from producer_pkm import *

from gsg_imu import *

def main():
    done = False
    gsg_imu_obj = GSG_IMU()
    condition = threading.Condition()
    t1 = Producer_PKM(done, gsg_imu_obj, condition)
    t2 = Consumer_PKM(done, gsg_imu_obj, condition)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

if __name__ == '__main__':
    main()

