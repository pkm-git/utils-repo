import numpy as np

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068]

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915]

ambient_temp_array = [33.5, 32.1, 30.8, 27.5, 24.2, 19.8, 16.0, 12.5]

ambient_pressure = 0
llh_ht = 978
altitude_prev = 0
altitude = 0

# pts = np.vstack([np.array(altitude_array), np.array(ambient_pressure_array), np.array(ambient_temp_array)]).transpose()

pts = np.vstack([np.array(altitude_array), np.array(ambient_pressure_array), np.array(ambient_temp_array)]).transpose()

# pts = np.vstack([altitude_array, ambient_pressure_array, ambient_temp_array]).transpose()

indx = 0
for p in pts:
   print(' ************ indx = ' + str(indx) + ' p = ' + str(p))
   indx += 1


