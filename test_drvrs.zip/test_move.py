from PyQt4 import QtCore, QtGui
from random import randint

from collections import deque

class Widget(QtGui.QWidget):

    def __init__(self):
       super(Widget, self).__init__()

       self.setObjectName("MainWindow")

       mainLayout = QtGui.QVBoxLayout(self)
       mainLayout.setSpacing(0)
       mainLayout.setMargin(20)

       self.widgets = deque()
       self.widgets.append(None)
       self.widgets.append(self)

       for i in xrange(3): 
          w = QtGui.QWidget()
          name = "widget%d" % i
          color = [str(randint(0,255)) for _ in xrange(3)]
          w.setObjectName(name)
          w.setStyleSheet("#%s { background: rgb(%s) }" % (name, ','.join(color)))
          mainLayout.addWidget(w)
          self.widgets.append(w)

       self.button = QtGui.QPushButton("Move", self)
       self.button.clicked.connect(self.random_move)

    def random_move(self):
       b = self.button
       parent = b.parent()
       pos = b.pos()
       name = parent and parent.objectName() or "None"
       print "\nOld Parent/Pos: ", name, (pos.x(), pos.y())

       new_parent = parent 
       while new_parent is parent:
          self.widgets.rotate(1)
          new_parent = self.widgets[0]

       self.button.setParent(new_parent)
       # self.button.move(randint(0, 50), randint(0, 50))
       
       self.button.move(35, 20)
       
       pos = b.pos()
       name = new_parent and new_parent.objectName() or "None"
       print "New Parent/Pos: ", name, (pos.x(), pos.y())
       self.button.show()

if __name__ == "__main__":

   app = QtGui.QApplication([])

   w = Widget()
   w.resize(800,600)
   w.show()

   app.exec_()
