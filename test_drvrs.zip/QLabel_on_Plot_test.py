#changed original code to simple plot() because manual window structure
#somehow didn't automatically cooperate with viewbox' map methods

from pyqtgraph.Qt import QtGui, QtCore
import numpy as np
import pyqtgraph as pg

voieTT=np.ones(100)
voieTemps=np.ones(100)
for i in range(100):
    voieTT[i]=np.random.random_sample()
    voieTemps[i]=i

signemax=np.max(voieTT)
tmax=np.where(voieTT==np.max(voieTT))[0][0]

grapheTT = pg.plot(enableMenu=False)

grapheTTVB=grapheTT.getViewBox()
grapheTT.plot(voieTemps, voieTT)
grapheTT.plot([tmax],[signemax],symbol='o',symbolSize=8)
grapheTT.showGrid(x=True, y=True)

textVmax = pg.TextItem(anchor=(0.5,1.5), border='w', fill=(0,0,255))
textVmax.setHtml('<div style="text-align: center"><span style="color: #FFF;">Vmax=%0.1f mm/s @ %0.1f s</span></div>'%(np.abs(signemax),tmax))
grapheTT.addItem(textVmax)
textVmax.setPos(tmax, signemax)



#DISCLAIMER: there's likely a better way, but this works too:

#you can get pixel dimensions x,y,w,h from bounding rectangle
br = textVmax.boundingRect()
print br

#and scale them into viewbox data dimensions
sx, sy = grapheTTVB.viewPixelSize() #scaling factors
print sx, sy
print sx*br.width(), sy*br.height()


#ALSO, you can just use ViewBox autorange
#ViewBox autoranges based on its contained items' dataBounds() info
#however TextItem.py is a UIGraphicsItem.py with dataBounds() return None
"""Called by ViewBox for determining the auto-range bounds.
By default, UIGraphicsItems are excluded from autoRange."""

#so, following example of... ArrowItem.py
#here is a simple dataBounds() for TextItem

def Autoranging_TextItem_dataBounds(axis, frac=1.0, orthoRange=None):
    br = textVmax.boundingRect()
    sx, sy = grapheTTVB.viewPixelSize()
    w, h = sx*br.width(), sy*br.height()
    if axis == 0: return [-w/2, w/2]
    if axis == 1: return [0, h]

textVmax.dataBounds = Autoranging_TextItem_dataBounds


if __name__ == '__main__':
    import sys
    if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
        QtGui.QApplication.instance().exec_()
