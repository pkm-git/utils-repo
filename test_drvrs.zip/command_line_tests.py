python -c "import math; import numpy as np; n = -0.00915122; e = 0.00584629; mag = vel_NE_mag = np.sqrt(np.power(n, 2) + np.power(e, 2)); print(str(float(math.acos(n/mag))));"

python -c "import math; print(' ********** math.radians(185.0) = ' + str(math.radians(185.0)));"
