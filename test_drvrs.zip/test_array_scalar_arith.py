import numpy as np
import math

# Create altitude array (in meters above sea level)
tow_array = [0, 4, 7, 10, 15, 20]

# Create ambient pressure array (in bar)
lat_array = [10.5, 12.3, 13.9, 14.8, 15.4, 23.7]

print(' ************ BEFORE: lat_array: ************ ')
for t in lat_array:
   print(t),
print('\n')

lat_array = np.array(lat_array) - 3

print(' ************ AFTER: lat_array: ************ ')
for t in lat_array:
   print(t),
print('\n')

lat_array = lat_array / 2

print(' ************ AFTER divide: lat_array: ************ ')
for t in lat_array:
   print(t),
print('\n')

print(' ************** math.exp(2) = ' + str(math.exp(2)))
