from PyQt4 import QtCore, QtGui

# parse_to_csv_action = 'pfmb'
parse_to_csv_action = 'helloworld'

print(' ******** parse_to_csv_action = ' + parse_to_csv_action)

print(' ******** parse_to_csv_action[:2] = ' + parse_to_csv_action[:2])

print(' ******** parse_to_csv_action[2:] = ' + parse_to_csv_action[2:])

print(' ******** parse_to_csv_action[1:3] = ' + parse_to_csv_action[1:3])

print(' ******** parse_to_csv_action[1] = ' + parse_to_csv_action[1])

print(' ******** parse_to_csv_action[:1] = ' + parse_to_csv_action[:1])

print(' ******** parse_to_csv_action[:-1] = ' + parse_to_csv_action[:-1])

print(' ******** parse_to_csv_action[-1] = ' + parse_to_csv_action[-1])

print(' ******** parse_to_csv_action[-2] = ' + parse_to_csv_action[-2])

print(' ******** parse_to_csv_action[-2:] = ' + parse_to_csv_action[-2:])

print(' ******** parse_to_csv_action[:] = ' + parse_to_csv_action[:])

if (parse_to_csv_action[-1] == 'b'):
   print(' ******** ends with b')
else:
   print(' ******** does not end with b')

str2 = 'hello'

if ('el' in str2):
   print(' ************ el in str2')
else:
   print(' ************ el NOT in str2')

str_array = ['hello', 'world', 'bob']

for c in str_array:
  if ('el' in c):
     print(' ************ el in str_array, c = ' + c)
  else:
     print(' ************ el NOT in str_array, c = ' + c)

str3 = 'Pitch_x8205'

indx = str3.find('x')

print(' ********* index of x in str3 = ' + str(indx))

print(' ******** str3[indx+1:indx+5] = ' + str3[indx+1:indx+5])

print(' *********** str3[:-4] = ' + str3[:-4])

print(' *********** str3[:2] = ' + str3[:2])

# Find substring in a string
if ('82' in str3):
   print(' ********** 82 in str3')
else:
   print(' ********** 82 NOT in str3')

pos_inf = float("inf")

print(' ************ pos_inf = ' + str(pos_inf))

# Check if pos_inf is a numeric value that can be used in a math expression
if (pos_inf > 100000):
  print(' ********** Greater ' )
else:
  print(' ********** less ' )

# Superscript test (m/s^2)
print("m/s" + u"\u00B2")

str4 = 'Pitch_x8205'

if (str3 != str4):
   print(' str3 is NOT equal to str4')
else:
   print(' str3 is equal to str4')

qstr = QtCore.QString(str4)

print(' ************ qstr = ' + str(qstr))

str5 = ' Pitch x8205  '
print(' ************ str5.strip() = ' + str5.strip() + ', len(str5.strip()) = ' + str(len(str5.strip())))
