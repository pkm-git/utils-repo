import re
import operator
import os
import sys
import csv
import numpy

from PyQt4.QtCore import *
from PyQt4.QtGui import *

# from async_csv_table_model_thread import AsyncLoadCSVTableModel

def main_line(argv):
   in_file_name = None
   for i in range(len(argv)):
      print('**********  argv[i] = ' + argv[i]);
      if(argv[i] == '-i' and len(argv) > i+1):
        in_file_name = argv[i+1]
   # } for i in range(len(argv))..

   if (in_file_name != None):
      app = QApplication(sys.argv)

      w = MyWindow()
      w.show()
      
      w.processFile(in_file_name)
      
      app.exec_()
   # } if (in_file_name != None)..   
  
# def main():
   # app = QApplication(sys.argv)
   # w = MyWindow()
   # w.show()
   # sys.exit(app.exec_())

class MyWindow(QWidget):
   def __init__(self, *args):
      QWidget.__init__(self, *args)
      # QWidget.__init__(self)

      # create table
      # self.get_table_data()

      if (0):
         # col_name_array, csv_data, empty_cell_col_array = self.get_table_data(False)
         self.headers, self.tabledata = self.get_table_data(init_file_name)

         print(' ********** len(self.headers) = ' + str(len(self.headers)) + ' len(self.tabledata[0]) = ' + str(len(self.tabledata[0])))

         table = self.createTable()

         # layout
         layout = QVBoxLayout()
         layout.addWidget(table)
         self.setLayout(layout)
         
   def processFile(self, init_file_name):
   
      self.headers, self.tabledata = self.get_table_data(init_file_name)

      print(' ********** len(self.headers) = ' + str(len(self.headers)) + ' len(self.tabledata[0]) = ' + str(len(self.tabledata[0])))

      table = self.createTable()

      # layout
      layout = QVBoxLayout()
      layout.addWidget(table)
      self.setLayout(layout)
     
   def get_table_data(self, file_name_to_use):
      col_name_array = []
      csv_data = {}
      empty_cell_col_array = []

      csv_data_list_of_lists = []

      if (file_name_to_use != None):
         in_csvfile = open(file_name_to_use,'rUb')
         csvreader = csv.reader(in_csvfile, delimiter=',')

         determine_headers = False
         headers_found = False
         data_row_cnt = 0
         channel_names = []
         pos_inf = float("+inf")

         for row_item in csvreader:

            # determined that last row in CSV indicated data start (headers are in this row)
            if (determine_headers):
               self.n_data_columns = len(row_item)

               # Create a list of channel names from the headers
               for i in range(self.n_data_columns-1):
                  col_name_array.append(row_item[i])
                  csv_data[row_item[i]] = []

               # column headers have been found
               headers_found = True

               # headers no longer need to be determined
               determine_headers = False

            elif(headers_found):
               if (len(row_item) > 0):
                  try:
                     data_row_cnt = data_row_cnt + 1
		     
		     print(' ******* data_row_cnt: ' + str(data_row_cnt) + ', row_item[0] = ' + str(row_item[0]) + ', row_item[:-1] = ' + str(row_item[:-1]) + ', row_item[-1] = ' + str(row_item[-1]))
		     
                     csv_data_list_of_lists.append(row_item[:-1])

                     for i in range(self.n_data_columns-1):
                        col_name = col_name_array[i]
                        if (row_item[i] == ''):
                           if (col_name not in empty_cell_col_array):
                              empty_cell_col_array.append(col_name)
                           # } if (i not in empty_cell_col_array)..
                           csv_data[col_name].append(pos_inf)
                        else:
                           if ('lat' in col_name.lower() or 'lon' in col_name.lower()):
                              csv_data[col_name].append(numpy.double(row_item[i]))
                           else:
                              csv_data[col_name].append(float(row_item[i]))
                           # } if ('lat' in col_name.lower()..
                        # } if (row_item[i] != '')..
                     # } for i in range(self.n_data_columns-1)..
                  except ValueError as err:
                     print(' ******** ValueError: data_row_cnt = ' + str(data_row_cnt) + ', i = ' + str(i) + ' row_item[i] = ' + row_item[i] + ' Error Msg: {0}'.format(err))
                     sys.exit()
               # } if (len(row_item) > 0)..

            # this row is neither column headers nor data elements
            else:
               # test for DATA_START row (column headers to follow)
               # if (len(row_item) == 1 and row_item[0] == 'DATA_START'):
	       if (len(row_item) > 0 and row_item[0].strip() == 'DATA_START'):
                  determine_headers = True
            # } if (determine_headers == True)..
         # } for row_item in csvreader..
      # } if (self.init_file_name != None)..

      # return col_name_array, csv_data, empty_cell_col_array
      return col_name_array, csv_data_list_of_lists

   def createTable(self):
      # create the view
      tv = QTableView()

      # set the table model
      # # header = ['date', 'time', '', 'size', 'filename']
      # # tm = MyTableModel(self.tabledata, header, self)
      tm = MyTableModel(self.tabledata, self.headers, self)
      tv.setModel(tm)
      
      # lv = QListView()
      # lm = MyListModel(self.tabledata, self.headers, self)
      # lm = MyListModel(self.tabledata, self)
      # lv.setModel(lm)

      # set the minimum size
      tv.setMinimumSize(400, 300)
      # lv.setMinimumSize(400, 300)

      # hide grid
      # tv.setShowGrid(False)
      tv.setShowGrid(True)
      # lv.setShowGrid(True)

      # set the font
      font = QFont("Courier New", 8)
      tv.setFont(font)
      # lv.setFont(font)

      # hide vertical header
      vh = tv.verticalHeader()
      # vh = lv.verticalHeader()
      vh.setVisible(False)

      # set horizontal header properties
      hh = tv.horizontalHeader()
      # hh = lv.horizontalHeader()
      hh.setStretchLastSection(True)

      # set column width to fit contents
      tv.resizeColumnsToContents()

      # set row height
      nrows = len(self.tabledata)
      for row in xrange(nrows):
         # lv.setRowHeight(row, 18)
         tv.setRowHeight(row, 18)

      # enable sorting
      # tv.setSortingEnabled(True)
      tv.setSortingEnabled(False)

      return tv
      # return lv

   def get_table_data_from_dir_cmd(self):
      stdouterr = os.popen4("dir c:\\")[1].read()
      lines = stdouterr.splitlines()
      # row = lines[0]
      # print(' **** after splitlines: row = ' + str(row))

      lines = lines[5:]
      # row = lines[0]
      # print(' **** after lines[5:]: row = ' + str(row))

      lines = lines[:-2]
      # row = lines[0]
      # print(' **** after lines[:-2]: row = ' + str(row))

      self.tabledata = [re.split(r"\s+", line, 4)
                   for line in lines]

      # print(' ******* len(self.tabledata) = ' + str(len(self.tabledata)))

      i = 0
      for x in self.tabledata:
         # print(' ****** i = ' + str(i) + ' row = ' + str(x))
         print(' ****** i = ' + str(i) + ' row[0] = ' + str(x[0]) + ' row[1] = ' + str(x[1]) + ' row[2] = ' + str(x[2]))
         i = i + 1

# lm = MyListModel(self.tabledata, self.headers, self)

class MyListModel(QAbstractListModel): 
   def __init__(self, datain, parent=None): 
      """ datain: a list where each item is a row
      """
      QAbstractListModel.__init__(self, parent) 
      self.listdata = datain

   def rowCount(self, parent=QModelIndex()): 
      return len(self.listdata) 

   def data(self, index, role): 
      if index.isValid() and role == Qt.DisplayRole:
         return QVariant(self.listdata[index.row()])
      else: 
         return QVariant()
      # } if index.isValid() and..

class MyTableModel(QAbstractTableModel):
   def __init__(self, datain, headerdata, parent=None, *args):
      """ datain: a list of lists
          headerdata: a list of strings
      """
      QAbstractTableModel.__init__(self, parent, *args)
      self.arraydata = datain
      self.headerdata = headerdata

   def rowCount(self, parent):
      return len(self.arraydata)

   def columnCount(self, parent):
      return len(self.arraydata[0])

   def data(self, index, role):
      if not index.isValid():
         return QVariant()
      elif role != Qt.DisplayRole:
         return QVariant()
      return QVariant(self.arraydata[index.row()][index.column()])

   def headerData(self, col, orientation, role):
      # print(' ******** in headerData, col = ' + str(col))

      if orientation == Qt.Horizontal and role == Qt.DisplayRole:
         # print(' ********** orient = Horiz, col = ' + str(col))

         return QVariant(self.headerdata[col])
      return QVariant()

   def sort(self, Ncol, order):
      """Sort table by given column number.
      """
      self.emit(SIGNAL("layoutAboutToBeChanged()"))
      self.arraydata = sorted(self.arraydata, key=operator.itemgetter(Ncol))
      if order == Qt.DescendingOrder:
          self.arraydata.reverse()
      self.emit(SIGNAL("layoutChanged()"))

# if __name__ == "__main__":
   # main()

if(__name__ == "__main__"):
  main_line(sys.argv)

