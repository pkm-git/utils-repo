import re

str = "how much for the maple_syrup? - [$20.99]? That's ridiculous!!!"
tmp_str = str.strip().replace(" ", "_")
str_no_spl = re.sub(r'[^a-zA-Z0-9_.-]', r'', tmp_str)

print('  Orig str: ' + str + '\n  str_no_spl: ' + str_no_spl)

row_header = 'Lat [x8103]'
# tmp_channel_name = row_header.strip().replace(" ", "_")

row_header = row_header.strip().replace(" ", "_")

# All characters other than AlphaNumeric, _, -, and .: Replace with empty char:
row_hdr_no_spl = re.sub(r'[^a-zA-Z0-9_.-]', r'', row_header)

print(' *********** AFTER row_header = ' + row_hdr_no_spl)

command_line = 'python sensor_cloud_utils.py -d "' + 'OAPI00QKJTDKCM0R' + '" -s "' + 'GX4-45-2' + '" -k "' + 'db9d91a4d8b235d18612a306ae449bb04e3437a65532229c2fa5b0fb16eb2c00' + '" -r 100 -rt "HERTZ" -a pufmb -i "' + "U:\Lord\Python_HIL_Sim_From_File\Vehicle_Logs\2016_07_12\3DM-GX4-45 6236.46589 Data Log 7-19-2016 4.53.30 PM.bin" + '"'

print(' ******** command_line = ' + command_line)
