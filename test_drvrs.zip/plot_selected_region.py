from pyqtgraph.Qt import QtGui, QtCore
import numpy as np
import pyqtgraph as pg
#
app = QtGui.QApplication([])
#
# win = pg.GraphicsWindow()
win = pg.GraphicsLayoutWidget()

win.resize(1000, 600)
#
p1 = win.addPlot(title="Multiple curves")
p1.plot(np.random.normal(size=100), pen=(255, 0, 0), name="Red curve")
p1.plot(np.random.normal(size=110) + 5, pen=(0, 255, 0), name="Blue curve")
# LinearRegionItem
#
def updateRegion(window, viewRange):
    region = lr.getRegion()
    print region
#

regionBrush = pg.mkBrush('#5133E6')

# lr = pg.LinearRegionItem([10, 40], brush=regionBrush)
lr = pg.LinearRegionItem([10, 40])
lr.setZValue(-10)
p1.addItem(lr)
# p1.sigXRangeChanged.connect(updateRegion)

# lr2 = pg.LinearRegionItem([60, 80])
# lr2.setZValue(-10)
# p1.addItem(lr2)
# p1.sigXRangeChanged.connect(updateRegion)

p2 = win.addPlot(title="Copy of Multiple curves")
p2.plot(np.random.normal(size=100), pen=(255, 0, 0), name="Red curve")
p2.plot(np.random.normal(size=110) + 5, pen=(0, 255, 0), name="Blue curve")


#
if __name__ == '__main__':
    import sys
    if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
        QtGui.QApplication.instance().exec_()
