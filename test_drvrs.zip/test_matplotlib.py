import numpy as np
from matplotlib import pyplot as plt

x = np.linspace(1, 10, 40)
y = x**2

fig = plt.figure()
ax = fig.add_subplot(111)
params = {'mathtext.default': 'regular' }
plt.rcParams.update(params)
ax.set_xlabel('$x_{my text}$')
ax.set_ylabel('$y_i$')
ax.plot(x, y)
ax.grid()
plt.show()
