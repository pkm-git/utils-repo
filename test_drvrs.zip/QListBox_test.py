import sys
from PyQt4 import QtGui, QtCore

class Example(QtGui.QWidget):

    def __init__(self):
        super(Example, self).__init__()

        self.initUI()

    def initUI(self):

        # self.lbl = QtGui.QLabel("Ubuntu", self)
	self.lbl = QtGui.QLabel(self)

        # list = QtGui.QListBox(self)
	# list = QtGui.QListView(self)
	self.list = QtGui.QListWidget(self)
        self.list.addItem("Ubuntu")
        self.list.addItem("Mandriva")
        self.list.addItem("Fedora")
        self.list.addItem("Red Hat")
        self.list.addItem("Gentoo")

        # self.list.move(50, 50)
        # self.lbl.move(50, 150)
        self.list.move(50, 100)
        self.lbl.move(50, 40)

        # list.activated[str].connect(self.onActivated)
	self.list.clicked.connect(self.onActivated)
	# list.currentIndexChanged.connect(self.onActivated)
	
        self.setGeometry(300, 300, 300, 200)
        self.setWindowTitle('QtGui.QListBox')
        self.show()

    # def onActivated(self, text):
    def onActivated(self, b):

        # self.lbl.setText(text)
	self.lbl.setText(self.list.currentItem().text())
	# self.lbl.setText(str(b))
	
        self.lbl.adjustSize()

def main():

    app = QtGui.QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
