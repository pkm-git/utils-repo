import numpy

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]

ambient_pressure = 0
llh_ht = 978
altitude_prev = 0
altitude = 0

print(' *************** altitude_array[2] = ' + str(altitude_array[2]))

# print(' *********** altitude_array.index(2) = ' + str(altitude_array.index(2)))

ekf_default_cols_seq_array = ["8211", "8210", "8201", "8208", "8202", "8209", "8205", "820A", "8203", "8212", "8207", "820C", "8217", "8219", "8206", "820B", "8216", "8218", "820D", "821C", "820E", "8213", "820F", "8214", "8215", "8220", "8221", "8230", "8231", "8204", "8227", "821A", "821B", "8223", "8224", "8225", "8228", "8226", "8229", "822A", "822B", "822C", "822D"]

print(' *********** ekf_default_cols_seq_array.index("8208") = ' + str(ekf_default_cols_seq_array.index("8208")))

imu_default_cols_dict = {"8012":1, "8004":2, "8005":3, "8007":4, "8008":5, "8006":6, "8017":7, "8009":8, "800A":9, "800C":10, "8010":11, "8011":12}

key_from_value = imu_default_cols_dict.keys()[imu_default_cols_dict.values().index(4)]

print(' ************ key_from_value for value of 4 is: ' + key_from_value)

for altitude_array_index in range(len(altitude_array[0:4])):
   altitude = numpy.int32(altitude_array[altitude_array_index])
   print(' *********** altitude_array_index = ' + str(altitude_array_index) + ' altitude = ' + str(altitude))


