# import time, math
import math
import calendar
import sys

# import datetime
from datetime import datetime
# from datetime import *
# from time import localtime
from time import *

current_time = datetime.now()
local_time = localtime()

# tz = time.timezone()
tz = timezone

print(' ******** local date/time: ' + str(local_time) + ' ' + str(tz) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')

utc_now = datetime.utcnow()

str_date_now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')

print(' ********** utc_now = ' + str(utc_now) + '\nstr_date_now = ' + str_date_now)

# utc_now_posix_timestamp = time.mktime(datetime.utcnow().utctimetuple())
utc_now_posix_timestamp = mktime(datetime.utcnow().utctimetuple())

# 1472 505 338

# utc_now_posix_timestamp = calendar.timegm(datetime.utcnow())

print(' ******* utc_now_posix_timestamp = ' + str(utc_now_posix_timestamp))

# print(' ********** time.mktime(utc_now) = ' + str(time.mktime(utc_now)))
# print('*********** utc_now.timestamp() = ' + str(utc_now.timestamp()))

# x = time.gmtime(time.time())
x = gmtime(time())
y = calendar.timegm(x)

# 1472 487 338

print(' ******** x = ' + str(x) + ', y = ' + str(y) )

# x = time.gmtime(utc_now)
# y = calendar.timegm(utc_now)

# print(' ******** y = calendar.timegm(utc_now) = ' + str(y) )

y = calendar.timegm(datetime.utcnow().utctimetuple())

print(' ******** y = calendar.timegm(datetime.utcnow().utctimetuple()) = ' + str(y) )

# x = time.gmtime(y)
# print(' *********** x = ' + str(x))

y = calendar.timegm(datetime.now().utctimetuple())

print(' ******** y = calendar.timegm(datetime.now().utctimetuple()) = ' + str(y) )

time1 = datetime(2016,6,17,15,0,0)

# tmktime = time.mktime(time1.utctimetuple())
tmktime = mktime(time1.utctimetuple())

# ts1 = time.mktime(time1.utctimetuple()) * 1000000000
ts1 = mktime(time1.utctimetuple()) * 1000000000
ts2 = ts1 + (1000000000)
ts3 = ts2 + 1000000000
data = [(int(ts1), 55.5), (int(ts2), 15), (int(ts3), 25.5)]

print('*********** time1 = ' + str(time1) + '\ntmktime = ' + str(tmktime) + '\nts1 = ' + str(ts1) + '\ntime1.utctimetuple() = ' + str(time1.utctimetuple()))

dateStr = '2016-06-17T20:46:12Z'
s = datetime.strptime(dateStr, '%Y-%m-%dT%H:%M:%SZ')

print(' ********* strptime s = ' + str(s))

# print(' ********* datetime.time = ' + str(datetime.time()))

# print(' ********* time.time() = ' + str(time.time()))
print(' ********* time() = ' + str(time()))

# print(' ********* time.gmtime(time.time()) = ' + str(time.gmtime(time.time())))
print(' ********* gmtime(time()) = ' + str(gmtime(time())))

# x = time.gmtime(time.time())
x = gmtime(time())
y = calendar.timegm(x)

print(' ******** x = ' + str(x) + ', y = ' + str(y) )

# print(' ********* date.fromtimestamp(time.time()) = ' + str(date.fromtimestamp(time.time())))

# print(' ********* time.clock() = ' + str(time.clock()))

gpsEpoch = (1980, 1, 6, 0, 0, 0)

print(' ********* gpsEpoch = ' + str(gpsEpoch))

aprilFirst = datetime(2012, 04, 01, 0, 0)

z = calendar.timegm(aprilFirst.timetuple())

print(' ********* z = ' + str(z))

zdiff = (datetime(2012,04,01,0,0,0) - datetime(1970,1,1,0,0,0)).total_seconds()

print(' ********* zdiff = ' + str(zdiff))

print(' ********* clock() = ' + str(clock()))
