import os
import math
import sys
import platform
# import numpy

print('********* sys.maxsize method: ')
is_64bits = sys.maxsize > 2**32
print(' ********** is_64bits: ' + str(is_64bits))

print('********* platform.architecture method: ')
print(platform.architecture()[0])
#'32bit'

print (' *********** struct.calcsize method: ********** ')
import struct;
print struct.calcsize("P") * 8

print(' ********** sys.maxsize = ' + str(sys.maxsize))

print(' ********** sys.maxint = ' + str(sys.maxint))


