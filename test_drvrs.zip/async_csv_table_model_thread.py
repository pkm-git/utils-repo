import sys
import threading       #import thread library
import StringIO
from time import time  #import time library
from time import sleep           #sleep
# from CSV_TableModel_test import *

from PyQt4.QtCore import *
from PyQt4.QtGui import *

class MyTimer(QTimer):
   # def __init__(self, my_controller_obj):
   def __init__(self):
      super(MyTimer, self).__init__()
      self.step = 0
      # self.my_controller_obj = my_controller_obj
      self.timeout.connect(self.tick)
      print(' ********** MyTimer contr over ********** ')
      
   def tick(self):
      self.step += 1
      print('********** TICK: Time elapsed: ' + str(self.step) + ' sec')
      # if (self.step % 2 == 0 and self.win_obj.done):
      # if (self.my_controller_obj.done):
         # print(' ******** step = ' + str(self.step) + ', my_controller_obj is DONE **********')
         # self.stop()
   
   def start(self, timeout):
      super(MyTimer, self).start(timeout)
      print(' ********** MyTimer start over ********** ')

   def stop(self):
      super(MyTimer, self).stop()
      print(' ********** MyTimer stop over ********** ')

class MyBasicTimer(QBasicTimer):
   # def __init__(self, my_controller_obj):
   def __init__(self):
      super(MyBasicTimer, self).__init__()
      self.step = 0
      # self.my_controller_obj = my_controller_obj
      # self.timeout.connect(self.tick)
      print(' ********** MyBasicTimer contr over ********** ')
      
   # def tick(self):
      # self.step += 1
      # print('********** TICK: Time elapsed: ' + str(self.step) + ' sec')
      # # if (self.step % 2 == 0 and self.win_obj.done):
      # if (self.my_controller_obj.done):
         # print(' ******** step = ' + str(self.step) + ', my_controller_obj is DONE **********')
         # self.stop()
   
   def start(self, timeout, obj):
      print(' ********** MyBasicTimer will call super start ********** ')
      super(MyBasicTimer, self).start(timeout, obj)
      print(' ********** MyBasicTimer start over ********** ')

   def stop(self):
      super(MyBasicTimer, self).stop()
      print(' ********** MyBasicTimer stop over ********** ')
      
   # def timerEvent(self, e):
      # print('********** MyBasicTimer TimerEvent: Time elapsed: ' + str(self.step) + ' sec')

      # if (self.my_controller_obj.done):
         # self.stop()
         # return

      # self.step = self.step + 1

      # print('********** MyBasicTimer TimerEvent: Time elapsed: ' + str(self.step) + ' sec')

#Class to asynchronously load CSV Table Model
# class AsyncLoadCSVTableModel(threading.Thread):
class AsyncLoadCSVTableModel(QThread):
   """Thread Object for loading CSV Table Model """
   # def __init__(self, csv_table_model_object, timeout = 0.001):
   # def __init__(self, csv_table_model_object):
   def __init__(self):
      """Initialize the AsyncLoadSensorList Object"""
      # threading.Thread.__init__(self)
      super(AsyncLoadCSVTableModel, self).__init__()
      # self.csv_table_model_object = csv_table_model_object
      # self.timeout = timeout
      self._stop = False
      self.run_step = 0
      self.timer = MyTimer()
   
   def start(self):
      print(' *********** AsyncLoadCSVTableModel::start(): ')
      # self.timer = MyTimer()
      # timer.timeout.connect(self.tick)
      # self.timer.start(10)
   
   def stop(self):
      """Stop thread loop"""
      print(' *********** AsyncLoadCSVTableModel::stop(): ')
      self._stop = True
      # self.timer.stop()

   def startTimer(self):
      print(' *********** AsyncLoadCSVTableModel::startTimer(): ')
      self.timer.start(1000)

   def stopTimer(self):
      print(' *********** AsyncLoadCSVTableModel::stopTimer(): ')
      self.timer.stop()

   def run(self):
      print(' *********** AsyncLoadCSVTableModel::run(): ')
      while(not self._stop):
         # if (self.csv_table_model_object.done):
            # self.stop()
         sleep(1)
         self.run_step += 1
         print(' *********** AsyncLoadCSVTableModel: run(): Time elapsed: ' + str(self.run_step) + ' sec')
      # } while(True).. 
