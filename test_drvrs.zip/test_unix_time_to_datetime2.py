import calendar, pytz, sys

from datetime import datetime

import dateutil.parser

def getDateTimeFromISO8601String(s):
   d = dateutil.parser.parse(s)
   return d
   
# Convert a unix time u to a datetime object d, and vice versa

NBR_OF_LEAP_SECONDS = 17 # (as of July 2016)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800

def dt(u):
   # return datetime.datetime.utcfromtimestamp(u)
   return datetime.utcfromtimestamp(u)

def ut(d):
   return calendar.timegm(d.timetuple())

def main_line(argv):

   # print(' ********* Now in ISOFormat: ' + datetime.datetime.now(pytz.utc).isoformat())
   print(' ********* Now in ISOFormat: ' + datetime.now(pytz.utc).isoformat())

   # '2012-02-17T11:58:44.789024+00:00'

   # print(' ********* Now (Eastern Timezone) in ISOFormat: ' + datetime.datetime.now(pytz.timezone('US/Eastern')).isoformat())
   print(' ********* Now (Eastern Timezone) in ISOFormat: ' + datetime.now(pytz.timezone('US/Eastern')).isoformat())
   
   # '2012-02-17T13:00:10.885743+01:00'

   gps_week = 1922
   gps_tow = 492542.2502

   gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
   utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

   print(' ********* gps_sec_from_gps_epoch = ' + str(gps_sec_from_gps_epoch))
   print(' ********* utc_sec_from_utc_epoch = ' + str(utc_sec_from_utc_epoch))
   
   datetime_from_unix = dt(utc_sec_from_utc_epoch)
   
   print(' ********* datetime from unix timestamp = ' + str(datetime_from_unix))
   print(' ********* datetime from unix timestamp isoformat = ' + str(datetime_from_unix.isoformat()))
   
   # datetime_from_isoformat = datetime.strptime(datetime_from_unix.isoformat(), '%Y-%m-%d %H:%M:%S.%f')
   datetime_from_isoformat = getDateTimeFromISO8601String(datetime_from_unix.isoformat())
   
   print(' ********* datetime_from_isoformat = ' + str(datetime_from_isoformat))
   
   unix_from_datetime = ut(datetime_from_unix)
   print(' ********* unix from datetime = ' + str(unix_from_datetime))
   
   
if(__name__ == "__main__"):
  main_line(sys.argv)

