import math
import numpy

# grnd_trace_angle = math.degrees(math.asin(-0.5))

# print(' ***** grnd_trace_angle: ' + str(grnd_trace_angle))

ekf_vned_N = -2.27999997
ekf_vned_E = 5.73999977

# ekf_vned_N = 0.01057493
# ekf_vned_E = -0.00435031

vel_NE_mag = math.sqrt(math.pow(ekf_vned_N, 2) + math.pow(ekf_vned_E, 2))

grnd_trace_angle = math.degrees(math.acos(ekf_vned_N/vel_NE_mag))

print(' **** vel_NE_mag = ' + str(vel_NE_mag) + ', grnd_trace_angle = ' + str(grnd_trace_angle)) 
# print('''**** vel_NE_mag, grnd_trace_angle''') 

euler_yaw_deg = 1.42004667438
euler_yaw_rad = math.radians(euler_yaw_deg)
euler_yaw_back_to_deg = math.degrees(euler_yaw_rad)

print(' **** ORIG euler_yaw_deg: ' + str(euler_yaw_deg) + ', euler_yaw_rad = ' + str(euler_yaw_rad) + ', back to deg: ' + str(euler_yaw_back_to_deg))

