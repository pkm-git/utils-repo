

ekf_valid_packet_field_desc_array = ["8211", "8210", "8201", "8208", "8202", "8209", "8205", "820A", "8203", "8212", "8207", "820C", "8217", "8219", "8206", "820B", "8216", "8218", "820D", "821C", "820E", "8213", "820F", "8214", "8215", "8220", "8221", "8230", "8231", "8204", "8227", "821A", "821B", "8223", "8224", "8225", "8228", "8226", "8229", "822A", "822B", "822C", "822D"]

indx = ekf_valid_packet_field_desc_array.index("8207")

print(' ********* index of 8208 is: ' + str(indx))

if ("8208" in ekf_valid_packet_field_desc_array.lower()):
   print(' ***** FOUND 820 IN ekf_valid_packet_field_desc_array')
