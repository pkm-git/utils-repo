from collections import OrderedDict

my_dictionary = OrderedDict()
my_dictionary['foo']=3
my_dictionary['del']=8
my_dictionary['aol']=1

# my_dictionary
# OrderedDict([('foo', 3), ('aol', 1)])
for k in my_dictionary.keys():
   print(' ******** key = ' + k + ', value: ' + str(my_dictionary[k]))

my_num_dictionary = OrderedDict()
# my_num_dictionary = {}
my_num_dictionary[7]=3
my_num_dictionary[5]=8
my_num_dictionary[12]=1

for k in my_num_dictionary.keys():
   print(' ******** num key = ' + str(k) + ', num value: ' + str(my_num_dictionary[k]))

print('\n******* Approach 1 ********** ')
for k in sorted(my_num_dictionary):
   print ('***** k: ' + str(k) + ', value: ' + str(my_num_dictionary[k]))

print('\n******* Approach 2 ********** ')
for k, v in sorted(my_num_dictionary.items()):
   print ('***** k: ' + str(k) + ', v: ' + str(v))


