python -c "import math; rem_360 = math.floor(abs(-3600.01)) % 360; print '***** rem_360 = ' + str(rem_360) + ' abs(rem_360) = ' + str(abs(rem_360))"

python -c "import math; gyro_x = 449.9999064; tmp = math.floor(gyro_x); tmp_frac = gyro_x - tmp; gyro_x = tmp % 360; print '***** tmp = ' + str(tmp) + ' tmp_frac = ' + str(tmp_frac) + ' gyro_x = ' + str(gyro_x + tmp_frac)"

python -c "import math; orig_gyro_x = -450.2004416; tmp = int(math.floor(abs(orig_gyro_x))); tmp_frac = abs(orig_gyro_x) - tmp; gyro_x = tmp % 360 + tmp_frac; print '***** tmp = ' + str(tmp) + ' tmp_frac = ' + str(tmp_frac) + ' gyro_x = ' + str(gyro_x)"

python -c "import math; orig_gyro_x = -3599.002689; tmp = int(round((orig_gyro_x))); tmp_frac = abs(orig_gyro_x) - tmp; gyro_x = tmp % 360 + tmp_frac; print '***** tmp = ' + str(tmp) + ' tmp_frac = ' + str(tmp_frac) + ' gyro_x = ' + str(gyro_x)"






