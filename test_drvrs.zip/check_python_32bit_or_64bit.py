import os
import math
import sys
import platform
import psutil
import numpy
import wx

print('********* sys.maxsize method: ')
is_64bits = sys.maxsize > 2**32
print(' ********** is_64bits: ' + str(is_64bits))

print('********* platform.architecture method: ')
print(platform.architecture()[0])
#'32bit'

print (' *********** struct.calcsize method: ********** ')
import struct;
print struct.calcsize("P") * 8

print(' ********** sys.maxsize = ' + str(sys.maxsize))

print(' ********** sys.maxint = ' + str(sys.maxint))

svmem_obj = psutil.virtual_memory()

print(" ********* psutil.virtual_memory(): " + str(svmem_obj))
print('***** svmem_obj.free: ' + str(svmem_obj.free) + ', svmem_obj.available: ' + str(svmem_obj.available))

# sswap_obj = psutil.swap_memory()

# print(" ********* psutil.swap_memory(): " + str(sswap_obj))

# l_array = os.popen('vm_stat').readlines()

# print(' ********* len(l_array) = ' + str(len(l_array)))

# for l in l_array:
   # print(" ************ l: " + l)

# avail_mem = 120 000 000
# avail_mem = numpy.uint64(0.7 * 120507898)
# avail_mem = numpy.uint64(0.7 * 80507898)
avail_mem = 1000000

# print(' ********* 0.7 * 80507898 = ' + str(0.7 * 80507898) + ', avail_mem: ' + str(avail_mem))

# file_size = 260000000
file_size = 5207112

result = numpy.float(file_size)/avail_mem

result_int = numpy.float(file_size)//avail_mem

result_int2 = int(numpy.float(file_size)/avail_mem)

result_ceil = int(math.ceil(numpy.float(file_size)/avail_mem))

rem = file_size % avail_mem

print('******** result (file_size/avail_mem) = ' + str(result) + ', result_int (file_size//avail_mem) = ' + str(result_int) + ', file_size/avail_mem = ' + str(file_size/avail_mem) + ', result_int2 (int(file_size/avail_mem)) = ' + str(result_int2) + ', result_ceil = ' + str(result_ceil) + ', rem = ' + str(rem))

ifloat = numpy.finfo(numpy.float)

print(' ********* float min: ' + str(ifloat.min) )
print(' ********* float max: ' + str(ifloat.max) )

curr_dir = os.getcwd()
print(' ************** curr_dir = ' + curr_dir)
