class IMU_8012_struct:
   def __init__(self):
      [self.imu_tow, self.imu_week, self.flags_80_12] = [0,0,0]

imu_format_dict_array = []

imu_format_dict = {}

imu_8012_struct = IMU_8012_struct()
tmp_imu_8012_struct = IMU_8012_struct()

for i in range(5):
   imu_format_dict = {}
   #  print(' ********* instantiated imu_format_dict = ' + str(imu_format_dict))
   
   imu_8012_struct = IMU_8012_struct()
   imu_8012_struct.imu_tow = i + 100.1
   print(' ************* i = ' + str(i) + ', adding imu_tow to dict = ' + str(imu_8012_struct.imu_tow))
   imu_format_dict["8012"] = imu_8012_struct
   imu_format_dict_array.append(imu_format_dict)

indx = 0

for idict in imu_format_dict_array:
   indx += 1
   tmp_imu_8012_struct = idict['8012']
   imu_tow = tmp_imu_8012_struct.imu_tow
   print(' ************* indx = ' + str(indx) + ' imu_tow from dict = ' + str(imu_tow))
   
   if ("8012" in idict.keys()):
      print(' ******* 8012 in idict ****** ')
   else:
      print(' ******* 8012 NOT in idict ****** ')


