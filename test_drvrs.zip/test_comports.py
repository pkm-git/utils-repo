import serial
import serial.tools.list_ports

ports = list(serial.tools.list_ports.comports())
for p in ports:
   print(' *********** comport: ' + str(p))
   
# for s in serial.tools.list_ports.comports():
# for s in serial.tools.list_ports:
  # print(' *********** comport: ' + s)

