for k in range(1, 5):
  print('******* k = ' + str(k))
  if (k % 1 == 0):
     print('******* Modulus is 0, at k = ' + str(k))
   
x = 0 % 1

print(' ****** 0 mod 1 = ' + str(x))


