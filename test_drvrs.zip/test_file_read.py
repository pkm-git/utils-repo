import os
import sys
from binascii import hexlify     #function to display hexadecimal bytes as ascii
from struct import * #import all objects and functions from the struct library

MIP_HEADER_SIZE = 4

try:
   in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2016_12_12/3DM-GX5-45 6251.59121 Data Log 11-30-2016 5.51.15 PM.bin'
   # in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2016_12_12/3DM-GX5-45 6251.00416 Data Log 10-28-2016 3.29.15 PM.bin'
   # in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2016_12_12/3DM-GX4-45 6236.21047 Data Log 12-12-2016 3.46.33 PM.bin'
   # in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2016_12_12/3DM-GX5-45 6251.59122 Data Log 12-7-2016 10.42.36 AM.bin'

   file_size = os.path.getsize(in_file_name)

   print(' ************ input file_size = ' + str(file_size))

   fin_bin = open(in_file_name, "rb")
   bytes_read = fin_bin.read();

   print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

   # for k in range(0, len(bytes_read)):
   k = 0
   while(k < len(bytes_read)):
      if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
         print(' ***** Found first [0x75 0x65] MIP pair at byte index: ' + str(k) + '\n')
         k_start = k;
         break;
      k = k + 1

   payload_size = 0
   packet_cnt = 0

   k = k_start

   ekf_total_packet_cnt = 0
   gps_total_packet_cnt = 0
   imu_packet_cnt = 0
   other_packet_cnt = 0

   packet_field_descr_found_array = []

   k_crossed = k_start

   # Look for beginning of a valid MIP packet (Bytes: 0x7565):
   # while (k < len(bytes_read)):
   # while (k < 120000000):
   while (k < 10000000):
      # if ((k-k_crossed) > 2000000):
         # k_crossed = k
         # cnt_10_MB_blocks += 1
         # print('******* Processed ' + str(cnt_10_MB_blocks) + ' blocks of 10 MB each')
         # print('******* Processed ' + str(cnt_10_MB_blocks) + ' blocks of 2 MB each')

      if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
         packet_cnt = packet_cnt + 1

         desc_set = hexlify( bytearray(bytes_read[k+2]) ).upper()
         [payload_size] = unpack('<B', bytearray(bytes_read[k+3]))
         packet_bytes = bytearray( bytes_read[k:k+payload_size+6] )

         # print('****** Packet Nbr: ' + str(packet_cnt) + ' Descriptor Set = ' + hexlify( bytearray(bytes_read[k+2]) ).upper() + ' Payload size = ' + str(payload_size) )

         # tmp_str = hexlify( bytearray(packet_bytes) ).upper()
         # print(' ****** desc_set = ' + str(desc_set) + ', payload_size = ' + str(payload_size) + ' and packet_bytes: '),
         # for i1 in range(0,len(tmp_str),2):
            # print(tmp_str[i1] + tmp_str[i1+1]),
         # print('\n')

         if (desc_set == '82'):
            ekf_total_packet_cnt = ekf_total_packet_cnt + 1
         elif (desc_set == '81'):
            gps_total_packet_cnt = gps_total_packet_cnt + 1
         elif (desc_set == '80'):
            imu_packet_cnt = imu_packet_cnt + 1
         else:
            other_packet_cnt = other_packet_cnt + 1

         j = k+MIP_HEADER_SIZE

         # Get all fields in the packet, and set attributes of appropriate format object:
         while(j < k+payload_size+4):
            [field_size] = unpack('<B', bytearray(bytes_read[j]))
            field_desc = hexlify( bytearray(bytes_read[j+1]) ).upper()
            field_bytes = bytes_read[j+2:j+field_size]
            packet_field_descr = desc_set + field_desc.upper()

            if (packet_field_descr not in packet_field_descr_found_array):
               print(' ****** k = ' + str(k) + ', packet_cnt = ' + str(packet_cnt) + ', found new packet_field_descr = ' + str(packet_field_descr))
               packet_field_descr_found_array.append(packet_field_descr)

            j = j + field_size
         # } while(j < k+payload_size+4)..

         k = k + payload_size + 6
      else:
         k = k + 1
      # } if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65')..
   # } while (k < len(bytes_read))..

   fin_bin.close()

except MemoryError as err:
   print(' ******** MemoryError: Error Msg: {0}'.format(err))
   fin_bin.close()
