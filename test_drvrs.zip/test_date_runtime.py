import numpy

str_start_utc = '03-14-2016 10:00:43.0 UTC'

runtime = 78.9

cntStr = 0
dateSplitStrings = str_start_utc.split('-')
for s in dateSplitStrings:
   if (cntStr == 0):
      month = int(s)
   elif (cntStr == 1):
      day = int(s)
   elif (cntStr == 2):
      year = int(s[0:4])
      timeStr = s[5:]
      timeSplitStrings = timeStr.split(':')
      cntTimeStr = 0
      for st in timeSplitStrings:
         if (cntTimeStr == 0):
            hr = int(st)
         elif (cntTimeStr == 1):
            min = int(st)
         elif (cntTimeStr == 2):
            sec = numpy.double(st[0:4])

         cntTimeStr = cntTimeStr + 1
      # }
   # }
   cntStr = cntStr + 1
# } for s in dateSplitStrings..

total_sec = 3600 * hr + 60 * min + sec

total_sec_minus_runtime = total_sec - runtime

new_hr = int(total_sec_minus_runtime / 3600)

new_min = int((total_sec_minus_runtime - new_hr * 3600) / 60)

new_sec = (total_sec_minus_runtime - new_hr * 3600 - new_min * 60) % 60

print('  str_start_utc:\t\t' + str_start_utc + '\n  runtime:\t\t\t' + str(runtime) + '\n  total_sec:\t\t\t' + str(total_sec) + '\n  total_sec_minus_runtime:\t' + str(total_sec_minus_runtime)
      + '\n  new_hr: \t\t\t' + str(new_hr) + '\n  new_min:\t\t\t' + str(new_min) + '\n  new_sec:\t\t\t' + str(new_sec))


