import sys
import serial
import numpy
import os
import struct
import platform

from PyQt4.QtCore import QT_VERSION_STR
from PyQt4.Qt import PYQT_VERSION_STR
from sip import SIP_VERSION_STR

print('**** Python exe is at: ' + str(sys.executable))

print('\n*** Qt version: ' + str(QT_VERSION_STR))
print('*** SIP version: ' + str(SIP_VERSION_STR))
print('*** PyQt version: ' + str(PYQT_VERSION_STR))

print '\n*** PySerial version: ' + serial.VERSION
print '*** Numpy version: ' + numpy.version.version

print '\nos.curdir: ' + os.curdir
print 'os.name: ' + os.name

# 32-bit or 64-bit Python?
print('\n***** sys.maxsize method: ')
is_64bits = sys.maxsize > 2**32
print(' ***** is_64bits: ' + str(is_64bits))

print('\n**** platform.architecture method: ')
print('  ' + str(platform.architecture()[0]))
#'32bit'

print ('\n****** struct.calcsize method: ********** ')
print '  ' + str(struct.calcsize("P") * 8)

print(' ***** sys.maxsize = ' + str(sys.maxsize))
print(' ***** sys.maxint = ' + str(sys.maxint))

# python --version  # 2.7.6


