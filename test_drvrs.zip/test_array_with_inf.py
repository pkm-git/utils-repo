import numpy

pos_inf = float("+inf")

# Create altitude array (in meters above sea level)
tow_array = [0, 4, 7, 10, 15, 20]

# Create ambient pressure array (in bar)
lat_array = [10.5, 12.3, pos_inf, pos_inf, 15.4, 23.7]

lat_array_indices = [i for i,x in enumerate(lat_array) if x !=pos_inf]

print(' ************ lat_array_indices: ************ ')

for i in lat_array_indices:
   print(i),

print('\n')
   
tow_array_values = [x for i,x in enumerate(tow_array) if i in lat_array_indices]

print(' ************ tow_array_values: ************ ')

for t in tow_array_values:
   print(t),

print('\n')

lat_array = [x for i,x in enumerate(lat_array) if x !=pos_inf]

print(' ************ lat_array after removing infs: ************ ')

for t in lat_array:
   print(t),

print('\n')
