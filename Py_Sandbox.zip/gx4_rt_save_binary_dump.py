import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder
from mip_parser import *         #local file should be in local folder

from time import sleep           #sleep
from time import time  #import time library
from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 # print("****** mip_parser_callback: callback_type = " + str(callback_type))
 # print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
  print('Time: ' + str(time()) + ', Time from start: ' + str(time() - start_time) + ', Valid Packet Found')

  #loop over fields in received valid packet
  for field in mip_get_next_field(packet_bytes):
   #if this field is an ack/nack output it to show the user
   # if (field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):  # 0xF1
     # print('field[1]: ' + str(field[1]) + ', Device response to command: (' + hex(field[2]).upper() + ') = '\
     #    + mip_ack_nacks[field[3]])
   # elif (field[1] == MIP_REPLY_DESC_ENABLE_DISABLE_STREAMING_DATA_VALUE): # 0x85
   if (field[1] == MIP_REPLY_DESC_ENABLE_DISABLE_STREAMING_DATA_VALUE): # 0x85
     mip_parser.set_streaming_enabled(field[3])
     # print('field[1]: ' + str(field[1]) + ', Device: (' + hex(field[2]).upper() + ') = ' + str(field[3]))
          # + mip_enable_disable[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

ComPort = serial.Serial('COM4')  # open the COM Port

# ComPort.baudrate = 921600      # set Baud rate
ComPort.baudrate = 12000000    # set Baud rate

ComPort.bytesize = 8             # Number of data bits = 8
ComPort.parity   = 'N'           # No parity
ComPort.stopbits = 1             # Number of Stop bits = 1

#Close port in case it was left open by other process
ComPort.close()

start_time = time()
print(' ************* GX4 read no async WITH START/STOP: start_time = ' + str(start_time) );

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

# Open specified port
ComPort.open()

#set up background process to update data buffers
# background_data_update = AsyncMIPDataUpdater(ComPort, mip_parser, 10000)

#start the response parsing thread
# background_data_update.start()

# print(' *************** INSIDE START STOP, will start background *************** ')

# read_filter_streaming_onoff_command = bytearray.fromhex('75650C04041102030411');
# ComPort.write(read_filter_streaming_onoff_command)

print(' *************** called read command, mip_parser.get_streaming_enabled() = ' + str(mip_parser.get_streaming_enabled()))

read_filter_streaming_onoff_command = bytearray.fromhex('75650C04041102030411');

# Check every second until filter streaming is enabled:
# while(mip_parser.get_streaming_enabled() == 0):

  # print(' *************** STREAMING DISABLED ************ ')
  # ComPort.write(read_filter_streaming_onoff_command)
  # sleep(1)

  # bytes_read = [];
  # # sleep(0.002)                         # Sleep [or inWaiting() doesn't give the correct value]

  # data_left = ComPort.inWaiting()        # Get the number of characters ready to be read
  # bytes_read += ComPort.read(data_left)  # Do the read and combine it with the first character

  # mip_parser.write(bytearray(bytes_read))
  # mip_parser.parse_input_buffer()

  # if (mip_parser.get_streaming_enabled() == 1):
    # break;

fout = open("U:\Lord\Python_HIL_Sim_From_File\GX4_RT_Port_Dump.txt", "w")
fout_bin = open("U:\Lord\Python_HIL_Sim_From_File\GX4_RT_Port_Dump.bin", "wb")

# Now do the main loop (as long as filter streaming remains enabled):
# while(mip_parser.get_streaming_enabled() == 1):
while(True):
  # print(' *************** INSIDE START STOP WHILE LOOP *************** ')

  # bytes_read = ComPort.read()          # Wait forever for anything
  bytes_read = [];
  # sleep(0.002)                         # Sleep [or inWaiting() doesn't give the correct value]

  data_left = ComPort.inWaiting()        # Get the number of characters ready to be read
  bytes_read += ComPort.read(data_left)  # Do the read and combine it with the first character

  # Now check if streaming is still enabled
  # ComPort.write(read_filter_streaming_onoff_command)
  # sleep(0.01)

  # streaming_enabled_bytes_read = [];

  # data_left = ComPort.inWaiting()        # Get the number of characters ready to be read
  # streaming_enabled_bytes_read += ComPort.read(data_left)  # Do the read and combine it with the first character

  # mip_parser.write(bytearray(streaming_enabled_bytes_read))
  # mip_parser.parse_input_buffer()

  # if (mip_parser.get_streaming_enabled() == 1):
    # fout.write(hexlify(bytearray(bytes_read)).upper())
    # print(' *************** MAIN WHILE LOOP, mip_parser.get_streaming_enabled() = ' + str(mip_parser.get_streaming_enabled()) + '\n')

  # Check if streaming is still enabled
  # ComPort.write(read_filter_streaming_onoff_command)

  fout.write(hexlify(bytearray(bytes_read)).upper())
  fout_bin.write(bytearray(bytes_read))

  fout.flush()
  fout_bin.flush()

#sleep while waiting for response
# sleep(1)

#stop background response parsing thread
# background_data_update.stop()

end_time = time()
print(' ************* GX4 read WITH START/STOP: end_time = ' + str(end_time) );

# print(' *************** LENGTH OF BYTES READ = ' + str(len(bytes_read)));

# while ComPort.inWaiting() > 0:
  # out += ComPort.read(1)
  # byte_reply = bytearray(ComPort.read(ComPort.inWaiting()))
  # data = ComPort.readline(ComPort.inWaiting())        # Wait and read data
  # print('********************** data: ' + hexlify(bytearray(data)).upper())
  # sleep(0.003)

#stop background response parsing thread
# background_data_update.stop()

ComPort.close()                  # Close the COM Port
fout.close()
