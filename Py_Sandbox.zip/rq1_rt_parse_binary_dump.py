import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder
from mip_parser import *         #local file should be in local folder

from time import sleep           #sleep
from time import time  #import time library

from struct import * #import all objects and functions from the struct library

import numpy

fout_bin = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump.bin", "rb")

fout_x = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_x.csv", "w")
fout_P = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_P.csv", "w")
fout_Q = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_Q.csv", "w")
fout_P_meas = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_P_meas.csv", "w")
fout_R = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_R.csv", "w")
fout_z = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_z.csv", "w")
fout_y = open("C:\MP\Lord\Python_HIL_Sim_From_File\RQ1_RT_Port_Dump_y.csv", "w")

bytes_read = fout_bin.read();

k_start = 0

print(' ********** len(bytes_read) = ' + str(len(bytes_read)) )

# packet_size = 437
packet_size = 438

for k in range(0, len(bytes_read)):
   # if (hexlify(bytearray(bytes_read[k])) == 'b5' and hexlify(bytearray(bytes_read[k+1])) == '62' and hexlify(bytearray(bytes_read[k+410])) == 'a6' and hexlify(bytearray(bytes_read[k+411])) == '72'):
   if (hexlify(bytearray(bytes_read[k])) == 'b5' and hexlify(bytearray(bytes_read[k+1])) == '62' and hexlify(bytearray(bytes_read[k+packet_size-2])) == 'a6' and hexlify(bytearray(bytes_read[k+(packet_size-1)])) == '72'):
      print(' ***** Found first B562 pair\n')
      k_start = k;
      break;

# for k in range(k_start,len(bytes_read)):

print(' ************ k_start = ' + str(k_start) )

bad_data = 0

i = 0
bad_packets = 0
k = k_start
# while (k < len(bytes_read) and i < 500):
while (k < len(bytes_read)):
  # print(hexlify(bytearray(bytes_read[k+2:k+6])).upper()) + '  '  + hexlify(bytearray(bytes_read[k+6:k+14])).upper()))

  # if (bad_data == 1 and bad_packets == 1 and k < 4850):
     # print('**** k = ' + str(k) + ', Bytes: ' + hexlify( bytearray(bytes_read[k]) ).upper() + '  '  + hexlify( bytearray(bytes_read[k+1]) ).upper()   )

  if (hexlify(bytearray(bytes_read[k])) == 'b5' and hexlify(bytearray(bytes_read[k+1])) == '62'):

     bad_data = 0

     # if (k+411 < len(bytes_read) and hexlify(bytearray(bytes_read[k+410])) == 'a6' and hexlify(bytearray(bytes_read[k+411])) == '72'):
     if (k+(packet_size-1) < len(bytes_read) and hexlify(bytearray(bytes_read[k+(packet_size-2)])) == 'a6' and hexlify(bytearray(bytes_read[k+(packet_size-1)])) == '72'):

        # [time_unpacked, tow_unpacked] = unpack('<id', bytearray( bytes_read[k+2:k+14] ) )
        [time_unpacked, state_unpacked, tow_unpacked, x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,x20,x21,x22,x23,x24,x25] = unpack('<iHdfffffffffffffffffffffffff', bytearray(bytes_read[k+2:k+(16+25*4)]) )
        [P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25] = unpack('<fffffffffffffffffffffffff', bytearray(bytes_read[k+116:k+216]) )
        [P_meas1,P_meas2,P_meas3,P_meas4,P_meas5,P_meas6,P_meas7,P_meas8,P_meas9,P_meas10,P_meas11,P_meas12,P_meas13,P_meas14,P_meas15,P_meas16,P_meas17,P_meas18,P_meas19,P_meas20,P21,P22,P23,P24,P25] = unpack('<fffffffffffffffffffffffff', bytearray(bytes_read[k+216:k+316]) )
        [Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10,Q11,Q12] = unpack('<ffffffffffff', bytearray(bytes_read[k+316:k+364]) )
        [z1,z2,z3,z4,z5,z6] = unpack('<ffffff', bytearray(bytes_read[k+364:k+388]) )
        [y1,y2,y3,y4,y5,y6] = unpack('<ffffff', bytearray(bytes_read[k+388:k+412]) )
        [R1,R2,R3,R4,R5,R6] = unpack('<ffffff', bytearray(bytes_read[k+412:k+436]) )

        print(' k = ' + str(k) + ' Global Time (ms): ' + str(time_unpacked) + ', state_unpacked = ' + str(state_unpacked) + ', TOW: ' + str(tow_unpacked) )

        fout_x.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,x20,x21,x22,x23,x24,x25) )
        fout_P.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25) )
        fout_P_meas.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,P_meas1,P_meas2,P_meas3,P_meas4,P_meas5,P_meas6,P_meas7,P_meas8,P_meas9,P_meas10,P_meas11,P_meas12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25) )
        fout_Q.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10,Q11,Q12) )
        fout_z.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,z1,z2,z3,z4,z5,z6) )
        fout_y.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,y1,y2,y3,y4,y5,y6) )
        fout_R.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,R1,R2,R3,R4,R5,R6) )

        i = i + 1
        # k = k + 412
        k = k + packet_size
     else:
        bad_data = 1
        bad_packets = bad_packets + 1
        print(' ******** k = ' + str(k) + ', Bad Data found')
        # k = k + 413
        k = k + packet_size + 1
  else:
     k = k + 1

# fout_bin.read(bytearray(bytes_read))

print ('****************** Nbr of valid packets = ' + str(i) + ', Nbr of bad packets = ' + str(bad_packets))

fout_bin.close()

fout_x.close()
fout_P.close()
fout_Q.close()
fout_R.close()
fout_P_meas.close()
fout_z.close()
fout_y.close()

