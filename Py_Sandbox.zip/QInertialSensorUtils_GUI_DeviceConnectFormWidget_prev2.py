# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os, sys
import ConfigParser
import serial.tools.list_ports

from datetime import datetime
from PyQt4 import QtCore, QtGui

from QInertialSensorUtils_GUI_CommonWidgets import *
from QInertialSensorUtils_GUI_MIP_Utils import *

from time import sleep         #sleep
from serial import *

BAUD_RATE = 12000000

# currentItemBackgroundColor = QtGui.QColor("#F8F3FC")
# currentItemBackgroundColor = QtGui.QColor("#DDC7F3")
currentItemBackgroundColor = QtGui.QColor("#ACCCFA")
# currentItemBackgroundColor.setNamedColor("#F8F3FC")

currentItemForegroundColor = QtGui.QColor("#257219")
# currentItemForegroundColor.setNamedColor("#F8F3FC")
# currentItemForegroundColor.setNamedColor("#333300")

currentForegroundBrush = QtGui.QBrush()
# currentForegroundBrush.setColor('w')
# currentForegroundBrush.setColor(currentItemForegroundColor)
currentForegroundBrush.setColor(QtCore.Qt.white)

# otherItemBackgroundColor = QtGui.QColor("#C9E0F5")
otherItemBackgroundColor = QtGui.QColor("#F2EBE3")
# otherItemBackgroundColor.setNamedColor("#F3FDFC")
 
otherItemForegroundColor = QtGui.QColor("#2C15A1")

otherForegroundBrush = QtGui.QBrush()
# otherForegroundBrush.setColor('w')
otherForegroundBrush.setColor(otherItemForegroundColor)

class MyDeviceConnectFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyDeviceConnectFormWidget, self).__init__(parent)
      self.parent_obj = parent
      self.deviceList = None
      # self.currentRow = 0
      # self.first_time_select = False
      
      self.get_device_info_command = bytearray.fromhex('756501020203E2C8')
      
      self.declare_spaces()
      
      # self.setFixedSize(550,250)
      # self.setFixedSize(550,200)
      self.setFixedSize(600,175)
      
      # self.setStyleSheet("background-color: #CCE5FF;");
      
      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyDeviceConnectFormWidget window"

      super(MyDeviceConnectFormWidget, self).closeEvent(event)

   def __controls(self):
      self.lbl_title = QtGui.QLabel("Device Connect Form")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(80)
      self.lbl_title.setFixedHeight(25)
      
      print('****************************************************************************')
      print(' ****** WILL CALL REFRESH METHOD FROM INIT ************ ')
      print('****************************************************************************')

      self.loadDeviceList()
     
   def loadDeviceList(self):

      print('****************************************************************************')
      print(' ****** IN REFRESH METHOD ************ ')
      print('****************************************************************************')
      
      self.deviceList = QtGui.QListWidget(self)
      
      list = serial.tools.list_ports.comports()
      
      ComPort = None
      bytes_read = bytearray()
      
      port_obj = comp_port_data_struct()
      port_obj.model_name = 'Model Name'
      port_obj.serial_nbr = 'Serial Number'
      port_obj.fw_version = 'FW Ver'
      port_obj.model_nbr = 'Model Number'
      port_obj.options = 'Options'
      port_obj.port_nbr = 'COM'
      
      str_port = '{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}'.format('Model Name', 'Serial Nbr', 'FW Ver', 'Model Nbr', 'Options', 'COM', 'Status')
      
      item = MyListWidgetItem(str_port, port_obj)
      
      self.deviceList.addItem(item)
      
      # item.setStyleSheet("background-color: #CCE5FF; font-weight: bold;");
      # item.setBackgroundColor(QtGui.QColor("#D6D2F7"))
      # item.setBackgroundColor(QtGui.QColor("#1E1380")) # Dark blue
      # item.setBackgroundColor(QtGui.QColor("#305812")) # Dark green
      # item.setBackgroundColor(QtGui.QColor("#2D5111")) # Very Dark green
      # item.setBackgroundColor(QtGui.QColor("#76985B")) # Light green
      # item.setBackgroundColor(QtGui.QColor("#F2CFC0")) # Light orange
      # item.setBackgroundColor(QtGui.QColor("#F5B39F")) # Light orange
      # item.setBackgroundColor(QtGui.QColor("#ACE1FF")) # Light blue
      item.setBackgroundColor(QtGui.QColor("#B7DFF6")) # Light dull blue
      
      currentForegroundBrush = QtGui.QBrush()
      # currentForegroundBrush.setColor(QtCore.Qt.white)
      currentForegroundBrush.setColor(QtCore.Qt.black)
      # currentForegroundBrush.setColor(currentItemForegroundColor)
      
      item.setForeground(currentForegroundBrush)
      
      self.read_current_imu_streaming_command = bytearray.fromhex(   '75650C0404110201020F');
      self.read_current_gps_streaming_command = bytearray.fromhex(   '75650C04041102020310');
      self.read_current_filter_streaming_command = bytearray.fromhex('75650C04041102030411');
     
      for element in list:
         # port_name = element.device.text()
         port_name = element.device
 
         port_nbr = port_name.replace('COM', '')
  
         print(' **** port_name = ' + str(port_name) + ', port_nbr = ' + str(port_nbr))
 
         if (ComPort != None):
            ComPort.close()
         # } if (ComPort != None)..
 
         try:
            ComPort = Serial(port_name, BAUD_RATE)  # open the COM Port
    
            ComPort.bytesize = 8             # Number of data bits = 8
            ComPort.parity   = 'N'           # No parity
            ComPort.stopbits = 1             # Number of Stop bits = 1

            # Close port in case it was left open by other process
            ComPort.close()
    
            # Open specified port
            ComPort.open()
            
            ComPort.reset_input_buffer()
    
            # Send 'Get Device Info' command
            print(' ****** Will send get_device_info_command **** ')
            ComPort.write(self.get_device_info_command)
    
            # In the sleep call below, if 0.02 is used, it gets GX5-45 but not GX4-45.
            # With 0.03, it gets both.
            sleep(0.03) 
            
            data_left = ComPort.in_waiting    # Get the number of characters ready to be read
        
            print(' ****** data_left = ' + str(data_left))
    
            if (data_left > 0):
               bytes_read = ComPort.read(data_left)
               if (bytes_read == None):
                  print(' ****** bytes_read is None ****** ')
               else:  
                  print(' ***** len(bytes_read) = ' + str(len(bytes_read)))
       
                  command_echo, error_code, fw_version, model_name, model_nbr, serial_nbr, options = parse_mip_packet(bytes_read, CMD_STREAM)
                  
                  print(' **** model_name: ' + model_name)
                  print(' **** serial_nbr: ' + serial_nbr)
                  print(' **** fw_version: ' + str(fw_version))
                  print(' **** model_nbr: ' + model_nbr)
                  print(' **** port_nbr: ' + port_nbr)
                  # print(' **** status: ' + status)
  
                  # str_filter_status = get_filter_status(ComPort)
                  # str_filter_status = 'Not Connected'
                  str_filter_status = 'Idle'
       
                  str_port = '{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}'.format(model_name.strip(), serial_nbr.strip(), str(fw_version), model_nbr.strip(), options.strip(), port_nbr.strip(), str_filter_status)
  
                  port_obj = comp_port_data_struct()
                  port_obj.ComPort = ComPort
                  port_obj.port_name = port_name
                  port_obj.port_baud = BAUD_RATE
                  port_obj.model_name = model_name
                  port_obj.serial_nbr = serial_nbr
                  port_obj.fw_version = fw_version
                  port_obj.model_nbr = model_nbr
                  port_obj.options = options
                  port_obj.port_nbr = port_nbr
                  port_obj.filter_status = str_filter_status
  
                  item = MyListWidgetItem(str_port, port_obj)   
  
                  self.deviceList.addItem(item)
               # } if (bytes_read == None)..  
            # } if (data_left > 0)..
    
            ComPort.close()
    
         except SerialException as err:
            print(" **** SerialException: Port: " + port_name + ", Error Msg: {0}".format(err))
         # } try..
      
      # } for element in list..

      self.device_array = []
      for index in xrange(self.deviceList.count()):
         self.device_array.append(self.deviceList.item(index))
      # } for index in..

      self.deviceList.clicked.connect(self.onDeviceSelect)

   def onDeviceSelect(self):
      d_curr = self.deviceList.currentItem()
      
      # Use values from current port row object to set state of streaming and record buttons
      if (d_curr.port_obj.waiting_to_rec):
         self.parent_obj.start_stop_recording_button.setState(-1)
      else:
         self.parent_obj.start_stop_recording_button.setState(d_curr.port_obj.recording_on)
 
         if (d_curr.port_obj.recording_on):
            self.parent_obj.edt_filename.setReadOnly(False)
         # } if (d_curr.port_obj.recording_on)..
    
      # } if (d_curr.port_obj.waiting_to_rec)..
      
      self.parent_obj.start_stop_streaming_button.setState(d_curr.port_obj.streaming_on)
      self.parent_obj.edt_filename.setText(d_curr.port_obj.bin_filename)
      
      self.parent_obj.start_stop_streaming_button.switchIcon()
      self.parent_obj.start_stop_recording_button.switchIcon()
      
      cnt = 0
      for d in self.device_array:
         cnt += 1
 
         # Skip the header item
         if (cnt > 1):
            if (d != self.deviceList.currentItem()):
               d.setBackgroundColor(otherItemBackgroundColor)
               d.setForeground(otherForegroundBrush)
            else:
               # d.setBackgroundColor(currentItemBackgroundColor)
               d.setBackgroundColor(QtGui.QColor("#1E1380")) # Dark blue
               d.setForeground(currentForegroundBrush)
       
               if (d.port_obj != None):
                  default_filename = get_filename(d.port_obj.model_name.strip(), d.port_obj.serial_nbr.strip())
                  self.parent_obj.edt_filename.setText(default_filename)
                  d.port_obj.bin_filename = default_filename
               # } if (d.port_obj != None)..  
            # } if (d != self.deviceList.currentItem())..
         # } if (cnt > 1)..   
      # } for d in self.device_array..
   
   def updateStreamStatus(self, item, b, b_secondary = None):

      print(' ************************************************************************************** ')
      print(' ***** in updateStreamStatus: INITIAL status = ' + item.port_obj.filter_status) 
      print(' ************************************************************************************** ')
      
      str_filter_status = ''
      
      # print('**** Button type = ' + str(b.getType()) + ', state = ' + str(b.getState()) + ', str_filter_status_prev = ' + str_filter_status_prev)
      
      if (b.getState() == 0):
         if (b.getType() == TYPE_STREAM_BUTTON):
            # str_filter_status = 'Not Connected'
            str_filter_status = 'Idle'
         elif (b_secondary != None and b_secondary.getState()):
            str_filter_status = 'Streaming Data'
         else:
            str_filter_status = 'Idle'
         # } if (b.getType() == TYPE_STREAM_BUTTON)..
      else:
         if (b.getType() == TYPE_STREAM_BUTTON):
            if (item.port_obj.filter_status == 'Waiting to Record'):
               str_filter_status = 'Recording Data'
            else:
               str_filter_status = 'Streaming Data'
            # } if (item.port_obj.filter_status ==..   
         elif (b.getType() == TYPE_RECORD_BUTTON):
            if (b.getState() == -1):
               str_filter_status = 'Waiting to Record'
            else:
               str_filter_status = 'Recording Data'
            # } if (b.getState() == -1)..   
         # } if (b.getType() == TYPE_STREAM_BUTTON)..
      # } if (b.getState() == 0)..
      
      item.port_obj.filter_status = str_filter_status
      item.setText(item.port_obj.toString())
      
      print(' ************************************************************************************** ')
      print(' ***** in updateStreamStatus: FINAL status = ' + item.port_obj.filter_status)
      print(' ************************************************************************************** ')
      
   def __layout(self):

      self.vDeviceListBox = QtGui.QVBoxLayout()
      self.vDeviceListBox.addWidget(self.deviceList)

      self.setLayout(self.vDeviceListBox)

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(60)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(90)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(110)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.lbl_space_resizable_filler = QtGui.QLabel()
      self.lbl_space_resizable_filler.setFixedWidth(65)
      self.lbl_space_resizable_filler.setFixedHeight(25)

      self.lbl_space_resizable_filler2 = QtGui.QLabel()
      self.lbl_space_resizable_filler2.setFixedWidth(15)
      self.lbl_space_resizable_filler2.setFixedHeight(25)

      self.lbl_space_resizable_fillerFWBox = QtGui.QLabel()
      self.lbl_space_resizable_fillerFWBox.setFixedWidth(2)
      self.lbl_space_resizable_fillerFWBox.setFixedHeight(25)
      
      self.lbl_space_resizable_filler3 = QtGui.QLabel()
      self.lbl_space_resizable_filler3.setFixedWidth(75)
      self.lbl_space_resizable_filler3.setFixedHeight(5)


