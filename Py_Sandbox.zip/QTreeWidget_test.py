import sys
from PyQt4 import QtGui, QtCore

class My_QTreeWidget(QtGui.QTreeWidget):
    def __init__(self):
       super(My_QTreeWidget, self).__init__()
       self.initUI()

    def initUI(self):
       d = { 'key1': 'value1',
             'key2': 'value2',
             'key3': [1,2,3, { 1: 3, 7 : 9}],
             'key4': object(),
             'key5': { 'another key1' : 'another value1',
                       'another key2' : 'another value2'} }

       # widget = QtGui.QTreeWidget()
       # fill_widget(widget, d)
       # widget.show()

       # widget = QtGui.QTreeWidget()
       self.fill_widget(d)
       self.show()

    def fill_item(self, item, value):
       # item.setExpanded(True)
       item.setExpanded(False)
       if type(value) is dict:
         for key, val in sorted(value.iteritems()):
           child = QtGui.QTreeWidgetItem()
           child.setText(0, unicode(key))
           item.addChild(child)
           self.fill_item(child, val)
       elif type(value) is list:
         for val in value:
           child = QtGui.QTreeWidgetItem()
           item.addChild(child)
           if type(val) is dict:
             child.setText(0, '[dict]')
             self.fill_item(child, val)
           elif type(val) is list:
             child.setText(0, '[list]')
             self.fill_item(child, val)
           else:
             child.setText(0, unicode(val))
           # child.setExpanded(True)
           child.setExpanded(False)
       else:
         child = QtGui.QTreeWidgetItem()
         child.setText(0, unicode(value))
         item.addChild(child)

    def fill_widget(self, value):
       self.clear()
       self.fill_item(self.invisibleRootItem(), value)

    # def onChanged(self, text):
       # self.lbl.setText(text)
       # self.lbl.adjustSize()

def main():
   app = QtGui.QApplication(sys.argv)
   ex = My_QTreeWidget()
   sys.exit(app.exec_())

if __name__ == '__main__':
    main()
