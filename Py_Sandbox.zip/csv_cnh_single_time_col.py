# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it

import os
import csv
import numpy as np

def print_row(csv_data, col_name_array, csv_time_s_col_dict, index_time_s_pitch_angle, fout_csv_file):
   
   print(' ****** in print_row, index_time_s_pitch_angle = ' + str(index_time_s_pitch_angle))
   
   cnt_time_s = 0
   try:
      time_s_array_of_pitch_angle = []
      
      if ('CoC PitchAngle[deg]' in csv_data.keys()): 
         time_s_array_of_pitch_angle = csv_data['Time[s]_' + str(index_time_s_pitch_angle)]
      
      i = 0
      for t in time_s_array_of_pitch_angle:
         if (i < 10):
            print(' ******* Time t of time_s_array_of_pitch_angle = ' + str(t))
	 i += 1
      
      debug = False
      i = 0
      for c in col_name_array:
         # print('***** csv_data key = ' + str(k))
	 print('***** csv_data col name = ' + str(c))
	 
         if ('Time[s]' not in c):
            i = 0
            print(' ****** KEY c = ' + str(c) + ', csv_time_s_col_dict[c] = ' + str(csv_time_s_col_dict[c]))
	    
            # for val in csv_data['Time[s]_' + str(csv_time_s_col_dict[c])]:
               # if (i < 10):
                  # print(' ******* i = ' + str(i) + ', csv_data Time val = ' + str(val))
               # i += 1
            # } for val in csv_data['Time[s]_' + str(csv_time_s_col_dict[c])]..

            # for val in csv_data[c]:
               # if (i < 10):
                  # print(' ******* i = ' + str(i) + ', csv_data val = ' + str(val))
               # i += 1
            # } for val in csv_data[c]..

            # for val in time_s_array_of_pitch_angle:
               # if (i < 10):
                  # print(' ******* i = ' + str(i) + ', Pitch angle time_s = ' + str(val))
               # i += 1
            # } for val in time_s_array_of_pitch_angle..
            
            csv_data[c] = np.interp(time_s_array_of_pitch_angle, csv_data['Time[s]_' + str(csv_time_s_col_dict[c])], csv_data[c])
            
            i = 0
            # for val in csv_data[c]:
               # if (i < 10):
                  # print(' ******* INTERPOLATED csv_data col name c = ' + str(c) + ', Value = ' + str(val))
               # i += 1
            # } for val in csv_data[c]..
         # } if ('Time[s]' not in c)..
      # } for c in col_name_array..
      
      i = 0
      for row_num in range(len(time_s_array_of_pitch_angle)):
         fout_csv_file.write('%14.8f,'%(time_s_array_of_pitch_angle[row_num]))
 
	 for c in col_name_array:
            i += 1
            if ('Time[s]' not in c):
	       # print(' ***** Time[s] NOT in col name c = ' + str(c))
	       
               if (i == len(csv_data.keys())):
                  fout_csv_file.write('%14.8f'%(csv_data[c][row_num]))
               else:
                  fout_csv_file.write('%14.8f,'%(csv_data[c][row_num]))
               # } if (i == len(csv_data.keys()))..
            # } if ('Time[s]' not in c)..
         # } for c in col_name_array..
	 
	 fout_csv_file.write('\n')
      # } for row_num in len(time_s_array_of_pitch_angle)..
   except ValueError:
      print(' ******* ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))

def process_csv_file(csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   
   index_time_s_pitch_angle = 0
   header_time_s_pitch_angle = ''
   
   csv_data = {}
   csv_time_s_col_dict = {}
   col_name_array = []
   cnt_time_s = 0
   
   for data_row in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         col_name = ''
 	 
	 if ('CoC PitchAngle[deg]' in data_row):
	    fout_csv_file.write('Time_PitchAngle[s],')
	    
	 i = 0
         for c in data_row:
	    i += 1
	    if ('Time[s]' not in c):
               if (i == len(data_row)):
                  fout_csv_file.write(c)
               else:
                  fout_csv_file.write(c + ',')
               # } if (i == len(data_row))..
    
            # Get zero-based index of 'Time[s]' column immediately on left of column 'CoC PitchAngle[deg]':
            if (c == 'CoC PitchAngle[deg]'):
               index_time_s_pitch_angle = cnt_time_s
	       print(' ****** index_time_s_pitch_angle = ' + str(index_time_s_pitch_angle))
               header_time_s_pitch_angle = c
            # } if (c == 'CoC PitchAngle[deg]')..
    
            if ('Time[s]' not in c):
	       print(' ***** NON-TIME column: adding to csv_time_s_col_dict: key = ' + str(c) + ', value = ' + str(cnt_time_s))
               csv_time_s_col_dict[c] = cnt_time_s
               cnt_time_s = cnt_time_s + 1
               col_name = c
            else:
               col_name = c + '_' + str(cnt_time_s)
            # } if (c == 'CoC PitchAngle[deg]')..
    
            csv_data[col_name] = []
            col_name_array.append(col_name)
    
         # } for c in data_row..   
         fout_csv_file.write('\n')
 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
 	 
         for i in range(n_data_columns):
            csv_data[col_name_array[i]].append(float(data_row[i]))
         # } for i in range(n_data_columns)..
 
      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..
   # } for data_row in csvreader..
   
   print_row(csv_data, col_name_array, csv_time_s_col_dict, index_time_s_pitch_angle, fout_csv_file)
  
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/SlopesTest2_corrected.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/GrizzlyTest2_corrected_10Hz - C.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/GrizzlyTest2_corrected - C.csv'
in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/LongTruckTest2_corrected - C.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/HardBucketDumpTest2_corrected - C.csv'

# in_csvfile = open(in_file_name,'rUb')
in_csvfile = open(in_file_name, 'r')
csvreader = csv.reader(in_csvfile, delimiter=',')

(fin_filepath, fin_filename) = os.path.split(in_file_name)

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_SingleTimeCol.csv"), "w")

fout_csv_file.write('DATA_START\n')

process_csv_file(csvreader)

fout_csv_file.close()
