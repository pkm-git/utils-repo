import threading       #import thread library
from time import time  #import time library
from time import sleep           #sleep

#Class to asynchronously sleep for 2 ms
class Async2msUpdateThread(threading.Thread):

 """Thread Object for doing Threaded Data Updating"""
 def __init__(self, 2ms_interval_obj):
  """Initialize the Async2msUpdateThread Object"""
  threading.Thread.__init__(self)
  self.2ms_interval_obj = 2ms_interval_obj
  self._stop = False

 def stop(self):
  self._stop = True

 def run(self):
  """Enter infinite 2 ms Sleep loop"""

  while(self._stop == False):
   # self.parser.parse_input_buffer()
   # sleep for 2 ms
   2ms_interval_obj.set_begin()
   sleep(0.002)
   2ms_interval_obj.set_end()
