
# fin = open("C:\MP\Lord\SourceCode_Greg\Sensor_Sim\INS HIL From File\IMU_Log.csv", "r")
# bytes_read = fin.read()

# for b in bytes_read:
  # process_byte(b)

# fout = open("C:\MP\Lord\SourceCode_Greg\Sensor_Sim\INS HIL From File\IMU_Log_Echo.csv", "w")

# fout.write(bytes_read)

# fin.close()
# fout.close()

#module imports
import csv
import sys
from mip_csv_utils import *

def print_usage_message():
    """Output usage instructions"""

    print("usage: python pkm_spoof_data_creator.py -i input_file_name -o output_file_name -d descriptor_string -D dictionary_file_name\n")
    print("input_file_name\t\t-- the name of the input file including the path")
    print("output_file_name\t-- the name of the output file including the path")
    print("descriptor_string\t-- hex character string representing a series of descriptor-set/field-descriptor pairs (e.g. 800480058006)")
    print("dictionary_file_name\t-- the path and name of the heading dictionary file ('.\Desc-Header strings.csv' DEFAULT)")

def main_line(argv):
    """Main line program"""

    # initialize command line arguments
    in_file_name = None
    out_file_name = None
    n_data_columns = 0
    output_descriptors = []
    output_headers = True
    dictionary_file_name = "Desc-Header strings.csv"
    ignore_empty_rows = False

    # parse command line arguements
    for i in range(len(argv)):
        # assign specified filenames
        if(argv[i] == '-i' and len(argv) > i+1):
            in_file_name = argv[i+1]
        elif(argv[i] == '-o' and len(argv) > i+1):
            out_file_name = argv[i+1]
        #specify number of data elements in the csv file
        elif(argv[i] == '-n' and len(argv) > i+1):
            n_data_columns = int(argv[i+1])
        elif(argv[i] == '-d' and len(argv) > i+1):
            #is this only 1 descriptor?
            if(len(argv[i+1]) == 4):
                #split up the 2 bytes into DS and FD
                output_descriptors.append((bytearray.fromhex(argv[i+1])[0], \
                                           bytearray.fromhex(argv[i+1])[1]))
            #is this more than one descriptor?
            elif(len(argv[i+1]) % 4 == 0 and len(argv[i+1]) > 0):
                #loop over the specified bytes
                for j in range(0,len(argv[i+1]),4):
                 output_descriptors.append((bytearray.fromhex(argv[i+1][j:j+4])[0], \
                                            bytearray.fromhex(argv[i+1][j:j+4])[1]))

    # load the column header dictionary
    desc_dictionary = load_mip_header_dictionary(dictionary_file_name)

    # Overwrite GPS Time entries to be consistent with MIP Monitor consolidated
    # time outputs
    consolidated_time_headers = (['GPS TFlags','GPS Week','GPS TOW'])
    desc_dictionary.update({(0x80,0x12):consolidated_time_headers})
    desc_dictionary.update({(0x81,0x09):consolidated_time_headers})
    desc_dictionary.update({(0x82,0x11):consolidated_time_headers})

    # create a list of all recognized column headers from
    full_header_list = [item for sublist in desc_dictionary.values() for item in sublist]

    #initialize all state variables
    n_input_rows = 0
    n_output_rows = 0
    determine_headers = False
    headers_found = False
    headers = []
    output_order = []

    # read the specified input csv file
    with open(in_file_name,'rUb') as in_csvfile:
        with open(out_file_name, 'wb') as out_csvfile:
            csvreader = csv.reader(in_csvfile, delimiter=',')
            csvwriter = csv.writer(out_csvfile, delimiter=',')

            # loop over each row in the input file
            for row_items in csvreader:

                # determined that last row in CSV indicated data start (headers are in this row)
                if (determine_headers == True):
                    # determine the number of columns
                    n_data_columns =  len(row_items)

                    # create a list of the headers
                    for i in range(n_data_columns):
                        headers.append(row_items[i])

                    # determine the order of the desired outputs in terms of the input column indices

                    # generate the output row for the output csv
                    output_header_row = []

                    # loop over specified output descriptors
                    for descriptor in output_descriptors:
                        # add the headings for the output file to the output header row
                        try:
                            output_header_row.extend(desc_dictionary[descriptor])
                            # loop over all headings associated with this descriptor
                            for column_header in desc_dictionary[descriptor]:
                                # is the specified data in the input file?
                                try:
                                    output_order.append(headers.index(column_header))
                                # if not put in placeholder indices
                                except ValueError:
                                    output_order.append(-1)
                        except KeyError:
                            print(hex(descriptor[0])[-2:]+hex(descriptor[1])[-2:]+" not found in dictionary.")
                            sys.exit()

                    print("Headers found, generating output file")

                    # write the output header row
                    if(output_headers == True):
                        csvwriter.writerow(['DATA_START'])
                        csvwriter.writerow(output_header_row)

                    # column headers have been found
                    headers_found = True

                    # headers no longer need to be determined
                    determine_headers = False

                elif (headers_found == True):
                    # create the empty output_row
                    output_row = len(output_order)*[[]]

                    # set flag to ignore this row until valid data is found in it
                    if(ignore_empty_rows == True):
                        ignore_row = True
                    else:
                        ignore_row = False

                    # loop over all requested columns in current input row
                    for output_index in range(len(output_order)):
                        input_index = output_order[output_index]

                        # is this data type in the input file?
                        if(input_index == -1): # this element isn't located in the input file
                            output_row[output_index] = str(missing)
                        else: # this element is located in the input file
                            # is this an empty entry?
                            if(row_items[input_index] == ''):#no data in this row for this column
                                # determining the padding specified and adjust accordingly
                                if(padding != 'hold'):#if not holding previous value, pad with specified
                                    output_row[output_index] = str(padding)
                                else:# if holding previous value pad with previous value
                                    # if the previous value is empty (no previous valid data) use 0.0
                                    # initially
                                    if(last_output_row[output_index] == ''):
                                        output_row[output_index] = '0.0'
                                    # previous valid data found, hold that until next valid data point
                                    else:
                                        output_row[output_index] = last_output_row[output_index]
                            else:# there is data in this column for this row
                                output_row[output_index] = row_items[input_index]
                                print(row_items[input_index])
                                # if there is ever valid data for this row, output it, otherwise
                                # ignore it (including any time stamp)
                                if(output_header_row[output_index] not in consolidated_time_headers):
                                    ignore_row = False

                       # reset the last output row
                       last_output_row = list(output_row)

                       # output the generated output row
                       if(ignore_row == False):
                           csvwriter.writerow(output_row)
                           n_output_rows += 1

                       n_input_rows += 1
                # this row is neither column headers nor data elements
                else:
                    print(row_items)
                    # test for DATA_START row (column headers to follow)
                    if(len(row_items) == 1 and row_items[0] == 'DATA_START'):
                        determine_headers = True
                        print("DATA_START found, collecting headers")

        # file complete
        print(str(n_input_rows)+" input rows processed")
        print("******** Output file generation complete")
        print(str(n_output_rows)+" output rows written.")

############ END OF MAIN #############################

if(__name__ == "__main__"):
  main_line(sys.argv)

