LOAD_SENSOR_LIST_UNINITIALIZED               = 0

class LOAD_SENSOR_LIST(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
     self.init()
  except:
     self.state = LOAD_SENSOR_LIST_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""

   self.done = True
   self.sensor_list_widget = None

