# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os
import re
import sys
import csv
import calendar
import math
import numpy
import pyqtgraph as pg

from datetime import datetime

from PyQt4 import QtCore, QtGui
from QInertialSensorUtils_GUI_CommonWidgets import *

from imu_format_using_dict import *
from gps_format_using_dict import *
from ekf_format_using_dict import *

GRND_TRC_COL_HEADER = 'Grnd Trace'
GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8202]'
DELTA_REL_GBL_TME_HEADER_TO_USE = 'Delta Global Tme MS [x8250]'
# DELTA_EKF_TOW_HEADER_TO_USE = 'Delta EKF TmeWk'
DELTA_EKF_TOW_HEADER_TO_USE = 'Delta TmeOfWk'

class MyTreeWidget(QtGui.QTreeWidget):
    def __init__(self, parent, init_file_name = None, csv_object_name = None, gps_week = 0):
       super(MyTreeWidget, self).__init__()

       self.parent_obj = parent

       self.sensor_name = ''
       self.desired_action = 'gs'
       self.sensor_label = None
       self.init_file_name = None
       self.append_file_name = None
       self.csv_object_name = None
       self.name_to_use = None
       self.csv_col_name_dict = None
       self.csv_data_dict = {}
       self.csv_data_bounded_dict = {}
       self.empty_cell_col_dict = {}
       self.x8210_flag_on_col_dict = {}
       self.heading_type_col_name_dict = {}
       self.csv_mode = False
       self.gps_week = gps_week

       self.n_data_columns = 0

       if (init_file_name != None):
          self.init_file_name = init_file_name
          if (csv_object_name != None):
             self.csv_object_name = str(csv_object_name)
             self.name_to_use = self.csv_object_name
          else:
             (fin_filepath, fin_filename) = os.path.split(init_file_name)
             self.name_to_use = fin_filename
          # } if (csv_object_name != None)..
          self.csv_mode = True
       # } if (init_file_name != None)..

       self.setItemHidden(self.headerItem(), True)
       self.initUI(gps_week)
       # self.itemClicked.connect(self.handleTreeWidgetClicked)

    def closeEvent(self, event):
       print "Closing MyTreeWidget window"

       super(MyTreeWidget, self).closeEvent(event)

    def initUI(self, gps_week):
       if (self.init_file_name != None):
          self.csv_col_name_dict = {}
          col_name_array, csv_data, empty_cell_col_array, x8210_flag_on_col_array, heading_type_col_name_array = self.get_table_data(False, gps_week)
  
          if (self.csv_object_name != None):
             self.csv_col_name_dict[self.csv_object_name] = col_name_array
             self.csv_data_dict[self.csv_object_name] = csv_data
             self.empty_cell_col_dict[self.csv_object_name] = empty_cell_col_array
             self.x8210_flag_on_col_dict[self.csv_object_name] = x8210_flag_on_col_array
             self.heading_type_col_name_dict[self.csv_object_name] = heading_type_col_name_array
          else:
             (fin_filepath, fin_filename) = os.path.split(self.init_file_name)
             self.csv_col_name_dict[fin_filename] = col_name_array
             self.csv_data_dict[fin_filename] = csv_data
             self.empty_cell_col_dict[fin_filename] = empty_cell_col_array
             self.x8210_flag_on_col_dict[fin_filename] = x8210_flag_on_col_array
             self.heading_type_col_name_dict[fin_filename] = heading_type_col_name_array
          # } if (self.csv_object_name != None)..
          self.fill_widget(self.csv_col_name_dict)
       else:
          self.parent_obj.updateSensorList()

          self.sensors_dict = {}

          sensors  = self.parent_obj.sensor_list_dict

          imu_format_using_dict = IMU_format_using_dict()
          gps_format_using_dict = GPS_format_using_dict()
          ekf_format_using_dict = EKF_format_using_dict()

          if (sensors != None and len(sensors) > 0):
             i = 0

             for s in sensors.values():
                sensor_name = str(s["name"])
                channel_name_array = []
                channel_name_sorted_array = []
                channel_name_dict = {}
                imu_channel_name_dict = {}
                gps_channel_name_dict = {}
                ekf_channel_name_dict = {}
                imu_channel_name_array = []
                gps_channel_name_array = []
                ekf_channel_name_array = []
                imu_field_desc_array = []
                gps_field_desc_array = []
                ekf_field_desc_array = []

                channels = s["channels"]
                channel_array = channels.values()
                if (channel_array != None):
                   has_810C = False
                   visible_channel_nbr_array = []

                   for c in channel_array:
                      channel_name = str(c["name"])
                      channel_name_array.append(channel_name)

                      if ('channel_nbr_x810c' in channel_name.lower()):
                         if (not has_810C):
                            has_810C = True
                         # } if (not has_810C)..

                         channel_nbr = int(channel_name[18:])
                         # print(' ********* channel_nbr: ' + str(channel_nbr))
                         visible_channel_nbr_array.append(channel_nbr)
                      # } if ('channel_nbr_x810c' in channel_name.lower())..
                   # } for c in channel_array..

                   if (has_810C and len(visible_channel_nbr_array) > 0):
                      visible_channel_nbr_array.sort()
                      gps_format_using_dict = GPS_format_using_dict(None, visible_channel_nbr_array)
                   # } if (has_810C and..

                   # Arrange/sort the channel names to be same as in csv file (not alphabetical)
                   imu_flags_wk_tow_array = imu_format_using_dict.format_channel_name(0)

                   imu_data_tow_col_indices = [i for i,x in enumerate(channel_name_array) if x in imu_flags_wk_tow_array]

                   imu_data_col_indices = [i for i,x in enumerate(channel_name_array) if 'x80' in x.lower()]

                   gps_flags_wk_tow_array = gps_format_using_dict.format_channel_name(0)
                   gps_data_tow_col_indices = [i for i,x in enumerate(channel_name_array) if x in gps_flags_wk_tow_array]
                   gps_data_col_indices = [i for i,x in enumerate(channel_name_array) if 'x81' in x.lower()]

                   ekf_flags_wk_tow_array = ekf_format_using_dict.format_channel_name(0)
                   ekf_data_tow_col_indices = [i for i,x in enumerate(channel_name_array) if x in ekf_flags_wk_tow_array]

                   ekf_data_col_indices = [i for i,x in enumerate(channel_name_array) if 'x82' in x.lower()]

                   # other_data_col_indices = [i for i,x in enumerate(channel_name_array) if i not in imu_data_tow_col_indices and i not in imu_data_col_indices \
                                                                                      # and i not in gps_data_tow_col_indices and i not in gps_data_col_indices \
                                                                                      # and i not in ekf_data_tow_col_indices and i not in ekf_data_col_indices]

                   imu_tow_cols = [y for j,y in enumerate(channel_name_array) if j in imu_data_tow_col_indices]
                   if (len(imu_tow_cols) > 0):
                      imu_channel_name_dict['8012'] = imu_flags_wk_tow_array
                   # } if (len(imu_tow_cols) > 0)..

                   for i in imu_data_col_indices:
                      channel_name = channel_name_array[i]

                      indx = channel_name.find('x80')
                      if (indx != -1):
                         imu_channel_name_array.append(channel_name)
                         field_descriptor = channel_name[indx+1:indx+5].upper()
                         if (field_descriptor not in imu_channel_name_dict):
                            imu_other_than_tow_cols = imu_format_using_dict.format_channel_name(imu_default_cols_seq_array.index(field_descriptor))
                            imu_channel_name_dict[field_descriptor] = imu_other_than_tow_cols
                         # } if (field_descriptor not in imu_channel_name_dict)..
                      # } if (indx != -1)..
                   # } for i in imu_data_col_indices..

                   gps_tow_cols = [y for j,y in enumerate(channel_name_array) if j in gps_data_tow_col_indices]
                   if (len(gps_tow_cols) > 0):
                      gps_channel_name_dict['8109'] = gps_flags_wk_tow_array
                   # } if (len(gps_tow_cols) > 0)..

                   for i in gps_data_col_indices:
                      channel_name = channel_name_array[i]
                      indx = channel_name.find('x81')
                      if (indx != -1):
                         gps_channel_name_array.append(channel_name)
                         field_descriptor = channel_name[indx+1:indx+5].upper()
                         if (field_descriptor not in gps_channel_name_dict):
                            gps_channel_name_dict[field_descriptor] = gps_format_using_dict.format_channel_name(gps_default_cols_seq_array.index(field_descriptor))
                         # } if (field_descriptor not in gps_channel_name_dict)..
                      # } if (indx != -1)..
                   # } for i in gps_data_col_indices..

                   ekf_tow_cols = [y for j,y in enumerate(channel_name_array) if j in ekf_data_tow_col_indices]
                   if (len(ekf_tow_cols) > 0):
                      ekf_channel_name_dict['8211'] = ekf_flags_wk_tow_array
                   # } if (len(ekf_tow_cols) > 0)..

                   for i in ekf_data_col_indices:
                      channel_name = channel_name_array[i]
                      indx = channel_name.find('x82')
                      if (indx != -1):
                         ekf_channel_name_array.append(channel_name)
                         field_descriptor = channel_name[indx+1:indx+5].upper()
                         if (field_descriptor not in ekf_channel_name_dict):
                            ekf_channel_name_dict[field_descriptor] = ekf_format_using_dict.format_channel_name(ekf_default_cols_seq_array.index(field_descriptor))
                         # } if (field_descriptor not in ekf_channel_name_dict)..
                      # } if (indx != -1)..
                   # } for i in ekf_data_col_indices..

                   # other_data_cols = [y for j,y in enumerate(channel_name_array) if j in other_data_col_indices]
                   # other_channel_name_dict['OTHER'] = other_data_cols
                   # channel_name_sorted_array.extend([y for j,y in enumerate(channel_name_array) if j in other_data_col_indices])

                   imu_channel_name_sorted_indices_array = []
                   gps_channel_name_sorted_indices_array = []
                   ekf_channel_name_sorted_indices_array = []

                   for k in imu_channel_name_dict.keys():
                      if (k in imu_default_cols_seq_array):
                         imu_channel_name_sorted_indices_array.append(imu_default_cols_seq_array.index(k))
                      # } if (k in imu_default_cols_seq_array)..
                   # } for k in imu_channel_name_dict.keys()..
                   imu_channel_name_sorted_indices_array.sort()

                   for k in gps_channel_name_dict.keys():
                      if (k in gps_default_cols_seq_array):
                         gps_channel_name_sorted_indices_array.append(gps_default_cols_seq_array.index(k))
                      # } if (k in gps_default_cols_seq_array)..
                   # } for k in gps_channel_name_dict.keys()..
                   gps_channel_name_sorted_indices_array.sort()

                   for k in ekf_channel_name_dict.keys():
                      if (k in ekf_default_cols_seq_array):
                         ekf_channel_name_sorted_indices_array.append(ekf_default_cols_seq_array.index(k))
                      # } if (k in ekf_default_cols_seq_array)..
                   # } for k in ekf_channel_name_dict.keys()..
                   ekf_channel_name_sorted_indices_array.sort()

                   final_channel_name_array_to_use = []
                   for k in imu_channel_name_sorted_indices_array:
                      final_channel_name_array_to_use.extend(imu_channel_name_dict[imu_default_cols_seq_array[k]])

                   for k in gps_channel_name_sorted_indices_array:
                      final_channel_name_array_to_use.extend(gps_channel_name_dict[gps_default_cols_seq_array[k]])

                   for k in ekf_channel_name_sorted_indices_array:
                      final_channel_name_array_to_use.extend(ekf_channel_name_dict[ekf_default_cols_seq_array[k]])
                # } if (channel_array != None)..

                self.sensors_dict[sensor_name] = final_channel_name_array_to_use

                i = i + 1
             # } for s in sensors.values()..
          # } if (sensors != None and len(sensors) > 0)..

          self.fill_widget(self.sensors_dict)

       # } if (self.init_file_name != None)..

       self.createCheckboxesForTree()

    def append_tree_obj_from_file(self, append_file_name, append_csv_object_name = None, append_gps_week = 0):
       self.append_file_name = append_file_name
       self.append_gps_week = append_gps_week
       
       if (append_csv_object_name != None):
          self.name_to_use = append_csv_object_name
       else:
          (fin_filepath, fin_filename) = os.path.split(self.append_file_name)
          self.name_to_use = fin_filename
       # } if (append_csv_object_name != None)..

       # col_name_array, csv_data, csv_data_bounded_cols, empty_cell_col_array, x8210_flag_on_col_array, heading_type_col_name_array = self.get_table_data(True)
       col_name_array, csv_data, empty_cell_col_array, x8210_flag_on_col_array, heading_type_col_name_array = self.get_table_data(True, append_gps_week)
       
       if (append_csv_object_name != None):
          self.csv_col_name_dict[append_csv_object_name] = col_name_array
          self.csv_data_dict[append_csv_object_name] = csv_data
          # self.csv_data_bounded_dict[append_csv_object_name] = csv_data_bounded_cols
          self.empty_cell_col_dict[append_csv_object_name] = empty_cell_col_array
          self.x8210_flag_on_col_dict[append_csv_object_name] = x8210_flag_on_col_array
          self.csv_object_name = append_csv_object_name
          self.heading_type_col_name_dict[append_csv_object_name] = heading_type_col_name_array
       else:
          (fin_filepath, fin_filename) = os.path.split(self.append_file_name)
          self.csv_col_name_dict[fin_filename] = col_name_array
          self.csv_data_dict[fin_filename] = csv_data
          # self.csv_data_bounded_dict[fin_filename] = csv_data_bounded_cols
          self.empty_cell_col_dict[fin_filename] = empty_cell_col_array
          self.x8210_flag_on_col_dict[fin_filename] = x8210_flag_on_col_array
          self.heading_type_col_name_dict[fin_filename] = heading_type_col_name_array
       # } if (append_csv_object_name != None)..

       print(' ************* in append_tree, self.name_to_use = ' + self.name_to_use)

       self.fill_widget(self.csv_col_name_dict)
       self.createCheckboxesForTree()

    def delete_tree_obj(self, delete_object_name):

       self.csv_col_name_dict.pop(delete_object_name, None)
       self.csv_data_dict.pop(delete_object_name, None)
       self.csv_data_bounded_dict.pop(delete_object_name, None)
       self.empty_cell_col_dict.pop(delete_object_name, None)
       self.x8210_flag_on_col_dict.pop(delete_object_name, None)

       self.fill_widget(self.csv_col_name_dict)
       self.createCheckboxesForTree()

    def createCheckboxesForTree(self):
       regionBrush = pg.mkBrush('r')

       root = self.invisibleRootItem()
       self.child_count = root.childCount()
       if (self.child_count > 0):
          for i in range(self.child_count):
             item = root.child(i)
             item.setCheckState(0, QtCore.Qt.Unchecked)
             self.childs_child_count = item.childCount()
             parent_obj_name = str(item.text(0))
             for j in range(self.childs_child_count):
                items_child = item.child(j)
                col_name = str(items_child.text(0))
                if ('x8210' in col_name.lower() and 'flag_' in col_name.lower()):
                   if (parent_obj_name in self.x8210_flag_on_col_dict and col_name in self.x8210_flag_on_col_dict[parent_obj_name]):
                      items_child.setForeground(0, regionBrush);
                      items_child.setCheckState(0, QtCore.Qt.Unchecked)
                   # } if (parent_obj_name in self.x8210_flag_on_col_dict..
                # } if ('x8210' in col_name.lower()..
                items_child.setCheckState(0, QtCore.Qt.Unchecked)
             # } for j in range(self.childs_child_count)..
          # } for i in range(self.child_count)..
       # } if (self.child_count > 0)..

    def get_table_data(self, appendMode, gps_week):
       col_name_array = []
       csv_data = {}
       # csv_data_bounded_cols = {}
       empty_cell_col_array = []    # array of column names that have one or more empty cells in that column
       x8210_flag_on_col_array = []
       x810C_visible_SV_col_array = []
       completely_empty_col_array = [] # array of column names that have all rows empty
       # grnd_trc_vel_n_col_name = ''
       grnd_trc_vel_n_col_name_dict = {}
       
       # fout_grnd_trace = open(self.name_to_use + "_grnd_trc_debug.csv", "w")
       # fout_grnd_trace.write('data_row_cnt,Vned_N,Vned_E,Vned_D,vel_NE_mag,Grnd Angle Prev,Grnd Ang,Grnd Ang 360,Delta Grnd Ang,Adder,Grnd Ang Final\n')
       
       cnt_neg = 0;
       
       if (not appendMode):
          file_name_to_use = self.init_file_name
       else:
          file_name_to_use = self.append_file_name
       # } if (not appendMode)..

       if (file_name_to_use != None):
          in_csvfile = open(file_name_to_use,'rUb')
          csvreader = csv.reader(in_csvfile, delimiter=',')

          determine_headers = False
          headers_found = False
          data_row_cnt = 0
          data_row_cnt_non_zero_yaw = 0
          data_row_cnt_non_zero_yaw_found = 0
 
          non_zero_yaw_found = False
  
          POS_INF = float("+inf")

          sum_delta_theta_x = 0.0
          sum_delta_theta_y = 0.0
          sum_delta_theta_z = 0.0

          sum_delta_v_x = 0.0
          sum_delta_v_y = 0.0
          sum_delta_v_z = 0.0

          # Flag to convert 100Hz Novatel to 10Hz (useful if Lord IMU gives 10 Hz output)
          # calc_10Hz_Novatel_IMU = False
          calc_downsampled_IMU = False
          # DOWNSAMPLE_RATIO = 50  # example: down sample from 500 Hz to 10 Hz: => DOWNSAMPLE_RATIO = 500/10 = 50
          DOWNSAMPLE_RATIO = 1  # example: down sample from 500 Hz to 10 Hz: => DOWNSAMPLE_RATIO = 500/10 = 50
          # DOWNSAMPLE_RATIO = 5  # example: down sample from 500 Hz to 10 Hz: => DOWNSAMPLE_RATIO = 500/10 = 50

          convert_to_unbounded_yaw = True
          # convert_to_unbounded_yaw = False

          if ('nrtsim' in self.name_to_use.lower()):
             # calc_downsampled_IMU = True
             calc_downsampled_IMU = False
          # } if ('nrtsim' in self.name_to_use.lower())..

          print(' *************** self.name_to_use: ' + self.name_to_use + ', calc_downsampled_IMU is ' + str(calc_downsampled_IMU))

          found_VNED = False
          found_relGlobalTime = False
          empty_VNED_row_dict = {}
          empty_relGlobalTime = False
          grnd_trace_angle_calc_valid_found = False

          other_yaw_headers = []
    
          yaw_angle_valid_found_dict = {}
          yaw_angle_valid_found_dict['EULER_YAW_ANGLE'] = False
          yaw_angle_valid_found_dict['INIT_YAW_ANGLE'] = False
          yaw_angle_valid_found_dict['GPS_HEADING'] = False
          yaw_angle_valid_found_dict['HEADING_SOURCE'] = False
          yaw_angle_valid_found_dict['OTHER_HEADING'] = False
          yaw_angle_valid_found_dict['AZIMUTH'] = False
  
          ekf_8202_struct = EKF_8202_struct()
          col_header_dict = {}
          grnd_trc_index = 0
  
          euler_yaw_prev_dict = {}
          euler_yaw_prev_dict['EULER_YAW_ANGLE'] = 0
          euler_yaw_prev_dict['INIT_YAW_ANGLE'] = 0
          euler_yaw_prev_dict['GPS_HEADING'] = 0
          euler_yaw_prev_dict['HEADING_SOURCE'] = 0
          euler_yaw_prev_dict['OTHER_HEADING'] = 0
          euler_yaw_prev_dict['AZIMUTH'] = 0
  
          grnd_trace_angle_prev = 0.0
          grnd_trace_angle_calc_prev = 0.0
          grnd_trace_angle_calc = 0.0
          grnd_trace_angle_calc_bounded = 0.0
          delta_grnd_trace_calc = 0.0
  
          adder_yaw_dict = {}
          adder_yaw_dict['EULER_YAW_ANGLE'] = 0
          adder_yaw_dict['INIT_YAW_ANGLE'] = 0
          adder_yaw_dict['GPS_HEADING'] = 0
          adder_yaw_dict['HEADING_SOURCE'] = 0
          adder_yaw_dict['OTHER_HEADING'] = 0
          adder_yaw_dict['AZIMUTH'] = 0
  
          delta_yaw = 0.0
          delta_azimuth = 0.0
          other_csv = False
          heading_type_col_name_array = []
          row_item_prev = []
          col_name_array_extended = []
          derived_col_cnt = 0
          euler_yaw_raw_csv = 0
          euler_yaw_degrees = 0
          euler_yaw_360_bounded_degrees = 0
          azimuth_raw_csv = 0
          ekf_tow_found = False
          adder_grnd_trace = 0
  
          grnd_trc_angle_valid_found_dict = {}
          adder_grnd_trace_dict = {}
          grnd_trace_angle_raw_csv_dict = {}
          grnd_trace_angle_calc_prev_dict = {}
          ekf_8202_struct_dict = {}
  
          # Some csv files have multiple 'Time[s]' columns
          cnt_time_cols = 0
  
          for row_item in csvreader:
             # Determined that previous row in CSV indicated data start (in other words, headers are in the current row)
             if (determine_headers):
                self.n_data_columns = len(row_item)

                print(' ******* NO. OF HEADERS: self.n_data_columns = ' + str(self.n_data_columns))

                # Create a list of channel names from the headers
                for i in range(self.n_data_columns):
                   col_name = row_item[i].strip()
   
                   if ('Time[s]' in col_name):
                      col_name = col_name + '_' + str(cnt_time_cols)
                      cnt_time_cols = cnt_time_cols + 1
                   # } if ('Time[s]' in col_name)..
      
                   col_name_array.append(col_name)
                   col_name_array_extended.append(col_name)
                   csv_data[col_name] = []
   
                   # print(' ***** HEADER SECTION: Column index: i = ' + str(i) + ', COLUMN NAME: ' + col_name)
                   # Exclude 'P_Tilt_Yaw' [x8255] from Yaw/Heading type column, because no need to convert that to unbounded
                   if ( \
                        ('yaw' in col_name.lower() and 'uc' not in col_name.lower() and 'acc' not in col_name.lower() and 'x8255' not in col_name.lower()) \
                        or \
                        # (('x8105' in col_name.lower() or 'x8257' in col_name.lower()) and 'heading' in col_name.lower() and 'acc' not in col_name.lower()) \
			('x8259' not in col_name.lower() and 'heading' in col_name.lower() and 'uc' not in col_name.lower() and 'acc' not in col_name.lower()) \
                        or \
                        ('x8214' in col_name.lower() and 'true heading' in col_name.lower()) \
                        or \
                        ('508' in col_name.lower() and 'azimuth' in col_name.lower()) \
                        or \
                        ('gpscog' in col_name.lower() or ('grnd trc' in col_name.lower() and ('323/266' in col_name.lower() or '99' in col_name.lower()))) \
                      ):
         
                      print(' **** HEADING TYPE COLUMN: ' + col_name)
 
                      heading_type_col_name_array.append(col_name)
                      heading_type_col_name_array.append(col_name + '_Unbounded')
                      heading_type_col_name_array.append(col_name + '_360_Bounded')
                      heading_type_col_name_array.append(col_name + '_Orig_in_Deg')
                      heading_type_col_name_array.append(col_name + '_Orig_Log')
 
                      csv_data[col_name + '_Unbounded'] = []
                      csv_data[col_name + '_360_Bounded'] = []
                      csv_data[col_name + '_Orig_in_Deg'] = []
                      csv_data[col_name + '_Orig_Log'] = []
                      
                      # Create an array of column names that contain the text 'Yaw', but no 'uc' and NOT a LORD MIP message.
                      # Example: Custom header(s) with text 'Yaw' + whatever, created by a customer
                      # such as: 'Yaw (Reference)', 'EKF Yaw (3DM-GX5-25)', 'EKF Yaw (3DM-GX5-45)', etc.
                      if ('yaw' in col_name.lower() and 'uc' not in col_name.lower() and \
                          'x8255' not in col_name.lower() and \
                          'x8205' not in col_name.lower() and \
                          'x800c' not in col_name.lower() and \
                          'x8254' not in col_name.lower() \
                         ):
                         other_yaw_headers.append(col_name.lower())
                      # } if ('yaw' in col_name.lower() and..
                   # } if ( \..
   
                   # if (col_name not in found_VNED_dict and ( \
                   # if (col_name not in grnd_trc_vel_n_col_name_dict and ( \
                   if ( \
                         ( \
                            (('vel n' in col_name.lower() or 'vel_n' in col_name.lower()) and 'uc' not in col_name.lower()) \
                            and \
                            ('x8202' in col_name.lower() or 'x8105' in col_name.lower() or 'x8257' in col_name.lower()) \
                         ) \
                         or \
                         ( \
                            'vned_n' in col_name.lower() \
                            # and \
                            # '508/507' in col_name.lower() \
                         ) \
                      ):

                      found_VNED = True
      
                      if ('x8202' in col_name.lower()):
                         GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8202]'
                      elif ('x8105' in col_name.lower()):
                         GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8105]'
                      elif ('x8257' in col_name.lower()):
                         GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8257]'
                      else:
                         GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [508/507]'
                      # } if ('x8202' in col_name.lower())..
                      
                      print(' ****** ADDING KEY = ' + col_name + ' to grnd_trc_vel_n_col_name_dict')
                      grnd_trc_vel_n_col_name_dict[col_name] = GRND_TRC_COL_HEADER_TO_USE
      
                      heading_type_col_name_array.append(GRND_TRC_COL_HEADER_TO_USE)
                      heading_type_col_name_array.append(GRND_TRC_COL_HEADER_TO_USE + '_Unbounded')
                      heading_type_col_name_array.append(GRND_TRC_COL_HEADER_TO_USE + '_360_Bounded')
                      heading_type_col_name_array.append(GRND_TRC_COL_HEADER_TO_USE + '_Orig_in_Deg')
                      heading_type_col_name_array.append(GRND_TRC_COL_HEADER_TO_USE + '_Orig_Log')
      
                      csv_data[GRND_TRC_COL_HEADER_TO_USE] = []
                      csv_data[GRND_TRC_COL_HEADER_TO_USE + '_Unbounded'] = []
                      csv_data[GRND_TRC_COL_HEADER_TO_USE + '_360_Bounded'] = []
                      csv_data[GRND_TRC_COL_HEADER_TO_USE + '_Orig_in_Deg'] = []
                      csv_data[GRND_TRC_COL_HEADER_TO_USE + '_Orig_Log'] = []
      
                      col_header_dict[col_name] = i
      
                   # } if (not found_VNED and..
   
                   if (not found_relGlobalTime and ( \
                                                   'rel global tme ms' in col_name.lower() \
                                                   and \
                                                   'x8250' in col_name.lower() \
                                                   )\
                      ):

                      found_relGlobalTime = True
      
                      # Insert new, computed Delta Rel Glb Time column after Rel Gbl Time column
                      # delta_rel_gbl_tme_index = i+1
         
                      print(' ******** Found Rel Global Tme at i = ' + str(i))
                      col_header_dict['REL_GBL_TME'] = i
      
                      col_name_array_extended.append(DELTA_REL_GBL_TME_HEADER_TO_USE)

                      csv_data[DELTA_REL_GBL_TME_HEADER_TO_USE] = []
      
                      # 'Delta Rel Gbl Time' for 1st row is undefined, so we append POS_INF
                      # so that it is disregarded at the time of plotting
                      csv_data[DELTA_REL_GBL_TME_HEADER_TO_USE].append(POS_INF) 
                      empty_cell_col_array.append(DELTA_REL_GBL_TME_HEADER_TO_USE)

                   # } if (found_relGlobalTime)..

                   if ('ekf tow' in col_name.lower() or 'gps tow' in col_name.lower() or 'imu tow' in col_name.lower()):
                      ekf_tow_found = True
      
                      # Insert new, computed 'Delta TOW' column after 'EKF TOW' column
                      # delta_tow_index = i+1
         
                      col_name_array_extended.append(DELTA_EKF_TOW_HEADER_TO_USE)

                      csv_data[DELTA_EKF_TOW_HEADER_TO_USE] = []
      
                      # 'Delta TOW' for 1st row is undefined, so we append POS_INF
                      # so that it is disregarded at the time of plotting
                      csv_data[DELTA_EKF_TOW_HEADER_TO_USE].append(POS_INF)
                      empty_cell_col_array.append(DELTA_EKF_TOW_HEADER_TO_USE)

                   # } if ('ekf tow' in col_name.lower()..
                # } for i in range(self.n_data_columns)..

                if (found_VNED):
                   for key in grnd_trc_vel_n_col_name_dict.keys():
                      index_vel_n = col_name_array_extended.index(key)
   
                      col_name_array_extended.insert(index_vel_n + 3, grnd_trc_vel_n_col_name_dict[key])
      
                      grnd_trc_angle_valid_found_dict[grnd_trc_vel_n_col_name_dict[key]] = False
                      grnd_trace_angle_calc_prev_dict[grnd_trc_vel_n_col_name_dict[key]] = 0.0
                      adder_grnd_trace_dict[grnd_trc_vel_n_col_name_dict[key]] = 0.0
      
                   # } for key in grnd_trc_vel_n_col_name_dict.keys()..
                # } if (found_VNED)..

                if (len(other_yaw_headers) > 0):
                   for ky in other_yaw_headers:
                      yaw_angle_valid_found_dict[ky] = False
                      euler_yaw_prev_dict[ky] = 0
                      adder_yaw_dict[ky] = 0
                   # } for ky in other_yaw_headers..
                # } if (len(other_yaw_headers) > 0 and..
                
                # column headers have been found
                headers_found = True

                # headers no longer need to be determined
                determine_headers = False

             elif (headers_found):
                if (len(row_item) > 0):
                   try:
                      cnt_time_cols = 0
                      data_row_cnt = data_row_cnt + 1
                  
                      for i in range(self.n_data_columns):

                         col_name = col_name_array[i]
 
                         # print(' ***** DATA SECTION: data_row_cnt: ' + str(data_row_cnt) + ', Column index: i = ' + str(i) + ', COLUMN NAME: ' + col_name)
 
                         if (row_item[i].strip() != '' and 'dop' not in col_name.lower() and ('tow' in col_name.lower() or 'time' in col_name.lower())):
                            # print(' ****** i = ' + str(i) + ', TIME FOUND *******')
    
                            if (ekf_tow_found and data_row_cnt > 1):
                               csv_data[DELTA_EKF_TOW_HEADER_TO_USE].append(numpy.double(row_item[i]) - numpy.double(row_item_prev[i]))
                            # } if (data_row_cnt > 1)..

                         if (row_item[i].strip() == '' or row_item[i].strip() == '-1.#IND' or row_item[i].strip() == '1.#QNAN'):
    
                            if (col_name not in empty_cell_col_array):
                               empty_cell_col_array.append(col_name)
       
                               if (col_name == 'Init Attitude Yaw [x8254]'):
                                  print(' **** Added Init Attitude Yaw [x8254] to empty col array')
                               
                               if (col_name in heading_type_col_name_array):
                                  empty_cell_col_array.append(col_name + '_Unbounded')
                                  empty_cell_col_array.append(col_name + '_360_Bounded')
                                  empty_cell_col_array.append(col_name + '_Orig_in_Deg')
                                  empty_cell_col_array.append(col_name + '_Orig_Log')
                               # } if (col_name in heading_type_col_name_array)..   
                            # } if (col_name not in empty_cell_col_array)..
    
                            # Insert dummy (positive infinity) value for empty cells found in csv file.
                            # At the time of plotting this column, these dummy values (and corresponding TOW) will be removed.
                            # Next, non-dummy values and their matching TOW will be plotted as a function of TOW.
                            # If we don't insert dummy values like this, we end up with a bunch of values in the column
                            # with no idea of corresponding TOW.
    
                            csv_data[col_name].append(POS_INF)
    
                            if (col_name in heading_type_col_name_array):
                               csv_data[col_name + '_Unbounded'].append(POS_INF)
                               csv_data[col_name + '_360_Bounded'].append(POS_INF)
                               csv_data[col_name + '_Orig_in_Deg'].append(POS_INF)
                               csv_data[col_name + '_Orig_Log'].append(POS_INF)
                            # } if (col_name in heading_type_col_name_array)..
                         elif ( \
                                ('yaw' in col_name.lower() and 'uc' not in col_name.lower() and 'acc' not in col_name.lower() and 'x8255' not in col_name.lower()) \
                                or \
                                (('x8105' in col_name.lower() or 'x8257' in col_name.lower()) and 'heading' in col_name.lower() and 'acc' not in col_name.lower()) \
                                or \
                                ('x8214' in col_name.lower() and 'true heading' in col_name.lower()) \
                                or \
                                ('x8259' not in col_name.lower() and 'heading' in col_name.lower() and 'uc' not in col_name.lower() and 'acc' not in col_name.lower()) \
                              ):
    
                            # MIP EKF Euler Yaw currently is the only column that has 0 to +/-180 deg range.
                            # Convert this to 0 - 360 range, in order to be in sync with:
                            # * Heading (x8105)
                            # * Grnd Trace computed columns (x8202, x8105)
                            # * Novatel's EKF Grnd Trace (Msg 99)
                            # * INS Grnd Trace (Msg 323/266), and
                            # * PVA_Azimuth (msg: 508/507)
    
                            yaw_case = ''

                            if ('yaw' in col_name.lower() and 'uc' not in col_name.lower() and 'x8255' not in col_name.lower()):
                               if ('x8205' in col_name.lower() or 'x800c' in col_name.lower()):
                                  yaw_case = 'EULER_YAW_ANGLE'
                               elif ('x8254' in col_name.lower()):
                                  yaw_case = 'INIT_YAW_ANGLE'
                               elif (col_name.lower() in other_yaw_headers):  
                                  yaw_case = col_name.lower()
                               # } if ('x8205' in col_name.lower())..
                            elif (('x8105' in col_name.lower() or 'x8257' in col_name.lower()) and 'heading' in col_name.lower() and 'acc' not in col_name.lower()):
                               yaw_case = 'GPS_HEADING'
                            elif ('x8214' in col_name.lower() and 'true heading' in col_name.lower()):
                               yaw_case = 'HEADING_SOURCE'
                            elif ('x8259' not in col_name.lower() and 'heading' in col_name.lower() and 'uc' not in col_name.lower() and 'acc' not in col_name.lower()):
                               yaw_case = 'OTHER_HEADING'
                            # } if ('yaw' in col_name.lower()..
    
                            # print(' ****** YAW CASE: ' + yaw_case)
    
                            in_radians = False
                            if ('x8205' in col_name.lower() or 'x800c' in col_name.lower() or 'x8254' in col_name.lower() or 'x8214' in col_name.lower() or 'yaw [06]' in col_name.lower()):
                               in_radians = True
                            # } if ('x8205' in col_name.lower()..

                            euler_yaw_raw_csv = float(row_item[i])
    
                            if (not in_radians):
                               euler_yaw = float(row_item[i])
                            else:
                               euler_yaw = math.degrees(float(row_item[i]))
                            # } if ('x8105' not in col_name.lower())..
    
                            euler_yaw_degrees = euler_yaw
    
                            # Convert 0 - +/- 180 range to: 0 - 360 range:
                            if (euler_yaw < 0):
                               euler_yaw = 360.0 + euler_yaw
                            # } if (euler_yaw < 0)..
    
                            euler_yaw_360_bounded_degrees = euler_yaw
    
                            if (convert_to_unbounded_yaw):
                               if (not yaw_angle_valid_found_dict[yaw_case]):
                                  euler_yaw_prev_dict[yaw_case] = euler_yaw
                                  yaw_angle_valid_found_dict[yaw_case] = True
                               else:
                                  delta_yaw = (euler_yaw - euler_yaw_prev_dict[yaw_case])

                                  if (delta_yaw < -180.0):
                                     adder_yaw_dict[yaw_case] += 360.0
                                  elif (delta_yaw > 180.0):
                                     adder_yaw_dict[yaw_case] -= 360.0
                                  # } if (delta_yaw < -180.0)..

                                  euler_yaw_prev_dict[yaw_case] = euler_yaw
  
                                  euler_yaw = euler_yaw + adder_yaw_dict[yaw_case]

                                  # if (non_zero_yaw_found and yaw_case == 'EULER_YAW_ANGLE' and (data_row_cnt_non_zero_yaw < 15 or abs(euler_yaw_raw) > 355 or abs(euler_yaw_raw) < 5)):
                                     # print(' **** UNBOUNDED euler_yaw (deg): ' + str(euler_yaw) + ', adder_yaw_dict[yaw_case]: ' + str(adder_yaw_dict[yaw_case]) + ', euler_yaw_prev_dict[yaw_case] = ' + str(euler_yaw_prev_dict[yaw_case]) + ', delta_yaw = ' + str(delta_yaw))
  
                               # } if (data_row_cnt == 1)..
                            # } if (convert_to_unbounded_yaw)..
                            
                            csv_data[col_name].append(euler_yaw)
                            csv_data[col_name + '_Unbounded'].append(euler_yaw)
                            csv_data[col_name + '_360_Bounded'].append(euler_yaw_360_bounded_degrees)
                            csv_data[col_name + '_Orig_in_Deg'].append(euler_yaw_degrees)
                            csv_data[col_name + '_Orig_Log'].append(euler_yaw_raw_csv)
           
                         elif ('508' in col_name.lower() and 'azimuth' in col_name.lower()):
                            azimuth = float(row_item[i])
                            azimuth_raw_csv = azimuth
    
                            yaw_case = 'AZIMUTH'
    
                            if (convert_to_unbounded_yaw):
                               if (not yaw_angle_valid_found_dict[yaw_case]):
                                  azimuth_prev = azimuth
                                  yaw_angle_valid_found_dict[yaw_case] = True
                               else:
                                  delta_azimuth = (azimuth - azimuth_prev)

                                  if (delta_azimuth < -180.0):
                                     adder_yaw_dict[yaw_case] += 360.0
                                  elif (delta_azimuth > 180.0):
                                     adder_yaw_dict[yaw_case] -= 360.0
                                  # } if (delta_azimuth < -180.0)..

                                  azimuth_prev = azimuth

                                  azimuth = azimuth + adder_yaw_dict[yaw_case]
  
                               # } if (not yaw_angle_valid_found)..
                            # } if (convert_to_unbounded_yaw)..

                            csv_data[col_name].append(azimuth)
                            csv_data[col_name + '_Unbounded'].append(azimuth)
                            csv_data[col_name + '_360_Bounded'].append(azimuth_raw_csv)
                            csv_data[col_name + '_Orig_in_Deg'].append(azimuth_raw_csv)
                            csv_data[col_name + '_Orig_Log'].append(azimuth_raw_csv)
    
                         elif ('gpscog' in col_name.lower() or ('grnd trc' in col_name.lower() and ('323/266' in col_name.lower() or '99' in col_name.lower()))):
                            grnd_trace_angle = float(row_item[i])
                            grnd_trace_angle_raw_csv = grnd_trace_angle
    
                            if (convert_to_unbounded_yaw):
                               if (not grnd_trace_angle_calc_valid_found):
                                  grnd_trace_angle_prev = grnd_trace_angle
                                  grnd_trace_angle_calc_valid_found = True
                               else:
                                  delta_grnd_trace_angle = (grnd_trace_angle - grnd_trace_angle_prev)

                                  if (delta_grnd_trace_angle < -180.0):
                                     adder_grnd_trace += 360.0
                                  elif (delta_grnd_trace_angle > 180.0):
                                     adder_grnd_trace -= 360.0
                                  # } if (delta_grnd_trace_angle < -180.0)..

                                  grnd_trace_angle_prev = grnd_trace_angle

                                  grnd_trace_angle = grnd_trace_angle + adder_grnd_trace
                               # } if (not grnd_trace_angle_calc_valid_found):..
                            # } if (convert_to_unbounded_yaw)..

                            csv_data[col_name].append(grnd_trace_angle)
                            csv_data[col_name + '_Unbounded'].append(grnd_trace_angle)
                            csv_data[col_name + '_360_Bounded'].append(grnd_trace_angle_raw_csv)
                            csv_data[col_name + '_Orig_in_Deg'].append(grnd_trace_angle_raw_csv)
                            csv_data[col_name + '_Orig_Log'].append(grnd_trace_angle_raw_csv)
                         else:
                            if ('lat' in col_name.lower() or 'lon' in col_name.lower()):
                               csv_data[col_name].append(numpy.double(row_item[i]))
                            elif (calc_downsampled_IMU and ('325' in col_name.lower() or 'x8007' in col_name.lower() or 'x8008' in col_name.lower())):
                               # delta_value = float(row_item[i])
                               delta_value = numpy.double(row_item[i])
                               if ('deltatheta_x' in col_name.lower()):
                                  sum_delta_theta_x += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     csv_data[col_name].append(sum_delta_theta_x)
                                     sum_delta_theta_x = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltatheta_y' in col_name.lower()):
                                  sum_delta_theta_y += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_theta_y)
                                     csv_data[col_name].append(sum_delta_theta_y)
                                     sum_delta_theta_y = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltatheta_z' in col_name.lower()):
                                  sum_delta_theta_z += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_theta_z)
                                     csv_data[col_name].append(sum_delta_theta_z)
                                     sum_delta_theta_z = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltav_x' in col_name.lower()):
                                  sum_delta_v_x += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     csv_data[col_name].append(sum_delta_v_x)
                                     sum_delta_v_x = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltav_y' in col_name.lower()):
                                  sum_delta_v_y += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_v_y)
                                     csv_data[col_name].append(sum_delta_v_y)
                                     sum_delta_v_y = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltav_z' in col_name.lower()):
                                  sum_delta_v_z += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_v_z)
                                     csv_data[col_name].append(sum_delta_v_z)
                                     sum_delta_v_z = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               # } if ('deltatheta_x' in col_name.lower())..
                            else:
                               try:
                                  if ('flag' in col_name.lower() or 'x810c' in col_name.lower()):
                                     csv_data[col_name].append(int(row_item[i]))
                                  elif ('vned_u' in col_name.lower()):
                                     csv_data[col_name].append(float(row_item[i]) * -1)
                                  elif (found_relGlobalTime and i == col_header_dict['REL_GBL_TME']):
                                     csv_data[col_name].append(float(row_item[i]))
  
                                     if (data_row_cnt > 1):
                                        csv_data[DELTA_REL_GBL_TME_HEADER_TO_USE].append(float(row_item[i]) - float(row_item_prev[i]))
                                     # } if (data_row_cnt > 1)..
                                  else:
                                     csv_data[col_name].append(float(row_item[i]))
                                  # } if ('x8210' in col_name.lower()..
       
                               except ValueError:
                                  csv_data[col_name].append(row_item[i])
                               # } try..
                            # } if ('lat' in col_name.lower()..
                         # } if (row_item[i].strip() == '' or..
                         
                         # if (found_VNED_dict[col_name] and row_item[i].strip() != '' and col_name in grnd_trc_vel_n_col_name_dict): 
                         if (found_VNED and col_name in grnd_trc_vel_n_col_name_dict):
			    if (row_item[i].strip() != ''):
                               try:
                                  ekf_8202_struct.ekf_vned_N = float(row_item[i])
                                  ekf_8202_struct.ekf_vned_E = float(row_item[i+1])
                                  ekf_8202_struct.ekf_vned_D = float(row_item[i+2])
     
                                  ekf_8202_struct_dict[col_name] = ekf_8202_struct
             
                                  empty_VNED_row_dict[col_name] = False
				  
				  print(' ***** DATA PART: col_name: ' + str(col_name) + ', i = ' + str(i) + ', row_item[i] = ' + row_item[i])
				  
                               except ValueError as err:
                                  print(" ******** ValueError from VNED: data_row_cnt = " + str(data_row_cnt) + ", Col Header: ' + key + ', Value: " + row_item[i] + ", Error Msg: {0}".format(err))
                                  empty_VNED_row_dict[col_name] = True
                               # } try..
			    else:
                               empty_VNED_row_dict[col_name] = True
			    # } if (row_item[i].strip() != '')..   
                         # } if (found_VNED..
                      # } for i in range(self.n_data_columns)..
                   except ValueError as err:
                      if (data_row_cnt < 5):
                         print(' ******** ValueError: data_row_cnt = ' + str(data_row_cnt) + ', i = ' + str(i) + ', col_name: ' + str(col_name) + ', row_item[i] = ' + row_item[i] + ' Error Msg: {0}'.format(err))
                   except IndexError as err:
                      print(' ******** IndexError: data_row_cnt = ' + str(data_row_cnt) + ', i = ' + str(i) + ', col_name: ' + str(col_name) + ' self.n_data_columns = ' + str(self.n_data_columns) + ', len(row_item) = ' + str(len(row_item)) + ' Error Msg: {0}'.format(err))
                      # sys.exit()
                      # return col_name_array, csv_data, csv_data_bounded_cols, empty_cell_col_array, x8210_flag_on_col_array, heading_type_col_name_array
                   # } try..

                   if (found_VNED):
                      for key in grnd_trc_vel_n_col_name_dict.keys():
			 
                         if (not empty_VNED_row_dict[key]):
                            ekf_8202_struct = ekf_8202_struct_dict[key]
                            vel_NE_mag = math.sqrt(math.pow(ekf_8202_struct.ekf_vned_N, 2) + math.pow(ekf_8202_struct.ekf_vned_E, 2))

                            # if ((abs(ekf_8202_struct.ekf_vned_N) > 0.01 or abs(ekf_8202_struct.ekf_vned_E) > 0.01) and vel_NE_mag > 0.01):
                            # if ((abs(ekf_8202_struct.ekf_vned_N) > 0.1 or abs(ekf_8202_struct.ekf_vned_E) > 0.1) and vel_NE_mag > 0.1):
                            if (vel_NE_mag > 0.5):
                               grnd_trace_angle_calc = math.degrees(math.acos(ekf_8202_struct.ekf_vned_N/vel_NE_mag))

                               # Convert 0 - 180 range Grnd Trace to 0 - 360 range Grnd Trace
                               # by using sign of Grnd Trace Angle and the East component of VNED
                               if (grnd_trace_angle_calc < 0):
                                  grnd_trace_angle_calc = 360.0 + grnd_trace_angle_calc
                               elif (ekf_8202_struct.ekf_vned_E < 0):
                                  grnd_trace_angle_calc = 360.0 - grnd_trace_angle_calc
                               # } if (grnd_trace_angle_calc < 0)..
       
                               grnd_trace_angle_calc_360_bounded_degrees = grnd_trace_angle_calc
       
                               if (convert_to_unbounded_yaw):
                                  if (not grnd_trc_angle_valid_found_dict[grnd_trc_vel_n_col_name_dict[key]]):
                                     grnd_trace_angle_calc_prev_dict[grnd_trc_vel_n_col_name_dict[key]] = grnd_trace_angle_calc
                                     grnd_trc_angle_valid_found_dict[grnd_trc_vel_n_col_name_dict[key]] = True
                                  else:
                                     delta_grnd_trace_calc = (grnd_trace_angle_calc - grnd_trace_angle_calc_prev_dict[grnd_trc_vel_n_col_name_dict[key]])
     
                                     if (delta_grnd_trace_calc < -180.0):
                                        adder_grnd_trace_dict[grnd_trc_vel_n_col_name_dict[key]] += 360.0
                                     elif (delta_grnd_trace_calc > 180.0):
                                        adder_grnd_trace_dict[grnd_trc_vel_n_col_name_dict[key]] -= 360.0
                                     # } if (delta_grnd_trace_calc < -180.0)..

                                     grnd_trace_angle_calc_prev_dict[grnd_trc_vel_n_col_name_dict[key]] = grnd_trace_angle_calc

                                     grnd_trace_angle_calc = grnd_trace_angle_calc + adder_grnd_trace_dict[grnd_trc_vel_n_col_name_dict[key]]

                                  # } if (not grnd_trc_angle_valid_found_dict[grnd_trc_vel_n_col_name_dict[key]])..
          
                                  # fout_grnd_trace.write(',{:-14.8f},{:-14.8f},{:-14.8f}\n'.format(delta_grnd_trace_calc, adder_grnd_trace_calc, grnd_trace_angle_calc))
          
                               # } if (convert_to_unbounded_yaw)..
       
                               csv_data[grnd_trc_vel_n_col_name_dict[key]].append(grnd_trace_angle_calc)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Unbounded'].append(grnd_trace_angle_calc)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_360_Bounded'].append(grnd_trace_angle_calc_360_bounded_degrees)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Orig_in_Deg'].append(grnd_trace_angle_calc)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Orig_Log'].append(grnd_trace_angle_calc)
       
                            else:
                               csv_data[grnd_trc_vel_n_col_name_dict[key]].append(POS_INF)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Unbounded'].append(POS_INF)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_360_Bounded'].append(POS_INF)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Orig_in_Deg'].append(POS_INF)
                               csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Orig_Log'].append(POS_INF)
       
                               if (grnd_trc_vel_n_col_name_dict[key] not in empty_cell_col_array):
                                  empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key])
         
                                  empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_Unbounded')
                                  empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_360_Bounded')
                                  empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_Orig_in_Deg')
                                  empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_Orig_Log')
                               # } if (grnd_trc_vel_n_col_name_dict[key]..
                            # } if (vel_NE_mag > 0.5)..

                            empty_VNED_row_dict[key] = False
                         else:
                            csv_data[grnd_trc_vel_n_col_name_dict[key]].append(POS_INF)
                            csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Unbounded'].append(POS_INF)
                            csv_data[grnd_trc_vel_n_col_name_dict[key] + '_360_Bounded'].append(POS_INF)
                            csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Orig_in_Deg'].append(POS_INF)
                            csv_data[grnd_trc_vel_n_col_name_dict[key] + '_Orig_Log'].append(POS_INF)
    
                            if (grnd_trc_vel_n_col_name_dict[key] not in empty_cell_col_array):
                               empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key])
       
                               empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_Unbounded')
                               empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_360_Bounded')
                               empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_Orig_in_Deg')
                               empty_cell_col_array.append(grnd_trc_vel_n_col_name_dict[key] + '_Orig_Log')

                         # } if (not empty_VNED_row)..
                      # } for (key in grnd_trc_vel_n_col_name_dict.keys())..
                   # } if (found_VNED and ..

                   ekf_8202_struct = EKF_8202_struct()
   
                # } if (len(row_item) > 0)..

             # this row is neither column headers nor data elements
             else:
                # test for DATA_START row (column headers to follow)
                if (len(row_item) > 0 and row_item[0].strip().startswith('DATA_START')):
                   determine_headers = True
                   if ('[other]' in row_item[0].strip().lower()):
                      other_csv = True
                   # } if ('[other]'..   
                # } if (len(row_item) > 0 and..
             # } if (determine_headers)..
      
             row_item_prev = row_item
      
          # } for row_item in csvreader..
  
          for key in grnd_trc_vel_n_col_name_dict.keys():
             print(' ***** GRND TRC key = ' + str(key))
  
          cnt = 0
  
          # Insert interpolated GPS TOW into messages: 03, 04, 06, 07, 08, 09, 36 using GPS TOW of [02] message
          # if csv file contains 'Time_Since_Powerup' columns in both [02] and destination messages
          if ('Time_Since_Powerup [02]' in csv_data.keys()):
     
             col_time_powerup_values_02 = numpy.array([x for i,x in enumerate(csv_data['Time_Since_Powerup [02]']) if x !=POS_INF])
             col_gps_tow_values_02 = numpy.array([x for i,x in enumerate(csv_data['GPS TOW [02]']) if x !=POS_INF])
     
             msg_id_array = [3, 4, 6, 7, 8, 9, 36]
     
             for id in msg_id_array:
                str_msg_id = '{:02d}'.format(id)
        
                gps_week_id_key = 'GPS Week [' + str_msg_id + ']'
                gps_tow_id_key = 'GPS TOW [' + str_msg_id + ']'
                time_since_powerup_key = 'Time_Since_Powerup [' + str_msg_id + ']'

                if ('Time_Since_Powerup [' + str_msg_id + ']' in csv_data.keys()):
                   col_time_powerup_values_id = numpy.array([x for i,x in enumerate(csv_data[time_since_powerup_key]) if x !=POS_INF])
                   csv_data[gps_tow_id_key] = numpy.interp(col_time_powerup_values_id, col_time_powerup_values_02, col_gps_tow_values_02)
        
                   indx = col_name_array_extended.index('Time_Since_Powerup [' + str_msg_id + ']')
                   col_name_array_extended.insert(indx + 1, gps_week_id_key)
                   col_name_array_extended.insert(indx + 2, gps_tow_id_key)
        
                   csv_data[gps_week_id_key] = []
        
                   for x in csv_data[gps_tow_id_key]:
                      csv_data[gps_week_id_key].append(self.gps_week)
                   # } for x in csv_data['GPS TOW [08]']..   
                # } if ('Time_Since_Powerup [08]' in csv_data.keys())..
             # } for id in msg_id_array..
          # } if ('Time_Since_Powerup [02]' in..
  
          for col_name in csv_data.keys():
             if ('x8210' in col_name.lower() and 'flag_' in col_name.lower() and 1 in csv_data[col_name]):
                x8210_flag_on_col_array.append(col_name)
             elif (other_csv):
                valid_column_value_array = numpy.array([x for i,x in enumerate(csv_data[col_name]) if x !=POS_INF])
                if (len(valid_column_value_array) == 0):
                   completely_empty_col_array.append(col_name)
                # } if (len(valid_column_value_array) == 0)..
             # } if ('x8210' in col_name.lower() and 'flag_' in col_name.lower())..
          # } for col_name in csv_data.keys()..

          # Discard x8210 Flag columns that never turned on during the run (to reduce clutter)
          try:
             for col_name in csv_data.keys():
                if ('x8210' in col_name.lower() and 'flag_' in col_name.lower() and col_name not in x8210_flag_on_col_array):
                   csv_data.pop(col_name, None)
                   # col_name_array.remove(col_name)
                   col_name_array_extended.remove(col_name)
                # } if col_name not in..
             # } for col_name in..
          except ValueError as err:
             print(" ******** ValueError from x8210 Flag columns: col_name = " + str(col_name) + ", Error Msg: {0}".format(err))

          # Discard x810C (SV Info) columns for SV's that were never visible during the run (to reduce clutter)
          # for col_name in csv_data.keys():
             # if ('x810c' in col_name.lower() and col_name not in x810C_visible_SV_col_array):
                # csv_data.pop(col_name, None)
                # col_name_array.remove(col_name)
             # } if col_name not in..
          # } for col_name in..
  
          # Discard any 'completely empty column' and its header (to reduce clutter)
          if (len(completely_empty_col_array) > 0):
             for col_name in csv_data.keys():
                if (col_name in completely_empty_col_array):
                   print(' ********* COMPLETELY EMPTY COLUMN: ' + str(col_name))
   
                   csv_data.pop(col_name, None)
                   # col_name_array.remove(col_name)
                   col_name_array_extended.remove(col_name)
                # } if col_name not in..
             # } for col_name in..
          # } if (len(completely_empty_col_array) > 0)..
       # } if (file_name_to_use != None)..
       
       return col_name_array_extended, csv_data, empty_cell_col_array, x8210_flag_on_col_array, heading_type_col_name_array

    def handleTreeWidgetClicked(self, item, column):
       self.blockSignals(True)
       item_parent = item.parent()

       if (item != None):
          if (item.checkState(column) == QtCore.Qt.Checked):
             self.childs_child_count = item.childCount()
             for i in range(self.childs_child_count):
                items_child = item.child(i)
                items_child.setCheckState(0, QtCore.Qt.Checked)
             # } for i in range(self.childs_child_count)..
          elif item.checkState(column) == QtCore.Qt.Unchecked:
             self.childs_child_count = item.childCount()
             for i in range(self.childs_child_count):
                items_child = item.child(i)
                items_child.setCheckState(0, QtCore.Qt.Unchecked)
             # } for i in range(self.childs_child_count)..
          # } if (item.checkState(column) == QtCore.Qt.Checked)..
       # } if (item != None)..
       self.blockSignals(False)

    def fill_item(self, item, value):
       # item.setExpanded(True)
       item.setExpanded(False)

       if (type(value) is dict):
          for key, val in sorted(value.iteritems()):
             child = QtGui.QTreeWidgetItem()
             child.setText(0, unicode(key))
             item.addChild(child)
             self.fill_item(child, val)
          # } for key, val in sorted(value.iteritems())..
       elif type(value) is list:
          for val in value:
             child = QtGui.QTreeWidgetItem()
             item.addChild(child)
             
             if type(val) is dict:
                child.setText(0, '[dict]')
                self.fill_item(child, val)
             elif type(val) is list:
                child.setText(0, '[list]')
                self.fill_item(child, val)
             else:
                child.setText(0, unicode(val))
             # } if type(val) is dict..
     
             child.setExpanded(False)
          # } for val in value..
       else:
          child = QtGui.QTreeWidgetItem()
          child.setText(0, unicode(value))
          item.addChild(child)
       # } if (type(value) is dict)..

    def fill_widget(self, value):
       self.clear()
       self.fill_item(self.invisibleRootItem(), value)

