#import libraries used
from mip import *              #local file should be in local folder
from mip_parser import *       #local file should be in local folder
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM12'
port_baud = 115200    # USE THIS FOR RQ1
# port_baud = 460800  # DON'T USE

# port_name = 'COM4'
# port_baud = 921600   # DON'T USE
# port_baud = 12000000 # USE THIS FOR GX4

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-m' and len(argv) > i+1):
  mode = argv[i+1]

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name,port_baud)

#Close port in case it was left open by other process
port.close()

#open specified port
port.open()

bytes_read = []

while(True):
   bytes_read = port.read()               # Wait forever for anything
   # bytes_read = [];
   sleep(0.002)                           # Sleep [or inWaiting() doesn't give the correct value]

   data_left = port.inWaiting()           # Get the number of characters ready to be read
   if (data_left == 0):
      break;
   else:        
      bytes_read += port.read(data_left)  # Do the read and combine it with the first character

      # mip_parser.write(bytearray(bytes_read))
      # mip_parser.parse_input_buffer()

   # if (mip_parser.get_streaming_enabled() == 1):
     # break;

print(' *************** DONE FLUSHING THE PORT **************** ')
#close port
port.close()


