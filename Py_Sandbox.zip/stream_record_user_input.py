# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

STREAM_REC_USER_INPUT_UNINITIALIZED = 0

class STREAM_REC_USER_INPUT(object):
   #default 'constructor'
   def __init__(self):
      """Class default initialization function"""
      try:
         self.init()
      except:
         self.state = STREAM_REC_USER_INPUT_UNINITIALIZED

   #class initializer function
   def init(self):
      """Class initialization function"""
      
      self.streaming_on = False
      self.recording_on = False
      self.filter_status = ''
      self.imu_status = ''
      self.gnss_status = ''


