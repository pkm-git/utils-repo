import threading       #import thread library
import random
from time import time  #import time library
from time import sleep           #sleep

class Producer(threading.Thread):
    # Produces random integers to a list
    def __init__(self, integers, condition):
        threading.Thread.__init__(self)
        self.integers = integers
        self.condition = condition

    def run(self):
        # Thread run method. Append random integers to the integers list at random time.
        while True:
            integer = random.randint(0, 256)
            self.condition.acquire()
            print 'condition acquired by %s' % self.name
            self.integers.append(integer)
            print '%d appended to list by %s' % (integer, self.name)
            print 'condition notified by %s' % self.name
            self.condition.notify()
            print 'condition released by %s' % self.name
            self.condition.release()
            sleep(1)

