# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# To create .exe, call the following command at a folder that has all source files:
#   python setup.py py2exe

from distutils.core import setup
import py2exe

import numpy
import os
import sys

# add any numpy directory containing a dll file to sys.path
def numpy_dll_paths_fix():
    paths = set()
    np_path = numpy.__path__[0]
    for dirpath, _, filenames in os.walk(np_path):
        for item in filenames:
            if item.endswith('.dll'):
                paths.add(dirpath)

    sys.path.append(*list(paths))

numpy_dll_paths_fix()

excludes = ["PyQt4.uic.port_v3", "Tkconstants","Tkinter","tcl", \
            "email", "future", "matplotlib", "OpenGL", "setuptools"]

dll_excludes = ["MSVCP90.dll", "HID.DLL", "w9xpopen.exe", "IPHLPAPI.DLL", "NSI.dll",  "WINNSI.DLL",  "WTSAPI32.dll", "mswsock.dll", "powrprof.dll", "user32.dll", "shell32.dll", "wsock32.dll", "advapi32.dll", "kernel32.dll", "ntwdblib.dll", "ws2_32.dll", "oleaut32.dll", "ole32.dll"]

setup(windows=[{"script" : "QInertialSensorUtils_GUI.py"}], data_files = ['./close_icon.png', './icon_stream.png', './icon_stop.png', './icon_stream_hover.png', './icon_stop_hover.png', './icon_record_hover.png', './icon_record.png', './icon_refresh.png', './icon_stream_enable_border.png', './icon_record_enable_border.png', './icon_stop_enable_border.png', 'Inertial Sensor Utils (8500-0079).pdf', 'LICENSE.txt', 'LICENSE_GPLv3_PyQt4.txt', 'LICENSE_Python_2_7_6.txt'], options={"py2exe" : {"includes" : ['sip', 'PyQt4.QtCore', 'PyQt4.QtGui', 'psutil'], "dll_excludes": dll_excludes, "excludes": excludes}})


