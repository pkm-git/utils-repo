#include <QtGui/QApplication>
#include <QtGui/QMainWindow>
#include <QtGui/QVBoxLayout>
#include <QtGui/QPushButton>
#include <QtCore/QFile>

int main(int ArgC, char* ArgV[])
{
   QApplication MyApp(ArgC, ArgV);

   QMainWindow* pWindow = new QMainWindow;
   QVBoxLayout* pLayout = new QVBoxLayout(pWindow);
   pWindow->setLayout(pLayout);

   QPushButton* pButton = new QPushButton("Test", pWindow);
   pLayout->addWidget(pButton);

   QFile file(".");
   file.open(QFile::ReadOnly);
   QString styleSheet = QLatin1String(file.readAll());

   qApp->setStyleSheet(styleSheet);

   pWindow->setVisible(true);
   MyApp.exec();
}
