import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

class MyNRTSIMTab5FormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyNRTSIMTab5FormWidget, self).__init__(parent)
      self.parent_obj = parent
      
      # self.setFixedSize(550,250)
      # self.setFixedSize(575,200)
      self.setFixedSize(600,175)

      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyNRTSIMTab5FormWidget window"

      super(MyNRTSIMTab5FormWidget, self).closeEvent(event)

   def __controls(self):

      self.declare_spaces()
      
      # REF: accelwn_x=0.1 accelwn_y=0.1 accelwn_z=0.1 accelmarkovbeta_x=0.0 accelmarkovbeta_y=0.0 accelmarkovbeta_z=0.0 accelmarkovbetasigma_x=0.00001 accelmarkovbetasigma_y=0.00001 accelmarkovbetasigma_z=0.00001 gyrown_x=0.001 gyrown_y=0.001 gyrown_z=0.001 gyromarkovbeta_x=0.0 gyromarkovbeta_y=0.0 gyromarkovbeta_z=0.0 gyromarkovbetasigma_x=0.00001 gyromarkovbetasigma_y=0.00001 gyromarkovbetasigma_z=0.00001       
      self.lbl_accel_noise = QtGui.QLabel("Accel Noise [X/Y/Z] (m/s" + u"\u00B2" + "):")
      self.lbl_accel_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_accel_noise.setFixedSize(175,30)
      
      self.edt_accel_noise_x = MyLineEdit()
      self.edt_accel_noise_x.setStyleSheet("background-color: white;");
      self.edt_accel_noise_x.setFixedSize(60,20)
      
      self.edt_accel_noise_y = MyLineEdit()
      self.edt_accel_noise_y.setStyleSheet("background-color: white;");
      self.edt_accel_noise_y.setFixedSize(60,20)
      
      self.edt_accel_noise_z = MyLineEdit()
      self.edt_accel_noise_z.setStyleSheet("background-color: white;");
      self.edt_accel_noise_z.setFixedSize(60,20)

      self.lbl_accel_bias_beta = QtGui.QLabel("Accel Bias Beta [X/Y/Z] (1/s):")
      self.lbl_accel_bias_beta.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_accel_bias_beta.setFixedSize(175,30)
      
      self.edt_accel_bias_beta_x = MyLineEdit()
      self.edt_accel_bias_beta_x.setStyleSheet("background-color: white;");
      self.edt_accel_bias_beta_x.setFixedSize(60,20)
      
      self.edt_accel_bias_beta_y = MyLineEdit()
      self.edt_accel_bias_beta_y.setStyleSheet("background-color: white;");
      self.edt_accel_bias_beta_y.setFixedSize(60,20)

      self.edt_accel_bias_beta_z = MyLineEdit()
      self.edt_accel_bias_beta_z.setStyleSheet("background-color: white;");
      self.edt_accel_bias_beta_z.setFixedSize(60,20)

      self.lbl_accel_bias_noise = QtGui.QLabel("Accel Bias Noise [X/Y/Z](m/s" + u"\u00B2" + "):")
      self.lbl_accel_bias_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_accel_bias_noise.setFixedSize(175,30)
      
      self.edt_accel_bias_noise_x = MyLineEdit()
      self.edt_accel_bias_noise_x.setStyleSheet("background-color: white;");
      self.edt_accel_bias_noise_x.setFixedSize(60,20)

      self.edt_accel_bias_noise_y = MyLineEdit()
      self.edt_accel_bias_noise_y.setStyleSheet("background-color: white;");
      self.edt_accel_bias_noise_y.setFixedSize(60,20)

      self.edt_accel_bias_noise_z = MyLineEdit()
      self.edt_accel_bias_noise_z.setStyleSheet("background-color: white;");
      self.edt_accel_bias_noise_z.setFixedSize(60,20)

      self.lbl_gyro_noise = QtGui.QLabel("Gyro Noise [X/Y/Z] (rad/s):")
      self.lbl_gyro_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_gyro_noise.setFixedSize(175,30)
      
      self.edt_gyro_noise_x = MyLineEdit()
      self.edt_gyro_noise_x.setStyleSheet("background-color: white;");
      self.edt_gyro_noise_x.setFixedSize(60,20)
      
      self.edt_gyro_noise_y = MyLineEdit()
      self.edt_gyro_noise_y.setStyleSheet("background-color: white;");
      self.edt_gyro_noise_y.setFixedSize(60,20)
      
      self.edt_gyro_noise_z = MyLineEdit()
      self.edt_gyro_noise_z.setStyleSheet("background-color: white;");
      self.edt_gyro_noise_z.setFixedSize(60,20)

      
      self.lbl_gyro_bias_beta = QtGui.QLabel("Gyro Bias Beta [X/Y/Z] (1/s):")
      self.lbl_gyro_bias_beta.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_gyro_bias_beta.setFixedSize(175,30)
      
      self.edt_gyro_bias_beta_x = MyLineEdit()
      self.edt_gyro_bias_beta_x.setStyleSheet("background-color: white;");
      self.edt_gyro_bias_beta_x.setFixedSize(60,20)

      self.edt_gyro_bias_beta_y = MyLineEdit()
      self.edt_gyro_bias_beta_y.setStyleSheet("background-color: white;");
      self.edt_gyro_bias_beta_y.setFixedSize(60,20)

      self.edt_gyro_bias_beta_z = MyLineEdit()
      self.edt_gyro_bias_beta_z.setStyleSheet("background-color: white;");
      self.edt_gyro_bias_beta_z.setFixedSize(60,20)


      self.lbl_gyro_bias_noise = QtGui.QLabel("Gyro Bias Noise [X/Y/Z] (rad/s):")
      self.lbl_gyro_bias_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_gyro_bias_noise.setFixedSize(175,30)
      
      self.edt_gyro_bias_noise_x = MyLineEdit()
      self.edt_gyro_bias_noise_x.setStyleSheet("background-color: white;");
      self.edt_gyro_bias_noise_x.setFixedSize(60,20)

      self.edt_gyro_bias_noise_y = MyLineEdit()
      self.edt_gyro_bias_noise_y.setStyleSheet("background-color: white;");
      self.edt_gyro_bias_noise_y.setFixedSize(60,20)

      self.edt_gyro_bias_noise_z = MyLineEdit()
      self.edt_gyro_bias_noise_z.setStyleSheet("background-color: white;");
      self.edt_gyro_bias_noise_z.setFixedSize(60,20)
      
      self.setNoiseValues()
      
   def setNoiseValues(self):

      self.edt_accel_noise_x.setText(self.parent_obj.noise_data.accel_noise_x)
      self.edt_accel_noise_y.setText(self.parent_obj.noise_data.accel_noise_y)
      self.edt_accel_noise_z.setText(self.parent_obj.noise_data.accel_noise_z)
      
      if (self.parent_obj.nrtsim_form_widget.device_name == 'GX5-45'):
         self.edt_accel_bias_beta_x.setText(self.parent_obj.noise_data.accel_bias_beta_x)
         self.edt_accel_bias_beta_y.setText(self.parent_obj.noise_data.accel_bias_beta_y)
         self.edt_accel_bias_beta_z.setText(self.parent_obj.noise_data.accel_bias_beta_z)

         self.edt_accel_bias_noise_x.setText(self.parent_obj.noise_data.accel_bias_noise_x)
         self.edt_accel_bias_noise_y.setText(self.parent_obj.noise_data.accel_bias_noise_y)
         self.edt_accel_bias_noise_z.setText(self.parent_obj.noise_data.accel_bias_noise_z)
 
         self.edt_accel_bias_beta_x.setReadOnly(False)
         self.edt_accel_bias_beta_y.setReadOnly(False)
         self.edt_accel_bias_beta_z.setReadOnly(False)
         
         self.edt_accel_bias_noise_x.setReadOnly(False)
         self.edt_accel_bias_noise_y.setReadOnly(False)
         self.edt_accel_bias_noise_z.setReadOnly(False)

      else:
         self.edt_accel_bias_beta_x.setText('')
         self.edt_accel_bias_beta_y.setText('')
         self.edt_accel_bias_beta_z.setText('')

         self.edt_accel_bias_noise_x.setText('')
         self.edt_accel_bias_noise_y.setText('')
         self.edt_accel_bias_noise_z.setText('')
 
         self.edt_accel_bias_beta_x.setReadOnly(True)
         self.edt_accel_bias_beta_y.setReadOnly(True)
         self.edt_accel_bias_beta_z.setReadOnly(True)
         
         self.edt_accel_bias_noise_x.setReadOnly(True)
         self.edt_accel_bias_noise_y.setReadOnly(True)
         self.edt_accel_bias_noise_z.setReadOnly(True)

      # } if (self.parent_obj..device_name == 'GX5-45')..
      
      self.edt_gyro_noise_x.setText(self.parent_obj.noise_data.gyro_noise_x)
      self.edt_gyro_noise_y.setText(self.parent_obj.noise_data.gyro_noise_y)
      self.edt_gyro_noise_z.setText(self.parent_obj.noise_data.gyro_noise_z)

      self.edt_gyro_bias_beta_x.setText(self.parent_obj.noise_data.gyro_bias_beta_x)
      self.edt_gyro_bias_beta_y.setText(self.parent_obj.noise_data.gyro_bias_beta_y)
      self.edt_gyro_bias_beta_z.setText(self.parent_obj.noise_data.gyro_bias_beta_z)

      self.edt_gyro_bias_noise_x.setText(self.parent_obj.noise_data.gyro_bias_noise_x)
      self.edt_gyro_bias_noise_y.setText(self.parent_obj.noise_data.gyro_bias_noise_y)
      self.edt_gyro_bias_noise_z.setText(self.parent_obj.noise_data.gyro_bias_noise_z)


   def __layout(self):

      self.vNRTSIMFirstColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_accel_noise)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_accel_bias_beta)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_accel_bias_noise)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_gyro_noise)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_gyro_bias_beta)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_gyro_bias_noise)
      
      self.vNRTSIMSecondColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_accel_noise_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_accel_bias_beta_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_accel_bias_noise_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_gyro_noise_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_gyro_bias_beta_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_gyro_bias_noise_x)

      self.vNRTSIMThirdColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_accel_noise_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_accel_bias_beta_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_accel_bias_noise_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_gyro_noise_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_gyro_bias_beta_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_gyro_bias_noise_y)
      
      self.vNRTSIMFourthColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_accel_noise_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_accel_bias_beta_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_accel_bias_noise_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_gyro_noise_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_gyro_bias_beta_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_gyro_bias_noise_z)
      
      self.vNRTSIMBottomRowLayout = QtGui.QHBoxLayout()
      self.vNRTSIMBottomRowLayout.addWidget(self.lbl_space_medium)

      self.vNRTSIMBottomRowWidget = QtGui.QWidget()
      self.vNRTSIMBottomRowWidget.setLayout(self.vNRTSIMBottomRowLayout)
      self.vNRTSIMBottomRowWidget.setFixedSize(575,10)

      self.hNRTSIMOptionsBox = QtGui.QHBoxLayout()
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMFirstColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMSecondColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMThirdColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMFourthColumnBox)
      self.hNRTSIMOptionsBox.addWidget(self.lbl_space_small)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.hNRTSIMOptionsBox)
      self.vbox.addWidget(self.vNRTSIMBottomRowWidget)

      self.setLayout(self.vbox)

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)
