import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder
from mip_parser import *         #local file should be in local folder

from time import sleep           #sleep
from time import time  #import time library

from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

from struct import * #import all objects and functions from the struct library

import numpy

fin_bin = open("U:\Lord\Python_HIL_Sim_From_File\Vehicle_Logs\10_01_2015\RTSIM\GX4-45\2015_11_09\3DM-GX4-45 6236.46589 Data Log 11-9-2015 10.14.24 AM.bin", "rb")

fout_imu = open("U:\Lord\Python_HIL_Sim_From_File\Vehicle_Logs\10_01_2015\RTSIM\GX4-45\2015_11_09\GX4-45_Veh_IMU_Log_wHeaders_11-9-2015 10.14.24 AM_None.csv", "w")
fout_gps = open("U:\Lord\Python_HIL_Sim_From_File\Vehicle_Logs\10_01_2015\RTSIM\GX4-45\2015_11_09\GX4-45_Veh_GPS_Log_wHeaders_11-9-2015 10.14.24 AM_None.csv", "w")
fout_ekf = open("U:\Lord\Python_HIL_Sim_From_File\Vehicle_Logs\10_01_2015\RTSIM\GX4-45\2015_11_09\GX4-45_Veh_EKF_Log_wHeaders_11-9-2015 10.14.24 AM_None.csv", "w")

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 print("****** mip_parser_callback: callback_type = " + str(callback_type))
 print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
  # print('Time: ' + str(time()) + ', Time from start: ' + str(time() - start_time) + ', Valid Packet Found')
  print('Valid Packet Found')

  #loop over fields in received valid packet
  for field in mip_get_next_field(packet_bytes):
   # [state_unpacked, tow_unpacked, x1,x2,x3,x4,x5,x6] = unpack('<iHdfffff', bytearray(bytes_read[k+2:k+(16+6*4)]) )
   # fout_imu.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(state_unpacked,tow_unpacked,z1,z2,z3,z4,z5,z6) )
   # print(state_unpacked = ' + str(state_unpacked) + ', TOW: ' + str(tow_unpacked) )

   #if this field is an ack/nack output it to show the user
   if (field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):  # 0xF1
     print('field[1]: ' + str(field[1]) + ', Device response to command: (' + hex(field[2]).upper() + ') = '\
        + mip_ack_nacks[field[3]])
   elif (field[1] == MIP_REPLY_DESC_ENABLE_DISABLE_STREAMING_DATA_VALUE): # 0x85
   # if (field[1] == MIP_REPLY_DESC_ENABLE_DISABLE_STREAMING_DATA_VALUE): # 0x85
     mip_parser.set_streaming_enabled(field[3])
     print('field[1]: ' + str(field[1]) + ', Device: (' + hex(field[2]).upper() + ') = ' + str(field[3]))
          # + mip_enable_disable[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

start_time = time()
print(' ************* Parse MIP Binary Log: start_time = ' + str(start_time) );

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

# bytes_read = bytearray([])

bytes_read = fin_bin.read();

print(' ********** All bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

mip_parser.write(bytearray(streaming_enabled_bytes_read))
mip_parser.parse_input_buffer()

# ComPort.write(read_filter_streaming_onoff_command)
sleep(1)

# sleep(0.002)                         # Sleep [or inWaiting() doesn't give the correct value]

% [time_unpacked, state_unpacked, tow_unpacked, x1,x2,x3,x4,x5,x6] = unpack('<iHdffffff', bytearray(bytes_read[k+2:k+(16+6*4)]) )

mip_parser.write(bytearray(bytes_read))
mip_parser.parse_input_buffer()

# fout.write(hexlify(bytearray(bytes_read)).upper())
# fout_bin.write(bytearray(bytes_read))

# fout_z.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,z1,z2,z3,z4,z5,z6) )

end_time = time()
print(' ************* Parse MIP Binary Log: end_time = ' + str(end_time) );

# **********************************************************************************************

k_start = 0

# packet_size = 437
packet_size = 438

for k in range(0, len(bytes_read)):
   if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
      print(' ***** Found first 0x75 0x65 pair\n')
      k_start = k;
      break;

print(' ************ k_start = ' + str(k_start) )

# for k in range(k_start,len(bytes_read)):

bad_data = 0

i = 0
bad_packets = 0
k = k_start

while (k < len(bytes_read)):
  # print(hexlify(bytearray(bytes_read[k+2:k+6])).upper()) + '  '  + hexlify(bytearray(bytes_read[k+6:k+14])).upper()))

  # if (bad_data == 1 and bad_packets == 1 and k < 4850):
     # print('**** k = ' + str(k) + ', Bytes: ' + hexlify( bytearray(bytes_read[k]) ).upper() + '  '  + hexlify( bytearray(bytes_read[k+1]) ).upper()   )

  if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '62'):

     bad_data = 0

     # if ( k+411 < len(bytes_read) ):
     if (k+(packet_size-1) < len(bytes_read)):

        # [time_unpacked, tow_unpacked] = unpack('<id', bytearray( bytes_read[k+2:k+14] ) )
        [time_unpacked, state_unpacked, tow_unpacked, x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,x20,x21,x22,x23,x24,x25] = unpack('<iHdfffffffffffffffffffffffff', bytearray(bytes_read[k+2:k+(16+25*4)]) )
        [P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25] = unpack('<fffffffffffffffffffffffff', bytearray(bytes_read[k+116:k+216]) )
        [P_meas1,P_meas2,P_meas3,P_meas4,P_meas5,P_meas6,P_meas7,P_meas8,P_meas9,P_meas10,P_meas11,P_meas12,P_meas13,P_meas14,P_meas15,P_meas16,P_meas17,P_meas18,P_meas19,P_meas20,P21,P22,P23,P24,P25] = unpack('<fffffffffffffffffffffffff', bytearray(bytes_read[k+216:k+316]) )
        [Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10,Q11,Q12] = unpack('<ffffffffffff', bytearray(bytes_read[k+316:k+364]) )
        [z1,z2,z3,z4,z5,z6] = unpack('<ffffff', bytearray(bytes_read[k+364:k+388]) )
        [y1,y2,y3,y4,y5,y6] = unpack('<ffffff', bytearray(bytes_read[k+388:k+412]) )
        [R1,R2,R3,R4,R5,R6] = unpack('<ffffff', bytearray(bytes_read[k+412:k+436]) )

        print(' k = ' + str(k) + ' Global Time (ms): ' + str(time_unpacked) + ', state_unpacked = ' + str(state_unpacked) + ', TOW: ' + str(tow_unpacked) )

        fout_x.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,x20,x21,x22,x23,x24,x25) )
        fout_P.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25) )
        fout_P_meas.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,P_meas1,P_meas2,P_meas3,P_meas4,P_meas5,P_meas6,P_meas7,P_meas8,P_meas9,P_meas10,P_meas11,P_meas12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25) )
        fout_Q.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8,Q9,Q10,Q11,Q12) )
        fout_z.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,z1,z2,z3,z4,z5,z6) )
        fout_y.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,y1,y2,y3,y4,y5,y6) )
        fout_R.write('%9d,%d,%10.3f,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e,%12.7e\n'%(time_unpacked,state_unpacked,tow_unpacked,R1,R2,R3,R4,R5,R6) )

        i = i + 1
        # k = k + 412
        k = k + packet_size
     else:
        bad_data = 1
        bad_packets = bad_packets + 1
        print(' ******** k = ' + str(k) + ', Bad Data found')
        # k = k + 413
        k = k + packet_size + 1
  else:
     k = k + 1

# fin_bin.read(bytearray(bytes_read))

print ('****************** Nbr of valid packets = ' + str(i) + ', Nbr of bad packets = ' + str(bad_packets))

fin_bin.close()

fout_imu.close()
fout_gps.close()
fout_ekf.close()

