import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from time import sleep           #sleep
from time import time  #import time library

fout = open("C:\MP\Lord\Python_HIL_Sim_From_File\GX4_RT_Port_Dump.txt", "w")

ComPort = serial.Serial('COM4')  # open the COM Port

ComPort.baudrate = 921600        # set Baud rate
ComPort.bytesize = 8             # Number of data bits = 8
ComPort.parity   = 'N'           # No parity
ComPort.stopbits = 1             # Number of Stop bits = 1

start_time = time()
print(' ************* GX4 read no async: start_time = ' + str(start_time) );

cnt = 0

while(cnt < 200):
  bytes_read = ComPort.read()            # Wait forever for anything
  sleep(0.002)                           # Sleep [or inWaiting() doesn't give the correct value]

  data_left = ComPort.inWaiting()        # Get the number of characters ready to be read
  bytes_read += ComPort.read(data_left)  # Do the read and combine it with the first character

  # if (hexlify(bytes_read[0]).upper() == 'B5' and hexlify(bytes_read[1]).upper() == '62'):
  # bytes_read = ComPort.read(ComPort.inWaiting())
  # print('********************** Packet: ' + hexlify(bytearray(bytes_read)).upper())

  fout.write(hexlify(bytearray(bytes_read)).upper())
  # fout.write(bytes_read)
  cnt = cnt + 1

end_time = time()
print(' ************* GX4 read no async: end_time = ' + str(end_time) );


# print(' *************** LENGTH OF BYTES READ = ' + str(len(bytes_read)));

# read_time = time()
# print('********** GX4_rt_read: Read time: ' + str(read_time));

# while ComPort.inWaiting() > 0:
  # out += ComPort.read(1)
  # byte_reply = bytearray(ComPort.read(ComPort.inWaiting()))
  # data = ComPort.readline(ComPort.inWaiting())        # Wait and read data
  # print('********************** data: ' + hexlify(bytearray(data)).upper())
  # sleep(0.003)

#ComPort.close()                  # Close the COM Port

fout.close()
