# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import sys
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from novatel_csv_format_using_dict import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

from sensor_cloud_api import *

import numpy
import math
import os
import re
import psutil

import struct

NBR_OF_LEAP_SECONDS_2016 = 17 # (as of July 2016)
NBR_OF_LEAP_SECONDS = 18 # (as of Jan 2017)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800
MAX_ROWS_SENSOR_CLOUD_UPLOAD = 100000

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

def novatel_binary_to_csv_or_sensor_cloud_fn(in_file_name, destination, output_category = None, server = None, token = None, device_id = None, sensor_name = None, sensor_label = None, sampleRate = 0, sampleRateType = HERTZ):

   print('\n------------------------------------------------------------------')
   print( ' ********* destination = ' + destination)

   short_header_length = 12
   long_header_length = 28

   # Grouping of Messages:

   # ----------
   # EKF Group:
   # ----------
   # 42: BESTPOS
   # 99: BESTVEL
   # 241: BESTXYZ

   # --------------------------------------------
   # INS Group: [Long/Short Header Message Pairs]
   # --------------------------------------------
   # 263: INSATT
   # 319: INSATTS

   # 265: INSPOS
   # 321: INSPOSS

   # 266: INSSPD
   # 323: INSSPDS

   # 267: INSVEL
   # 324: INSVELS

   # 507: INSPVA
   # 508: INSPVAS

   # -------------
   # RAWIMU Group:
   # -------------
   # 268: RAWIMU
   # 325: RAWIMUS

   # ----------
   # GPS Group:
   # ----------
   # 101: TIME (UTC-related)

   # -----------------------
   # Veh2BodyRotation Group:
   # -----------------------
   # 642: VEHICLEBODYROTATION

   # Define "Master columns" (i.e. subset, consisting of 'minimum' or 'important' columns in DCP) in a "master sequence"
   min_gps_default_cols_dict = {321:1, 42:2, 324:3, 323:4, 99:5, 241:6, 319:7, 508:8, 325:9, 101:10, 642:11}

   # Map message id's of long header messages to message id of corresponding short header message (and use only the short header msg id beyond that point)
   min_gps_default_long2shorthdr_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

   gyro_scale_factor = 0.1/(3600.0 * 256.0)
   accel_scale_factor = 0.05/(2**15)

   # if arguments sent in were not properly specified, tell the user and exit
   if (in_file_name == None or (output_category != None and output_category not in ['i', 'e', 'r', 'g', 'v'])):
      print('Input file name cannot be empty and output_category must be one of: i, e, r, g')
      sys.exit()
   # } if (in_file_name == None..
   
   (fin_filepath, fin_filename) = os.path.split(in_file_name)
   
   if ('.' in fin_filename):
      INS_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_INS_Log.csv")
      EKF_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_EKF_Log.csv")
      RAWIMU_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_RAWIMU_Log.csv")
      GPS_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_GPS_Log.csv")
      Veh2BodyRotation_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_Veh2BodyRotation_Log.csv")
   else:
      INS_filename = os.path.join(fin_filepath, fin_filename + "_INS_Log.csv")
      EKF_filename = os.path.join(fin_filepath, fin_filename + "_EKF_Log.csv")
      RAWIMU_filename = os.path.join(fin_filepath, fin_filename + "_RAWIMU_Log.csv")
      GPS_filename = os.path.join(fin_filepath, fin_filename + "_GPS_Log.csv")
      Veh2BodyRotation_filename = os.path.join(fin_filepath, fin_filename + "_Veh2BodyRotation_Log.csv")
   # } if ('.' in fin_filename)..
   
   # out_type_file_name_dict = {'i':"INS_Log.csv", 'e':"EKF_Log.csv", 'r':"RAWIMU_Log.csv", 'g':"GPS_Log.csv", 'v':"Veh2BodyRotation.csv"}
   out_type_file_name_dict = {'i':INS_filename, 'e':EKF_filename, 'r':RAWIMU_filename, 'g': GPS_filename, 'v':Veh2BodyRotation_filename}
   output_category_dict = {'i':"INS", 'e':"EKF", 'r':"RAWIMU", 'g':"GPS", 'v':"Veh2BodyRot"}

   sensStatus = 0
   if (destination != None):
      if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
         if (sensor_name == None):
            print(' ***** Must provide valid Sensor Name for SensorCloud Upload')
            sys.exit()
         else:
            # Spaces not allowed in Sensor Name, replace with _:
            sensor_name = sensor_name.strip().replace(" ", "_")
            sensor_name = sensor_name.replace("/", "_")

            # All characters other than (AlphaNumeric, _, -, and .): Replace with empty char:
            sensor_name = re.sub(r'[^a-zA-Z0-9_.-]', r'', sensor_name)

            if(sensor_label != None):
               sensStatus = addSensor(server, token, device_id, sensor_name, "", sensor_label)
            else:
               sensStatus = addSensor(server, token, device_id, sensor_name)

            print(' ********** addSensor: status = ' + str(sensStatus))
         # } if (sensor_name == None)..
      # } if (destination.upper() == 'CLOUD'..
      if (destination.upper() != 'CSV' and destination.upper() != 'CLOUD' and destination.upper() != 'BOTH'):
         print(' ******* Destination must be either CSV, CLOUD or BOTH (case-insensitive) ********')
         sys.exit()
      # } if (destination.upper() != 'CSV'..
   else:
      print(' ******* Destination cannot be None; must be CSV, CLOUD or BOTH (case-insensitive) ********')
      sys.exit()
   # } if (destination != None)..

   # Create an array of output categories (INS, EKF, RAWIMU, GPS)
   out_category_array = []

   if (output_category == None):
      out_category_array.append('i')  # INS (INSATT, INSPOS, INSVEL, INSPVA)
      out_category_array.append('e')  # EKF (BESTPOS, BESTVEL, BESTXYZ)
      out_category_array.append('r')  # RAWIMU
      out_category_array.append('g')  # GPS (TIME)
      out_category_array.append('v')  # Veh2BodyRotation (VEHICLEBODYROTATION)
   else:
      out_category_array.append(output_category)
   # } if (output_category == None)..
   
   found_bad_pkt = False
   message_cnt_of_bad_pkt = 0
   
   # Loop thro binary input file for each output category (INS, EKF, RAWIMU, GPS and Veh2BodyRotation):
   for output_category in out_category_array:
      if (found_bad_pkt and output_category != 'e'):
         # sys.exit()
         return
 
      print(' ******************************************************* ')
      print(' **************** output_category = ' + output_category_dict[output_category] + ', found_bad_pkt = ' + str(found_bad_pkt))
      print(' ******************************************************* ')

      # Array of channel names and channel data to send to Sensor Cloud (for this output_category)
      channel_names = []
      channel_data = {sensor_name:{}}

      # Dictionary to store array of range of indices of channels by message master sequence index
      channel_index_range_dict = {}

      # Array to store the order of columns requested by the user (in binary log file):
      novatel_output_order_in_log = []

      # Array to store final, sorted output column order based on 'master sequence'
      novatel_output_order_final = []

      # Add GPS Week, GPS TOW for every category
      novatel_output_order_in_log.append(0)

      headers_printed = False

      gps_valid_tow_found = False

      novatel_format_dict_array = []
      novatel_format_dict = {}
      novatel_format_using_dict = Novatel_CSV_format_using_dict()
      novatel_timestamp_struct = Novatel_Timestamp_struct()

      [novatel_timestamp_struct, novatel_321_struct, novatel_42_struct, novatel_324_struct, novatel_323_struct, novatel_99_struct] = \
           [Novatel_Timestamp_struct(), Novatel_321_struct(), Novatel_42_struct(), Novatel_324_struct(), Novatel_323_struct(), Novatel_99_struct()]
      [novatel_241_struct, novatel_319_struct, novatel_508_struct, novatel_325_struct, novatel_101_struct, novatel_642_struct] = \
           [Novatel_241_struct(), Novatel_319_struct(), Novatel_508_struct(), Novatel_325_struct(), Novatel_101_struct(), Novatel_642_struct()]

      file_size = os.path.getsize(in_file_name)

      print(' ************ input file_size = ' + str(file_size))

      fin_bin = open(in_file_name, "rb")

      if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
         out_file_name = out_type_file_name_dict[output_category]
         fout_novatel = open(os.path.join(fin_filepath, out_file_name), "w")
      # } if (destination.upper() == 'CSV'..
      
      message_id_array = []
      if (output_category == 'i'):
         message_id_array = [321, 323, 324, 319, 508]
      elif (output_category == 'g'):
         message_id_array = [101]
      elif (output_category == 'e'):
         message_id_array = [42, 99, 241]
      elif (output_category == 'r'):
         message_id_array = [325]
      elif (output_category == 'v'):
         message_id_array = [642]
      # } if (output_category == 'i')..
      
      message_id_found_array = []
      
      # found_bad_pkt = False
      # message_cnt_of_bad_pkt = 0
      
      total_channel_cnt = 0

      k_start = 0

      svmem_obj = psutil.virtual_memory()

      # For sake of safety, consider 70% of free memory as available for this program
      avail_mem = numpy.uint64(0.7 * svmem_obj.free)

      # *************** TEST ONLY *************
      # avail_mem = 1000000

      print(' ********** Free memory: ' + str(svmem_obj.free) + ', Available memory: ' + str(avail_mem))

      if (avail_mem < file_size):
         nbr_of_loops = int(math.ceil(numpy.float(file_size)/avail_mem))
      else:
         nbr_of_loops = 1
      # } if (avail_mem < file_size)..

      print(' ************ Novatel nbr_of_loops = ' + str(nbr_of_loops))

      bytes_read_trunc = None
      bytes_read_chopped_off = None
      found_last_Novatel_pkt_prev = False

      total_message_cnt = 0
      message_cnt = 0
      message_set_cnt = 0
      temp_tow_ms_prev = 0
      crossed_40_sec = False
      found_first_tow = False
      init_tow = 0.0

      for n in range(nbr_of_loops):
         if (avail_mem < file_size):
            bytes_read = fin_bin.read(avail_mem)

            print('\n ****** LOOP n = ' + str(n) + ', len(bytes_read) = ' + str(len(bytes_read)))
            found_last_Novatel_pkt = False
            k_start_of_last_Novatel_pkt = 0
            k = len(bytes_read)-1

            # Find where last Novatel packet begins in current block of bytes
            # and chop off that packet till end of block, for use with next block of bytes
            while(k > 1):
               if (hexlify(bytearray(bytes_read[k-2])).upper() == 'AA' and hexlify(bytearray(bytes_read[k-1])) == '44' and \
                  (hexlify(bytearray(bytes_read[k])) == '12' or hexlify(bytearray(bytes_read[k])) == '13')):

                  print(' ***** Found last [0xAA 44 12 OR 0xAA 44 13] Novatel trio at byte index: k-2: ' + str(k-2))
                  k_start_of_last_Novatel_pkt = k-2
                  found_last_Novatel_pkt = True
                  break;
               k = k - 1
            # } while(k > 1)..

            if (found_last_Novatel_pkt):
               bytes_read_to_use = []

               # First add chopped off bytes from previous read
               if (found_last_Novatel_pkt_prev and bytes_read_chopped_off != None):
                  print(' ******** first 3 bytes of bytes_read_chopped_off being added = ' + hexlify(bytes_read_chopped_off[:3]).upper())
                  bytes_read_to_use.extend(bytes_read_chopped_off)
               # } if (found_last_Novatel_pkt_prev..
               
               # If last block of bytes, take ALL bytes (no need to chop off last MIP packet from it)
               if (n == nbr_of_loops-1):
                  bytes_read_to_use.extend(bytes_read)
               else:
                  bytes_read_trunc = bytes_read[:k_start_of_last_Novatel_pkt]
                  print(' ******** last 3 bytes of bytes_read_trunc = ' + hexlify(bytes_read_trunc[-3:]).upper())

                  # Now add the truncated bytes from current read
                  bytes_read_to_use.extend(bytes_read_trunc)
               # } if (n == nbr_of_loops-1)..

               # if (found_last_Novatel_pkt_prev and bytes_read_chopped_off != None):
                  # print(' ************* LOOP n = ' + str(n) + ', from previous read, len(bytes_read_chopped_off) = ' + str(len(bytes_read_chopped_off)) + ', curr read: len(bytes_read_trunc) = ' + str(len(bytes_read_trunc)) + ', NET effect: len(bytes_read_to_use) = ' + str(len(bytes_read_to_use)) )
               # else:
                  # print(' ************* LOOP n = ' + str(n) + ', curr read: len(bytes_read_trunc) = ' + str(len(bytes_read_trunc)) + ', NET effect: len(bytes_read_to_use) = ' + str(len(bytes_read_to_use)) )
               # } if (found_last_Novatel_pkt_prev..
               
               bytes_read_chopped_off = bytes_read[k_start_of_last_Novatel_pkt:]
               found_last_Novatel_pkt_prev = found_last_Novatel_pkt
            # } if (found_last_Novatel_pkt)..
            bytes_read = bytes_read_to_use
         else:
            bytes_read = fin_bin.read()
         # } if (avail_mem < file_size)..

         # Find first Novatel packet begin index
         k = 0
         while(k < len(bytes_read)-2):
            if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])) == '44' and \
               (hexlify(bytearray(bytes_read[k+2])) == '12' or hexlify(bytearray(bytes_read[k+2])) == '13')):
               print(' ***** output_category = ' + output_category_dict[output_category] + ', LOOP: ' + str(n) + ', Found first SYNC BYTE trio (AA 44 12 or AA 44 13) at byte index: ' + str(k) + '\n')
               k_start = k;
               break;
            k = k + 1
         # } while(k < len(bytes_read))..

         k = k_start

         packet_size = 0
         message_length = 0

         [temp_week, temp_tow_ms, crc_length] = [0,0,4]
         [message_id, message_type, port_address, sequence, idle_time, time_status, rcvr_status, res1, res2] = [0,0,0,0,0,0,0,0,0]

         [temp_soln_status, temp_pos_type, res3, res4, res5, sig_mask, temp_ext_sol_status] = [0,0,0,0,0,0,0]
         [temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age] = [0,0,0,0,0,0]
         [temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used] = [0,0,0,0,0]

         [gps_week, gps_tow] = [0,0]
         [ins_vned_N, ins_vned_E, ins_vned_D] = [0,0,0]
         [gps_lat, gps_lon, gps_ht_ellip] = [0,0,0]
         [temp_ins_lat, temp_ins_lon, temp_ins_ht_abv_ellips, temp_ins_vned_N, temp_ins_vned_E, temp_ins_vned_D, temp_roll, temp_pitch, temp_azimuth, temp_ins_status] = [0,0,0,0,0,0,0,0,0,0]
         [temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_heading] = [0,0,0,0,0]

         # Look for beginning of a valid Novatel packet (Bytes: 0xAA4412):
         while (k < len(bytes_read)):
            if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])).upper() == '44'):
               if (hexlify(bytearray(bytes_read[k+2])).upper() == '12'): # Long header
                  total_message_cnt += 1

                  # print(' ********* LONG header')

                  [header_length] = unpack('<B', bytearray(bytes_read[k+3]))
                  [message_length] = unpack('<H', bytearray(bytes_read[k+8:k+10]) )

                  # Parse the remaining part of header:
                  [message_id, message_type, port_address, message_length, sequence, idle_time, time_status, temp_week, temp_tow_ms, rcvr_status, res1, res2] = unpack('<HbBHHBBHLLHH', bytearray(bytes_read[k+4:k+header_length]) )

               elif (hexlify(bytearray(bytes_read[k+2])).upper() == '13'): # Short header
                  total_message_cnt += 1

                  # print(' ********* SHORT header')

                  # Check if it is a message with short header (in this case, message_length becomes equal to header_length read before):
                  [message_length] = unpack('<B', bytearray(bytes_read[k+3]))
                  header_length = short_header_length

                  # Parse the remaining part of header:
                  [message_id, temp_week, temp_tow_ms] = unpack('<HHL', bytearray(bytes_read[k+4:k+header_length]) )
               else:
                  k = k + 1
                  continue
               # } if (hexlify(bytearray(bytes_read[k+2])).upper() == '12')..

               # Get a list of unique message id's in the log file (useful if looking for new messages added in the log but the parser currently does not handle)
               if (output_category == 'e' and message_id not in message_id_found_array):
                   # print(' ****** k = ' + str(k) + ', total_message_cnt = ' + str(total_message_cnt) + ', message_id = ' + str(message_id))
                   print(' ****** Found new message_id = ' + str(message_id))
                   message_id_found_array.append(message_id)
               # } if (output_category == 'e'..
               
               if (message_id in message_id_array):
                  # If GPS TOW changed, a new packet set begins. So, print current packet set to csv and/or add channel data for Sensor Cloud, before
                  # setting the new packet set values:

                  temp_tow = temp_tow_ms/1000.0

                  if (not found_first_tow and temp_week > 0):
                     found_first_tow = True
                     init_tow = temp_tow
                     print(' ************* FIRST TOW: total_message_cnt = ' + str(total_message_cnt) + ', temp_week = ' + str(temp_week) + ', temp_tow: ' + str(temp_tow))
                  # } if (not found_first_tow..
                  
                  if (found_first_tow and not crossed_40_sec and (temp_tow - init_tow) > 40.0):
                     crossed_40_sec = True
                  # } if (found_first_tow..
                  
                  if (found_first_tow and temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms and temp_tow_ms > temp_tow_ms_prev):
                     novatel_format_dict['TIMESTAMP'] = novatel_timestamp_struct

                     if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                        # If crossed the first 40 sec, we can be reasonably certain that no more 'new' messages would appear beyond this point.
                        # Note that Novatel allows only 1 Hz or slightly lower as the slowest rate of data logging.  So in theory, one should expect all messages to show up in the first 1 or 2 sec of data.
                        # However, in reality, in spite of selecting the slowest logging rate, often times, some of the messages do not appear until about 15 sec or so into the run.
                        # So for the sake of safety, a value of 40 sec is being selected here.
                        # If we did cross the 40 sec point, print the headers and the stored dictionaries in the dict array, if headers not already printed.
                        # Then print the current dictionary to csv file.
                        # Otherwise if we haven't yet crossed the 40 sec point, add current dictionary to array of dict.
                        # If total duration of file is less than 40 sec, then we will print the whole dict array later, in one shot at the end.
                        if (crossed_40_sec):
                           if (headers_printed == False):
                              novatel_output_order_in_log.sort()

                              fout_novatel.write('DATA_START\n')

                              for i, input_index in enumerate(novatel_output_order_in_log):
                                 fout_novatel.write(novatel_format_using_dict.format_header(input_index, i == len(novatel_output_order_in_log)-1, output_category))
                              # } for i, input_index in enumerate(novatel_output_order_in_log)..

                              fout_novatel.write('\n')

                              headers_printed = True

                              # Next, print data values of dict array collected during first 2 sec:
                              [gps_week, gps_tow] = [0,0]
                              cnt = 0
                              for ndict in novatel_format_dict_array:
                                 novatel_format_using_dict = Novatel_CSV_format_using_dict(ndict)
                                 cnt += 1
                                 if ('TIMESTAMP' in ndict):
                                    novatel_timestamp_struct = ndict['TIMESTAMP']

                                    gps_week = novatel_timestamp_struct.gps_week
                                    gps_tow = novatel_timestamp_struct.gps_tow

                                    if (gps_valid_tow_found == False and gps_week > 0):
                                       gps_valid_tow_found = True
                                    # } if (gps_valid_tow_found == False)..
                                 # } if ('TIMESTAMP' in gps_format_dict)..

                                 if (gps_valid_tow_found or 642 in ndict):  # Msg 642 has GPS Week = 0, TOW = 0, so allow it as an exception to the rule
                                    for i, input_index in enumerate(novatel_output_order_in_log):
                                       fout_novatel.write(novatel_format_using_dict.format(input_index, i == len(novatel_output_order_in_log)-1, output_category))
                                    # } for i, input_index in enumerate(novatel_output_order_in_log)..

                                    fout_novatel.write('\n')
                                 # } if (gps_valid_tow_found)..
                              # } for ndict in novatel_format_dict_array..
                           # } if (headers_printed == False)..

                           # Now print current data row to csv file
                           novatel_format_using_dict = Novatel_CSV_format_using_dict(novatel_format_dict)

                           for i, input_index in enumerate(novatel_output_order_in_log):
                              fout_novatel.write(novatel_format_using_dict.format(input_index, i == len(novatel_output_order_in_log)-1, output_category))
                           # } for i, input_index in enumerate(novatel_output_order_in_log)..

                           fout_novatel.write('\n')
                        else:
                           novatel_format_dict_array.append(novatel_format_dict)
                        # } if (crossed_40_sec)..
                     # } if (destination.upper() == 'CSV' or..

                     # Track the number of 'message sets' (i.e. set of Novatel messages at same GPS Timestamp)
                     message_set_cnt = message_set_cnt + 1

                     if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                        novatel_format_dict_array_cloud.append(novatel_format_dict)
                        if (message_set_cnt % MAX_ROWS_SENSOR_CLOUD_UPLOAD == 0):
                           novatel_format_dict_array_cloud_array.append(novatel_format_dict_array_cloud)
                           novatel_format_dict_array_cloud = []
                        # } if (message_set_cnt % MAX_ROWS_SENSOR_CLOUD_UPLOAD == 0)..
                     # } if (destination.upper() == 'CLOUD' or..

                     novatel_format_dict = {}
                     novatel_timestamp_struct = Novatel_Timestamp_struct()
                  # } if (temp_tow_ms_prev != 0 and..

                  [temp_soln_status, temp_imu_status, temp_ins_status] = [0,0,0]
                  [temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used] = [0,0,0,0]

                  if (output_category == 'i'):
                     [novatel_321_struct, novatel_324_struct, novatel_323_struct, novatel_319_struct, novatel_508_struct] = \
                        [Novatel_321_struct(), Novatel_324_struct(), Novatel_323_struct(), Novatel_319_struct(), Novatel_508_struct()]
                  elif (output_category == 'g'):
                     message_id_array = [101]
                  elif (output_category == 'e'):
                     [novatel_42_struct, novatel_99_struct, novatel_241_struct] = [Novatel_42_struct(), Novatel_99_struct(), Novatel_241_struct()]
                  elif (output_category == 'r'):
                     novatel_325_struct = Novatel_325_struct()
                  elif (output_category == 'v'):
                     novatel_642_struct = Novatel_642_struct()
                  # } if (output_category == 'i')..
                  
                  novatel_timestamp_struct.gps_week = temp_week
                  novatel_timestamp_struct.gps_tow = temp_tow_ms/1000.0
  
                  message_cnt = message_cnt + 1

                  if (found_bad_pkt):
                     print(' ***** found_bad_pkt = True, current message_cnt = ' + str(message_cnt))

                  # Add index of Message ID to final output order array.  If Message has a long header, convert to equivalent short header message ID.
                  # Include only those message ID's that are in 'min_gps_default_cols_dict' or 'min_gps_default_long2shorthdr_cols_dict' and not already added to 'novatel_output_order_in_log':
                  if (message_id in min_gps_default_cols_dict or message_id in min_gps_default_long2shorthdr_cols_dict):
                     if (message_id in min_gps_default_long2shorthdr_cols_dict):
                        message_id = min_gps_default_long2shorthdr_cols_dict[message_id]

                     index = min_gps_default_cols_dict[message_id]
                     # Exclude indices of Message ID's already added to 'novatel_output_order_in_log':
                     if (not crossed_40_sec and index not in novatel_output_order_in_log):
                        # print(' *** added message_id: ' + str(message_id) + ' to header')
                        novatel_output_order_in_log.append(index)
                     # } if (not crossed_40_sec and index not in novatel_output_order_in_log)..
                  # } if (message_id in min_gps_default_cols_dict..

                  # full_message_bytes = bytearray( bytes_read[k:k+message_length+header_length+crc_length] )
                  full_message_bytes = bytearray( bytes_read[k:k+message_length+header_length+crc_length+10] )
                  message_bytes = bytearray( bytes_read[k+header_length:k+header_length+message_length] )

                  if (message_id == 319):  # INSATTS [INS Attitude]
                     [temp_gps_week, temp_tow_ms2, novatel_319_struct.roll, novatel_319_struct.pitch, novatel_319_struct.azimuth, temp_ins_status] = unpack('<LddddI', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_319_struct

                  elif (message_id == 42):   # BESTPOS [GPS/INS Blended Position]
                     try:
                        [temp_soln_status, novatel_42_struct.pos_type, novatel_42_struct.ekf_lat, novatel_42_struct.ekf_lon, novatel_42_struct.ekf_ht_abv_MSL, novatel_42_struct.undulation, temp_datum_id_nbr, novatel_42_struct.lat_sd, novatel_42_struct.lon_sd, novatel_42_struct.ht_MSL_sd, temp_base_station_id, temp_diff_age, novatel_42_struct.sol_age, novatel_42_struct.nbr_svs_tracked, novatel_42_struct.nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfIfffIffBBBBBBBB', message_bytes )
                        novatel_format_dict[message_id] = novatel_42_struct
                     except struct.error as err:

                        tmp_str = hexlify( bytearray(full_message_bytes) ).upper()
                        print(' ****** struct.error: Novatel Packet: message_cnt: ' + str(message_cnt) + ' message_id: ' + str(message_id) + ', full_message_bytes = '),
                        for i1 in range(0,len(tmp_str),2):
                           print(tmp_str[i1] + tmp_str[i1+1]),
                        print('\n')

                        tmp_str = hexlify( bytearray(message_bytes) ).upper()
                        print(' ****** struct.error: Novatel Packet: message_cnt: ' + str(message_cnt) + ' message_id: ' + str(message_id) + ', message_bytes = '),
                        for i1 in range(0,len(tmp_str),2):
                           print(tmp_str[i1] + tmp_str[i1+1]),
                        print('\n')

                        found_bad_pkt = True

                        message_cnt_of_bad_pkt = message_cnt
                        print(' ******* FOUND BAD PCKT: message_cnt = ' + str(message_cnt))

                  elif (message_id == 321):   # INSPOSS [INS Position]
                     [temp_gps_week, temp_tow_ms2, novatel_321_struct.ins_lat, novatel_321_struct.ins_lon, novatel_321_struct.ins_ht_abv_ellip, temp_ins_status] = unpack('<LddddI', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_321_struct

                  elif (message_id == 508):   # INSPVAS [INS Position, Velocity and Attitude]
                     [temp_gps_week, temp_tow_ms2, novatel_508_struct.ins_pva_lat, novatel_508_struct.ins_pva_lon, novatel_508_struct.ins_pva_ht_abv_ellips, novatel_508_struct.ins_pva_vned_N, novatel_508_struct.ins_pva_vned_E, novatel_508_struct.ins_pva_vned_D, novatel_508_struct.ins_pva_roll, novatel_508_struct.ins_pva_pitch, novatel_508_struct.ins_pva_azimuth, temp_ins_status] = unpack('<LddddddddddI', bytearray(message_bytes) )

                     # Convert 'up' velocity to 'down' velocity
                     novatel_508_struct.ins_pva_vned_D *= -1

                     novatel_format_dict[message_id] = novatel_508_struct

                  elif (message_id == 101):   # TIME
                     [novatel_101_struct.rcvr_clock_status, novatel_101_struct.rcvr_clock_offset, novatel_101_struct.rcvr_clock_offset_sd, novatel_101_struct.utc_offset, novatel_101_struct.utc_year, novatel_101_struct.utc_month, novatel_101_struct.utc_day, novatel_101_struct.utc_hour, novatel_101_struct.utc_min, novatel_101_struct.utc_ms, novatel_101_struct.utc_status] = unpack('<IdddLBBBBLI', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_101_struct

                  elif (message_id == 99):   # BESTVEL [GPS/INS Blended Velocity]
                     [temp_soln_status, novatel_99_struct.vel_type, novatel_99_struct.ekf_latency, novatel_99_struct.diff_age, novatel_99_struct.ekf_horiz_speed, novatel_99_struct.ekf_grnd_trc, novatel_99_struct.ekf_vert_speed, res5] = unpack('<IIffdddf', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_99_struct

                  elif (message_id == 241):   # BESTXYZ [GPS/INS ECEF Position/Velocity]
                     [novatel_241_struct.p_sol_status, novatel_241_struct.pos_type, novatel_241_struct.ecef_pos_x, novatel_241_struct.ecef_pos_y, novatel_241_struct.ecef_pos_z, novatel_241_struct.ecef_pos_x_sd, novatel_241_struct.ecef_pos_y_sd, novatel_241_struct.ecef_pos_z_sd, novatel_241_struct.v_sol_status, novatel_241_struct.vel_type, novatel_241_struct.ecef_vel_x, novatel_241_struct.ecef_vel_y, novatel_241_struct.ecef_vel_z, novatel_241_struct.ecef_vel_x_sd, novatel_241_struct.ecef_vel_y_sd, novatel_241_struct.ecef_vel_z_sd, temp_base_station_id, novatel_241_struct.vel_time_latency, temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfffIIdddfffIfffBBBBbbbb', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_241_struct

                  elif (message_id == 324):   # INSVELS [INS NED Velocity]
                     [temp_gps_week, temp_tow_ms2, novatel_324_struct.ins_vned_N, novatel_324_struct.ins_vned_E, novatel_324_struct.ins_vned_D, temp_ins_status] = unpack('<LddddI', bytearray(message_bytes) )

                     # Convert 'up' velocity to 'down' velocity
                     novatel_324_struct.ins_vned_D *= -1

                     novatel_format_dict[message_id] = novatel_324_struct

                  elif (message_id == 323):   # INSSPDS [INS Speed]
                     [temp_gps_week, temp_tow_ms2, novatel_323_struct.ins_grnd_trc, novatel_323_struct.ins_horiz_speed, novatel_323_struct.ins_vert_speed, novatel_323_struct.ins_status] = unpack('<LddddI', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_323_struct

                  elif (message_id == 325):   # RAWIMUS [IMU Raw values]
                     [temp_gps_week, temp_tow_ms2, temp_imu_status, temp_z_accel, temp_y_accel, temp_x_accel, temp_z_gyro, temp_y_gyro, temp_x_gyro] = unpack('<Ldlllllll', bytearray(message_bytes) )

                     novatel_325_struct.z_accel = temp_z_accel * accel_scale_factor
                     novatel_325_struct.y_accel = -temp_y_accel * accel_scale_factor
                     novatel_325_struct.x_accel = temp_x_accel * accel_scale_factor

                     novatel_325_struct.z_gyro = temp_z_gyro * gyro_scale_factor
                     novatel_325_struct.y_gyro = -temp_y_gyro * gyro_scale_factor
                     novatel_325_struct.x_gyro = temp_x_gyro * gyro_scale_factor

                     novatel_format_dict[message_id] = novatel_325_struct

                  elif (message_id == 642):   # VEHICLEBODYROTATION
                     [self.novatel_642_struct.x_veh2body_angle, self.novatel_642_struct.y_veh2body_angle, self.novatel_642_struct.z_veh2body_angle, self.novatel_642_struct.x_veh2body_angle_unc, self.novatel_642_struct.y_veh2body_angle_unc, self.novatel_642_struct.z_veh2body_angle_unc] = unpack('<ddddddI', bytearray(message_bytes) )
                     novatel_format_dict[message_id] = novatel_642_struct

                  # } if (message_id == 319)..
  
                  if (found_bad_pkt):
                     print(' ******* AFTER IF-ELSE STATEMENT and FOUND BAD PCKT: message_cnt = ' + str(message_cnt))
  
                  novatel_timestamp_struct.imu_status = temp_imu_status
                  novatel_timestamp_struct.ins_status = temp_ins_status
                  novatel_timestamp_struct.soln_status = temp_soln_status

                  temp_tow_ms_prev = temp_tow_ms

               # } if (message_id in message_id_array) ..

               if (found_bad_pkt):
                  print(' ******* AFTER if (message_id in message_id_array) STATEMENT and FOUND BAD PCKT: message_cnt = ' + str(message_cnt) + ', k = ' + str(k) + ', message_length = ' + str(message_length))

               k = k + header_length + message_length + crc_length
            else:
               k = k + 1
            # } if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and..
         # } while (k < len(bytes_read))..
      # } for n in range(nbr_of_loops)..

      message_set_cnt += 1

      # Set the timestamp key to use in the last dict
      novatel_format_dict['TIMESTAMP'] = novatel_timestamp_struct

      # Print content to csv if total data never crossed 40 sec, or the last packet set if data did cross 40 sec
      if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
         if (not crossed_40_sec):
            novatel_output_order_in_log.sort()

            fout_novatel.write('DATA_START\n')

            for i, input_index in enumerate(novatel_output_order_in_log):
               fout_novatel.write(novatel_format_using_dict.format_header(input_index, i == len(novatel_output_order_in_log)-1, output_category))
            # } for i, input_index in enumerate(novatel_output_order_in_log)..

            fout_novatel.write('\n')

            # Add the last dict to dict array (for this category), because there won't be any more timestamp change beyond this point
            novatel_format_dict_array.append(novatel_format_dict)

            # Next, print data values of dict array collected during first 40 sec:
            [gps_week, gps_tow] = [0,0]
            cnt = 0
            for ndict in novatel_format_dict_array:
               novatel_format_using_dict = Novatel_CSV_format_using_dict(ndict)
               cnt += 1
               if ('TIMESTAMP' in ndict):
                  novatel_timestamp_struct = ndict['TIMESTAMP']

                  gps_week = novatel_timestamp_struct.gps_week
                  gps_tow = novatel_timestamp_struct.gps_tow

                  if (not gps_valid_tow_found and gps_week > 0):
                     gps_valid_tow_found = True
                  # } if (gps_valid_tow_found == False)..
               # } if ('TIMESTAMP' in gps_format_dict)..

               if (gps_valid_tow_found or 642 in ndict):  # Msg 642 has GPS Week = 0, TOW = 0, so allow it as an exception to the rule
                  for i, input_index in enumerate(novatel_output_order_in_log):
                     fout_novatel.write(novatel_format_using_dict.format(input_index, i == len(novatel_output_order_in_log)-1, output_category))
                  # } for i, input_index in enumerate(novatel_output_order_in_log)..

                  fout_novatel.write('\n')
               # } if (gps_valid_tow_found)..
            # } for ndict in novatel_format_dict_array..
         else:
            # Print last packet set to csv file (because we never got a 'next' timestamp to determine end of that packet set)
            novatel_format_using_dict = Novatel_CSV_format_using_dict(novatel_format_dict)

            for i, input_index in enumerate(novatel_output_order_in_log):
               fout_novatel.write(novatel_format_using_dict.format(input_index, i == len(novatel_output_order_in_log)-1, output_category))
            # } for i, input_index in enumerate(novatel_output_order_in_log)..

            fout_novatel.write('\n')
         # } if (not crossed_40_sec)..

         fout_novatel.close()
      # } if (destination.upper() == 'CSV' or..

      # Append last packet set to cloud array, because we never got a 'next' timestamp to determine end of that packet set
      # Finally append last cloud array (leftover from last time we did modulus 100,000) to array of arrays to be sent to cloud
      if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
         message_set_cnt += 1
         novatel_format_dict_array_cloud.append(novatel_format_dict)
         novatel_format_dict_array_cloud_array.append(novatel_format_dict_array_cloud)

         leap_sec_to_use = NBR_OF_LEAP_SECONDS

         # --------------------------------------------
         # Add channel names to sensor in sensor cloud:
         # --------------------------------------------
         # First, create channels using column header names (if not already created):

         novatel_output_order_in_log.sort()

         for i, input_index in enumerate(novatel_output_order_in_log):
            tmp_channel_name_array = novatel_format_using_dict.format_channel_name(input_index, output_category)

            index_range_array = []

            for c in tmp_channel_name_array:
               channel_names.append(c)
               chStatus = addChannel(server, token, device_id, sensor_name, c)
               channel_data[sensor_name][total_channel_cnt] = []
               index_range_array.append(total_channel_cnt)

               total_channel_cnt += 1
            # } for c in tmp_channel_name_array..

            channel_index_range_dict[input_index] = index_range_array
         # } for i, input_index in enumerate(novatel_output_order_in_log)..

         # -------------------------------------------------------
         # Now add Novatel channel data to sensor in sensor cloud:
         # -------------------------------------------------------
         [gps_week, gps_tow] = [0,0]
         cnt = 0
         for novatel_format_dict_array_cloud in novatel_format_dict_array_cloud_array:
            for novatel_format_dict in novatel_format_dict_array:
               novatel_format_using_dict = Novatel_CSV_format_using_dict(novatel_format_dict)
               cnt += 1
               if ('TIMESTAMP' in novatel_format_dict):
                  novatel_timestamp_struct = novatel_format_dict['TIMESTAMP']

                  gps_week = novatel_timestamp_struct.gps_week
                  gps_tow = novatel_timestamp_struct.gps_tow

                  if (gps_valid_tow_found == False and gps_week > 0):
                     gps_valid_tow_found = True
                  # } if (gps_valid_tow_found == False)..
               # } if ('TIMESTAMP' in gps_format_dict)..

               if (gps_valid_tow_found or 642 in novatel_format_dict):  # Msg 642 has GPS Week = 0, TOW = 0, so allow it as an exception to the rule

                  if (gps_week < 1930):
                     leap_sec_to_use = NBR_OF_LEAP_SECONDS_2016
                  # } if (gps_week < 1930)..

                  for i, input_index in enumerate(novatel_output_order_in_log):
                     tmp_channel_value_array = novatel_format_using_dict.format_channel_value(input_index, output_category)

                     if (tmp_channel_value_array != None):
                        gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                        utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - leap_sec_to_use + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                        # Convert UTC sec from UTC Epoch into unix nanosecond time
                        ts = utc_sec_from_utc_epoch * 1000000000

                        tmp_channel_index_range_array = channel_index_range_dict[input_index]

                        indx = 0
                        for c in tmp_channel_value_array:
                           try:
                              ch = channel_data_struct()
                              ch.ts = numpy.int64(ts)
                              ch.value = float(c)
                              channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                           except ValueError as err:
                              print(" ******** ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " gps_tow: " + str(gps_tow) + " 0-based column index = " + str(indx) + ", Channel Name: " + channel_names[tmp_channel_index_range_array[indx]] + ", Value = " + c + ", Error Msg: {0}".format(err))

                           indx = indx + 1
                        # } for c in tmp_channel_value_array..
                     # } if (tmp_channel_value_array != None)..
                  # } for i, input_index in enumerate(novatel_output_order_in_log)..
               # } if (gps_valid_tow_found..
            # } for novatel_format_dict in novatel_format_dict_array..

            print("******* Novatel Binary to Sensor Cloud: len(channel_data[sensor_name]) = " + str(len(channel_data[sensor_name])))

            # Upload one column (channel) at a time to Sensor Cloud:
            for index in range(len(channel_data[sensor_name])):
               print(' *********** index = ' + str(index) + ' channel_names[index] = ' + channel_names[index] + ' len(channel_data[sensor_name][index]) = ' + str(len(channel_data[sensor_name][index])))

               channel_data_list = channel_data[sensor_name][index]

               addTimeSeriesData(server, token, device_id, sensor_name, channel_names[index], sampleRate, sampleRateType, channel_data_list)
            # } for index in range(len(channel_data[sensor_name]))..
         # } for novatel_format_dict_array_cloud in novatel_format_dict_array_cloud_array..
      # } if (destination.upper() == 'CLOUD'..

      print('\n------------------------------------------------------------------')
      print ('\n************* output_category = ' + output_category_dict[output_category] + ', Total nbr of Novatel packets: ' + str(message_cnt) + ', Nbr of Packet Sets = ' + str(message_set_cnt) + ' len(novatel_format_dict_array) = ' + str(len(novatel_format_dict_array)))
      print('\n------------------------------------------------------------------')

      fin_bin.close()

   # } for output_category in out_category_array..

if(__name__ == "__main__"):
  main_line(sys.argv)




