import csv
import sys
import numpy
import serial                  #library for accessing serial ports
from mip_csv_utils import *

from ublx import *

from struct import * #import all objects and functions from the struct library
from binascii import hexlify #hexlify is a function to print bytearrays as
                             #ascii strings for debugging (NOT NECESSARY FOR
                             #DATA CONVERSTIONS)

from time import sleep         #sleep
#from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                         #response update thread

def main_line(argv):
    """Main line program"""

    # in_file_name = 'GPS_Log.csv'
    # in_file_name = 'GPS_Log_full.csv'
    # in_file_name = 'GPS_Log_wHeaders_7-21-2015 4.49.56 PM.csv'
    in_file_name = 'GPS_Log_wHeaders_7-24-2015 3.33.07 PM.csv'

    in_csvfile = open(in_file_name,'rUb')

    in_debug_file_name = 'C:\MP\Lord\SourceCode_Greg\MIP_NAV\RQ1\_Project\RQ1_45_Debug_Output.csv'
    #in_debug_csvfile = open(in_debug_file_name,'rUb')
    in_debug_csvfile = open(in_debug_file_name,'r+b')

    in_debug_csvfile.truncate()

    # csv.register_dialect('notepad', delimiter=',')
    # csvreader = csv.reader(in_csvfile, dialect='notepad')
    csvreader = csv.reader(in_csvfile, delimiter=',')
    debug_csvreader = csv.reader(in_debug_csvfile, delimiter=',')

    determine_headers = False
    output_descriptors = []
    output_headers = True
    headers_found = False
    headers = []
    n_input_rows = 0
    n_output_rows = 0

    row_cnt = 0
    data_row_cnt = 0

    debug_mode = 0

    #default port settings
    port_name = 'COM10'
    #port_baud = 230400
    port_baud = 115200

    #Assign serial port object
    port = serial.Serial(port_name, port_baud)

    #Close port in case it was left open by other process
    port.close()

    #open specified port
    port.open()

    #set up background process to update data buffers
    # background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

    #start the response parsing thread
    # background_data_update.start()

    #sleep while waiting for response
    #sleep(1)

    #stop background response parsing thread
    # background_data_update.stop()

    for row_items in csvreader:

        row_cnt = row_cnt + 1

        # print(" ***** row: " + str(row_cnt)  );

        # determined that last row in CSV indicated data start (headers are in this row)
        if (determine_headers == True):
            # column headers have been found
            headers_found = True

            # headers no longer need to be determined
            determine_headers = False

        elif(headers_found == True):

            data_row_cnt = data_row_cnt + 1

            debug_over = False;

            # if (data_row_cnt > 1):
            #      while(debug_over == False):
            #          for debug_row_items in debug_csvreader:
            #             if (debug_row_items[0] == 'Debug1'):
            #                 debug_over = True
            #                 break
            #      sleep(0.1)

            # if (data_row_cnt == 1 or debug_over == True):

            if (data_row_cnt > 1 and debug_mode == 1):
                raw_input("Press Enter to continue...")

            # if (data_row_cnt == 1):
            # print("\n ************  headers_found == True ******************** \n");

            # print(" ****** GPS: TOW = " + str(row_items[2]) + " Lat = " + str(row_items[3]) + " Lon = " + str(row_items[4]) + " Height = " + row_items[5]);
            print(" ****** GPS: Week = " + str(row_items[1]) + " TOW = " + str(row_items[2]) );

            # print( " ************** Real TOW (ms): " + str(numpy.double(row_items[2]) * 1000.0))
            # print( " ************** Rounded TOW (ms) = " + str( numpy.uint32(numpy.rint(numpy.double(row_items[2]) * 1000.0)) ) )
            # print( " ************** Real - Rounded TOW (ms) = " + str(numpy.double(row_items[2]) * 1000.0 - numpy.uint32(numpy.rint(numpy.double(row_items[2]) * 1000.0)) ) )

            packet_data = bytearray([])

            ##################################
            # NAV-TIMEGPS message (0x01 0x20):
            ##################################
            GPS_TOW_rounded_ms = numpy.uint32(numpy.rint(numpy.double(row_items[2]) * 1000.0))
            GPS_TOW_Real_Minus_Rounded_ms = numpy.double(row_items[2]) * 1000.0 - numpy.uint32(numpy.rint(numpy.double(row_items[2]) * 1000.0))
            GPS_TOW_Real_Minus_Rounded_nano_s = GPS_TOW_Real_Minus_Rounded_ms * 1e6

            # print(" ******** GPS_TOW_rounded_ms = " + str(GPS_TOW_rounded_ms) );
            # print(" ******** GPS_TOW_Real_Minus_Rounded_ms = " + str(GPS_TOW_Real_Minus_Rounded_ms) );
            # print(" ******** GPS_TOW_Real_Minus_Rounded_nano_s = " + str(GPS_TOW_Real_Minus_Rounded_nano_s));

            # As of July 15, 2015, there were 26 leap seconds since 1970..
            # Valid_flags = 7 is being sent here, to indicate valid TOW, Week, and leap seconds.

            packet_data = pack('<IihbbI', GPS_TOW_rounded_ms, numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s), numpy.short(row_items[1]), 26, 7, 0)

            # print "********* NAV-TIMEGPS packet_data: " + hexlify(packet_data).upper()

            ublxp = ublx_create_ublx_message(0x01, 0x20, 16, packet_data)

            #finalize packet
            ublx_finalize(ublxp)

            # print "\nNAV-TIMEGPS Packet after finalize: " + hexlify(ublxp).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp)
            # port.flush()

            ##################################
            # NAV-STATUS message (0x01 0x03):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IBBBBII', GPS_TOW_rounded_ms, 2, 13, 0, 0, 0, 0)

            # print "********* NAV-STATUS packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_status = ublx_create_ublx_message(0x01, 0x03, 16, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_status)

            # print "\nNAV-STATUS Packet after finalize: " + hexlify(ublxp_nav_status).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_status)
            port.flush()

            ##################################
            # NAV-POSLLH message (0x01 0x02):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(row_items[4]) * 1e+07), numpy.int32(numpy.double(row_items[3]) * 1e+07), numpy.int32(numpy.double(row_items[5]) * 1e+03), numpy.int32(numpy.double(row_items[6]) * 1e+03), numpy.int32(numpy.double(row_items[7]) * 1e+03), numpy.int32(numpy.double(row_items[8]) * 1e+03))

            # print "********* NAV-POSLLH packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_llh = ublx_create_ublx_message(0x01, 0x02, 28, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_llh)

            # print "\nNAV-POSLLH Packet after finalize: " + hexlify(ublxp_nav_llh).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_llh)
            # port.flush()

            ##################################
            # NAV-VELNED message (0x01 0x12):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiIIiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(row_items[15]) * 1e+02), numpy.int32(numpy.double(row_items[16]) * 1e+02), numpy.int32(numpy.double(row_items[17]) * 1e+02), numpy.uint32(numpy.double(row_items[18]) * 1e+02), numpy.uint32(numpy.double(row_items[19]) * 1e+02), numpy.int32(numpy.double(row_items[20]) * 1e+05), numpy.uint32(numpy.double(row_items[21]) * 1e+02), numpy.uint32(numpy.double(row_items[22]) * 1e+05))

            # print "********* NAV-VELNED packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_vned = ublx_create_ublx_message(0x01, 0x12, 36, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_vned)

            # print "\nNAV-VELNED Packet after finalize: " + hexlify(ublxp_nav_vned).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_vned)
            port.flush()

            ##################################
            # NAV-TIMEUTC message (0x01 0x21):
            ##################################

            packet_data = bytearray([])

            # valid = 7 meaning UTC, Wk Nbr, and TOW all valid
            packet_data = pack('<IIiHBBBBBB', GPS_TOW_rounded_ms, 0, 0, numpy.short(row_items[37]), numpy.uint8(row_items[38]), numpy.uint8(row_items[39]), numpy.uint8(row_items[40]), numpy.uint8(row_items[41]), numpy.uint8(row_items[42]), 7 )

            # print "********* NAV-TIMEUTC packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_timeutc = ublx_create_ublx_message(0x01, 0x21, 20, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_timeutc)

            # print "\nNAV-TIMEUTC Packet after finalize: " + hexlify(ublxp).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_timeutc)
            port.flush()

            ##################################
            # NAV-POSECEF message (0x01 0x01):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiI', GPS_TOW_rounded_ms, numpy.int32(numpy.double(row_items[10]) * 1e+02), numpy.int32(numpy.double(row_items[11]) * 1e+02), numpy.int32(numpy.double(row_items[12]) * 1e+02), numpy.int32(numpy.double(row_items[13]) * 1e+02))

            # print "********* NAV-POSECEF packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_posecef = ublx_create_ublx_message(0x01, 0x01, 20, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_posecef)

            # print "\nNAV-POSECEF Packet after finalize: " + hexlify(ublxp_nav_posecef).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_posecef)
            port.flush()

            ##################################
            # NAV-VELECEF message (0x01 0x11):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiI', GPS_TOW_rounded_ms, numpy.int32(numpy.double(row_items[24]) * 1e+02), numpy.int32(numpy.double(row_items[25]) * 1e+02), numpy.int32(numpy.double(row_items[26]) * 1e+02), numpy.int32(numpy.double(row_items[27]) * 1e+02))

            # print "********* NAV-VELECEF packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_velecef = ublx_create_ublx_message(0x01, 0x11, 20, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_velecef)

            # print "\nNAV-VELECEF Packet after finalize: " + hexlify(ublxp_nav_velecef).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_velecef)
            port.flush()

            ##################################
            # NAV-DOP message (0x01 0x04):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IHHHHHHH', GPS_TOW_rounded_ms, numpy.uint32(numpy.double(row_items[29]) * 1e+02), numpy.uint32(numpy.double(row_items[30]) * 1e+02), numpy.uint32(numpy.double(row_items[31]) * 1e+02), numpy.uint32(numpy.double(row_items[32]) * 1e+02), numpy.uint32(numpy.double(row_items[33]) * 1e+02), numpy.uint32(numpy.double(row_items[34]) * 1e+02), numpy.uint32(numpy.double(row_items[35]) * 1e+02) )

            # print "********* NAV-DOP packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_dop = ublx_create_ublx_message(0x01, 0x04, 18, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_dop)

            # print "\nNAV-DOP Packet after finalize: " + hexlify(ublxp_nav_dop).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_dop)
            port.flush()

            ##################################
            # NAV-SOL message (0x01 0x06):
            ##################################

            packet_data = bytearray([])
            # Number of SV's used in solution = 5 (spoof value):
            packet_data = pack('<IihBBiiiIiiiIHBBI', GPS_TOW_rounded_ms, numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s), numpy.short(row_items[1]), 2, 13, numpy.int32(numpy.double(row_items[10]) * 1e+02), numpy.int32(numpy.double(row_items[11]) * 1e+02), numpy.int32(numpy.double(row_items[12]) * 1e+02), numpy.int32(numpy.double(row_items[13]) * 1e+02), numpy.int32(numpy.double(row_items[24]) * 1e+02), numpy.int32(numpy.double(row_items[25]) * 1e+02), numpy.int32(numpy.double(row_items[26]) * 1e+02), numpy.int32(numpy.double(row_items[27]) * 1e+02), numpy.uint32(numpy.double(row_items[30]) * 1e+02), 0, 5, 0)
            # print "********* NAV-SOL packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_sol = ublx_create_ublx_message(0x01, 0x06, 52, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_sol)

            # print "\nNAV-SOL Packet after finalize: " + hexlify(ublxp_nav_sol).upper()

            #send GPS UBLOX packet to device
            port.write(ublxp_nav_sol)

            port.flush()

            #sleep(0.001)
            #sleep(0.01)
            sleep(0.25)
            #sleep(1)

            # break

            n_input_rows += 1
        # this row is neither column headers nor data elements
        else:
            # print(" ELSE **************** : len(row_items) = " + str(len(row_items)) + " and row_items[0] = " + row_items[0]);
            # print(row_items)
            # test for DATA_START row (column headers to follow)
            #if(len(row_items) == 1 and row_items[0] == 'DATA_START'):
            if(row_items[0] == 'DATA_START'):
                determine_headers = True
                print("DATA_START found, collecting headers")

    #file complete
    print(str(n_input_rows)+" input rows processed")
    print("Output file generation complete")
    print(str(n_output_rows)+" output rows written.")

    port.close()

if(__name__ == "__main__"):
  main_line(sys.argv)


