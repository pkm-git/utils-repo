import sys
import threading       #import thread library
import StringIO

from time import time  #import time library
from time import sleep           #sleep
from pykeyboard import PyKeyboard

#Class to asynchronously generate the link to the engine control system
class AsyncCommandLine(threading.Thread):
   """Thread Object for running a python script on the command line """
   def __init__(self, command_line_obj, timeout = 0.001):
      """Initialize the AsyncCommandLine Object"""
      threading.Thread.__init__(self)
      self.command_line_obj = command_line_obj
      self.timeout = timeout
      self._stop = False
      self.waiting = False

   def stop(self):
      """Stop thread loop"""
      self._stop = True
      if (self.waiting == True):
         k = PyKeyboard()
         k.press_key(k.enter_key)
         k.release_key(k.enter_key)

   def run(self):
      """Enter infinite loop"""
      print('******** Will call command line function ********** ')
      self.waiting = True
      
      subprocess_fn(command_line_obj.str_command_line)
      
      self.command_line_obj.done = True
      self.waiting = False
      
      if (0):
         while(self._stop == False):
            print('******** Press Enter key to stop recording at any time ********** ')
            # self.waiting = True
            
            str_in = raw_input()
            if (str_in == ''):
               self.command_line_obj.done = True
               
               self.waiting = False
               sleep(0.15)

         # } while(self._stop == False)...
      # } if (0)..
