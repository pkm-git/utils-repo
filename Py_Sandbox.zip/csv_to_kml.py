# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os
import csv
import simplekml
import numpy as np

def csv_to_kml_fn(in_file_name, lat_col_nbr = 4, lon_col_nbr = 5, ht_col_nbr = 6):

   if (in_file_name == None):
      print('Input file name cannot be empty')
      sys.exit()

   in_csvfile = open(in_file_name,'rUb')
   csvreader = csv.reader(in_csvfile, delimiter=',')

   (fin_filepath, fin_filename) = os.path.split(in_file_name)

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0

   kml = simplekml.Kml()
   coord_array = []

   for row_item in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers == True):
         n_data_columns =  len(row_item)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

      elif(headers_found == True):
         data_row_cnt = data_row_cnt + 1

         if (len(row_item) > 0):
            gps_lat = row_item[lat_col_nbr-1]
            gps_lon = row_item[lon_col_nbr-1]
            gps_ht = row_item[ht_col_nbr-1]

            coord_array.append((np.double(gps_lon), np.double(gps_lat), float(gps_ht)))
            # pnt = kml.newpoint(name='A Point', coords=(np.double(gps_lon), np.double(gps_lat), np.double(gps_ht)))
            # pnt.style = None
            
         # } if (len(row_item) > 0)..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(row_item) > 0 and row_item[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers == True)..

   # } for row_item in csvreader..

   ls = kml.newlinestring(name=fin_filename[:-4], coords=coord_array, extrude=1)

   ls.style.linestyle.width = 4
   ls.style.linestyle.color = simplekml.Color.blue

   # Create the kml file in the same folder as the input file
   kml.save(os.path.join(fin_filepath, fin_filename[:-4] + '.kml'))


