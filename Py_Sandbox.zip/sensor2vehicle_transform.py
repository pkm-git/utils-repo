#import libraries used
from mip import *              #local file should be in local folder
from mip_parser import *       #local file should be in local folder
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 # global streaming_enabled
 print("****** mip_parser_callback: callback_type = " + str(callback_type))
 print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
   print("Valid Packet Found")

   #loop over fields in received valid packet
   for field in mip_get_next_field(packet_bytes):
     # print('field[1]: ' + str(field[1]) + ', Device response to command: (' + hex(field[2]).upper() + ') = '\
            # + mip_ack_nacks[field[3]])

     #if this field is an ack/nack output it to show the user
     if (field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):  # 0xF1
       print('field[1]: ' + str(field[1]) + ', Device response to command: (' + hex(field[2]).upper() + ') = '\
            + mip_ack_nacks[field[3]])

       # print('Device response to command '+hex(field[2]).upper()+': '\
            # +mip_ack_nacks[field[3]])
     elif (field[1] == MIP_REPLY_DESC_SENSOR2VEHICLE_TRANSFORM_VALUE): # 0x81
       mip_parser.set_streaming_enabled(field[3])
       print('field[1]: ' + str(field[1]) + ', Device: (' + hex(field[2]).upper() + ') = ' + str(field[3]))
            # + mip_enable_disable[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

# streaming_enabled = 0

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM12'
# port_baud = 115200  # DON'T USE FOR RQ1
# port_baud = 460800  # DON'T USE
port_baud = 921600    # USE THIS FOR RQ1

# port_name = 'COM4'
# port_baud = 921600   # DON'T USE
# port_baud = 12000000 # USE THIS FOR GX4

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-m' and len(argv) > i+1):
  mode = argv[i+1]

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name, port_baud)

#Close port in case it was left open by other process
port.close()

# Sensor 2 Vehicle Transform Read Command
sensor_2_vehicle_transform_read_command = bytearray.fromhex('75650D03031102000B')

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

#open specified port
port.open()

#set up background process to update data buffers
background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

#start the response parsing thread
background_data_update.start()

if (mode == 'read'):
    print('Sending Read Current command:')
    port.write(sensor_2_vehicle_transform_read_command)

#sleep while waiting for response
sleep(1)

#stop background response parsing thread
background_data_update.stop()

#close port
port.close()


