import threading       #import thread library
from time import time  #import time library
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text

#Class to asynchronously update data from serial port
class AsyncRTDataParser(threading.Thread):

 """Thread Object for doing Threaded Data Updating"""
#def __init__(self, serial_port, mip_parser, timeout = 0.001):
 def __init__(self, serial_port, timeout = 0.001):
  """Initialize the AsyncRTDataParser Object"""
  threading.Thread.__init__(self)
  # self.parser = rt_parser
  self.serial_port = serial_port
  self.serial_buffer = []
  self.timeout = timeout
  self._stop = False

 def stop(self):
  """Stop thread loop"""
  self._stop = True

 def load_serial_buffer(self):
  """Load data bytes waiting on the serial buffer"""
  start_time = time()

  #- print('************** in async while loop of run(), i = ' + str(i))
  print('********** Async::load_serial_buffer, PORT: ' + self.serial_port.name + ' Start time: ' + str(start_time));

  j = 1
  #Read response if any
  while self.serial_port.inWaiting():
   print ('************** in async::load_serial_buffer(), while loop: j = ' + str(j))
   # bytes_read = self.serial_port.read(self.serial_port.inWaiting())
   # byte1_read = bytes_read[0]
   # byte2_read = bytes_read[1]

   byte1_read = self.serial_port.read()
   byte2_read = self.serial_port.read()

   print(' ************** byte1_read = ' + hexlify(byte1_read).upper() + ' byte2_read = ' + hexlify(byte2_read).upper());

   if (hexlify(byte1_read).upper() == 'B5' and hexlify(byte2_read).upper() == '62'):
     print(' ************** byte1_read == 0xB5 and byte2_read == 0x62 ************** ');

     bytes_read = self.serial_port.read(self.serial_port.inWaiting())
     # bytes_read = self.serial_port.read(410)
     # bytes_read = self.serial_port.read(822)
     print(' *************** LENGTH OF BYTES READ = ' + str(len(bytes_read)));

     # print('********************** load_serial_buffer: j = ' + str(j) + ', Packet: ' + hexlify(bytearray(byte_reply)).upper())
     # byte_reply = self.serial_port.read(size=410)
     # byte_reply = bytearray(self.serial_port.readline())
     self.serial_buffer.extend(bytearray(byte1_read));
     self.serial_buffer.extend(bytearray(byte2_read));
     self.serial_buffer.extend(bytearray(bytes_read));

     break;

   j = j + 1

 def run(self):
  """Enter infinite Update loop"""
  i = 1
  while(self._stop == False):
  # while(i == 1):
   print ('\n************** in async::run(), while loop: i = ' + str(i) + ' and time: ' + str(time()))
   #Read reply
   self.load_serial_buffer()

   #write the response bytes to the parser
   # self.parser.write(bytearray(self.serial_buffer))

   #print contents of buffer
   #print(self.serial_buffer)
   #print(self.serial_buffer[1:10])

   # print('********************** Bytes read: ' + hexlify(self.serial_buffer).upper())

   print('********************** i = ' + str(i) + ', Packet: ' + hexlify(bytearray(self.serial_buffer[0:412])).upper())
   # print('********************** i = ' + str(i) + ', Packet: ' + hexlify(bytearray(self.serial_buffer[0:824])).upper())
   # print('********************** Bytes read: ' + bytearray(self.serial_buffer))

   #clear the buffer
   self.serial_buffer = [];

   #parse the response
   # self.parser.parse_input_buffer()

   i = i + 1

# while 1:
  # tdata = s.read()           # Wait forever for anything
  # time.sleep(1)              # Sleep (or inWaiting() doesn't give the correct value)
  # data_left = s.inWaiting()  # Get the number of characters ready to be read
  # tdata += s.read(data_left) # Do the read and combine it with the first character

