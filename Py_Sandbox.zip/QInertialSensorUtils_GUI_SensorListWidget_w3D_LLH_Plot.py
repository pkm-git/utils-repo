import numpy as np
import os
import pyqtgraph as pg
## make a widget for displaying 3D objects
import pyqtgraph.opengl as gl
import calendar

from datetime import datetime
from PyQt4 import QtCore, QtGui
from sensor_cloud_api import *
from QInertialSensorUtils_GUI_TreeWidget import *
from time import sleep         #sleep

class MySensorListWidget(QtGui.QWidget):
   def __init__(self, parent, in_file_name = None, csv_object_name = None):
      super(MySensorListWidget, self).__init__(parent)

      self.parent_obj = parent

      self.sensor_name = ''
      self.desired_action = 'gs'
      self.sensor_label = None
      self.sensor_being_deleted = ''
      self.from_delete_selected = False
      self.csv_data_dict_of_dicts = {}
      self.unix_timestamp_dict_of_dicts = {}
      self.child_count = 0
      self.selected_sensor_count = 0
      self.selected_sensor_being_deleted_count = 0
      self.nbrOfSubmitCalls = 0
      self.sensor_list_tree = None
      self.plotted_channels_dict = {}

      self.in_file_name = None
      self.appendMode = False
      self.csv_mode = False
      self.selected_sensor_names = []

      self.outputFile = None
      self.processError = False

      if (in_file_name != None):
         self.in_file_name = in_file_name
         self.csv_object_name = csv_object_name
         self.csv_mode = True
      else:
         # Open log file in append mode
         self.outputFile = open('InertialSensorUtils_DeleteSensor.log','a')

      # QProcess object for 'delete all sensors'
      self.process_delete_all = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process_delete_all.readyRead.connect(lambda: self.dataReady(self.process_delete_all))
      self.process_delete_all.readyReadStandardOutput.connect(lambda: self.readyReadStandardOutput(self.process_delete_all))
      self.process_delete_all.readyReadStandardError.connect(lambda: self.readyReadStandardError(self.process_delete_all))

      self.process_delete_all.started.connect(self.processDeleteAllStarted)
      self.process_delete_all.finished.connect(self.processDeleteAllDone)

      # QProcess object for 'delete selected sensors'
      self.process_del_selected = QtCore.QProcess(self)

      # self.process_del_selected.readyRead.connect(lambda: self.dataReady(self.process_del_selected))
      self.process_del_selected.readyReadStandardOutput.connect(lambda: self.readyReadStandardOutput(self.process_del_selected))
      self.process_del_selected.readyReadStandardError.connect(lambda: self.readyReadStandardError(self.process_del_selected))

      self.process_del_selected.started.connect(self.processDelSelStarted)
      self.process_del_selected.finished.connect(self.processDelSelDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

      self.__controls()
      self.__layout()

   def closeEvent(self, event):
      print "Closing MySensorListWidget window"

      if (self.csv_mode == False):
         self.outputFile.close()

      super(MySensorListWidget, self).closeEvent(event)

   def processDeleteAllStarted(self):
      if (self.csv_mode == False):
         self.outputFile.write(' ******* Starting Delete All Sensors:\n')

      self.lbl_status.setText("Status: Deleting all sensors.. please wait")

      # Just to prevent accidentally running multiple times
      # Disable the delete buttons when process starts, and enable them when it finishes
      self.delete_all_sensors_button.setEnabled(False)
      self.delete_selected_sensors_button.setEnabled(False)
      self.doAction()

   def processDeleteAllDone(self):
      if (self.processError):
         logMsg = ' ******* ERROR: Delete All Sensors: Pl. check Delete Sensors Log ********'
      else:
         logMsg = 'DONE Delete All Sensors'

      if (self.csv_mode == False):
         self.outputFile.write(' ******* ' + logMsg)

      self.lbl_status.setText('Status: ' + logMsg)

      # Reset processError flag for next call
      self.processError = False
      self.step = 0

      # Re-enable the delete buttons after completing the command:
      self.delete_all_sensors_button.setEnabled(True)
      self.delete_selected_sensors_button.setEnabled(True)

      # Refresh list of sensors after deleting selected ones:
      self.sensor_list_tree.initUI()

      if (self.csv_mode == False):
         self.outputFile.flush()

   def processDelSelStarted(self):
      if (self.csv_mode == False):
         self.outputFile.write(' ******* Starting Delete Selected Sensors: ' + str(self.sensor_being_deleted) + '\n')

      strStatusLabel = 'Status: Deleting sensor: ' + str(self.sensor_being_deleted) + ' [' + str(self.selected_sensor_being_deleted_count) + ' of ' + str(self.selected_sensor_count) + ']'
      self.lbl_status.setText(strStatusLabel)

      self.delete_selected_sensors_button.setEnabled(False)
      self.delete_all_sensors_button.setEnabled(False)
      self.doAction()

   def processDelSelDone(self):
      if (self.processError):
         logMsg = ' ******* ERROR: Delete Selected Sensors: Pl. check Delete Sensors Log ********'
      else:
         logMsg = 'DONE deleting sensor: ' + str(self.sensor_being_deleted) + ' [' + str(self.selected_sensor_being_deleted_count) + ' of ' + str(self.selected_sensor_count) + ']'

      if (self.csv_mode == False):
         self.outputFile.write(' ******* ' + logMsg)

      self.lbl_status.setText('Status: ' + logMsg)

      # Reset processError flag for next call
      self.processError = False
      self.step = 0

      if (self.selected_sensor_being_deleted_count == self.selected_sensor_count):
         self.delete_selected_sensors_button.setEnabled(True)
         self.delete_all_sensors_button.setEnabled(True)

         # Refresh list of sensors after deleting selected ones:
         self.sensor_list_tree.initUI()

         if (self.csv_mode == False):
            self.outputFile.flush()

   def readyReadStandardOutput(self, process):
      stdOutputStr = str(process.readAllStandardOutput())
      self.outputFile.write('\n' + stdOutputStr)
      self.outputFile.flush()

   def readyReadStandardError(self, process):
      self.processError = True

      self.outputFile.write('\n')
      errorLog = str(process.readAllStandardError())
      self.outputFile.write(errorLog)
      self.outputFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith("Status: DONE")):
         if (self.from_delete_selected):
            if (self.selected_sensor_being_deleted_count == self.selected_sensor_count):
               self.timer.stop()
            else:
               self.nbrOfSubmitCalls += 1
               self.submitDeleteSelectedSensors(False)
            # } if (self.selected_sensor_being_deleted_count ==..
         else:
            self.timer.stop()
         # } if (self.from_delete_selected)..

         return
      # } if (self.lbl_status.text().startsWith("Status: DONE")..

      self.step = self.step + 1
      strStatusLabel = ''
      if (self.from_delete_selected):
         strStatusLabel = "Status: Deleting sensor: " + str(self.sensor_being_deleted) + " [" + str(self.selected_sensor_being_deleted_count) + " of " + str(self.selected_sensor_count) + "]: Time elapsed: " + str(self.step) + " sec"
      else:
         strStatusLabel = "Status: Doing.. Time elapsed: " + str(self.step) + " seconds"
      self.lbl_status.setText(strStatusLabel)

   def doAction(self):
      if (self.timer.isActive() and self.from_delete_selected == False):
         self.timer.stop()
         return

      self.step = 0
      self.timer.start(1000, self)

   def append_tree_obj_from_file(self, append_file_name, csv_object_name = None):
      self.append_file_name = append_file_name
      self.appendMode = True
      self.csv_mode = True

      if (self.sensor_list_tree != None and self.append_file_name != None):
         # print(' ************* appending to tree: csv_object_name = ' + csv_object_name)
         self.sensor_list_tree.append_tree_obj_from_file(self.append_file_name, str(csv_object_name))

   def clearStatusText(self):
      self.lbl_status.setText("Status:")

   def __controls(self):

      labelText = "Sensor List"

      self.lbl_space_xxsmall = QtGui.QLabel()
      self.lbl_space_xxsmall.setFixedWidth(2)
      self.lbl_space_xxsmall.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(40)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(60)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(180)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.lbl_title = QtGui.QLabel(labelText)
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(475)
      self.lbl_status.setFixedHeight(25)

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_sensor_name = MyLineEdit()
      self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
      self.edt_sensor_name.setReadOnly(True)

      self.clear_status_text_button = QtGui.QPushButton("Clear")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");
      self.clear_status_text_button.setFixedWidth(60)

      if (self.csv_mode == False):
         self.delete_all_sensors_button = QtGui.QPushButton("Delete All Sensors")
         self.delete_all_sensors_button.setCheckable(True)
         self.delete_all_sensors_button.toggle()
         self.delete_all_sensors_button.clicked.connect(self.submitDeleteAllSensors)
         self.delete_all_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      if (self.csv_mode == False):
         self.delete_selected_sensors_button = QtGui.QPushButton("Delete Selected Sensors")
         self.delete_selected_sensors_button.setCheckable(True)
         self.delete_selected_sensors_button.toggle()
         self.delete_selected_sensors_button.clicked.connect(lambda: self.submitDeleteSelectedSensors(True))
         self.delete_selected_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_selected_cols_button = None
      self.plot_diff_selected_cols_button = None

      if (self.csv_mode == True):
         # self.plot_new_tab_each_col_button = QtGui.QPushButton("Plot Selected Columns")
         self.plot_new_tab_each_col_button = QtGui.QPushButton("1 Plot (tab) per Column")
         self.plot_diff_selected_cols_button = QtGui.QPushButton("Plot Diff Selected Columns")
         self.plot_2_sensors_on_same_plot_button = QtGui.QPushButton("2 CSV Files on 1 Plot")
      else:
         # self.plot_new_tab_each_col_button = QtGui.QPushButton("Plot Selected Channels")
         self.plot_new_tab_each_col_button = QtGui.QPushButton("1 Plot (tab) per Channel")
         self.plot_diff_selected_cols_button = QtGui.QPushButton("Plot Diff Selected Channels")
         self.plot_2_sensors_on_same_plot_button = QtGui.QPushButton("2 Sensors on 1 Plot")

      self.plot_LLH_button = QtGui.QPushButton("LLH Plot")

      self.plot_new_tab_each_col_button.setCheckable(True)
      self.plot_new_tab_each_col_button.toggle()
      self.plot_new_tab_each_col_button.clicked.connect(lambda: self.submitPlotSelectedCols(0))
      self.plot_new_tab_each_col_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_diff_selected_cols_button.setCheckable(True)
      self.plot_diff_selected_cols_button.toggle()
      self.plot_diff_selected_cols_button.clicked.connect(lambda: self.submitPlotSelectedCols(1))
      self.plot_diff_selected_cols_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_2_sensors_on_same_plot_button.setCheckable(True)
      self.plot_2_sensors_on_same_plot_button.toggle()
      self.plot_2_sensors_on_same_plot_button.clicked.connect(lambda: self.submitPlotSelectedCols(2))
      self.plot_2_sensors_on_same_plot_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_LLH_button.setCheckable(True)
      self.plot_LLH_button.toggle()
      self.plot_LLH_button.clicked.connect(lambda: self.submitPlotSelectedCols(3))
      self.plot_LLH_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      if (self.csv_mode == False):
         self.sensor_list_tree = MyTreeWidget(self.parent_obj)
      elif (self.appendMode == False):
         # print(' ******* appendMode is False, creating MyTreeWidget with self.csv_object_name = ' + self.csv_object_name)
         self.sensor_list_tree = MyTreeWidget(self.parent_obj, self.in_file_name, self.csv_object_name)

      self.sensor_list_tree.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()

      # -------------- TBD: -----------------------------
      if (0):
         if (desired_action == 'as'):
            if (sensor_label != None):
               addSensor(server, token, self.parent_obj.device_id, self.sensor_name, self.sensor_label)
            else:
               addSensor(server, token, self.parent_obj.device_id, self.sensor_name)
         elif (desired_action == 'us'):
            if (sensor_label != None):
               updateSensor(server, token, self.parent_obj.device_id, self.sensor_name, "", self.sensor_label)
            else:
               updateSensor(server, token, self.parent_obj.device_id, self.sensor_name, "")
         elif (desired_action == 'ac'):
            if (channel_label != None):
               addChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name, self.channel_label)
            else:
               addChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name)
         elif (desired_action == 'uc'):
            if (channel_label != None):
               updateChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name, self.channel_label)
            else:
               updateChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name)
            # } if (channel_label != None)..
         # } if (desired_action == 'as')..
      # } if (0)..

   def submitDeleteSelectedSensors(self, firstCall):
      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()
      self.from_delete_selected = True
      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to delete')
         return

      if (firstCall):
         self.nbrOfSubmitCalls = 0
         self.selected_sensor_count = 0
         self.selected_sensor_names = []
         self.selected_sensor_being_deleted_count = 0

         for i in range(self.child_count):
             item = root.child(i)
             sensor_name = str(item.text(0))
             if (item != None and item.checkState(0) == QtCore.Qt.Checked):
                self.selected_sensor_count += 1
                # self.selected_sensor_names[i] = item.text(0) # OR: item.text(column)?
                self.selected_sensor_names.append(sensor_name)
             # } if (item != None and..
         # } for i in range(self.child_count)..

         if (self.selected_sensor_count == 0):
           QtGui.QMessageBox.about(self, "Msg Box", 'No sensors selected to delete')
           return
         # } if (self.selected_sensor_count == 0)..
      # } if (firstCall)..

      s = self.selected_sensor_names[self.nbrOfSubmitCalls]
      print(' ********** Deleting sensor name: ' + s)

      command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
      command_line += '" -sv "' + self.parent_obj.server
      command_line += '" -t "' + self.parent_obj.token
      command_line += '" -s "' + s
      command_line += '" -a ds'

      if (self.csv_mode == False):
         self.outputFile.write('\n ******** Starting Sensor Cloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n' )
         self.outputFile.write(' ******* Deleted Selected Sensors: Command = ' + command_line + '\n')

      print(' ********* DELETE SELECTED SENSOR: command_line = ' + command_line)
      self.sensor_being_deleted = s
      self.selected_sensor_being_deleted_count += 1
      self.process_del_selected.start(command_line)

   def submitPlotSelectedCols(self, mode):
      # mode: 0 means 1 plot (tab) per column (or channel)
      # mode: 1 means 'diff plot'
      # mode: 2 means '2 sensor columns (or channels) on 1 plot
      # mode: 3 means 'Lat-Lon or LLH 3D' plot

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()
      self.from_delete_selected = False
      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to plot')
         return

      selected_column_names_dict = {}
      selected_plot_col_count = {}
      selected_plot_total_col_count = 0
      selected_llh_dict = {}

      c_tow_col = {}
      c_week_col = {}
      error_msg = ''
      llh_3d_plot = False

      for i in range(self.child_count):
         item = root.child(i)
         sensor_name = str(item.text(0))
         self.childs_child_count = item.childCount()

         print(' ********** sensor_name = ' + sensor_name + ' self.childs_child_count = ' + str(self.childs_child_count))

         for j in range(self.childs_child_count):
            items_child = item.child(j)
            # print(' ********** column name: items_child.text(0) = ' + str(items_child.text(0)))

            if (items_child.checkState(0) == QtCore.Qt.Checked):
               col_name = str(items_child.text(0))
               print(' ***** column: ' + col_name + ' is checked')
               if ('tow' in str(col_name).lower()):
                  c_tow_col[sensor_name] = col_name
               elif ('week' in str(col_name).lower()):
                  c_week_col[sensor_name] = col_name
               else:
                  if (sensor_name not in selected_plot_col_count):
                     print(' *********** adding sensor_name: ' + sensor_name  + ' to selected_column_names_dict')
                     selected_column_names_dict[sensor_name] = []
                     selected_plot_col_count[sensor_name] = 0

                  selected_column_names_dict[sensor_name].append(col_name)
                  selected_plot_col_count[sensor_name] += 1

                  selected_plot_total_col_count += 1
                  print(' ********* adding col_name to selected_column_names_dict[' + sensor_name + '], selected_plot_col_count = ' + str(selected_plot_col_count[sensor_name]))

               # } if ('tow' in col_name.lower())..
            # } if (items_child.checkState(0)..
         # } for j in range(self.childs_child_count)..

         if (sensor_name in selected_column_names_dict):
            # if (sensor_name in c_tow_col and len(selected_column_names_dict[sensor_name]) == 0):
            if (len(selected_column_names_dict[sensor_name]) == 0):
               error_msg += 'Must select at least one column for sensor: ' + sensor_name + '\n'
            elif (self.csv_mode == True and mode != 3 and sensor_name not in c_tow_col and len(selected_column_names_dict[sensor_name]) > 0):
               if (mode == 0):
                  error_msg += 'Must select a TOW column for sensor: ' + sensor_name + '\n'
               else:
                  error_msg += 'Must select GPS Week, TOW columns for sensor: ' + sensor_name + '\n'

            if (mode == 3):
               if (sensor_name in c_tow_col):
                  error_msg += 'Cannot select TOW column for LLH plot for sensor: ' + sensor_name + '\n'

               lat_in_sel_cols = False
               lon_in_sel_cols = False
               ht_in_sel_cols = False

               for col in selected_column_names_dict[sensor_name]:
                  if ('lat' in col.lower()):
                     lat_in_sel_cols = True
                     if (sensor_name not in selected_llh_dict):
                        selected_llh_dict[sensor_name] = {}
                     selected_llh_dict[sensor_name]['lat'] = col
                  # } if ('lat' in col.lower())..

                  if ('lon' in col.lower()):
                     lon_in_sel_cols = True
                     if (sensor_name not in selected_llh_dict):
                        selected_llh_dict[sensor_name] = {}
                     selected_llh_dict[sensor_name]['lon'] = col
                  # } if ('lon' in col.lower())..

                  if ('ht' in col.lower() or 'height' in col.lower()):
                     ht_in_sel_cols = True
                     if (sensor_name not in selected_llh_dict):
                        selected_llh_dict[sensor_name] = {}
                     selected_llh_dict[sensor_name]['ht'] = col
                  # } if ('ht' in col.lower())..
               # } for col in selected_column_names_dict[sensor_name]..

               if (lat_in_sel_cols == False or lon_in_sel_cols == False):
                  error_msg += 'Must select both lat and lon for LLH plot for sensor: ' + sensor_name + '\n'

               if (lat_in_sel_cols and lon_in_sel_cols and ht_in_sel_cols):
                  llh_3d_plot = True

            # } if (mode == 3)..

            if (mode == 1 or mode == 2):
               if (len(selected_column_names_dict[sensor_name]) > 1):
                  error_msg += 'Cannot select more than one column for diff plot\n'
               elif ((sensor_name in c_tow_col and sensor_name not in c_week_col) or \
                     (sensor_name not in c_tow_col and sensor_name in c_week_col)):
                  if (self.csv_mode == True):
                     if (mode == 1):
                        error_msg += 'For diff plot, must select Week if TOW selected, or TOW if Week selected\n'
                     else:
                        error_msg += 'For 2 CSV files in 1 plot, must select Week if TOW selected, or TOW if Week selected\n'
                  else:
                     if (mode == 1):
                        error_msg += 'For diff plot, must select Week if TOW selected, TOW if Week selected, or unselect both Week and TOW for both sensors\n'
                     else:
                        error_msg += 'For 2 sensors in 1 plot, must select Week if TOW selected, TOW if Week selected, or unselect both Week and TOW for both sensors\n'
                     # } if (mode == 1)..
                  # } if (self.csv_mode == True)..
               # } if (len(selected_column_names_dict[sensor_name])..
            # } if (mode == 1 or mode == 2)..
         # } if (sensor_name in selected_column_names_dict)..
      # } for i in range(self.child_count)..

      if (selected_plot_total_col_count == 0):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select at least 1 column to plot')
         return
      elif ((mode == 1 or mode == 2) and len(selected_column_names_dict.keys()) != 2):
         error_msg += 'Must select exactly 2 sensors to compare\n'

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
         return

      defaultPen = pg.mkPen('#5133E6', width=2, style=QtCore.Qt.DashLine)

      if (mode == 3):
         for s in selected_column_names_dict.keys():
            print(' ******* sensor name: ' + s)
            csv_data_dict = {}
            title = ''

            # Get LLH data if already obtained before
            if (s in self.csv_data_dict_of_dicts):
               csv_data_dict = self.csv_data_dict_of_dicts[s]

            # Get LLH data now (for selected LLH columns only, that were not obtained before)
            for c in selected_column_names_dict[s]:
               print('\n------------------------------------------------------------------------------------------------------------------------')
               print('\n******* sensor name: ' + s + ', column name: ' + c)

               if (c not in csv_data_dict):
                  if (self.csv_mode == True):
                     # Column name is not in csv_data_dict, so get csv_data_dict[c] using tree widget
                     csv_data_dict[c] = self.sensor_list_tree.csv_data_dict[s][c]
                  else:
                     # Channel name is not in csv_data_dict, so get csv_data_dict[c] and unix_timestamp_dict[c] using sensor cloud
                     csv_data_dict[c], unix_timestamp_dict[c] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c, 0, utcunix_now)
                  # } if (self.csv_mode == True)..
               # } if (c not in csv_data_dict)..
            # } for c in selected_column_names_dict[s]..

            xlabel = selected_llh_dict[s]['lon']
            ylabel = selected_llh_dict[s]['lat']

            self.parent_obj.plot_tab_cnt += 1

            tabIndex = self.parent_obj.plot_tab_cnt
            if (self.parent_obj.sensor_cloud_enabled == True):
               tabIndex += 1

            if (llh_3d_plot):
               try:
                  zlabel = selected_llh_dict[s]['ht']

                  # import pyqtgraph as pg
                  # pg.mkQApp()

                  # app = pg.mkQApp()
                  # view  = pg.GraphicsView()#useOpenGL = True)

                  # color='#A2C3F3'
                  # view.setBackground(color)

                  # view.show()

                  # view = gl.GLViewWidget()
                  # view.show()

                  ## create three grids, add each to the view
                  # xgrid = gl.GLGridItem()
                  # ygrid = gl.GLGridItem()
                  # zgrid = gl.GLGridItem()
                  # view.addItem(xgrid)
                  # view.addItem(ygrid)
                  # view.addItem(zgrid)

                  ## rotate x and y grids to face the correct direction
                  # xgrid.rotate(90, 0, 1, 0)
                  # ygrid.rotate(90, 1, 0, 0)

                  # graphicsItem = gl.GLGraphicsItem()
                  # *****************************

                  # pg.setConfigOption('background', '#A2C3F3')
                  # pg.setConfigOption('foreground', 'k')

                  w = gl.GLViewWidget()
                  # w.opts['distance'] = 40
                  w.opts['distance'] = 100
                  # w.show()
                  w.setWindowTitle('3D PLOT')
                  # w.setBackgroundColor('#A2C3F3')

                  gx = gl.GLGridItem()
                  gx.setSize(60, 60, 60)
                  gx.rotate(90, 0, 1, 0)
                  # gx.translate(-10, 0, 0)
                  # gx.translate(-20, 0, 0)
                  w.addItem(gx)

                  gy = gl.GLGridItem()
                  gy.setSize(60, 60, 60)
                  gy.rotate(90, 1, 0, 0)
                  # gy.translate(0, -10, 0)
                  # gy.translate(0, -20, 0)
                  w.addItem(gy)

                  gz = gl.GLGridItem()
                  gz.setSize(60, 60, 60)
                  # gz.translate(0, 0, -10)
                  gz.translate(0, 0, -30)
                  w.addItem(gz)

                  # ga = gl.GLAxisItem()
                  # w.addItem(ga)

                  # pts = np.array([X,Y,Z])
                  # pts = np.array([csv_data_dict[selected_llh_dict[s]['lon']], csv_data_dict[selected_llh_dict[s]['lat']], csv_data_dict[selected_llh_dict[s]['ht']]])

                  # n = 7
                  # y = np.linspace(-10,10,n)
                  # x = np.linspace(-10,10,100)

                  # for i in range(n):

                  # yi = X
                  # d = Y
                  # z = Z
                  # pts = np.vstack([X,Y,Z]).transpose()
                  # pts = np.array([X,Y,Z]).transpose()

                  tmp_llh_col_name_dict = selected_llh_dict[s]

                  lat_col_name = tmp_llh_col_name_dict['lat']
                  lon_col_name = tmp_llh_col_name_dict['lon']
                  ht_col_name = tmp_llh_col_name_dict['ht']
                  print(' ******* lat_col_name = ' + lat_col_name + ' lon_col_name = ' + lon_col_name + ' ht_col_name = ' + ht_col_name)

                  lon_col = csv_data_dict[lon_col_name]
                  lat_col = csv_data_dict[lat_col_name]
                  ht_col = csv_data_dict[ht_col_name]

                  print(' ***** len(lon_col) = ' + str(len(lon_col)))

                  x = lon_col
                  y = lat_col
                  z = ht_col

                  # n = 51
                  # y = np.linspace(-10,10,n)
                  # x = np.linspace(-10,10,100)

                  i = 10
                  # yi = np.array([y[i]]*100)

                  yi = np.array(y)

                  # d = (x**2 + yi**2)**0.5
                  # z = 10 * np.cos(d) / (d+1)

                  print(' ******** len(x) = ' + str(len(x)))
                  indx = 0
                  for tmp in x:
                     print(' ******* temp x = ' + str(tmp))
                     indx += 1
                     if (indx > 15):
                        break

                  print(' ******** len(y) = ' + str(len(y)))
                  indx = 0
                  for tmp in y:
                     print(' ******* temp y = ' + str(tmp))
                     indx += 1
                     if (indx > 15):
                        break

                  print(' ******** len(z) = ' + str(len(z)))
                  indx = 0
                  for tmp in z:
                     print(' ******* temp z = ' + str(tmp))
                     indx += 1
                     if (indx > 15):
                        break
               # except gl.error.GLError as err:
               except Exception as err:
                  print(" ******** OpenGL.error.GLError: Error Msg: {0}".format(err))
                  return

               # return

               #yi = np.array([y[i]]*100)
               #d = (x**22 + yi**2)**0.5
               #z = 10 * np.cos(d) / (d+1)

               pts = np.vstack([np.array(x)/5, np.array(y)/5, np.array(z)/5]).transpose()

               indx = 0
               for p in pts:
                  print(' ************ indx = ' + str(indx) + ' p = ' + str(p))
                  indx += 1
                  if (indx > 25):
                     break

               # pts = np.vstack([np.array(altitude_array), np.array(ambient_pressure_array), np.array(ambient_temp_array)]).transpose()

               # pts = np.vstack([x,yi,z]).transpose()
               # pts = np.vstack([x, yi, z])
               # pts = np.array([x, y, z])
               # pts = np.array([x, yi, z])

               # plt = gl.GLLinePlotItem(pos=pts, color=pg.glColor((i,n*1.3)), width=(i+1)/10., antialias=True)
               # for i in range(3):
               i = 10
               # plt = gl.GLLinePlotItem(pos=pts, color=pg.glColor((i,3*1.3)), width=(i+1)/10., antialias=True)
               plt = gl.GLLinePlotItem(pos=pts, color=pg.glColor((i,3*1.3)), antialias=True)

               # plt.enableAutoRange('xy', False)

               w.addItem(plt)

               # *****************************
               # -------------
               # graphicsWidget = pg.GraphicsLayoutWidget()
               # graphicsWidget.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

               # graphicsWidgetAnchor = pg.GraphicsWidgetAnchor

               # Enable antialiasing for prettier plots
               # pg.setConfigOptions(antialias=True)

               # Generate the figure parameters for plotting output data
               # p1 = graphicsWidget.addPlot()
               # -------------
               # p1.plot(csv_data_dict[selected_llh_dict[s]['lon']], csv_data_dict[selected_llh_dict[s]['lat']], csv_data_dict[selected_llh_dict[s]['ht']], pen=defaultPen)
               # p1.showGrid(x=True, y=True, z=True)
            else:
               pg.setConfigOption('background', '#A2C3F3')
               pg.setConfigOption('foreground', 'k')

               graphicsWidget = pg.GraphicsLayoutWidget()
               graphicsWidget.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

               # Enable antialiasing for prettier plots
               pg.setConfigOptions(antialias=True)

               # Generate the figure parameters for plotting output data
               p1 = graphicsWidget.addPlot()

               p1.plot(csv_data_dict[selected_llh_dict[s]['lon']], csv_data_dict[selected_llh_dict[s]['lat']], pen=defaultPen)
               p1.showGrid(x=True, y=True)

               p1.setLabel('bottom', xlabel)
               p1.setLabel('left', ylabel)

               title = s + ': ' + ylabel + ' vs ' + xlabel

               p1.setTitle(title)
            # } if (llh_3d_plot)..

            if (self.csv_mode == True):
               tabLabel = "CSV Plot"
            else:
               tabLabel = "Channel Plot"

            closeButton = QtGui.QPushButton()
            closeButton.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon.png")))
            closeButton.clicked.connect(lambda:self.parent_obj.whichbtn(closeButton))
            closeButton.setFixedWidth(15)
            closeButton.setFixedHeight(15)

            if (llh_3d_plot):
               graphicsWidgetObj = w
            else:
               graphicsWidgetObj = graphicsWidget

            self.parent_obj.tabs.addTab(graphicsWidgetObj, tabLabel)

            self.parent_obj.plot_tab_dict[closeButton] = self.parent_obj.plot_tab_cnt
            self.parent_obj.plot_tab_push_button_dict[closeButton] = self.parent_obj.tabs.indexOf(graphicsWidgetObj)

            self.parent_obj.tabs.tabBar().setTabButton(self.parent_obj.tabs.indexOf(graphicsWidgetObj), QtGui.QTabBar.RightSide, closeButton)

            self.parent_obj.tabs.setCurrentIndex(self.parent_obj.tabs.indexOf(graphicsWidgetObj))

         # } for s in selected_column_names_dict.keys()..
      else:
         utcnow = datetime.utcnow().utctimetuple()
         utcunix_now = calendar.timegm(utcnow) * 1000000000

         cnt_sensor = 0

         csv_data_prev = []
         csv_data_tow_prev = []
         csv_data_week_prev = []

         s_prev = None
         col_name_prev = None
         csv_data_prev_interp = []
         csv_data_curr_interp = []

         # defaultPen = pg.mkPen('#5133E6', width=2, style=QtCore.Qt.DashLine)

         if (self.csv_mode == False):
            unix_timestamp_dict_prev = {}

         for s in selected_column_names_dict.keys():
            print('\n----------------------------------------------------------------------')

            csv_data_dict = {}

            if (self.csv_mode == False):
               unix_timestamp_dict = {}

            print(' ******* sensor name: ' + s)
            cnt_sensor += 1

            if (s in self.csv_data_dict_of_dicts):
               csv_data_dict = self.csv_data_dict_of_dicts[s]
               if (self.csv_mode == False):
                  unix_timestamp_dict = self.unix_timestamp_dict_of_dicts[s]

            # Get the TOW column data if selected to plot by the user and not already in the csv data structure
            if (s in c_tow_col and c_tow_col[s] not in csv_data_dict):
               if (self.csv_mode == True):
                  csv_data_dict[c_tow_col[s]] = self.sensor_list_tree.csv_data_dict[s][c_tow_col[s]]
               else:
                  csv_data_dict[c_tow_col[s]], unix_timestamp_dict[c_tow_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_tow_col[s], 0, utcunix_now)

            # Get the Week column data if selected to plot by the user and not already in the csv data structure
            if (s in c_week_col and c_week_col[s] not in csv_data_dict):
               if (self.csv_mode == True):
                  csv_data_dict[c_week_col[s]] = self.sensor_list_tree.csv_data_dict[s][c_week_col[s]]
               else:
                  csv_data_dict[c_week_col[s]], unix_timestamp_dict[c_week_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_week_col[s], 0, utcunix_now)

            for c in selected_column_names_dict[s]:
               print('\n------------------------------------------------------------------------------------------------------------------------')
               print('\n******* sensor name: ' + s + ', column name: ' + c)

               if (c not in csv_data_dict):
                  if (self.csv_mode == True):
                     # Column name is not in csv_data_dict, so get csv_data_dict[c] using tree widget
                     csv_data_dict[c] = self.sensor_list_tree.csv_data_dict[s][c]
                  else:
                     # Channel name is not in csv_data_dict, so get csv_data_dict[c] and unix_timestamp_dict[c] using sensor cloud
                     csv_data_dict[c], unix_timestamp_dict[c] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c, 0, utcunix_now)

               if ((mode == 1 or mode == 2) and cnt_sensor == 1):
                  col_name_prev = c

               if (mode == 0 or ((mode == 1 or mode == 2) and cnt_sensor == 2)):
                  # pg.setConfigOption('background', 'w')
                  pg.setConfigOption('background', '#A2C3F3')
                  pg.setConfigOption('foreground', 'k')

                  # mkPen('y', width=3, style=QtCore.Qt.DashLine)          ## Make a dashed yellow line 2px wide
                  # mkPen(0.5)                                             ## solid grey line 1px wide
                  # mkPen(color=(200, 200, 255), style=QtCore.Qt.DotLine)

                  graphicsWidget = pg.GraphicsLayoutWidget()
                  graphicsWidget.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

                  # graphicsWidgetAnchor = pg.GraphicsWidgetAnchor

                  # Enable antialiasing for prettier plots
                  pg.setConfigOptions(antialias=True)

                  # Generate the figure parameters for plotting output data
                  p1 = graphicsWidget.addPlot()

                  if (s in c_tow_col):
                     if (mode == 1 or mode == 2):
                        if (cnt_sensor == 2):
                           # Check if the first element in GPS Week arrays are same between the 2 sensors
                           gps_week_sensor1 = csv_data_dict[c_week_col[s]][0]
                           gps_week_sensor2 = csv_data_week_prev[0]

                           print('******** gps_week_sensor1 = ' + str(gps_week_sensor1) + ', gps_week_sensor2 = ' + str(gps_week_sensor2))

                           if (gps_week_sensor1 == 0 or gps_week_sensor2 == 0 or gps_week_sensor1 != gps_week_sensor2):
                              print(' *********** The 2 GPS Weeks are not same')
                              QtGui.QMessageBox.about(self, "Msg Box", 'GPS Week must be none-zero and same between the 2 sensors for diff plot or 2 sensor plot')
                              return

                           if ( len(csv_data_dict[c_tow_col[s]]) != len(csv_data_dict[c]) or \
                                len(csv_data_tow_prev) != len(csv_data_prev) ):
                              QtGui.QMessageBox.about(self, "Msg Box", 'TOW column must have the same nbr of points as the column to plot')
                              return

                           if (mode == 2): # (2 sensors in 1 plot):
                              print(' *********** mode is TOW: 2 sensors in 1 plot')

                              legend = pg.LegendItem()
                              legend.setParentItem(p1)

                              legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

                              pdi1 = p1.plot(csv_data_tow_prev, csv_data_prev, pen=defaultPen, name='&nbsp;&nbsp;&nbsp;' + s_prev)  # dark blue
                              pdi2 = p1.plot(csv_data_dict[c_tow_col[s]], csv_data_dict[c], pen=pg.mkPen('#20541B', width=2, style=QtCore.Qt.DotLine), name='&nbsp;&nbsp;&nbsp;' + s)   # dark green

                              legend.addItem(pdi1, name=pdi1.opts['name'])
                              legend.addItem(pdi2, name=pdi2.opts['name'])

                           else: # mode = 1 (diff plot)
                              # Check if there is a need to interpolate.  If the time columns are same length
                              # and max difference between individual timestamp pairs is less than 1e-6, then
                              # we consider them to be identical
                              if ((len(csv_data_dict[c_tow_col[s]]) == len(csv_data_tow_prev)) and \
                                 max( abs(np.array(csv_data_dict[c_tow_col[s]]) - np.array(csv_data_tow_prev)) ) < 1e-6 ):
                                 # print('*********** len(csv_data_dict[c_tow_col[s]]) EQUAL TO len(csv_data_tow_prev) = ' + str(len(csv_data_dict[c_tow_col[s]])) + ' len(csv_data_dict[c]) = ' + str(len(csv_data_dict[c])) + ' len(csv_data_prev) = ' + str(len(csv_data_prev)) )
                                 print(' *** TOW columns identical, no need to interpolate')

                                 p1.plot(csv_data_dict[c_tow_col[s]], np.array(csv_data_dict[c])-np.array(csv_data_prev), pen=defaultPen)
                              else: # interpolate if there is an overlap of at least 20 percent
                                 tmp_min_tow_sensor = 0
                                 tmp_max_tow_sensor = 0

                                 min_tow_sensor2 = min( np.array(csv_data_dict[c_tow_col[s]]) )
                                 max_tow_sensor2 = max( np.array(csv_data_dict[c_tow_col[s]]) )

                                 min_tow_sensor1 = min( np.array(csv_data_tow_prev) )
                                 max_tow_sensor1 = max( np.array(csv_data_tow_prev) )

                                 # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
                                 if (min_tow_sensor1 > min_tow_sensor2):
                                    tmp_min_tow_sensor = min_tow_sensor1
                                    tmp_max_tow_sensor = max_tow_sensor1
                                    min_tow_sensor1 = min_tow_sensor2
                                    max_tow_sensor1 = max_tow_sensor2
                                    min_tow_sensor2 = tmp_min_tow_sensor
                                    max_tow_sensor2 = tmp_max_tow_sensor

                                 if ( ((max_tow_sensor1 - min_tow_sensor2)/(max_tow_sensor1-min_tow_sensor1) > 0.2) ):
                                    csv_data_prev_interp = np.interp(np.array(csv_data_dict[c_tow_col[s]]), np.array(csv_data_tow_prev), np.array(csv_data_prev))
                                    p1.plot(csv_data_dict[c_tow_col[s]], np.array(csv_data_dict[c])-np.array(csv_data_prev_interp), pen=defaultPen)
                                 else:
                                    QtGui.QMessageBox.about(self, "Msg Box", 'TOW columns must have at least 20 percent overlap for diff plot')
                                    return
                              # } if (len(csv_data_dict[c_tow_col[s]])..
                        # } if (cnt_sensor == 2)..
                     else:
                        if (len(csv_data_dict[c_tow_col[s]]) != len(csv_data_dict[c])):
                           QtGui.QMessageBox.about(self, "Msg Box", 'TOW column must have the same nbr of points as the column to plot')
                           return
                        else:
                           p1.plot(csv_data_dict[c_tow_col[s]], csv_data_dict[c], pen=defaultPen)
                        # } if (len(csv_data_dict[c_tow_col[s]]) !=..
                     # } if (mode == 1 or mode == 2)..
                  else:
                     print(' *********** s NOT in c_tow_col, s = ' + s)
                     if (mode == 1 or mode == 2):
                        if (cnt_sensor == 2):
                           if (mode == 2): # (2 sensors in 1 plot):
                              print(' *********** mode is Unix timestamp: 2 sensors in 1 plot')

                              legend = pg.LegendItem()
                              legend.setParentItem(p1)

                              legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

                              pdi1 = p1.plot(unix_timestamp_dict_prev[col_name_prev], csv_data_prev, pen=defaultPen, name='&nbsp;&nbsp;&nbsp;' + s_prev)
                              pdi2 = p1.plot(unix_timestamp_dict[c], csv_data_dict[c], pen=pg.mkPen('#20541B', width=2, style=QtCore.Qt.DotLine), name='&nbsp;&nbsp;&nbsp;' + s)

                              legend.addItem(pdi1, name=pdi1.opts['name'])
                              legend.addItem(pdi2, name=pdi2.opts['name'])

                           else: # mode = 1 (diff plot)
                              if ((len(unix_timestamp_dict[c]) == len(unix_timestamp_dict_prev[col_name_prev])) and \
                                 max( abs(np.array(unix_timestamp_dict[c]) - np.array(unix_timestamp_dict_prev[col_name_prev])) ) < 1e-6 ):
                                 print(' *** Unix timestamp columns identical, no need to interpolate')

                                 # p1.plot(unix_timestamp_dict[c], np.array(csv_data_dict[c])-np.array(csv_data_prev), pen='b')
                                 p1.plot(unix_timestamp_dict[c], np.array(csv_data_dict[c])-np.array(csv_data_prev), pen=defaultPen)
                              else: # interpolate
                                 tmp_min_unix_timestamp_sensor = 0
                                 tmp_max_unix_timestamp_sensor = 0

                                 min_unix_timestamp_sensor2 = min( np.array(unix_timestamp_dict[c]) )
                                 max_unix_timestamp_sensor2 = max( np.array(unix_timestamp_dict[c]) )
                                 min_unix_timestamp_sensor1 = min( np.array(unix_timestamp_dict_prev[col_name_prev]) )
                                 max_unix_timestamp_sensor1 = max( np.array(unix_timestamp_dict_prev[col_name_prev]) )

                                 # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
                                 if (min_unix_timestamp_sensor1 > min_unix_timestamp_sensor2):
                                    tmp_min_unix_timestamp_sensor = min_unix_timestamp_sensor1
                                    tmp_max_unix_timestamp_sensor = max_unix_timestamp_sensor1
                                    min_unix_timestamp_sensor1 = min_unix_timestamp_sensor2
                                    max_unix_timestamp_sensor1 = max_unix_timestamp_sensor2
                                    min_unix_timestamp_sensor2 = tmp_min_unix_timestamp_sensor
                                    max_unix_timestamp_sensor2 = tmp_max_unix_timestamp_sensor

                                 if ( ((max_unix_timestamp_sensor1 - min_unix_timestamp_sensor2)/(max_unix_timestamp_sensor1-min_unix_timestamp_sensor1) > 0.2) ):
                                    csv_data_prev_interp = np.interp(np.array(unix_timestamp_dict[c]), np.array(unix_timestamp_dict_prev[col_name_prev]), np.array(csv_data_prev))
                                    p1.plot(unix_timestamp_dict[c], np.array(csv_data_dict[c])-np.array(csv_data_prev_interp), pen=defaultPen)
                                 else:
                                    QtGui.QMessageBox.about(self, "Msg Box", 'Unix timestamp columns must have at least 20 percent overlap for diff plot')
                                    return
                              # } if (len(csv_data_dict[c_tow_col[s]])..
                        # } if (cnt_sensor == 2)..
                     else:
                        p1.plot(unix_timestamp_dict[c], csv_data_dict[c], pen=defaultPen)
                     # } if (mode == 1 or mode == 2)..
                  # } if (s in c_tow_col)..

                  p1.enableAutoRange('xy', False)
                  # p1.setXRange(0, data_rate/2.0, padding=0)

                  p1.showGrid(x=True, y=True)

                  xlabel = ''

                  if (s in c_tow_col):
                     xlabel = 'TOW'
                  else:
                     xlabel = 'Unix Time (Nanosec)'

                  ylabel = ''

                  if (mode == 1):
                     ylabel = 'Diff in: ' + c
                  else:
                     ylabel = c

                  p1.setLabel('bottom', xlabel)
                  p1.setLabel('left', ylabel)

                  title = ''

                  if (mode == 1 or mode == 2):
                     title += str(s_prev) + ' vs ' + str(s) + ': '
                  else:
                     title = s + ': '

                  title += ylabel

                  if (mode == 0):
                     title += ' vs ' + xlabel

                  p1.setTitle(title)

                  if (self.csv_mode == True):
                     tabLabel = "CSV Plot"
                  else:
                     tabLabel = "Channel Plot"

                  closeButton = QtGui.QPushButton()
                  closeButton.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon.png")))
                  closeButton.clicked.connect(lambda:self.parent_obj.whichbtn(closeButton))
                  closeButton.setFixedWidth(15)
                  closeButton.setFixedHeight(15)

                  self.parent_obj.plot_tab_cnt += 1

                  tabIndex = self.parent_obj.plot_tab_cnt
                  if (self.parent_obj.sensor_cloud_enabled == True):
                     tabIndex += 1

                  self.parent_obj.tabs.addTab(graphicsWidget, tabLabel)

                  self.parent_obj.plot_tab_dict[closeButton] = self.parent_obj.plot_tab_cnt
                  self.parent_obj.plot_tab_push_button_dict[closeButton] = self.parent_obj.tabs.indexOf(graphicsWidget)

                  print(' ********* SensorListWidget: self.parent_obj.plot_tab_cnt = ' + str(self.parent_obj.plot_tab_cnt) + ', self.parent_obj.tabs.indexOf(graphicsWidget) = ' + str(self.parent_obj.tabs.indexOf(graphicsWidget)) + ' closeButton = ' + str(closeButton))

                  self.parent_obj.tabs.tabBar().setTabButton(self.parent_obj.tabs.indexOf(graphicsWidget), QtGui.QTabBar.RightSide, closeButton)

                  self.parent_obj.tabs.setCurrentIndex(self.parent_obj.tabs.indexOf(graphicsWidget))

                  # if (s not in self.plotted_channels_dict):
                     # self.plotted_channels_dict[s] = []
                  # } if (str(c) not in plotted_channels_dict[s])..

                  # self.plotted_channels_dict[s].append(str(c))
               # } if (mode == 0 or (..
            # } for c in selected_column_names_dict[s]..

            if (s not in self.csv_data_dict_of_dicts):
               self.csv_data_dict_of_dicts[s] = csv_data_dict
               if (self.csv_mode == False):
                  self.unix_timestamp_dict_of_dicts[s] = unix_timestamp_dict

            if ((mode == 1 or mode ==2) and cnt_sensor == 1):
               s_prev = s
               csv_data_prev = csv_data_dict[col_name_prev]
               # print(' ******** csv_data_prev[0] = ' + str(csv_data_prev[0]) + ' csv_data_prev[1] = ' + str(csv_data_prev[1]) + ' csv_data_prev[2] = ' + str(csv_data_prev[2]))

               if (s in c_tow_col):
                  if (c_tow_col[s] in csv_data_dict):
                     print(' ******** c_tow_col[s] = ' + c_tow_col[s] + ' in csv_data_dict, will set csv_data_tow_prev')
                     csv_data_tow_prev = csv_data_dict[c_tow_col[s]]
                  if (c_week_col[s] in csv_data_dict):
                     csv_data_week_prev = csv_data_dict[c_week_col[s]]
                  # } if (c_tow_col[s] in csv_data_dict)..
               elif (self.csv_mode == False):
                  unix_timestamp_dict_prev = unix_timestamp_dict
               # } if (c_tow_col[s] in csv_data_dict)..
            # } if ((mode == 1 or mode ==2) and..
         # } for s in selected_column_names_dict.keys()..
      # } if (mode == 3)..

      # Clear selected sensor(s)/channel(s) (make ready for next set of selections by user):
      self.sensor_list_tree.createCheckboxesForTree()

   def submitDeleteAllSensors(self):
      self.from_delete_selected = False

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()

      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to delete')
      else:
         command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
         command_line += '" -sv "' + self.parent_obj.server
         command_line += '" -t "' + self.parent_obj.token
         command_line += '" -a das'

         if (self.csv_mode == False):
            self.outputFile.write('\n ******** Starting Sensor Cloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
            self.outputFile.write(' ******* Deleted ALL Sensors: Command = ' + command_line + '\n')

         print(' ********* DELETE ALL: command_line = ' + command_line)

         self.process_delete_all.start(command_line)

      return

   def __layout(self):
      self.v1box = QtGui.QVBoxLayout()
      # self.v1box.addWidget(self.sensor_list_table)
      self.v1box.addWidget(self.sensor_list_tree)

      self.h2box = QtGui.QHBoxLayout()
      self.h2box.addWidget(self.lbl_space_small)

      self.h2box.addWidget(self.plot_diff_selected_cols_button)
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.plot_2_sensors_on_same_plot_button)
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.plot_new_tab_each_col_button)
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.plot_LLH_button)
      self.h2box.addWidget(self.lbl_space_small)

      self.v2box = QtGui.QVBoxLayout()
      self.v2box.addLayout(self.h2box)

      if (self.csv_mode == False):
         self.h3box = QtGui.QHBoxLayout()
         self.h3box.addWidget(self.lbl_space_medium)
         self.h3box.addWidget(self.delete_selected_sensors_button)
         self.h3box.addWidget(self.lbl_space_small)
         self.h3box.addWidget(self.delete_all_sensors_button)
         self.h3box.addWidget(self.lbl_space_medium)

         self.v3box = QtGui.QVBoxLayout()
         self.v3box.addLayout(self.h3box)

         self.h4box = QtGui.QHBoxLayout()
         self.h4box.addWidget(self.lbl_status)
         self.h4box.addWidget(self.clear_status_text_button)

         self.v4box = QtGui.QVBoxLayout()
         self.v4box.addLayout(self.h4box)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.v1box)
      self.vbox.addLayout(self.v2box)

      if (self.csv_mode == False):
         self.vbox.addLayout(self.v3box)
         self.vbox.addLayout(self.v4box)

      self.setLayout(self.vbox)

