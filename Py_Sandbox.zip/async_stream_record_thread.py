# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import sys
import os
import threading       #import thread library

from serial import *
from time import time  #import time library
from time import sleep           #sleep

from QInertialSensorUtils_GUI_MIP_Utils import *

#Class to asynchronously check for user pressing Enter key (to stop recording from GSG scenario)
class AsyncStreamRecord(threading.Thread):
   """Thread Object for checking user input """
   def __init__(self, port_obj, timeout = 0.001):
      """Initialize the AsyncStreamRecord Object"""
      threading.Thread.__init__(self)
      
      self.port_obj = port_obj
      
      self.timeout = timeout
      self._stop = False
      self.state = 0
      self.port_obj.fout_bin = None
      
      print(' ******* in ASYNC THREAD: port_name = ' + port_obj.port_name)
      
   def setLogFile(self, overwrite = False, cnt_stream_click = 0):
      if (self.port_obj.bin_filename != None and (str(self.port_obj.bin_filename)).strip() != ''):
         print(' ****** ASync Thread, self.port_obj.bin_filename = ' + str(self.port_obj.bin_filename) \
               + ', overwrite = ' + str(overwrite) + ', cnt_stream_click = ' + str(cnt_stream_click))
         
         mode = "ab"
         if (overwrite and cnt_stream_click == 1):
            mode = "wb"
         # } if (overwrite):..
    
         self.port_obj.fout_bin = open(self.port_obj.bin_filename, mode)

   def stop(self):
      """Stop thread loop"""
      self._stop = True

   def run(self):
      """Enter infinite loop"""
      
      self.bytes_read = bytearray()

      ping_filter_command = bytearray.fromhex('756501020201E0C6');

      resume_imu_command = bytearray.fromhex('75650C050511010101041A');
      idle_imu_command =   bytearray.fromhex('75650C0505110101000319');

      resume_gps_command = bytearray.fromhex('75650C050511010201051C');
      idle_gps_command =   bytearray.fromhex('75650C050511010200041B');

      resume_filter_command = bytearray.fromhex('75650C050511010301061E');
      idle_filter_command =   bytearray.fromhex('75650C050511010300051D');

      # Enter Idle Mode
      idle_mode_command = bytearray.fromhex('756501020202E1C7')

      # Resume Streaming
      resume_command = bytearray.fromhex('756501020206E5CB')
      
      try:
         if (self.port_obj.ComPort.is_open):
            self.port_obj.ComPort.close()
         # } if (self.port_obj.ComPort.is_open)..
 
         sleep(0.05)
 
         self.port_obj.ComPort.open()
      except SerialException:
         print('Caught Serial Exception')
      
      sleep(0.05)
      
      print('\n****** Sending Stream IMU command:')
      self.port_obj.ComPort.write(resume_imu_command)
      
      sleep(0.05)
      print('****** Sending Stream GPS command:')
      self.port_obj.ComPort.write(resume_gps_command)
      
      sleep(0.05)
      print('\n****** Sending Stream Filter command:')
      self.port_obj.ComPort.write(resume_filter_command)
      
      sleep(0.05)
      print('****** Sending RESUME command:')
      self.port_obj.ComPort.write(resume_command)
      
      sleep(0.05)
      
      read_current_imu_streaming_command = bytearray.fromhex('75650C0404110201020F');
      read_current_gps_streaming_command = bytearray.fromhex('75650C04041102020310');
      read_current_filter_streaming_command = bytearray.fromhex('75650C04041102030411');

      # print('Sending Read Current IMU command:')
      # self.port_obj.ComPort.write(read_current_imu_streaming_command)

      # print('Sending Read Current GPS command:')
      # self.port_obj.ComPort.write(read_current_gps_streaming_command)
      
      # self.port_obj.filter_status = get_filter_status(self.ComPort)
      
      print(' ***************************************************************************** ')
      print('********** USER THREAD: BEFORE WHILE LOOP: self.port_obj.filter_status = ' + self.port_obj.filter_status)
      print(' ***************************************************************************** ')
      
      # Clear the port responses, since we just read them 
      # self.port_obj.ComPort.reset_output_buffer()
      
      while(not self._stop):
         sleep(0.01)
         # sleep(0.03)
 
         # Check if user pressed stop streaming button
         if (not self.port_obj.streaming_on):
            print('****** Sending STOP Streaming IMU command:')
            self.port_obj.ComPort.write(idle_imu_command)
    
            sleep(0.05)
            print('****** Sending STOP Streaming GPS command:')
            self.port_obj.ComPort.write(idle_gps_command)
    
            sleep(0.05)
            print('****** Sending STOP Streaming Filter command:')
            self.port_obj.ComPort.write(idle_filter_command)
    
            sleep(0.05)
            print('****** Sending IDLE command:')
            self.port_obj.ComPort.write(idle_mode_command)
    
            sleep(0.3)
    
            # Clear the port responses, since we just read them 
            # self.ComPort.reset_input_buffer()
            # self.ComPort.reset_output_buffer()
    
            if (self.port_obj.recording_state == 1 and self.port_obj.fout_bin != None):
               data_left = self.port_obj.ComPort.in_waiting         # Get the number of characters ready to be read
    
               if (data_left > 0):
                  self.bytes_read.extend(self.port_obj.ComPort.read(data_left))
           
                  self.port_obj.fout_bin.write(bytearray(self.bytes_read))
                  self.port_obj.fout_bin.flush()
               # } if (data_left > 0)..
    
               self.port_obj.fout_bin.close()
               self.port_obj.fout_bin = None
       
               self.port_obj.recording_state = -1
               self.port_obj.waiting_to_rec = True

            # } if (self.port_obj.recording_state == 1)..
    
            sleep(0.05)
    
            self.port_obj.ComPort.close()
    
            # self.port_obj.filter_status = get_filter_status(self.ComPort)
          
            print(' ***************************************************************************** ')
            print('********** USER THREAD: AFTER STOP STREAMING: self.port_obj.filter_status = ' + self.port_obj.filter_status)
            print(' ***************************************************************************** ')      
    
            self.stop()
         
         elif (self.port_obj.ComPort != None and self.port_obj.ComPort.is_open):
            data_left = self.port_obj.ComPort.in_waiting         # Get the number of characters ready to be read
            
            if (data_left > 0):
               self.bytes_read.extend(self.port_obj.ComPort.read(data_left))
           
               if (self.port_obj.fout_bin != None and self.port_obj.recording_state == 1):
                  self.port_obj.fout_bin.write(bytearray(self.bytes_read))
                  self.port_obj.fout_bin.flush()
               # } if (self.fout_bin != None)..

               self.bytes_read = bytearray()
            # } if (data_left > 0)..
    
            if (self.port_obj.recording_state == 0 and self.port_obj.fout_bin != None):
               self.port_obj.fout_bin.close()
               self.port_obj.fout_bin = None
            # } if (self.port_obj.recording_state..
         # } if (not self.port_obj.streaming_on)..
      # } while(self._stop == False)...

