import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from time import sleep           #sleep
from async_rt_usb_parse_thread import AsyncRTDataParser #Asynchronous RealTime (RT)
                                                        #data parsing thread

ComPort = serial.Serial('COM4')  # open the COM Port

# ComPort.close()

# ComPort.open()

ComPort.baudrate = 921600        # set Baud rate
ComPort.bytesize = 8             # Number of data bits = 8
ComPort.parity   = 'N'           # No parity
ComPort.stopbits = 1             # Number of Stop bits = 1

# background_data_update = AsyncRTDataParser(ComPort, 10000)

#start the response parsing thread
# background_data_update.start()

tdata = ComPort.read()

sleep(0.002)

#sleep while waiting for response
# sleep(0.002)

data_left = ComPort.inWaiting()  # Get the number of characters ready to be read
tdata += ComPort.read(data_left) # Do the read and combine it with the first character

# if (hexlify(tdata[0]).upper() == 'B5' and hexlify(tdata[1]).upper() == '62'):

# bytes_read = ComPort.read(ComPort.inWaiting())
print(' *************** LENGTH OF BYTES READ = ' + str(len(tdata)));

print('********************** load_serial_buffer: Packet: ' + hexlify(bytearray(tdata)).upper())

print(' *************** LENGTH OF BYTES READ = ' + str(len(tdata)));

# byte_reply = self.serial_port.read(size=410)
# byte_reply = bytearray(self.serial_port.readline())
# ComPort.extend(bytearray(byte1_read));

# read_time = time()
# print('********** GX4_rt_read: Read time: ' + str(read_time));

# while ComPort.inWaiting() > 0:
  # out += ComPort.read(1)
  # byte_reply = bytearray(ComPort.read(ComPort.inWaiting()))
  # data = ComPort.readline(ComPort.inWaiting())        # Wait and read data
  # print('********************** data: ' + hexlify(bytearray(data)).upper())
  # sleep(0.003)

# print('************** bytes read from COM4: ' + hexlify(bytearray(data)).upper()) # print the received data

#stop background response parsing thread
# background_data_update.stop()

#ComPort.close()                  # Close the COM Port


