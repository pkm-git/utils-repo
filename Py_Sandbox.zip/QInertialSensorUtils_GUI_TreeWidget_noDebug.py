import os
import re
import sys
import csv
import calendar
import math
import numpy
import pyqtgraph as pg

from datetime import datetime

from PyQt4 import QtCore, QtGui
from QInertialSensorUtils_GUI_CommonWidgets import *
from sensor_cloud_api import *

from imu_format_using_dict import *
from gps_format_using_dict import *
from ekf_format_using_dict import *

GRND_TRC_COL_HEADER = 'Grnd Trace'
GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8202]'

class MyTreeWidget(QtGui.QTreeWidget):
    def __init__(self, parent, init_file_name = None, csv_object_name = None):
       super(MyTreeWidget, self).__init__()

       self.parent_obj = parent

       self.sensor_name = ''
       self.desired_action = 'gs'
       self.sensor_label = None
       self.init_file_name = None
       self.append_file_name = None
       self.csv_object_name = None
       self.name_to_use = None
       self.csv_col_name_dict = None
       self.csv_data_dict = {}
       self.empty_cell_col_dict = {}
       self.x8210_flag_on_col_dict = {}
       self.csv_mode = False

       self.n_data_columns = 0

       if (init_file_name != None):
          self.init_file_name = init_file_name
          if (csv_object_name != None):
             self.csv_object_name = str(csv_object_name)
             self.name_to_use = self.csv_object_name
          else:
             (fin_filepath, fin_filename) = os.path.split(init_file_name)
             self.name_to_use = fin_filename
          # } if (csv_object_name != None)..
          self.csv_mode = True
       # } if (init_file_name != None)..

       self.setItemHidden(self.headerItem(), True)
       self.initUI()
       # self.itemClicked.connect(self.handleTreeWidgetClicked)

    def initUI(self):
       if (self.init_file_name != None):
          self.csv_col_name_dict = {}
          col_name_array, csv_data, empty_cell_col_array, x8210_flag_on_col_array = self.get_table_data(False)

          if (self.csv_object_name != None):
             self.csv_col_name_dict[self.csv_object_name] = col_name_array
             self.csv_data_dict[self.csv_object_name] = csv_data
             self.empty_cell_col_dict[self.csv_object_name] = empty_cell_col_array
             self.x8210_flag_on_col_dict[self.csv_object_name] = x8210_flag_on_col_array
          else:
             (fin_filepath, fin_filename) = os.path.split(self.init_file_name)
             self.csv_col_name_dict[fin_filename] = col_name_array
             self.csv_data_dict[fin_filename] = csv_data
             self.empty_cell_col_dict[fin_filename] = empty_cell_col_array
             self.x8210_flag_on_col_dict[fin_filename] = x8210_flag_on_col_array
          # } if (self.csv_object_name != None)..
          self.fill_widget(self.csv_col_name_dict)
       else:
          self.parent_obj.updateSensorList()

          self.sensors_dict = {}

          sensors  = self.parent_obj.sensor_list_dict

          imu_format_using_dict = IMU_format_using_dict()
          gps_format_using_dict = GPS_format_using_dict()
          ekf_format_using_dict = EKF_format_using_dict()

          if (sensors != None and len(sensors) > 0):
             i = 0

             for s in sensors.values():
                sensor_name = str(s["name"])
                channel_name_array = []
                channel_name_sorted_array = []
                channel_name_dict = {}
                imu_channel_name_dict = {}
                gps_channel_name_dict = {}
                ekf_channel_name_dict = {}
                imu_channel_name_array = []
                gps_channel_name_array = []
                ekf_channel_name_array = []
                imu_field_desc_array = []
                gps_field_desc_array = []
                ekf_field_desc_array = []

                channels = s["channels"]
                channel_array = channels.values()
                if (channel_array != None):
                   has_810C = False
                   visible_channel_nbr_array = []

                   for c in channel_array:
                      channel_name = str(c["name"])
                      channel_name_array.append(channel_name)

                      if ('channel_nbr_x810c' in channel_name.lower()):
                         if (not has_810C):
                            has_810C = True
                         # } if (not has_810C)..

                         channel_nbr = int(channel_name[18:])
                         print(' ********* channel_nbr: ' + str(channel_nbr))
                         visible_channel_nbr_array.append(channel_nbr)
                      # } if ('channel_nbr_x810c' in channel_name.lower())..
                   # } for c in channel_array..

                   if (has_810C and len(visible_channel_nbr_array) > 0):
                      visible_channel_nbr_array.sort()
                      gps_format_using_dict = GPS_format_using_dict(None, visible_channel_nbr_array)
                   # } if (has_810C and..

                   # Arrange/sort the channel names to be same as in csv file (not alphabetical)
                   imu_flags_wk_tow_array = imu_format_using_dict.format_channel_name(0)

                   imu_data_tow_col_indices = [i for i,x in enumerate(channel_name_array) if x in imu_flags_wk_tow_array]

                   imu_data_col_indices = [i for i,x in enumerate(channel_name_array) if 'x80' in x.lower()]

                   gps_flags_wk_tow_array = gps_format_using_dict.format_channel_name(0)
                   gps_data_tow_col_indices = [i for i,x in enumerate(channel_name_array) if x in gps_flags_wk_tow_array]
                   gps_data_col_indices = [i for i,x in enumerate(channel_name_array) if 'x81' in x.lower()]

                   ekf_flags_wk_tow_array = ekf_format_using_dict.format_channel_name(0)
                   ekf_data_tow_col_indices = [i for i,x in enumerate(channel_name_array) if x in ekf_flags_wk_tow_array]

                   ekf_data_col_indices = [i for i,x in enumerate(channel_name_array) if 'x82' in x.lower()]

                   # other_data_col_indices = [i for i,x in enumerate(channel_name_array) if i not in imu_data_tow_col_indices and i not in imu_data_col_indices \
                                                                                      # and i not in gps_data_tow_col_indices and i not in gps_data_col_indices \
                                                                                      # and i not in ekf_data_tow_col_indices and i not in ekf_data_col_indices]

                   imu_tow_cols = [y for j,y in enumerate(channel_name_array) if j in imu_data_tow_col_indices]
                   if (len(imu_tow_cols) > 0):
                      imu_channel_name_dict['8012'] = imu_flags_wk_tow_array
                   # } if (len(imu_tow_cols) > 0)..

                   for i in imu_data_col_indices:
                      channel_name = channel_name_array[i]

                      indx = channel_name.find('x80')
                      if (indx != -1):
                         imu_channel_name_array.append(channel_name)
                         field_descriptor = channel_name[indx+1:indx+5].upper()
                         if (field_descriptor not in imu_channel_name_dict):
                            imu_other_than_tow_cols = imu_format_using_dict.format_channel_name(imu_default_cols_seq_array.index(field_descriptor))
                            imu_channel_name_dict[field_descriptor] = imu_other_than_tow_cols
                         # } if (field_descriptor not in imu_channel_name_dict)..
                      # } if (indx != -1)..
                   # } for i in imu_data_col_indices..

                   gps_tow_cols = [y for j,y in enumerate(channel_name_array) if j in gps_data_tow_col_indices]
                   if (len(gps_tow_cols) > 0):
                      gps_channel_name_dict['8109'] = gps_flags_wk_tow_array
                   # } if (len(gps_tow_cols) > 0)..

                   for i in gps_data_col_indices:
                      channel_name = channel_name_array[i]
                      indx = channel_name.find('x81')
                      if (indx != -1):
                         gps_channel_name_array.append(channel_name)
                         field_descriptor = channel_name[indx+1:indx+5].upper()
                         if (field_descriptor not in gps_channel_name_dict):
                            gps_channel_name_dict[field_descriptor] = gps_format_using_dict.format_channel_name(gps_default_cols_seq_array.index(field_descriptor))
                         # } if (field_descriptor not in gps_channel_name_dict)..
                      # } if (indx != -1)..
                   # } for i in gps_data_col_indices..

                   ekf_tow_cols = [y for j,y in enumerate(channel_name_array) if j in ekf_data_tow_col_indices]
                   if (len(ekf_tow_cols) > 0):
                      ekf_channel_name_dict['8211'] = ekf_flags_wk_tow_array
                   # } if (len(ekf_tow_cols) > 0)..

                   for i in ekf_data_col_indices:
                      channel_name = channel_name_array[i]
                      indx = channel_name.find('x82')
                      if (indx != -1):
                         ekf_channel_name_array.append(channel_name)
                         field_descriptor = channel_name[indx+1:indx+5].upper()
                         if (field_descriptor not in ekf_channel_name_dict):
                            ekf_channel_name_dict[field_descriptor] = ekf_format_using_dict.format_channel_name(ekf_default_cols_seq_array.index(field_descriptor))
                         # } if (field_descriptor not in ekf_channel_name_dict)..
                      # } if (indx != -1)..
                   # } for i in ekf_data_col_indices..

                   # other_data_cols = [y for j,y in enumerate(channel_name_array) if j in other_data_col_indices]
                   # other_channel_name_dict['OTHER'] = other_data_cols
                   # channel_name_sorted_array.extend([y for j,y in enumerate(channel_name_array) if j in other_data_col_indices])

                   imu_channel_name_sorted_indices_array = []
                   gps_channel_name_sorted_indices_array = []
                   ekf_channel_name_sorted_indices_array = []

                   for k in imu_channel_name_dict.keys():
                      if (k in imu_default_cols_seq_array):
                         imu_channel_name_sorted_indices_array.append(imu_default_cols_seq_array.index(k))
                      # } if (k in imu_default_cols_seq_array)..
                   # } for k in imu_channel_name_dict.keys()..
                   imu_channel_name_sorted_indices_array.sort()

                   for k in gps_channel_name_dict.keys():
                      if (k in gps_default_cols_seq_array):
                         gps_channel_name_sorted_indices_array.append(gps_default_cols_seq_array.index(k))
                      # } if (k in gps_default_cols_seq_array)..
                   # } for k in gps_channel_name_dict.keys()..
                   gps_channel_name_sorted_indices_array.sort()

                   for k in ekf_channel_name_dict.keys():
                      if (k in ekf_default_cols_seq_array):
                         ekf_channel_name_sorted_indices_array.append(ekf_default_cols_seq_array.index(k))
                      # } if (k in ekf_default_cols_seq_array)..
                   # } for k in ekf_channel_name_dict.keys()..
                   ekf_channel_name_sorted_indices_array.sort()

                   final_channel_name_array_to_use = []
                   for k in imu_channel_name_sorted_indices_array:
                      final_channel_name_array_to_use.extend(imu_channel_name_dict[imu_default_cols_seq_array[k]])

                   for k in gps_channel_name_sorted_indices_array:
                      final_channel_name_array_to_use.extend(gps_channel_name_dict[gps_default_cols_seq_array[k]])

                   for k in ekf_channel_name_sorted_indices_array:
                      final_channel_name_array_to_use.extend(ekf_channel_name_dict[ekf_default_cols_seq_array[k]])
                # } if (channel_array != None)..

                self.sensors_dict[sensor_name] = final_channel_name_array_to_use

                i = i + 1
             # } for s in sensors.values()..
          # } if (sensors != None and len(sensors) > 0)..

          self.fill_widget(self.sensors_dict)

       # } if (self.init_file_name != None)..

       self.createCheckboxesForTree()

    def append_tree_obj_from_file(self, append_file_name, append_csv_object_name = None):
       self.append_file_name = append_file_name

       if (append_csv_object_name != None):
          self.name_to_use = append_csv_object_name
       else:
          (fin_filepath, fin_filename) = os.path.split(self.append_file_name)
          self.name_to_use = fin_filename
       # } if (append_csv_object_name != None)..

       col_name_array, csv_data, empty_cell_col_array, x8210_flag_on_col_array = self.get_table_data(True)

       if (append_csv_object_name != None):
          self.csv_col_name_dict[append_csv_object_name] = col_name_array
          self.csv_data_dict[append_csv_object_name] = csv_data
          self.empty_cell_col_dict[append_csv_object_name] = empty_cell_col_array
          self.x8210_flag_on_col_dict[append_csv_object_name] = x8210_flag_on_col_array
          self.csv_object_name = append_csv_object_name
       else:
          (fin_filepath, fin_filename) = os.path.split(self.append_file_name)
          self.csv_col_name_dict[fin_filename] = col_name_array
          self.csv_data_dict[fin_filename] = csv_data
          self.empty_cell_col_dict[fin_filename] = empty_cell_col_array
          self.x8210_flag_on_col_dict[fin_filename] = x8210_flag_on_col_array
       # } if (append_csv_object_name != None)..

       print(' ************* in append_tree, self.name_to_use = ' + self.name_to_use)

       self.fill_widget(self.csv_col_name_dict)
       self.createCheckboxesForTree()

    def delete_tree_obj(self, delete_object_name):

       self.csv_col_name_dict.pop(delete_object_name, None)
       self.csv_data_dict.pop(delete_object_name, None)
       self.empty_cell_col_dict.pop(delete_object_name, None)
       self.x8210_flag_on_col_dict.pop(delete_object_name, None)

       self.fill_widget(self.csv_col_name_dict)
       self.createCheckboxesForTree()

    def createCheckboxesForTree(self):
       regionBrush = pg.mkBrush('r')

       root = self.invisibleRootItem()
       self.child_count = root.childCount()
       if (self.child_count > 0):
          for i in range(self.child_count):
             item = root.child(i)
             item.setCheckState(0, QtCore.Qt.Unchecked)
             self.childs_child_count = item.childCount()
             parent_obj_name = str(item.text(0))
             for j in range(self.childs_child_count):
                items_child = item.child(j)
                col_name = str(items_child.text(0))
                if ('x8210' in col_name.lower() and 'flag_' in col_name.lower()):
                   if (parent_obj_name in self.x8210_flag_on_col_dict and col_name in self.x8210_flag_on_col_dict[parent_obj_name]):
                      items_child.setForeground(0, regionBrush);
                      items_child.setCheckState(0, QtCore.Qt.Unchecked)
                   # } if (parent_obj_name in self.x8210_flag_on_col_dict..
                # } if ('x8210' in col_name.lower()..
                items_child.setCheckState(0, QtCore.Qt.Unchecked)
             # } for j in range(self.childs_child_count)..
          # } for i in range(self.child_count)..
       # } if (self.child_count > 0)..

    def get_table_data(self, appendMode):
       col_name_array = []
       csv_data = {}
       empty_cell_col_array = []
       x8210_flag_on_col_array = []
       x810C_visible_SV_col_array = []
       
       cnt_neg = 0;
       
       if (not appendMode):
          file_name_to_use = self.init_file_name
       else:
          file_name_to_use = self.append_file_name
       # } if (not appendMode)..

       if (file_name_to_use != None):
          in_csvfile = open(file_name_to_use,'rUb')
          csvreader = csv.reader(in_csvfile, delimiter=',')

          determine_headers = False
          headers_found = False
          data_row_cnt = 0
          POS_INF = float("+inf")

          sum_delta_theta_x = 0.0
          sum_delta_theta_y = 0.0
          sum_delta_theta_z = 0.0

          sum_delta_v_x = 0.0
          sum_delta_v_y = 0.0
          sum_delta_v_z = 0.0

          # Flag to convert 100Hz Novatel to 10Hz (useful if Lord IMU gives 10 Hz output)
          # calc_10Hz_Novatel_IMU = False
          calc_downsampled_IMU = False
          # DOWNSAMPLE_RATIO = 50  # example: down sample from 500 Hz to 10 Hz: => DOWNSAMPLE_RATIO = 500/10 = 50
          DOWNSAMPLE_RATIO = 1  # example: down sample from 500 Hz to 10 Hz: => DOWNSAMPLE_RATIO = 500/10 = 50

          convert_to_unbounded_yaw = True
	  # convert_to_unbounded_yaw = False

          # if (self.csv_object_name != None):
             # name_to_use = self.csv_object_name
          # else:
             # (fin_filepath, fin_filename) = os.path.split(file_name_to_use)
             # name_to_use =  fin_filename
          # } if (self.csv_object_name != None)..

          if ('nrtsim' in self.name_to_use.lower()):
             # calc_downsampled_IMU = True
	     calc_downsampled_IMU = False
          # } if ('nrtsim' in self.name_to_use.lower())..

          print(' *************** self.name_to_use: ' + self.name_to_use + ', calc_downsampled_IMU is ' + str(calc_downsampled_IMU))

          found_VNED = False
          empty_VNED_row = False

          ekf_8202_struct = EKF_8202_struct()
          col_header_dict = {}
          grnd_trc_index = 0
          euler_yaw_prev = 0.0
	  grnd_trace_angle_prev = 0.0
	  grnd_trace_angle_calc_prev = 0.0
          # adder = 0.0
	  adder_yaw = 0.0
	  adder_grnd_trace = 0.0
	  adder_grnd_trace_calc = 0.0
          delta_yaw = 0.0
          delta_azimuth = 0.0

          for row_item in csvreader:
             # Determined that previous row in CSV indicated data start (in other words, headers are in the current row)
             if (determine_headers):
                self.n_data_columns = len(row_item)

                # Create a list of channel names from the headers
                for i in range(self.n_data_columns):
                   col_name_array.append(row_item[i])
                   csv_data[row_item[i]] = []

                   # if (not found_VNED and 'vel n' in row_item[i].lower() and ('x8202' in row_item[i].lower() or 'x8105' in row_item[i].lower())  ):
		   if (not found_VNED and ( \
		                             'vel n' in row_item[i].lower() \
					     and \
					     ('x8202' in row_item[i].lower() or 'x8105' in row_item[i].lower()) \
					  ) \
		                          or \
					  ( \
		                             'vned_n' in row_item[i].lower() \
					     and \
					     '508/507' in row_item[i].lower() \
					  ) \
		      ):
                      found_VNED = True

                      if ('x8202' in row_item[i].lower()):
                         GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8202]'
		      elif ('x8105' in row_item[i].lower()):
			 GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [x8105]'
                      else:
                         GRND_TRC_COL_HEADER_TO_USE = GRND_TRC_COL_HEADER + ' [508/507]'
                      # } if ('x8202' in row_item[i].lower())..

                      # Insert new, computed Grnd Trc column after VNED_D
                      grnd_trc_index = i+3
                   # } if (not found_VNED and..
                # } for i in range(self.n_data_columns)..

                if (found_VNED):
                   col_name_array.insert(grnd_trc_index, GRND_TRC_COL_HEADER_TO_USE)

                   csv_data[GRND_TRC_COL_HEADER_TO_USE] = []

                   for i in range(self.n_data_columns):
                      col_header = row_item[i].strip()
                      if ('vel n' in col_header.lower() or 'vned_n' in col_header.lower()):
                         col_header_dict['VEL_N'] = i
                      elif ('vel e' in col_header.lower() or 'vned_e' in col_header.lower()):
                         col_header_dict['VEL_E'] = i
                      elif ('vel d' in col_header.lower() or 'vned_d' in col_header.lower()):
                         col_header_dict['VEL_D'] = i
                      # } if ('vel n' in col_header.lower()..
                   # } for i in range(self.n_data_columns)..
                # } if (found_VNED)..

                # column headers have been found
                headers_found = True

                # headers no longer need to be determined
                determine_headers = False

             elif (headers_found):
                if (len(row_item) > 0):
                   try:
                      data_row_cnt = data_row_cnt + 1

                      for i in range(self.n_data_columns):
                         if (found_VNED and i >= grnd_trc_index):
                            i_col_hdr_to_use = i + 1
                         else:
                            i_col_hdr_to_use = i
                         # } if (found_VNED and i >= grnd_trc_index)..

                         # col_name = col_name_array[i]
                         col_name = col_name_array[i_col_hdr_to_use]

                         if (row_item[i] == ''):
                            if (col_name not in empty_cell_col_array):
                               empty_cell_col_array.append(col_name)
                            # } if (col_name not in empty_cell_col_array)..
                            csv_data[col_name].append(POS_INF)
			 elif ( (('x8205' in col_name.lower() or 'x800C' in col_name.lower()) and 'yaw' in col_name.lower()) \
			        or \
			        ('x8105' in col_name.lower() and 'heading' in col_name.lower() and 'acc' not in col_name.lower()) ):
                            
			    # MIP EKF Euler Yaw currently is the only column that has 0 to +/-180 deg range.
                            # Convert this to 0 - 360 range, in order to be in sync with:
                            # * Heading (x8105)
                            # * Grnd Trace computed columns (x8202, x8105)
                            # * Novatel's EKF Grnd Trace (Msg 99)
                            # * INS Grnd Trace (Msg 323/266), and
                            # * PVA_Azimuth (msg: 508/507)
			    
			    # GPS Msg x8105 has a 'Heading' column that is already in degrees, so no need to convert that
			    if ('x8105' not in col_name.lower()):
                               euler_yaw = math.degrees(float(row_item[i]))
			    else:
			       euler_yaw = float(row_item[i])
			    # } if ('x8105' not in col_name.lower())..
			    
                            if (euler_yaw < 0):
                               euler_yaw = 360.0 + euler_yaw
                            # } if (euler_yaw < 0)..

                            if (convert_to_unbounded_yaw):
                               if (data_row_cnt == 1):
                                  euler_yaw_prev = euler_yaw
                               else:
                                  delta_yaw = (euler_yaw - euler_yaw_prev)

                                  if (delta_yaw < -180.0):
                                     adder_yaw += 360.0
                                  elif (delta_yaw > 180.0):
                                     adder_yaw -= 360.0
                                  # } if (delta_yaw < -180.0)..

                                  euler_yaw_prev = euler_yaw
                                  
                                  euler_yaw = euler_yaw + adder_yaw
                               # } if (data_row_cnt == 1)..
                            # } if (convert_to_unbounded_yaw)..

                            # Convert back to radians (which will be converted again to degrees by SensorList page when plotting):
			    if ('x8105' not in col_name.lower()):
			       csv_data[col_name].append(math.radians(euler_yaw))
			    else:
			       csv_data[col_name].append(euler_yaw)
			    # } if ('x8105' not in col_name.lower())..
			       
                         elif ('508' in col_name.lower() and 'azimuth' in col_name.lower()):
                            azimuth = float(row_item[i])

                            if (convert_to_unbounded_yaw):
                               if (data_row_cnt == 1):
                                  azimuth_prev = azimuth
                               else:
                                  delta_azimuth = (azimuth - azimuth_prev)

                                  if (delta_azimuth < -180.0):
                                     adder_yaw += 360.0
                                  elif (delta_azimuth > 180.0):
                                     adder_yaw -= 360.0
                                  # } if (delta_azimuth < -180.0)..

                                  azimuth_prev = azimuth

                                  azimuth = azimuth + adder_yaw
                               # } if (data_row_cnt == 1)..
                            # } if (convert_to_unbounded_yaw)..

                            csv_data[col_name].append(azimuth)
			    
                         elif ('grnd trc' in col_name.lower() and ('323/266' in col_name.lower() or '99' in col_name.lower())):
                            grnd_trace_angle = float(row_item[i])

                            if (convert_to_unbounded_yaw):
                               if (data_row_cnt == 1):
                                  grnd_trace_angle_prev = grnd_trace_angle
                               else:
                                  delta_grnd_trace_angle = (grnd_trace_angle - grnd_trace_angle_prev)

                                  if (delta_grnd_trace_angle < -180.0):
                                     adder_grnd_trace += 360.0
                                  elif (delta_grnd_trace_angle > 180.0):
                                     adder_grnd_trace -= 360.0
                                  # } if (delta_grnd_trace_angle < -180.0)..

                                  grnd_trace_angle_prev = grnd_trace_angle

                                  grnd_trace_angle = grnd_trace_angle + adder_grnd_trace
                               # } if (data_row_cnt == 1)..
                            # } if (convert_to_unbounded_yaw)..

                            csv_data[col_name].append(grnd_trace_angle)

                         else:
                            if ('lat' in col_name.lower() or 'lon' in col_name.lower()):
                               csv_data[col_name].append(numpy.double(row_item[i]))
                            # elif ('vned_d' in col_name.lower() and '508' in col_name.lower() and '507' in col_name.lower()):
                               # csv_data[col_name].append(float(row_item[i]) * -1)
                            # elif (calc_downsampled_IMU and '325' in col_name.lower()):
                            elif (calc_downsampled_IMU and ('325' in col_name.lower() or 'x8007' in col_name.lower() or 'x8008' in col_name.lower())):
                               # delta_value = float(row_item[i])
                               delta_value = numpy.double(row_item[i])
                               if ('deltatheta_x' in col_name.lower()):
                                  # if (data_row_cnt < 101):
                                     # print('****** data_row_cnt: ' + str(data_row_cnt) + ', deltatheta_x value: %10.7f' + str(delta_value) + ', sum_delta_theta_x: ' + str(sum_delta_theta_x))
                                     # print('****** data_row_cnt: ' + str(data_row_cnt) + ', deltatheta_x value: %14.11f'%(delta_value) + ', sum_delta_theta_x: %14.11f'%(sum_delta_theta_x))

                                  sum_delta_theta_x += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # if (data_row_cnt < 101):
                                        # print('****** data_row_cnt: ' + str(data_row_cnt) + ' is multiple of 50, so will add to dict: sum_delta_theta_x: ' + str(sum_delta_theta_x))
                                        # print('****** data_row_cnt: ' + str(data_row_cnt) + ' is multiple of 50, so will add to dict: sum_delta_theta_x: %14.11f'%(sum_delta_theta_x))
                                        # return

                                     csv_data[col_name].append(sum_delta_theta_x)
                                     sum_delta_theta_x = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltatheta_y' in col_name.lower()):
                                  sum_delta_theta_y += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_theta_y)
                                     csv_data[col_name].append(sum_delta_theta_y)
                                     sum_delta_theta_y = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltatheta_z' in col_name.lower()):
                                  sum_delta_theta_z += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_theta_z)
                                     csv_data[col_name].append(sum_delta_theta_z)
                                     sum_delta_theta_z = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltav_x' in col_name.lower()):
                                  sum_delta_v_x += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     csv_data[col_name].append(sum_delta_v_x)
                                     sum_delta_v_x = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltav_y' in col_name.lower()):
                                  sum_delta_v_y += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_v_y)
                                     csv_data[col_name].append(sum_delta_v_y)
                                     sum_delta_v_y = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               elif ('deltav_z' in col_name.lower()):
                                  sum_delta_v_z += delta_value
                                  if (data_row_cnt % DOWNSAMPLE_RATIO == 0):
                                     # csv_data[col_name].append(-sum_delta_v_z)
                                     csv_data[col_name].append(sum_delta_v_z)
                                     sum_delta_v_z = 0.0
                                  else:
                                     if (col_name not in empty_cell_col_array):
                                        empty_cell_col_array.append(col_name)
                                     # } if (col_name not in empty_cell_col_array)..
                                     csv_data[col_name].append(POS_INF)
                                  # } if (data_row_cnt % DOWNSAMPLE_RATIO == 0)..
                               # } if ('deltatheta_x' in col_name.lower())..
                            else:
                               try:
                                  if ('x8210' in col_name.lower() and 'flag_' in col_name.lower()):
                                     csv_data[col_name].append(int(row_item[i]))
                                  else:
                                     csv_data[col_name].append(float(row_item[i]))
                                  # } if ('x8210' in col_name.lower()..
                               except ValueError:
                                  csv_data[col_name].append(row_item[i])
                               # } try..
                            # } if ('lat' in col_name.lower()..
                         # } if (row_item[i] != '')..

                         try:
                            if (i in col_header_dict.values()):
                               key = col_header_dict.keys()[col_header_dict.values().index(i)]
                               if (key == 'VEL_N'):
                                  ekf_8202_struct.ekf_vned_N = float(row_item[i])
                               elif (key == 'VEL_E'):
                                  ekf_8202_struct.ekf_vned_E = float(row_item[i])
                               elif (key == 'VEL_D'):
                                  ekf_8202_struct.ekf_vned_D = float(row_item[i])
                               # } if (key == 'VEL_N')..
                            # } if (i in col_header_dict.values())..
                         except ValueError as err:
                            print(" ******** ValueError from VNED: data_row_cnt = " + str(data_row_cnt) + ", Col Header: ' + key + ', Value: " + row_item[i] + ", Error Msg: {0}".format(err))
                            empty_VNED_row = True
                         # } try..
                      # } for i in range(self.n_data_columns)..
                   except ValueError as err:
                      print(' ******** ValueError: data_row_cnt = ' + str(data_row_cnt) + ', i = ' + str(i) + ' row_item[i] = ' + row_item[i] + ' Error Msg: {0}'.format(err))
                      sys.exit()
                   # } try..

                   if (found_VNED):
                      if (not empty_VNED_row):
                         vel_NE_mag = math.sqrt(math.pow(ekf_8202_struct.ekf_vned_N, 2) + math.pow(ekf_8202_struct.ekf_vned_E, 2))

                         if ((abs(ekf_8202_struct.ekf_vned_N) > 0.01 or abs(ekf_8202_struct.ekf_vned_E) > 0.01) and vel_NE_mag > 0.01):
			    if (data_row_cnt == 99 or data_row_cnt == 100 or data_row_cnt == 101 or data_row_cnt == 102):
			       print(' ******** BEFORE UNBOUNDED, data_row_cnt = ' + str(data_row_cnt) + ', grnd_trace_angle_calc_prev = ' + str(grnd_trace_angle_calc_prev))
			       
                            grnd_trace_angle_calc = math.degrees(math.acos(ekf_8202_struct.ekf_vned_N/vel_NE_mag))
			    
			    if (data_row_cnt == 102):
			       print(' ******** RAW grnd_trace_angle_calc = ' + str(grnd_trace_angle_calc))
				
                            # Convert 0 - 180 range Grnd Trace to 0 - 360 range Grnd Trace, by using sign of East component of VNED
			    
			    # Convert 0 - 180 range Grnd Trace to 0 - 360 range Grnd Trace
                            if (grnd_trace_angle_calc < 0):
                               grnd_trace_angle_calc = 360.0 + grnd_trace_angle_calc
                            elif (ekf_8202_struct.ekf_vned_E < 0):
                               grnd_trace_angle_calc = 360.0 - grnd_trace_angle_calc
                            # } if (grnd_trace_angle_calc < 0)..

			    if (data_row_cnt == 99 or data_row_cnt == 100 or data_row_cnt == 101 or data_row_cnt == 102):
			       print(' ******** AFTER 0-360 RANGE, grnd_trace_angle_calc = ' + str(grnd_trace_angle_calc))
			    
                            if (convert_to_unbounded_yaw):
                               if (data_row_cnt == 1):
                                  grnd_trace_angle_calc_prev = grnd_trace_angle_calc
                               else:
                                  delta_grnd_trace_calc = (grnd_trace_angle_calc - grnd_trace_angle_calc_prev)
				  
				  adder_grnd_trace_prev_calc = adder_grnd_trace_calc
				  
                                  if (delta_grnd_trace_calc < -180.0):
                                     adder_grnd_trace_calc += 360.0
                                  elif (delta_grnd_trace_calc > 180.0):
                                     adder_grnd_trace_calc -= 360.0
                                  # } if (delta_grnd_trace_calc < -180.0)..

                                  grnd_trace_angle_calc_prev = grnd_trace_angle_calc

     			          grnd_trace_angle_calc = grnd_trace_angle_calc + adder_grnd_trace_calc
                               # } if (data_row_cnt == 1)..
			       
			       if (data_row_cnt == 99 or data_row_cnt == 100 or data_row_cnt == 101 or data_row_cnt == 102):
			          print(' ******** AFTER UNBOUNDED, delta_grnd_trace_calc = ' + str(delta_grnd_trace_calc) + ', adder_grnd_trace_prev_calc = ' + str(adder_grnd_trace_prev_calc) + ', adder_grnd_trace_calc = ' + str(adder_grnd_trace_calc) + ', grnd_trace_angle_calc = ' + str(grnd_trace_angle_calc))

                            # } if (convert_to_unbounded_yaw)..

                            csv_data[GRND_TRC_COL_HEADER_TO_USE].append(grnd_trace_angle_calc)
                         else:
                            csv_data[GRND_TRC_COL_HEADER_TO_USE].append(POS_INF)
                            if (GRND_TRC_COL_HEADER_TO_USE not in empty_cell_col_array):
                               empty_cell_col_array.append(GRND_TRC_COL_HEADER_TO_USE)
                         # } if (vel_NE_mag > 0)..

                         empty_VNED_row = False
                      # } if (not empty_VNED_row)..
                   # } if (found_VNED)..

                   ekf_8202_struct = EKF_8202_struct()

                # } if (len(row_item) > 0)..
		
                # if (data_row_cnt == 102):
		    # return col_name_array, csv_data, empty_cell_col_array, x8210_flag_on_col_array

             # this row is neither column headers nor data elements
             else:
                # test for DATA_START row (column headers to follow)
                if (len(row_item) == 1 and row_item[0] == 'DATA_START'):
                   determine_headers = True
                # } if (len(row_item) == 1 and..
             # } if (determine_headers)..
          # } for row_item in csvreader..

          for col_name in csv_data.keys():
             if ('x8210' in col_name.lower() and 'flag_' in col_name.lower() and 1 in csv_data[col_name]):
                x8210_flag_on_col_array.append(col_name)
             elif ('x810c' in col_name.lower() and POS_INF in csv_data[col_name]):
                valid_column_value_array = np.array([x for i,x in enumerate(csv_data[col_name]) if x !=POS_INF])
                if (len(valid_column_value_array) > 0):
                   x810C_visible_SV_col_array.append(col_name)
                # } if (len(valid_column_value_array) > 0)..
             # } if ('x8210' in col_name.lower() and..
          # } for col_name in csv_data.keys()..

          # Discard x8210 Flag columns that never turned on during the run (to reduce clutter)
          for col_name in csv_data.keys():
             if ('x8210' in col_name.lower() and 'flag_' in col_name.lower() and col_name not in x8210_flag_on_col_array):
                csv_data.pop(col_name, None)
                col_name_array.remove(col_name)
             # } if col_name not in..
          # } for col_name in..

          # Discard x810C (SV Info) columns for SV's that were never visible during the run (to reduce clutter)
          for col_name in csv_data.keys():
             if ('x810c' in col_name.lower() and col_name not in x810C_visible_SV_col_array):
                csv_data.pop(col_name, None)
                col_name_array.remove(col_name)
             # } if col_name not in..
          # } for col_name in..
       # } if (file_name_to_use != None)..
       
       # Redundant line below?
       # if (found_VNED):
          # csv_data[GRND_TRC_COL_HEADER_TO_USE] = np.array([x for i,x in enumerate(csv_data[GRND_TRC_COL_HEADER_TO_USE]) if x !=1.0])
       # } if (found_VNED)..

       return col_name_array, csv_data, empty_cell_col_array, x8210_flag_on_col_array

    def handleTreeWidgetClicked(self, item, column):
       self.blockSignals(True)
       item_parent = item.parent()

       if (item != None):
          if (item.checkState(column) == QtCore.Qt.Checked):
             self.childs_child_count = item.childCount()
             for i in range(self.childs_child_count):
                items_child = item.child(i)
                items_child.setCheckState(0, QtCore.Qt.Checked)
             # } for i in range(self.childs_child_count)..
          elif item.checkState(column) == QtCore.Qt.Unchecked:
             self.childs_child_count = item.childCount()
             for i in range(self.childs_child_count):
                items_child = item.child(i)
                items_child.setCheckState(0, QtCore.Qt.Unchecked)
             # } for i in range(self.childs_child_count)..
          # } if (item.checkState(column) == QtCore.Qt.Checked)..
       # } if (item != None)..
       self.blockSignals(False)

    def fill_item(self, item, value):
       # item.setExpanded(True)
       item.setExpanded(False)

       if (type(value) is dict):
          for key, val in sorted(value.iteritems()):
             child = QtGui.QTreeWidgetItem()
             child.setText(0, unicode(key))
             item.addChild(child)
             self.fill_item(child, val)
          # } for key, val in sorted(value.iteritems())..
       elif type(value) is list:
          for val in value:
             child = QtGui.QTreeWidgetItem()
             item.addChild(child)
             if type(val) is dict:
                child.setText(0, '[dict]')
                self.fill_item(child, val)
             elif type(val) is list:
                child.setText(0, '[list]')
                self.fill_item(child, val)
             else:
                child.setText(0, unicode(val))

             child.setExpanded(False)
          # } for val in value..
       else:
          child = QtGui.QTreeWidgetItem()
          child.setText(0, unicode(value))
          item.addChild(child)
       # } if (type(value) is dict)..

    def fill_widget(self, value):
       self.clear()
       self.fill_item(self.invisibleRootItem(), value)

