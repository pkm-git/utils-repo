import csv
import sys
import numpy
import serial                  #library for accessing serial ports

from time import time  #import time library

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from time import sleep         #sleep

from datetime import datetime

from sensor_cloud_api import *

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

def print_usage_message():
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("Usage: python csv_to_sensor_cloud.py -d device_id -s sensor_name -l sensor_label -k key -i in_file_name\n")
 print("device_id\t-- the device id to use for the sensor cloud upload")
 print("sensor_name\t-- the sensor name to use for the sensor cloud upload")
 print("sensor_label\t-- the sensor label to use for the sensor cloud upload")
 print("key\t-- the key to use for the sensor cloud upload")
 print("in_file_name\t-- the name of the input csv data file including the path")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""

    in_file_name = None
    device_id = None
    sensor_name = None
    key = None
    sensor_label = None

    secsInWeek = 604800

    # Parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-i' and len(argv) > i+1):
         in_file_name = argv[i+1]
       elif(argv[i] == '-d' and len(argv) > i+1):
         device_id = argv[i+1]
       elif(argv[i] == '-s' and len(argv) > i+1):
         sensor_name = argv[i+1]
       elif(argv[i] == '-l' and len(argv) > i+1):
         sensor_label = argv[i+1]
       elif(argv[i] == '-k' and len(argv) > i+1):
         key = argv[i+1]

    # If command line arguments were not properly specified tell the user and exit
    if (in_file_name == None or device_id == None or key == None or sensor_name == None):
       print_usage_message()
       sys.exit()

    # Spaces not allowed in Sensor Name, replace with _:
    sensor_name.strip().replace(" ", "_")

    in_csvfile = open(in_file_name,'rUb')
    csvreader = csv.reader(in_csvfile, delimiter=',')

    determine_headers = False
    headers_found = False
    data_row_cnt = 0

    server, token = authenticate_key(device_id, key)

    sensStatus = 0
    if (sensor_label != None):
       sensStatus = addSensor(server, token, device_id, sensor_name, "", sensor_label)
    else:
       sensStatus = addSensor(server, token, device_id, sensor_name)

    print(' ********** addSensor: status = ' + str(sensStatus))

    channel_data = {sensor_name:{}}
    index_to_name = []
    n_data_columns = 0
    headers = []
    channel_names = []
    chStatus = 0

    for row_item in csvreader:

        # determined that last row in CSV indicated data start (headers are in this row)
        if (determine_headers == True):

            n_data_columns =  len(row_item)
            print(' ******* len(row_item) = ' + str(len(row_item)) + ', n_data_columns = ' + str(n_data_columns))

            # Create a list of the headers
            for i in range(n_data_columns-1):
               if (row_item[i] not in ("GPS TFlags", "GPS Week", "GPS TOW")):
                  # print(' ****** ADDING TO HDRS: i = ' + str(i) + ', row_item[i] = ' + row_item[i])
                  headers.append(row_item[i])

                  # Spaces not allowed in Channel Name, replace with _:
                  tmp_channel_name = row_item[i].strip().replace(" ", "_")
                  tmp_channel_name = tmp_channel_name.strip().replace("[", "")
                  tmp_channel_name = tmp_channel_name.strip().replace("]", "")

                  channel_names.append(tmp_channel_name)

                  chStatus = addChannel(server, token, device_id, sensor_name, tmp_channel_name)

                  print(' ********** addChannel: status = ' + str(chStatus))

                  # channel_data[i-3] = []
                  channel_data[sensor_name][i-3] = []

               # if (row_item[i] not in ("GPS TFlags", "GPS Week", "GPS TOW")):
                   # channel_data[i] = []

            # column headers have been found
            headers_found = True

            # headers no longer need to be determined
            determine_headers = False

        elif(headers_found == True):
            data_row_cnt = data_row_cnt + 1

            print(" ***** data_row_cnt: " + str(data_row_cnt) );

            # 1,2 indices (2nd and 3rd column in csv) are always the GPS Week, GPS Time of Week
            gps_week = int(row_item[1])
            gps_tow = numpy.double(row_item[2])

            print(' ******** data_row_cnt = ' + str(data_row_cnt) + ', gps_tow = ' + str(gps_tow))

            gps_sec_from_gps_epoch = gps_week * secsInWeek + gps_tow
            utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - 17 + 315964800

            # Convert UTC sec from UTC Epoch into unix nanosecond time
            ts = utc_sec_from_utc_epoch * 1000000000

            index = 0

            # Now iterate the values from index 3 (column 4) onward
            for i in range(3, (n_data_columns-1)):
               print(' ******** i: ' + str(i) + ', channel_names[i-3] = ' + channel_names[i-3] + ' row_item[i] = ' + row_item[i])

               ch = channel_data_struct()
               ch.ts = numpy.int64(ts)
               ch.value = float(row_item[i])

               print(' ******** csv2sensorcloud: Channel: ' + channel_names[i-3] + ', adding timestamp: ' + str(ch.ts) + ' and value = ' + str(ch.value))

               channel_data[sensor_name][i-3].append(ch)

            if (data_row_cnt > 4):
               break

        # this row is neither column headers nor data elements
        else:
            # test for DATA_START row (column headers to follow)
            if(len(row_item) == 1 and row_item[0] == 'DATA_START'):
               determine_headers = True
               # print("IMU DATA_START found, collecting headers")
        # } if (determine_headers == True)..

    # } for row_item in csvreader..

    print("******* CSV to Sensor Cloud: " + str(n_data_columns) + ' input headers found, ' + str(data_row_cnt) + " input data rows processed")

    print(' ******** len(channel_data[sensor_name]) = ' + str(len(channel_data[sensor_name])))

    for index in range(len(channel_data[sensor_name])):
       print(' ******** Uploading to Cloud: Index = ' + str(index) + ', Channel Name: ' + channel_names[index] + ' len(channel_data[index]) = ' + str(len(channel_data[sensor_name][index])) )

       channel_data_list = channel_data[sensor_name][index]

       for j in range(len(channel_data_list)):
          print(' ******** j = ' + str(j) + ' channel_data_list[j].ts: ' + str(channel_data_list[j].ts) + ' channel_data_list[j].value = ' + str(channel_data_list[j].value))

       uploadToSensorCloud(server, token, device_id, sensor_name, channel_names[index], 100, HERTZ, channel_data_list)

if(__name__ == "__main__"):
  main_line(sys.argv)


