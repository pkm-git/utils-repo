import sys
import visa
import numpy
import serial                  #library for accessing serial ports

from gpstime import *

from gsg_imu import *

from mip_csv_utils import *
from mip import *

from time import sleep           #sleep
from time import time  #import time library
from time import clock

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

def print_usage_message():
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("Usage: python gsg_to_imu_mip_packet.py -ip imu_port_name -ib imu_port_baud -ir imu_data_rate -mip want_imu_mip_packets -filedump filedump\n")
 print("imu_port_name\t\t-- the name of the IMU port (example: COM10)")
 print("imu_port_baud\t\t-- the baud rate of the IMU port (example: -ib 921600)")
 print("imu_data_rate\t\t-- the rate of input IMU data [use one of: 100 Hz, 250 Hz and 500 Hz.  Example: for 250 Hz, use: -ir 250]")
 print("imu_port_baud\t\t-- the baud rate of the IMU port (example: -ib 921600)")
 print("want_imu_mip_packets\t-- use 'y' if mip packets need to be created to send to the device, 'n' if it needs to run non-real-time (offline), to only save csv file data")
 print("filedump\t-- (used only if want_imu_mip_packets = 'n'): Use 'g' if you want IMU values to go to filedump, 'i' if you want IMU values to go to filedump")
 print("Note: -ir clause is optional.  If not present, it will assume 500 Hz IMU input data rate.  All other clauses are required.")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""
    imu_data_rate = 10 # 10 Hz data coming from GSG box

    imu_port_name = None
    imu_port_baud = 0

    want_imu_mip_packets = 'y'
    filedump = 'i'

    #parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-ip' and len(argv) > i+1):
         imu_port_name = argv[i+1]
       elif(argv[i] == '-ib' and len(argv) > i+1):
         imu_port_baud = int(argv[i+1])
       elif(argv[i] == '-ir' and len(argv) > i+1):
         imu_data_rate = int(argv[i+1])
       elif(argv[i] == '-mip' and len(argv) > i+1):
         want_imu_mip_packets = argv[i+1].lower()
       elif(argv[i] == '-filedump' and len(argv) > i+1):
         filedump = argv[i+1].lower()

    # if command line arguments were not properly specified tell the user and exit
    # if(imu_port_name == None or imu_port_baud == 0 or (imu_data_rate <> 100 and imu_data_rate <> 250 and imu_data_rate <> 500)):
    if(want_imu_mip_packets == 'y' and (imu_port_name == None or imu_port_baud == 0)):
      print_usage_message()
      sys.exit()

    if (want_imu_mip_packets == 'y'):
       print('********** IMU PORT : '+ imu_port_name);

       #Assign serial port object
       imu_port = serial.Serial(imu_port_name, imu_port_baud)

       #Close port in case it was left open by other process
       imu_port.close()

       #open specified port
       imu_port.open()

       fout_processing_time = open("Processing_time.csv", "w")

    rm = visa.ResourceManager()

    # inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
    inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

    print("****** SOUR:SCEN:CONT?")
    print(str(inst.query("SOUR:SCEN:CONT?")))

    str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

    print(' ********* RESPONSE: ' + str_scen_running)

    cnt = 0

    if (str_scen_running[0:5] == 'START'):

           print("SOUR:SCEN:SENS:REG ACC")
           print(str(inst.write("SOUR:SCEN:SENS:REG ACC")))

           print("SOUR:SCEN:SENS:REG? ACC")
           print(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

           print("****** BEFORE: SOUR:SCEN:SENS:REG? GYR")
           print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

           print("SOUR:SCEN:SENS:REG GYR")
           print(str(inst.write("SOUR:SCEN:SENS:REG GYR")))

           print("***** AFTER: SOUR:SCEN:SENS:REG? GYR")
           print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

           if (1):
              if (want_imu_mip_packets == 'n'):
                 # Create a file to log the IMU data that was supplied as input to the HIL
                 if (filedump == 'i'):
                    fout_imu_500Hz_hil = open("U:/Lord/GSG GNSS Simulator/GSG_RQ1_500Hz_IMU_HIL_Input.csv", "w")
                    fout_imu_10Hz_hil = open("U:/Lord/GSG GNSS Simulator/GSG_RQ1_10Hz_IMU_HIL_Input.csv", "w")
                    fout_imu_500Hz_hil.write('IMU interp loops,Scen Run Time,GPS Week,GPS TOW,X Accel,Y Accel,Z Accel,X Gyro,Y Gyro,Z Gyro,Delta Theta X,Delta Theta Y,Delta Theta Z,Delta Vel X,Delta Vel Y,Delta Vel Z\n')
                    fout_imu_10Hz_hil.write('IMU interp loops,Scen Run Time,GPS Week,GPS TOW,X Accel,Y Accel,Z Accel,X Gyro,Y Gyro,Z Gyro,Gyro X from Delta Theta,Gyro Y from Delta Theta,Gyro Z from Delta Theta,Accel X from Delta Vel,Accel X from Delta Vel,Accel X from Delta Vel\n')
                 else:
                    fout_gps_hil = open("U:/Lord/GSG GNSS Simulator/GSG_RQ1_GPS_HIL_Input.csv", "w")
                    fout_gps_hil.write('Run Time,TOW Using Start,TOD Using Start,Lat, Lon, Ht, ECEF_POS_x, ECEF_POS_y, ECEF_POS_z, Heading, Speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, Pitch, Roll, Yaw, Pitch Rate, Roll Rate, Yaw Rate\n')

           cnt = 0

           gsg_imu_obj = GSG_IMU()
           gsg_imu_obj_prev = GSG_IMU()

           str_gyr_acc  = ''
           str_utc = ''

           # 02-25-2016 13:35:33.8 UTC
           # str_start_utc = '02-25-2016 13:33:00.0 UTC'
           # str_start_utc = '02-25-2016 13:32:43.0 UTC'
           str_start_utc = '03-14-2016 10:54:43.0 UTC'

           cntStr = 0
           dateSplitStrings = str_start_utc.split('-')
           for s in dateSplitStrings:
               # print(' ***** cntStr: ' + str(cntStr) + ', s = ' + s)
               if (cntStr == 0):
                   month = int(s)
               elif (cntStr == 1):
                   day = int(s)
               elif (cntStr == 2):
                   year = int(s[0:4])
                   timeStr = s[5:]
                   timeSplitStrings = timeStr.split(':')
                   cntTimeStr = 0
                   for st in timeSplitStrings:
                       if (cntTimeStr == 0):
                           hr = int(st)
                       elif (cntTimeStr == 1):
                           min = int(st)
                       elif (cntTimeStr == 2):
                           sec = numpy.double(st[0:4])

                       cntTimeStr = cntTimeStr + 1

               cntStr = cntStr + 1

           # print(' ***** cnt: ' + str(cnt) + ', day = ' + str(day) + ', month: ' + str(month) + ', year: ' + str(year) + ', hr: ' + str(hr) + ', min: ' + str(min) + ', sec: ' + str(sec))

           (w_start, tow_start, d_start, tod_start) = gpsFromUTC(year, month, day, hr, min, sec)

           tow = tow_start
           tod = tod_start

           print(' **************************************************************************************** ')
           print(' **** START GPS VALUES: Week: ' + str(w_start) + ' TOW: ' + str(tow_start) + ' TOD: ' + str(tod_start))
           print(' **************************************************************************************** ')

           imu_data_row_cnt =  0

           runtime = 0

           if (1):
             # while(cnt < 3):
             # while(cnt < 100):
             while(True):
               imu_data_row_cnt = imu_data_row_cnt + 1

               str_runtime = "%s" %(str(inst.query("SOUR:SCEN:RUN?")))
               # print('******* str_runtime : ' + str_runtime)
               runtime = numpy.double(str_runtime)
               tow_using_start = tow_start + runtime
               tod_using_start = tod_start + runtime

               # str_gyr_acc = inst.query("SOUR:SCEN:SENS:DAT")
               # Accel: 0.427415, -0.0817233, -0.900354
               # Gyro: 0.0174533, 0.00523599, 0.00349066

               str_gyr_acc = "%s" %(str(inst.query("SOUR:SCEN:SENS:DAT?")))
               # print('******* str_gyr_acc : ' + str_gyr_acc)
               cntImuLine = 0
               accSplitStrings = str_gyr_acc.splitlines()
               for s in accSplitStrings:
                   if (s == ''):
                     break

                   # print(' ***** cntImuLine: ' + str(cntImuLine) + ', s = ' + s)

                   isGyro = 0
                   if (s[0:3].lower() == 'gyr'):
                      isGyro = 1

                   if (isGyro == 1):
                      startCol = 6
                   else:
                      startCol = 7

                   splitStrings = s[startCol:].split(',')

                   cntInertialStr = 0
                   for st in splitStrings:
                      # print('****** cntImuLine = ' + str(cntImuLine) + ', s = ' + s + ', st = ' + st + ' isGyro = ' + str(isGyro))
                      # if (cntImuLine == 0):
                      if (isGyro == 1):
                          if (cntInertialStr == 0):
                              orig_gyro_x = math.degrees(numpy.double(st))

                              tmp = int(math.floor(abs(orig_gyro_x)));
                              tmp_rem = tmp % 360
                              tmp_frac = abs(orig_gyro_x) - tmp;

                              if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
                                gyro_x = 0.0
                              elif (orig_gyro_x > 0):
                                gyro_x = tmp_rem + tmp_frac;
                              else:
                                gyro_x = -(tmp_rem + tmp_frac);

                              gyro_x = math.radians(gyro_x)

                          elif (cntInertialStr == 1):
                              orig_gyro_y = math.degrees(numpy.double(st))
                              tmp = int(math.floor(abs(orig_gyro_y)));
                              tmp_rem = tmp % 360
                              tmp_frac = abs(orig_gyro_y) - tmp;

                              if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
                                gyro_y = 0.0
                              elif (orig_gyro_y > 0):
                                gyro_y = tmp_rem + tmp_frac;
                              else:
                                gyro_y = -(tmp_rem + tmp_frac);

                              gyro_y = math.radians(gyro_y)

                          elif (cntInertialStr == 2):
                              orig_gyro_z = math.degrees(numpy.double(st))
                              tmp = int(math.floor(abs(orig_gyro_z)));
                              tmp_rem = tmp % 360
                              tmp_frac = abs(orig_gyro_z) - tmp;

                              if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
                                gyro_z = 0.0
                              elif (orig_gyro_z > 0):
                                gyro_z = tmp_rem + tmp_frac;
                              else:
                                gyro_z = -(tmp_rem + tmp_frac);

                              gyro_z = math.radians(gyro_z)
                      else:
                          if (cntInertialStr == 0):
                              accel_x = numpy.double(st)
                          elif (cntInertialStr == 1):
                              accel_y = numpy.double(st)
                          elif (cntInertialStr == 2):
                              accel_z = numpy.double(st)

                      cntInertialStr = cntInertialStr + 1

                   cntImuLine = cntImuLine + 1

               if (imu_data_row_cnt > 1):
                   dt = tow_using_start - gsg_imu_obj_prev.imu_tow

                   imu_interp_loops = int(dt/0.002)   # Interpolation loops based on 500 Hz (0.002 sec) IMU required rate
                   # print(' ******* imu_interp_loops = ' + str(imu_interp_loops))

                   sum_delta_theta_x = 0.0
                   sum_delta_theta_y = 0.0
                   sum_delta_theta_z = 0.0

                   sum_delta_vel_x = 0.0
                   sum_delta_vel_y = 0.0
                   sum_delta_vel_z = 0.0

                   # fout_processing_time.write('%10.4f,%4d,%4d\n'%(runtime, imu_data_row_cnt, imu_interp_loops))

                   # for i in range(imu_interp_loops):
                   for i in range(1, imu_interp_loops+1):
                       # print(" ***** Interp loop: i: " + str(i) );
                       # dt_interp = (runtime - gsg_imu_obj_prev.runtime) * i/imu_interp_loops
                       # packet_process_start_time = time()
                       packet_process_start_time = clock()

                       dt_interp = (runtime - gsg_imu_obj_prev.runtime)/imu_interp_loops
                       gsg_imu_obj.runtime = gsg_imu_obj_prev.runtime + dt_interp * i
                       gsg_imu_obj.imu_week = gsg_imu_obj_prev.imu_week
                       gsg_imu_obj.imu_tow = gsg_imu_obj_prev.imu_tow + (tow_using_start - gsg_imu_obj_prev.imu_tow) * i/imu_interp_loops
                       gsg_imu_obj.scaled_accel_x = gsg_imu_obj_prev.scaled_accel_x + (accel_x - gsg_imu_obj_prev.scaled_accel_x) * i/imu_interp_loops
                       gsg_imu_obj.scaled_accel_y = gsg_imu_obj_prev.scaled_accel_y + (accel_y - gsg_imu_obj_prev.scaled_accel_y) * i/imu_interp_loops
                       gsg_imu_obj.scaled_accel_z = gsg_imu_obj_prev.scaled_accel_z + (accel_z - gsg_imu_obj_prev.scaled_accel_z) * i/imu_interp_loops
                       gsg_imu_obj.scaled_gyro_x = gsg_imu_obj_prev.scaled_gyro_x + (gyro_x - gsg_imu_obj_prev.scaled_gyro_x) * i/imu_interp_loops
                       gsg_imu_obj.scaled_gyro_y = gsg_imu_obj_prev.scaled_gyro_y + (gyro_y - gsg_imu_obj_prev.scaled_gyro_y) * i/imu_interp_loops
                       gsg_imu_obj.scaled_gyro_z = gsg_imu_obj_prev.scaled_gyro_z + (gyro_z - gsg_imu_obj_prev.scaled_gyro_z) * i/imu_interp_loops

                       gsg_imu_obj.delta_theta_x = (gsg_imu_obj_prev.scaled_gyro_x + (gyro_x - gsg_imu_obj_prev.scaled_gyro_x) * (i-0.5)/imu_interp_loops) * dt_interp
                       gsg_imu_obj.delta_theta_y = (gsg_imu_obj_prev.scaled_gyro_y + (gyro_y - gsg_imu_obj_prev.scaled_gyro_y) * (i-0.5)/imu_interp_loops) * dt_interp
                       gsg_imu_obj.delta_theta_z = (gsg_imu_obj_prev.scaled_gyro_z + (gyro_z - gsg_imu_obj_prev.scaled_gyro_z) * (i-0.5)/imu_interp_loops) * dt_interp

                       gsg_imu_obj.delta_vel_x = (gsg_imu_obj_prev.scaled_accel_x + (accel_x - gsg_imu_obj_prev.scaled_accel_x) * (i-0.5)/imu_interp_loops) * dt_interp
                       gsg_imu_obj.delta_vel_y = (gsg_imu_obj_prev.scaled_accel_y + (accel_y - gsg_imu_obj_prev.scaled_accel_y) * (i-0.5)/imu_interp_loops) * dt_interp
                       gsg_imu_obj.delta_vel_z = (gsg_imu_obj_prev.scaled_accel_z + (accel_z - gsg_imu_obj_prev.scaled_accel_z) * (i-0.5)/imu_interp_loops) * dt_interp

                       sum_delta_theta_x += gsg_imu_obj.delta_theta_x
                       sum_delta_theta_y += gsg_imu_obj.delta_theta_y
                       sum_delta_theta_z += gsg_imu_obj.delta_theta_z

                       sum_delta_vel_x += gsg_imu_obj.delta_vel_x
                       sum_delta_vel_y += gsg_imu_obj.delta_vel_y
                       sum_delta_vel_z += gsg_imu_obj.delta_vel_z

                       # if (runtime > 34.5 and runtime < 35.4):
                          # fout_imu_500Hz_hil.write('%4d,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(int(imu_row_items_prev[0]), int(temp_imu_row_item[1]), temp_imu_row_item[2], temp_imu_row_item[3], temp_imu_row_item[4], temp_imu_row_item[5], temp_imu_row_item[6], temp_imu_row_item[7], temp_imu_row_item[8], temp_imu_row_item[9], temp_imu_row_item[10], temp_imu_row_item[11], temp_imu_row_item[12], temp_imu_row_item[13], temp_imu_row_item[14], temp_imu_row_item[15]))

                       if (want_imu_mip_packets == 'n'):
                          if (filedump == 'i'):
                             # fout_imu_500Hz_hil.write('%2d,%10.4f,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%15.12f,%15.12f,%15.12f,%14.8f,%14.8f,%14.8f\n'%(imu_interp_loops,gsg_imu_obj.runtime, int(gsg_imu_obj.imu_week), gsg_imu_obj.imu_tow, gsg_imu_obj.scaled_accel_x, gsg_imu_obj.scaled_accel_y, gsg_imu_obj.scaled_accel_z, gsg_imu_obj.scaled_gyro_x, gsg_imu_obj.scaled_gyro_y, gsg_imu_obj.scaled_gyro_z, gsg_imu_obj.delta_theta_x, gsg_imu_obj.delta_theta_y, gsg_imu_obj.delta_theta_z, gsg_imu_obj.delta_vel_x, gsg_imu_obj.delta_vel_y, gsg_imu_obj.delta_vel_z))
                             cnt = cnt
                       else: # want IMU MIP Packets
                             mp = bytearray([])

                             #initialize a packet for a base command
                             mip_init(mp,0x80)

                             mip_add_field(mp, 0x12, pack('>dHH', gsg_imu_obj.imu_tow, gsg_imu_obj.imu_week, 7))

                             # Accel (0x8004): Flip the x and y axes (GSG frame X = Lord Frame Y, similarly GSG frame Y = Lord Frame X)
                             mip_add_field(mp, 0x04, pack('>fff', gsg_imu_obj.scaled_accel_y, gsg_imu_obj.scaled_accel_x, -gsg_imu_obj.scaled_accel_z))

                             # Gyro (0x8005): Flip the x and y axes (GSG frame X = Lord Frame Y, similarly GSG frame Y = Lord Frame X)
                             mip_add_field(mp, 0x05, pack('>fff', gsg_imu_obj.scaled_gyro_y, gsg_imu_obj.scaled_gyro_x, -gsg_imu_obj.scaled_gyro_z))

                             # Mag (0x8006)
                             # # mip_add_field(mp, 0x06, pack('>fff', temp_imu_row_item[15], temp_imu_row_item[16], temp_imu_row_item[17]))
                             # mip_add_field(mp, 0x06, pack('>fff', temp_imu_row_item[16], temp_imu_row_item[17], temp_imu_row_item[18]))
                             # # mip_add_field(mp, 0x06, pack('>fff', 0, 0, 0))

                             # Delta Theta (0x8007)
                             mip_add_field(mp, 0x07, pack('>fff', gsg_imu_obj.delta_theta_y, gsg_imu_obj.delta_theta_x, -gsg_imu_obj.delta_theta_z))

                             # Delta Vel (0x8008)
                             mip_add_field(mp, 0x08, pack('>fff', gsg_imu_obj.delta_vel_y, gsg_imu_obj.delta_vel_x, -gsg_imu_obj.delta_vel_z))

                             #finalize packet
                             mip_finalize(mp)

                             #print "Packet after finalize: " + hexlify(mp).upper()

                             # print('\n************* Time for packet processing = ' + str(dt));
                             # fout_processing_time.write('%4d,%14.8f\n'%(5 * (imu_data_row_cnt-1) + (i+1), dt))
                             # fout_processing_time.write('%4d,%14.8f\n'%(imu_data_row_cnt, dt))

                             #send IMU MIP packet to device
                             imu_port.write(mp)
                             imu_port.flush()

                             # packet_process_end_time = time()
                             packet_process_end_time = clock()

                             deltaT = packet_process_end_time - packet_process_start_time
                             # print(' ********* runtime = ' + str(runtime) + ' gsg_imu_obj.imu_tow = ' + str(gsg_imu_obj.imu_tow) + ' deltaT = ' + str(deltaT))

                             # print 'runtime: %14.8f    %14.8f   %14.8f    %14.8f    %14.8f   %14.8f    %14.8f\n' % (runtime, accel_x, accel_y, accel_z, gyro_z, gyro_y, gyro_z)
                
                             # print('******* str_runtime : ' + str_runtime)

                   if (dt > 0 and want_imu_mip_packets == 'n' and filedump == 'i'):
                       # 'Back-calculate' 10 Hz Gyro, Accel from 500 Hz DeltaTheta, DeltaV:
                       gyro_x_from_delta_theta = sum_delta_theta_x / dt
                       gyro_y_from_delta_theta = sum_delta_theta_y / dt
                       gyro_z_from_delta_theta = sum_delta_theta_z / dt

                       accel_x_from_delta_vel = sum_delta_vel_x / dt
                       accel_y_from_delta_vel = sum_delta_vel_y / dt
                       accel_z_from_delta_vel = sum_delta_vel_z / dt

                       fout_imu_10Hz_hil.write('%2d,%10.4f,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%15.12f,%15.12f,%15.12f,%14.8f,%14.8f,%14.8f\n'%(imu_interp_loops,runtime, w_start, tow_using_start, accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z, gyro_x_from_delta_theta, gyro_y_from_delta_theta, gyro_z_from_delta_theta, accel_x_from_delta_vel, accel_y_from_delta_vel, accel_z_from_delta_vel))

               gsg_imu_obj_prev.runtime = runtime
               gsg_imu_obj_prev.imu_week = w_start
               gsg_imu_obj_prev.imu_tow = tow_using_start

               gsg_imu_obj_prev.scaled_accel_x = accel_x
               gsg_imu_obj_prev.scaled_accel_y = accel_y
               gsg_imu_obj_prev.scaled_accel_z = accel_z

               gsg_imu_obj_prev.scaled_gyro_x = gyro_x
               gsg_imu_obj_prev.scaled_gyro_y = gyro_y
               gsg_imu_obj_prev.scaled_gyro_z = gyro_z

               cnt = cnt + 1

               # Force a wait of 0.1 sec (100 ms) before next loop (to get data at 10 Hz):
               # inst.query("*OPC?")

    else:
       print(' *********** No scenario running ***********')

    if (1):
        if (want_imu_mip_packets == 'y'):
           imu_port.close()
           fout_processing_time.close()
        elif (filedump == 'i'):
           fout_imu_500Hz_hil.close()
           fout_imu_10Hz_hil.close()
        else:
           fout_gps_hil.close()

if(__name__ == "__main__"):
  main_line(sys.argv)

