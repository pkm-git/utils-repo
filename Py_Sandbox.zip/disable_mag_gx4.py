#import libraries used
from mip import *              #local file should be in local folder
from mip_parser import *       #local file should be in local folder
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 print("****** mip_parser_callback: callback_type = " + str(callback_type))
 print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
  #print("Valid Packet Found")

  #loop over fields in received valid packet
  for field in mip_get_next_field(packet_bytes):
   #if this field is an ack/nack output it to show the user
   if(field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):
    print('field[1] = ' + str(field[1]) + ' Device response to command '+hex(field[2]).upper()+': '\
          +mip_ack_nacks[field[3]])

    # print('Device response to command '+hex(field[2]).upper()+': '\
          # +mip_ack_nacks[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM1'
port_baud = 115200

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-p' and len(argv) > i+1):
  port_name = argv[i+1]
 elif(argv[i] == '-b' and len(argv) > i+1):
  port_baud = int(argv[i+1])
 elif(argv[i] == '-m' and len(argv) > i+1):
  mode = argv[i+1]

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name,port_baud)

#Close port in case it was left open by other process
port.close()

#generate command bytearrays

# Device in IMU Direct mode
imu_direct_command = bytearray.fromhex('75657F040410010274BD')

# Put device in Standard communication mode
std_mode_command = bytearray.fromhex('75657F040410010173BC')

# Enable Calibration Mode
enable_cal_mode = bytearray.fromhex('7565610C0C01D3C4A133010000000000C055')

# NAV Disable Magnetometer
nav_disable_mag_command = bytearray.fromhex('75656107070D01000000025920')

# NAV Enable Magnetometer
nav_enable_mag_command = bytearray.fromhex('75656107070D0100000000571E')

# Disable Magnetometer
imu_disable_mag_command = bytearray.fromhex('75656107070D01000500015D2E')

# Enable Magnetometer
imu_enable_mag_command = bytearray.fromhex('75656107070D01000700015F34')

# Save Factory Bit setting
save_factory_bit_command = bytearray.fromhex('75656103030D0351A8')

# Reset IMU
reset_imu_command = bytearray.fromhex('75650102027E5D43')

# Reset the device
reset_device_command = bytearray.fromhex('75650102027E5D43')

# Read current factory bits
read_factory_bits_command = bytearray.fromhex('75656103030D0250A7')

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

#open specified port
port.open()

#set up background process to update data buffers
background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

#start the response parsing thread
background_data_update.start()

print('----------------------------------------------------')
# ********************** Enable / Disable Magnetometer on the NAV Processor ***********
print('Sending Enable NAV Calibration Mode command:')
port.write(enable_cal_mode)

#sleep while waiting for response
sleep(0.1)

if (mode == 'disable_mag'):
    print('----------------------------------------------------')
    print('Sending NAV Disable Mag command:')
    port.write(nav_disable_mag_command)
elif (mode == 'enable_mag'):
    print('----------------------------------------------------')
    print('Sending NAV Enable Mag command:')
    port.write(nav_enable_mag_command)

#sleep while waiting for response
sleep(0.1)

if (mode == 'disable_mag' or mode == 'enable_mag'):
    print('----------------------------------------------------')
    # Save Factory Bit setting command
    print('Sending NAV Save Factory Bit setting command:')
    port.write(save_factory_bit_command)

elif (mode == 'read'):
    print('----------------------------------------------------')
    print('Sending NAV Read Factory Bits command:')
    port.write(read_factory_bits_command)

#sleep while waiting for response
sleep(0.1)

# -----------------------
# GX4-45 FW Verison 1105:
# -----------------------
# define FACTORY_BIT_DISABLE_PRESSURE_SENSOR 0x00000001
# define FACTORY_BIT_DISABLE_MAG_SENSOR      0x00000002
# define FACTORY_BIT_DISABLE_GPS_SENSOR      0x00000004

# u8 hw_specific_has_magnetometer()    {return !(factory_bits & FACTORY_BIT_DISABLE_MAG_SENSOR);};
# u8 hw_specific_has_gps()             {return !(factory_bits & FACTORY_BIT_DISABLE_GPS_SENSOR);};
# u8 hw_specific_has_pressure_sensor() {return !(factory_bits & FACTORY_BIT_DISABLE_PRESSURE_SENSOR);};

# ********************** Enable / Disable Magnetometer on the IMU Processor ***********

print('----------------------------------------------------')
print('Sending IMU Direct Mode command:')
port.write(imu_direct_command)

#sleep while waiting for response
sleep(0.1)

print('----------------------------------------------------')
print('Sending IMU Enable Calibration Mode command:')
port.write(enable_cal_mode)

#sleep while waiting for response
sleep(0.1)

if (mode == 'disable_mag'):
    print('----------------------------------------------------')
    print('Sending IMU Disable Mag command:')
    port.write(imu_disable_mag_command)
elif (mode == 'enable_mag'):
    print('----------------------------------------------------')
    print('Sending IMU Enable Mag command:')
    port.write(imu_enable_mag_command)

#sleep while waiting for response
sleep(0.1)

if (mode == 'disable_mag' or mode == 'enable_mag'):
    print('----------------------------------------------------')
    # Save Factory Bit setting command
    print('Sending IMU Save Factory Bit setting command:')
    port.write(save_factory_bit_command)
elif (mode == 'read'):
    print('----------------------------------------------------')
    print('Sending IMU Read Factory Bits command:')
    port.write(read_factory_bits_command)

#sleep while waiting for response
sleep(0.1)

print('----------------------------------------------------')
#send reset IMU command
print('Sending reset IMU command:')
port.write(reset_imu_command)

#sleep while waiting for response
sleep(0.1)

print('----------------------------------------------------')
#send reset IMU command
print('Sending std mode command:')
port.write(std_mode_command)

#sleep while waiting for response
sleep(0.1)

print('----------------------------------------------------')
#send reset device command
print('Sending reset device command:')
port.write(reset_device_command)

#sleep while waiting for response
sleep(0.1)

#stop background response parsing thread
background_data_update.stop()

#close port
port.close()

