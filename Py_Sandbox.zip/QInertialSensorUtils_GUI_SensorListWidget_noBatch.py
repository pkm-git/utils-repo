import numpy as np
import math
import os
import pyqtgraph as pg
## make a widget for displaying 3D objects
# import pyqtgraph.opengl as gl
import calendar

from datetime import datetime
from PyQt4 import QtCore, QtGui
from sensor_cloud_api import *
from QInertialSensorUtils_GUI_TreeWidget import *
from time import sleep         #sleep

RAD2DEG = 180.0 / np.pi
DEG2RAD = np.pi / 180.0
EARTH_MEAN_RADIUS = 6371000.0 # meters [https://en.wikipedia.org/wiki/Earth_radius]

pos_inf = float("+inf")
defaultPen = pg.mkPen('#5133E6', width=2, style=QtCore.Qt.DashLine)

pen_array = []
pen_array.append(defaultPen)
pen_array.append(pg.mkPen('#20541B', width=2, style=QtCore.Qt.DotLine))
pen_array.append(pg.mkPen('#7640E2', width=2, style=QtCore.Qt.DotLine))
pen_array.append(pg.mkPen('#AA31E6', width=2, style=QtCore.Qt.DotLine))
pen_array.append(pg.mkPen('#1C6F64', width=2, style=QtCore.Qt.DotLine))

mip_ekf_rad2deg_conversion_dict = {"8205":["Roll", "Pitch", "Yaw"], "820A":["Roll", "Pitch", "Yaw"], "8206":["Bias"], "820B":["Bias"], "820E":["Gyro"], "8214":["Heading"], "8215":["Incl", "Decl"]}
mip_imu_rad2deg_conversion_dict = {"8005":["Gyro"], "8007":["Theta"], "800C":["Roll", "Pitch", "Yaw"]}

mip_imu_column_units_dict = {"8004": {"Accel": "g"}, \
                             "8005": {"Gyro": "deg/s"}, \
                             "8006": {"Mag": "Gauss"}, \
                             "8017": {"Pressure": "mBar"}, \
                             "8007": {"Theta": "deg"}, \
                             "8008": {"Vel": "g*sec"}, \
                             "800C": {"Euler": "deg"}, \
                             "8010": {"Mag": "Gauss"}, \
                             "8011": {"Accel": "g"}}
mip_gps_column_units_dict = {"8103": {"Lat": "deg", "Lon": "deg", "Ht": "m", "Height": "m", "Horz": "m", "Vert": "m"}, \
                             "8104": {"ECEF": "m"}, \
                             "8105": {"Vel" : "m/s", "Speed": "m/s", "Heading": "deg"}, \
                             "8106": {"ECEF": "m/s"}, \
                             "810A": {"Bias": "sec", "Drift": "sec/sec", "Acc": "sec"}, \
                             "810C": {"Ratio": "dBHz", "Azimuth": "deg", "Elevation": "deg"} }
mip_ekf_column_units_dict = {"8201": {"Lat": "deg", "Lon": "deg", "Ht" : "m", "Height" : "m"}, \
                             "8202": {"Vel": "m/s"}, \
                             "8205": {"Roll": "deg", "Pitch" : "deg", "Yaw": "deg"}, \
                             "8206": {"Bias": "deg/s"}, \
                             "8207": {"Bias": "m/s" + u"\u00B2"}, \
                             "8208": {"LLH": "m"}, \
                             "8209": {"Vel": "m/s"}, \
                             "820A": {"Roll": "deg", "Pitch": "deg", "Yaw": "deg"}, \
                             "820B": {"Bias": "deg/s"}, \
                             "820C": {"Bias": "m/s" + u"\u00B2"}, \
                             "820D": {"Acc": "m/s" + u"\u00B2"}, \
                             "821C": {"Acc": "m/s" + u"\u00B2"}, \
                             "820E": {"Gyro": "deg/s"}, \
                             "820F": {"Gravity": "m/s" + u"\u00B2"}, \
                             "8213": {"Gravity": "m/s" + u"\u00B2"}, \
                             "8214": {"Heading": "deg"}, \
                             "8215": {"Inten": "Gauss", "Incl": "deg", "Decl": "deg"}, \
                             "8220": {"Alt": "m", "Temp": "degC", "Pressure": "mBar", "Density": "kg/m" + u"\u00B3"}, \
                             "8221": {"Alt": "m"}, \
                             "8230": {"Off": "m"}, \
                             "8231": {"Off": "m"}, \
                             "8227": {"Mag": "Gauss"}, \
                             "821A": {"Mag": "Gauss"}, \
                             "821B": {"Mag": "Gauss"}, \
                             "8225": {"Mag": "Gauss"}, \
                             "8228": {"Mag": "Gauss"}, \
                             "822C": {"Mag": "Gauss"}, \
                             "822D": {"Mag": "Gauss"} }

novatel_column_units_dict = {"Lat": "deg", \
                             "Lon": "deg", \
                             "Ht": "m", \
                             "Height": "m", \
                             "Undulation": "m", \
                             "Vel": "m/s", \
                             "DeltaV": "m/s", \
                             "DeltaTheta": "deg", \
                             "Speed": "m/s", \
                             "vned": "m/s", \
                             "Trc": "deg", \
                             "ECEF_Pos": "m", \
                             "ECEF_Vel": "m/s", \
                             "Roll": "deg", \
                             "Pitch": "deg", \
                             "Azimuth": "deg", \
                             "Angle": "deg"}

class Lat_Lon_Data_Struct:
   def __init__(self):
      self.lat_col_tow_values_to_use = []
      self.lat_col_values_to_use = []

      self.lon_col_tow_values_to_use = []
      self.lon_col_values_to_use = []
      
      self.lat_csv_curr_data_interp_at_prev_tow = []
      self.lon_csv_curr_data_interp_at_prev_tow = []
      
      self.lat_diff_array = []
      self.lon_diff_array = []
      self.lat_lon_diff_array = []

class MySensorListWidget(QtGui.QWidget):
   def __init__(self, parent, in_file_name = None, csv_object_name = None):
      super(MySensorListWidget, self).__init__(parent)

      self.parent_obj = parent

      self.sensor_name = ''
      self.desired_action = 'gs'
      self.sensor_label = None
      self.sensor_being_deleted = ''
      self.from_delete_selected = False
      self.csv_data_dict_of_dicts = {}
      self.empty_cell_col_dict_of_arrays = {}
      self.unix_timestamp_dict_of_dicts = {}
      self.child_count = 0
      self.selected_sensor_count = 0
      self.selected_sensor_being_deleted_count = 0
      self.nbrOfSubmitCalls = 0
      self.sensor_list_tree = None
      self.plotted_channels_dict = {}

      self.in_file_name = None
      self.appendMode = False
      self.csv_mode = False
      self.selected_sensor_names = []

      self.outputFile = None
      self.processError = False

      if (in_file_name != None):
         self.in_file_name = in_file_name
         self.csv_object_name = csv_object_name
         self.csv_mode = True
      else:
         # Open log file in append mode
         self.outputFile = open('InertialSensorUtils_DeleteSensor.log','a')

      # QProcess object for 'delete all sensors'
      self.process_delete_all = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process_delete_all.readyRead.connect(lambda: self.dataReady(self.process_delete_all))
      self.process_delete_all.readyReadStandardOutput.connect(lambda: self.readyReadStandardOutput(self.process_delete_all))
      self.process_delete_all.readyReadStandardError.connect(lambda: self.readyReadStandardError(self.process_delete_all))

      self.process_delete_all.started.connect(self.processDeleteAllStarted)
      self.process_delete_all.finished.connect(self.processDeleteAllDone)

      # QProcess object for 'delete selected sensors'
      self.process_del_selected = QtCore.QProcess(self)

      # self.process_del_selected.readyRead.connect(lambda: self.dataReady(self.process_del_selected))
      self.process_del_selected.readyReadStandardOutput.connect(lambda: self.readyReadStandardOutput(self.process_del_selected))
      self.process_del_selected.readyReadStandardError.connect(lambda: self.readyReadStandardError(self.process_del_selected))

      self.process_del_selected.started.connect(self.processDelSelStarted)
      self.process_del_selected.finished.connect(self.processDelSelDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

      self.__controls()
      self.__layout()

   def closeEvent(self, event):
      print "Closing MySensorListWidget window"

      if (self.csv_mode == False):
         self.outputFile.close()

      super(MySensorListWidget, self).closeEvent(event)

   def processDeleteAllStarted(self):
      if (self.csv_mode == False):
         self.outputFile.write(' ******* Starting Delete All Sensors:\n')

      self.lbl_status.setText("Status: Deleting all sensors.. please wait")

      # Just to prevent accidentally running multiple times
      # Disable the delete buttons when process starts, and enable them when it finishes
      self.delete_all_sensors_button.setEnabled(False)
      self.delete_selected_sensors_button.setEnabled(False)
      self.doAction()

   def processDeleteAllDone(self):
      if (self.processError):
         logMsg = ' ******* ERROR: Delete All Sensors: Pl. check Delete Sensors Log ********'
      else:
         logMsg = 'DONE Delete All Sensors'

      if (self.csv_mode == False):
         self.outputFile.write(' ******* ' + logMsg)

      self.lbl_status.setText('Status: ' + logMsg)

      # Reset processError flag for next call
      self.processError = False
      self.step = 0

      # Re-enable the delete buttons after completing the command:
      self.delete_all_sensors_button.setEnabled(True)
      self.delete_selected_sensors_button.setEnabled(True)

      # Refresh list of sensors after deleting selected ones:
      self.sensor_list_tree.initUI()

      if (self.csv_mode == False):
         self.outputFile.flush()

   def processDelSelStarted(self):
      if (self.csv_mode == False):
         self.outputFile.write(' ******* Starting Delete Selected Sensors: ' + str(self.sensor_being_deleted) + '\n')

      strStatusLabel = 'Status: Deleting sensor: ' + str(self.sensor_being_deleted) + ' [' + str(self.selected_sensor_being_deleted_count) + ' of ' + str(self.selected_sensor_count) + ']'
      self.lbl_status.setText(strStatusLabel)

      self.delete_selected_sensors_button.setEnabled(False)
      self.delete_all_sensors_button.setEnabled(False)
      self.doAction()

   def processDelSelDone(self):
      if (self.processError):
         logMsg = ' ******* ERROR: Delete Selected Sensors: Pl. check Delete Sensors Log ********'
      else:
         logMsg = 'DONE deleting sensor: ' + str(self.sensor_being_deleted) + ' [' + str(self.selected_sensor_being_deleted_count) + ' of ' + str(self.selected_sensor_count) + ']'

      if (self.csv_mode == False):
         self.outputFile.write(' ******* ' + logMsg)

      self.lbl_status.setText('Status: ' + logMsg)

      # Reset processError flag for next call
      self.processError = False
      self.step = 0

      if (self.selected_sensor_being_deleted_count == self.selected_sensor_count):
         self.delete_selected_sensors_button.setEnabled(True)
         self.delete_all_sensors_button.setEnabled(True)

         # Refresh list of sensors after deleting selected ones:
         self.sensor_list_tree.initUI()

         if (self.csv_mode == False):
            self.outputFile.flush()

   def readyReadStandardOutput(self, process):
      stdOutputStr = str(process.readAllStandardOutput())
      self.outputFile.write('\n' + stdOutputStr)
      self.outputFile.flush()

   def readyReadStandardError(self, process):
      self.processError = True

      self.outputFile.write('\n')
      errorLog = str(process.readAllStandardError())
      self.outputFile.write(errorLog)
      self.outputFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith("Status: DONE")):
         if (self.from_delete_selected):
            if (self.selected_sensor_being_deleted_count == self.selected_sensor_count):
               self.timer.stop()
            else:
               self.nbrOfSubmitCalls += 1
               self.submitDeleteSelectedSensors(False)
            # } if (self.selected_sensor_being_deleted_count ==..
         else:
            self.timer.stop()
         # } if (self.from_delete_selected)..

         return
      # } if (self.lbl_status.text().startsWith("Status: DONE")..

      self.step = self.step + 1
      strStatusLabel = ''
      if (self.from_delete_selected):
         strStatusLabel = "Status: Deleting sensor: " + str(self.sensor_being_deleted) + " [" + str(self.selected_sensor_being_deleted_count) + " of " + str(self.selected_sensor_count) + "]: Time elapsed: " + str(self.step) + " sec"
      else:
         strStatusLabel = "Status: Doing.. Time elapsed: " + str(self.step) + " seconds"
      self.lbl_status.setText(strStatusLabel)

   def doAction(self):
      if (self.timer.isActive() and self.from_delete_selected == False):
         self.timer.stop()
         return

      self.step = 0
      self.timer.start(1000, self)

   def append_tree_obj_from_file(self, append_file_name, csv_object_name = None):
      self.append_file_name = append_file_name
      self.appendMode = True
      self.csv_mode = True

      if (self.sensor_list_tree != None and self.append_file_name != None):
         # print(' ************* appending to tree: csv_object_name = ' + csv_object_name)
         self.sensor_list_tree.append_tree_obj_from_file(self.append_file_name, str(csv_object_name))

   def clearStatusText(self):
      self.lbl_status.setText("Status:")

   def __controls(self):

      labelText = "Sensor List"

      self.lbl_space_xxsmall = QtGui.QLabel()
      self.lbl_space_xxsmall.setFixedWidth(2)
      self.lbl_space_xxsmall.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(40)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(60)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(180)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.lbl_title = QtGui.QLabel(labelText)
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(475)
      self.lbl_status.setFixedHeight(25)

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_sensor_name = MyLineEdit()
      self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
      self.edt_sensor_name.setReadOnly(True)

      self.clear_status_text_button = QtGui.QPushButton("Clear")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");
      self.clear_status_text_button.setFixedWidth(60)

      if (self.csv_mode == False):
         self.delete_all_sensors_button = QtGui.QPushButton("Delete All Sensors")
         self.delete_all_sensors_button.setCheckable(True)
         self.delete_all_sensors_button.toggle()
         self.delete_all_sensors_button.clicked.connect(self.submitDeleteAllSensors)
         self.delete_all_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      if (self.csv_mode == False):
         self.delete_selected_sensors_button = QtGui.QPushButton("Delete Selected Sensors")
         self.delete_selected_sensors_button.setCheckable(True)
         self.delete_selected_sensors_button.toggle()
         self.delete_selected_sensors_button.clicked.connect(lambda: self.submitDeleteSelectedSensors(True))
         self.delete_selected_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_selected_cols_button = None
      self.plot_diff_selected_cols_button = None

      if (self.csv_mode):
         self.plot_new_tab_each_col_button = QtGui.QPushButton("1 Plot (tab) per Column")
         self.plot_2_sensors_on_same_plot_button = QtGui.QPushButton("2 CSV Files on 1 Plot")
      else:
         self.plot_new_tab_each_col_button = QtGui.QPushButton("1 Plot (tab) per Channel")
         self.plot_2_sensors_on_same_plot_button = QtGui.QPushButton("2 Sensors on 1 Plot")
      # } if (self.csv_mode):..
      
      self.plot_diff_selected_cols_button = QtGui.QPushButton("Diff Plot")
      # self.plot_LLH_button = QtGui.QPushButton("Lat/Lon Plot")
      self.plot_multi_cols_button = QtGui.QPushButton("Multi-Column Plot")

      self.plot_new_tab_each_col_button.setCheckable(True)
      self.plot_new_tab_each_col_button.toggle()
      self.plot_new_tab_each_col_button.clicked.connect(lambda: self.submitPlotSelectedCols(0))
      self.plot_new_tab_each_col_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_diff_selected_cols_button.setCheckable(True)
      self.plot_diff_selected_cols_button.toggle()
      self.plot_diff_selected_cols_button.clicked.connect(lambda: self.submitPlotSelectedCols(1))
      self.plot_diff_selected_cols_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_2_sensors_on_same_plot_button.setCheckable(True)
      self.plot_2_sensors_on_same_plot_button.toggle()
      self.plot_2_sensors_on_same_plot_button.clicked.connect(lambda: self.submitPlotSelectedCols(2))
      self.plot_2_sensors_on_same_plot_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      # self.plot_LLH_button.setCheckable(True)
      # self.plot_LLH_button.toggle()
      # self.plot_LLH_button.clicked.connect(lambda: self.submitPlotSelectedCols(3))
      # self.plot_LLH_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_multi_cols_button.setCheckable(True)
      self.plot_multi_cols_button.toggle()
      self.plot_multi_cols_button.clicked.connect(lambda: self.submitPlotSelectedCols(3))
      self.plot_multi_cols_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.chkbx_rel_time = MyCheckBox('Relative Time')
      self.chkbx_rel_time.setChecked(False)
      self.chkbx_rel_time.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      if (self.csv_mode == False):
         self.sensor_list_tree = MyTreeWidget(self.parent_obj)
      elif (self.appendMode == False):
         # print(' ******* appendMode is False, creating MyTreeWidget with self.csv_object_name = ' + self.csv_object_name)
         self.sensor_list_tree = MyTreeWidget(self.parent_obj, self.in_file_name, self.csv_object_name)

      self.sensor_list_tree.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()

      # -------------- TBD: -----------------------------
      if (0):
         if (desired_action == 'as'):
            if (sensor_label != None):
               addSensor(server, token, self.parent_obj.device_id, self.sensor_name, self.sensor_label)
            else:
               addSensor(server, token, self.parent_obj.device_id, self.sensor_name)
         elif (desired_action == 'us'):
            if (sensor_label != None):
               updateSensor(server, token, self.parent_obj.device_id, self.sensor_name, "", self.sensor_label)
            else:
               updateSensor(server, token, self.parent_obj.device_id, self.sensor_name, "")
         elif (desired_action == 'ac'):
            if (channel_label != None):
               addChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name, self.channel_label)
            else:
               addChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name)
         elif (desired_action == 'uc'):
            if (channel_label != None):
               updateChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name, self.channel_label)
            else:
               updateChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name)
            # } if (channel_label != None)..
         # } if (desired_action == 'as')..
      # } if (0)..

   def submitDeleteSelectedSensors(self, firstCall):
      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()
      self.from_delete_selected = True
      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to delete')
         return

      if (firstCall):
         self.nbrOfSubmitCalls = 0
         self.selected_sensor_count = 0
         self.selected_sensor_names = []
         self.selected_sensor_being_deleted_count = 0

         for i in range(self.child_count):
             item = root.child(i)
             sensor_name = str(item.text(0))
             if (item != None and item.checkState(0) == QtCore.Qt.Checked):
                self.selected_sensor_count += 1
                # self.selected_sensor_names[i] = item.text(0) # OR: item.text(column)?
                self.selected_sensor_names.append(sensor_name)
             # } if (item != None and..
         # } for i in range(self.child_count)..

         if (self.selected_sensor_count == 0):
           QtGui.QMessageBox.about(self, "Msg Box", 'No sensors selected to delete')
           return
         # } if (self.selected_sensor_count == 0)..
      # } if (firstCall)..

      s = self.selected_sensor_names[self.nbrOfSubmitCalls]
      print(' ********** Deleting sensor name: ' + s)

      command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
      command_line += '" -sv "' + self.parent_obj.server
      command_line += '" -t "' + self.parent_obj.token
      command_line += '" -s "' + s
      command_line += '" -a ds'

      if (self.csv_mode == False):
         self.outputFile.write('\n ******** Starting Sensor Cloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n' )
         self.outputFile.write(' ******* Deleted Selected Sensors: Command = ' + command_line + '\n')

      print(' ********* DELETE SELECTED SENSOR: command_line = ' + command_line)
      self.sensor_being_deleted = s
      self.selected_sensor_being_deleted_count += 1
      self.process_del_selected.start(command_line)

   def submitPlotSelectedCols(self, mode):
      # mode: 0 means 1 plot (tab) per column (or channel)
      # mode: 1 means 'diff plot'
      # mode: 2 means '2 sensor columns (or channels) on 1 plot
      # mode: 3 means 'multiple columns on 1 plot'

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()
      self.from_delete_selected = False
      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to plot')
         return

      selected_column_names_dict = {}
      selected_plot_col_count = {}
      selected_plot_total_col_count = 0
      selected_llh_dict = {}

      c_tow_col = {}
      c_week_col = {}
      error_msg = ''
      llh_3d_plot = False
      rel_time_plot = False

      if (self.chkbx_rel_time.checkState() == QtCore.Qt.Checked):
         rel_time_plot = True

      for i in range(self.child_count):
         item = root.child(i)
         sensor_name = str(item.text(0))
         self.childs_child_count = item.childCount()

         print(' ********** sensor_name = ' + sensor_name + ' self.childs_child_count = ' + str(self.childs_child_count))

         for j in range(self.childs_child_count):
            items_child = item.child(j)
            # print(' ********** column name: items_child.text(0) = ' + str(items_child.text(0)))

            if (items_child.checkState(0) == QtCore.Qt.Checked):
               col_name = str(items_child.text(0))
               print(' ***** column: ' + col_name + ' is checked')
               if ('tow' in str(col_name).lower()):
                  c_tow_col[sensor_name] = col_name
               elif ('week' in str(col_name).lower()):
                  c_week_col[sensor_name] = col_name
               else:
                  if (sensor_name not in selected_plot_col_count):
                     print(' *********** adding sensor_name: ' + sensor_name  + ' to selected_column_names_dict')
                     selected_column_names_dict[sensor_name] = []
                     selected_plot_col_count[sensor_name] = 0

                  selected_column_names_dict[sensor_name].append(col_name)
                  selected_plot_col_count[sensor_name] += 1

                  selected_plot_total_col_count += 1
                  print(' ********* adding col_name to selected_column_names_dict[' + sensor_name + '], selected_plot_col_count = ' + str(selected_plot_col_count[sensor_name]))

               # } if ('tow' in col_name.lower())..
            # } if (items_child.checkState(0)..
         # } for j in range(self.childs_child_count)..

         if (sensor_name in selected_column_names_dict):
            # if (sensor_name in c_tow_col and len(selected_column_names_dict[sensor_name]) == 0):
            if (len(selected_column_names_dict[sensor_name]) == 0):
               error_msg += 'Must select at least one column for sensor: ' + sensor_name + '\n'
            elif (mode == 3 and len(selected_column_names_dict[sensor_name]) > 5):
               error_msg += 'Cannot select more than 5 columns for multi-column plot\n'
            else:
               lat_in_sel_cols = False
               lon_in_sel_cols = False
               ht_in_sel_cols = False
               lat_lon_plot = False
               lat_lon_diff_plot = False
               llh_3d_plot = False

               for col in selected_column_names_dict[sensor_name]:
                  if ('lat' in col.lower()):
                     lat_in_sel_cols = True
                     if (sensor_name not in selected_llh_dict):
                        selected_llh_dict[sensor_name] = {}
                     selected_llh_dict[sensor_name]['lat'] = col
                  # } if ('lat' in col.lower())..

                  if ('lon' in col.lower()):
                     lon_in_sel_cols = True
                     if (sensor_name not in selected_llh_dict):
                        selected_llh_dict[sensor_name] = {}
                     selected_llh_dict[sensor_name]['lon'] = col
                  # } if ('lon' in col.lower())..

                  if ('ht' in col.lower() or 'height' in col.lower()):
                     ht_in_sel_cols = True
                     if (sensor_name not in selected_llh_dict):
                        selected_llh_dict[sensor_name] = {}
                     selected_llh_dict[sensor_name]['ht'] = col
                  # } if ('ht' in col.lower())..
               # } for col in selected_column_names_dict[sensor_name]..

               # if (lat_in_sel_cols == False or lon_in_sel_cols == False):
                  # error_msg += 'Must select both lat and lon for LLH plot for sensor: ' + sensor_name + '\n'

               if (lat_in_sel_cols and lon_in_sel_cols):
                  if (ht_in_sel_cols):
                     llh_3d_plot = True
                     error_msg += '3D LLH plot not implemented at this time\n'
                  else:
                     lat_lon_plot = True
                     if (mode == 1):
                        # error_msg += 'Lat-lon diff plot not implemented at this time\n'
                        lat_lon_diff_plot = True
                     elif (mode == 3):
                     # if (mode == 3):
                        error_msg += 'For Lat-lon plot, use 1 plot per tab or 2 sensors on 1 plot\n'
                     # } if (mode == 1)..
                  # } if (ht_in_sel_cols)..
               # } if (lat_in_sel_cols and lon_in_sel_cols)..

               if (self.csv_mode == True and lat_lon_plot == False and llh_3d_plot == False and sensor_name not in c_tow_col):
                  # if (mode == 0):
                  if (mode == 0 or mode == 3):
                     error_msg += 'Must select a TOW column for sensor: ' + sensor_name + '\n'
                  else:
                     error_msg += 'Must select GPS Week, TOW columns for sensor: ' + sensor_name + '\n'
                  # } if (mode == 0)..
               # } if (self.csv_mode == True and..
            # } if (len(selected_column_names_dict[sensor_name]) == 0)..

            # if (lat_lon_plot == False and (mode == 1 or mode == 2)):
            if (lat_lon_diff_plot or (lat_lon_plot == False and (mode == 1 or mode == 2))):
               if (lat_lon_plot and len(selected_column_names_dict[sensor_name]) > 2):
                  error_msg += 'Cannot select more than 2 columns for lat-lon diff plot or 2 sensor plot\n'
               elif (lat_lon_plot == False and len(selected_column_names_dict[sensor_name]) > 1):
                  error_msg += 'Cannot select more than one column for diff plot or 2 sensor plot\n'
               # } if (lat_lon_plot and..
                  
               if ((sensor_name in c_tow_col and sensor_name not in c_week_col) or \
                     (sensor_name not in c_tow_col and sensor_name in c_week_col)):
                  if (self.csv_mode == True):
                     if (mode == 1):
                        error_msg += 'For diff plot, must select Week if TOW selected, or TOW if Week selected\n'
                     else:
                        error_msg += 'For 2 CSV files in 1 plot, must select Week if TOW selected, or TOW if Week selected\n'
                     # } if (mode == 1)..
                  else:
                     if (mode == 1):
                        error_msg += 'For diff plot, must select Week if TOW selected, TOW if Week selected, or unselect both Week and TOW for both sensors\n'
                     else:
                        error_msg += 'For 2 sensors in 1 plot, must select Week if TOW selected, TOW if Week selected, or unselect both Week and TOW for both sensors\n'
                     # } if (mode == 1)..
                  # } if (self.csv_mode == True)..
               # } if ((sensor_name in c_tow_col ..
            # } if (lat_lon_diff_plot or..
         # } if (sensor_name in selected_column_names_dict)..
      # } for i in range(self.child_count)..

      if (selected_plot_total_col_count == 0):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select at least 1 column to plot')
         return
      elif ((mode == 1 or mode == 2) and len(selected_column_names_dict.keys()) != 2):
         error_msg += 'Must select exactly 2 sensors to compare\n'
      elif (mode == 3 and len(selected_column_names_dict.keys()) > 1):
         error_msg += 'Cannot select more than 1 sensor for multi-column plot\n'

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
         return
      
      empty_cell_col_array = None

      utcnow = datetime.utcnow().utctimetuple()
      utcunix_now = calendar.timegm(utcnow) * 1000000000
      
      if (lat_lon_plot):
         print(' ***************** IS A LAT LON PLOT **************')
         cnt_sensor = 0
         csv_data_dict_prev = {}
         if (self.csv_mode == False):
            unix_timestamp_dict = {}
         
         s_prev = ''
         col_name_prev = ''
         lat_lon_data_prev = Lat_Lon_Data_Struct()
         lat_lon_data = Lat_Lon_Data_Struct()
         lat_col_name_prev = ''
         lon_col_name_prev = ''
         
         for s in selected_column_names_dict.keys():
            print(' ******* sensor name: ' + s)
            csv_data_dict = {}
            
            if (self.csv_mode):
               empty_cell_col_array = []

            if (self.csv_mode == False):
               unix_timestamp_dict = {}
            
            found_lat = False
            found_lon = False
            
            print(' ******* sensor name: ' + s)
            cnt_sensor += 1
            
            lat_col_name = selected_llh_dict[s]['lat']
            lon_col_name = selected_llh_dict[s]['lon']
            
            if (cnt_sensor == 1):
               lat_col_name_prev = lat_col_name
               lon_col_name_prev = lon_col_name
               
               print(' ********** set lat_col_name_prev = ' + lat_col_name_prev + ', lon_col_name_prev = ' + lon_col_name_prev)
            # } if (cnt_sensor == 1)..
               
            # Get LLH data if already obtained before
            if (s in self.csv_data_dict_of_dicts):
               csv_data_dict = self.csv_data_dict_of_dicts[s]
               if (self.csv_mode):
                  if (s in self.empty_cell_col_dict_of_arrays):
                     empty_cell_col_array = self.empty_cell_col_dict_of_arrays[s]
                  # } if (s in self.empty_cell_col_dict_of_arrays)..
               elif (mode == 1 and s in self.unix_timestamp_dict_of_dicts):
                  unix_timestamp_dict = self.unix_timestamp_dict_of_dicts[s]
               # } if (self.csv_mode)..
            elif (self.csv_mode):
               csv_data_dict = self.sensor_list_tree.csv_data_dict[s]
               if (s in self.sensor_list_tree.empty_cell_col_dict):
                  empty_cell_col_array = self.sensor_list_tree.empty_cell_col_dict[s]
                  self.empty_cell_col_dict_of_arrays[s] = empty_cell_col_array
               # } if (s in self.sensor_list_tree.empty_cell_col_dict)..
            # } if (s in self.csv_data_dict_of_dicts)..

            # Get the TOW column data if selected to plot by the user and not already in the csv data structure
            if (mode == 1 and self.csv_mode == False and s in c_tow_col and c_tow_col[s] not in csv_data_dict):
               csv_data_dict[c_tow_col[s]], unix_timestamp_dict[c_tow_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_tow_col[s], 0, utcunix_now)

            # Get the Week column data if selected to plot by the user and not already in the csv data structure
            if (mode == 1 and self.csv_mode == False and s in c_week_col and c_week_col[s] not in csv_data_dict):
               csv_data_dict[c_week_col[s]], unix_timestamp_dict[c_week_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_week_col[s], 0, utcunix_now)
            
            # Get LLH data now (for selected LLH columns only, that were not obtained before)
            for c in selected_column_names_dict[s]:
               print('\n------------------------------------------------------------------------------------------------------------------------')
               print('\n******* sensor name: ' + s + ', column name: ' + c + ' selected_llh_dict[s][lat] = ' + selected_llh_dict[s]["lat"] + ' selected_llh_dict[s][lon]) = ' + selected_llh_dict[s]["lon"])
               
               # If channel name is not in csv_data_dict, get csv_data_dict[c] and unix_timestamp_dict[c] using sensor cloud
               if (c not in csv_data_dict and self.csv_mode == False):
                  csv_data_dict[c], unix_timestamp_dict[c] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c, 0, utcunix_now)
               # } if (c not in csv_data_dict)..

               # For lat_lon_diff plot
               if (mode == 1 and s in c_tow_col and len(csv_data_dict[c]) != len(csv_data_dict[c_tow_col[s]])):
                  QtGui.QMessageBox.about(self, "Msg Box", 'Lat/lon columns must have the same nbr of points as the TOW column')
                  return
               
               # For any lat-lon plot
               if (found_lat and found_lon and ( len(csv_data_dict[lat_col_name]) != len(csv_data_dict[lon_col_name]) )):
                  QtGui.QMessageBox.about(self, "Msg Box", 'Lat/lon columns must have the same nbr of points to plot')
                  return

               # if (mode == 1 and found_lat and found_lon and cnt_sensor == 2):
               
               if (c == lat_col_name):
                  found_lat = True
               elif (c == lon_col_name):
                  found_lon = True
               # } if (c == lat_col_name)..
               
               if ((mode == 1 or mode == 2) and cnt_sensor == 1):
                  s_prev = s
                  csv_data_dict_prev = csv_data_dict
                     
                  if (mode == 1):
                     if (s in c_tow_col):
                        # Store Lat-lon data of 1st sensor:
                        col_tow_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, empty_cell_col_array)
                        
                        if (c == lat_col_name):
                           lat_lon_data_prev.lat_col_tow_values_to_use = col_tow_values_to_use
                           lat_lon_data_prev.lat_col_values_to_use = col_values_to_use
                        elif (c == lon_col_name):
                           lat_lon_data_prev.lon_col_tow_values_to_use = col_tow_values_to_use
                           lat_lon_data_prev.lon_col_values_to_use = col_values_to_use
                        # } if (c == lat_col_name)..
                     else:
                        unix_timestamp_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, None, unix_timestamp_dict)
                     # } if (s in c_tow_col)..  
                  # } if (mode == 1).. 
               # } if (cnt_sensor == 1)..

               if (mode == 1 and cnt_sensor == 2):
                  # Store Lat-lon data of 2nd sensor:
                  
                  if (s in c_tow_col):
                     col_tow_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, empty_cell_col_array)
                     
                     if (c == lat_col_name):
                        lat_lon_data.lat_col_tow_values_to_use = col_tow_values_to_use
                        lat_lon_data.lat_col_values_to_use = col_values_to_use
                     elif (c == lon_col_name):
                        lat_lon_data.lon_col_tow_values_to_use = col_tow_values_to_use
                        lat_lon_data.lon_col_values_to_use = col_values_to_use
                     # } if (c == lat_col_name)..
                  else:
                     unix_timestamp_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, None, unix_timestamp_dict)
                  # } if (s in c_tow_col)..
               # } if (mode == 1).. 
               
               # Store csv data dictionary into a class attribute for faster retrieval in future
               self.csv_data_dict_of_dicts[s] = csv_data_dict
               
               # Do the actual plotting...
               if ((mode == 0 and found_lat and found_lon) or ((mode == 1 or mode == 2) and found_lat and found_lon and cnt_sensor == 2)):
                  graphicsWidget, p1 = self.setupPlot()
                  print(' *********** set up over, will do the plotting, mode = ' + str(mode))
                  
                  if (mode == 2):  # 2 Lat-lon's on 1 plot
                     legend = pg.LegendItem()
                     legend.setParentItem(p1)

                     legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

                     pdi1 = p1.plot(csv_data_dict_prev[lon_col_name_prev], csv_data_dict_prev[lat_col_name_prev], pen=defaultPen, name='&nbsp;&nbsp;&nbsp;' + s_prev)
                     pdi2 = p1.plot(csv_data_dict[lon_col_name], csv_data_dict[lat_col_name], pen=pg.mkPen('#20541B', width=2, style=QtCore.Qt.DotLine), name='&nbsp;&nbsp;&nbsp;' + s)

                     legend.addItem(pdi1, name=pdi1.opts['name'])
                     legend.addItem(pdi2, name=pdi2.opts['name'])
                  
                  elif (mode == 1): # same as lat_lon_diff_plot = True
                     print(' ************* will call getInterpData ************** ')
                     
                     # Check if both Lat and Lon sets of data have the same starting time and if lat/lon have same nbr of 'tow' points for both curr and prev
                     # if (abs(lat_lon_data.lat_col_tow_values_to_use[0] - lat_lon_data.lon_col_tow_values_to_use[0]) > 1e-06 or \
                         # abs(lat_lon_data_prev.lat_col_tow_values_to_use[0] - lat_lon_data_prev.lon_col_tow_values_to_use[0]) > 1e-06):
                         #    QtGui.QMessageBox.about(self, "Msg Box", 'The start time of Lat data must be same as the start time of the Lon data')
                         #    return
                     # elif (len(lat_lon_data.lat_col_tow_values_to_use) != len(lat_lon_data.lon_col_tow_values_to_use) or \
                       #     len(lat_lon_data_prev.lat_col_tow_values_to_use) != len(lat_lon_data_prev.lon_col_tow_values_to_use)):
                       #       QtGui.QMessageBox.about(self, "Msg Box", 'Lat data must have same number of points as the Lon data')
                       #       return
                     
                     error_msg, lat_col_tow_values_to_use_prev, lat_lon_diff_array = self.getInterpData(lat_lon_data_prev, lat_lon_data, rel_time_plot)

                     if (error_msg != ''):
                        QtGui.QMessageBox.about(self, "Msg Box", error_msg)
                        return
                     # } if (error_msg != '')..
                     
                     graphicsWidget, p1 = self.drawLatLonDiffPlot(lat_col_tow_values_to_use_prev, lat_lon_diff_array)
                     
                  else: # mode = 0
                     p1.plot(csv_data_dict[selected_llh_dict[s]['lon']], csv_data_dict[selected_llh_dict[s]['lat']], pen=defaultPen)
                  # } if (mode == 2 and cnt_sensor == 2)..

                  if ((mode == 1 or mode == 2) and s_prev != ''):
                     col_name_prev = selected_llh_dict[s_prev]['lat']
                  
                  if (mode != 1):
                     self.setLabelsTitleCloseButton(graphicsWidget, mode, p1, False, s, None, lat_col_name, s_prev, col_name_prev, True, False, lon_col_name)
                  else:
                     self.setLabelsTitleCloseButton(graphicsWidget, mode, p1, rel_time_plot, s, c_tow_col, c, s_prev, col_name_prev, True, True)
                  # } if (mode != 1)..
               # } if (mode == 0 or (mode == 1 and..
            
            # } for c in selected_column_names_dict[s]..

         # } for s in selected_column_names_dict.keys()..
      else:
         print(' ***************** IS NOT A LAT LON PLOT **************')
         cnt_sensor = 0

         col_values_to_use_prev = []
         col_tow_values_to_use_prev = []
         csv_data_week_prev = []

         s_prev = None
         col_name_prev = None
         csv_data_prev_interp = []
         csv_data_curr_interp = []

         if (self.csv_mode == False):
            unix_timestamp_dict_prev = {}
            unix_timestamp_values_to_use_prev = []

         first_tow_sensor1 = 0
         first_unix_timestamp_sensor1 = 0

         for s in selected_column_names_dict.keys():
            print('\n----------------------------------------------------------------------')

            csv_data_dict = {}
            if (self.csv_mode):
               empty_cell_col_array = []

            if (self.csv_mode == False):
               unix_timestamp_dict = {}

            print(' ******* sensor name: ' + s)
            cnt_sensor += 1

            if (s in self.csv_data_dict_of_dicts):
               csv_data_dict = self.csv_data_dict_of_dicts[s]
               if (self.csv_mode):
                  if (s in self.empty_cell_col_dict_of_arrays):
                     empty_cell_col_array = self.empty_cell_col_dict_of_arrays[s]
                  # } if (s in self.empty_cell_col_dict_of_arrays)..
               elif (s in self.unix_timestamp_dict_of_dicts):
                  unix_timestamp_dict = self.unix_timestamp_dict_of_dicts[s]
               # } if (self.csv_mode)..
            elif (self.csv_mode):
               csv_data_dict = self.sensor_list_tree.csv_data_dict[s]
               if (s in self.sensor_list_tree.empty_cell_col_dict):
                  empty_cell_col_array = self.sensor_list_tree.empty_cell_col_dict[s]
                  self.empty_cell_col_dict_of_arrays[s] = empty_cell_col_array
               # } if (s in self.sensor_list_tree.empty_cell_col_dict)..
            # } if (s in self.csv_data_dict_of_dicts)..

            # Get the TOW column data if selected to plot by the user and not already in the csv data structure
            if (self.csv_mode == False and s in c_tow_col and c_tow_col[s] not in csv_data_dict):
               csv_data_dict[c_tow_col[s]], unix_timestamp_dict[c_tow_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_tow_col[s], 0, utcunix_now)

            # Get the Week column data if selected to plot by the user and not already in the csv data structure
            if (self.csv_mode == False and s in c_week_col and c_week_col[s] not in csv_data_dict):
               csv_data_dict[c_week_col[s]], unix_timestamp_dict[c_week_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_week_col[s], 0, utcunix_now)

            col_tow_values_to_use_array = None
            col_values_to_use_array = None
            unix_timestamp_values_to_use_array = None
            
            if (mode == 3):
               col_tow_values_to_use_array = []
               col_values_to_use_array = []
               if (self.csv_mode == False):
                  unix_timestamp_values_to_use_array = []

            col_cnt = 0
            for c in selected_column_names_dict[s]:
               col_cnt += 1

               print('\n------------------------------------------------------------------------------------------------------------------------')
               print('\n******* sensor name: ' + s + ', column name: ' + c)

               if (self.csv_mode == False and c not in csv_data_dict):
                  # Channel name is not in csv_data_dict, so get csv_data_dict[c] and unix_timestamp_dict[c] from sensor cloud
                  csv_data_dict[c], unix_timestamp_dict[c] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c, 0, utcunix_now)
               # } if (c not in csv_data_dict)..
               
               # col_tow_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, empty_cell_col_array, col_tow_values_to_use_array, col_values_to_use_array)
               if (s in c_tow_col):
                  col_tow_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, empty_cell_col_array, None, col_tow_values_to_use_array, col_values_to_use_array)
               else:
                  unix_timestamp_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, None, unix_timestamp_dict, unix_timestamp_values_to_use_array, col_values_to_use_array)
               # } if (s in c_tow_col)..
               
               if ((mode == 1 or mode == 2) and cnt_sensor == 1):
                  col_name_prev = c
                  
                  if (rel_time_plot):
                     if (s in c_tow_col):
                        first_tow_sensor1 = col_tow_values_to_use[0]
                     else:
                        first_unix_timestamp_sensor1 = unix_timestamp_dict[c][0]
                     # } if (s in c_tow_col)..
                  # } if (rel_time_plot)..
               # } if ((mode == 1 or mode == 2) and cnt_sensor == 1)..

               # Begin plotting (regular 1 plot per tab, 2 sensors on 1 plot, diff plot, or multi-column plot):
               if (mode == 0 or mode == 3 or ((mode == 1 or mode == 2) and cnt_sensor == 2)):
                  if (s in c_tow_col):
                     print(' *********** s IS in c_tow_col, s = ' + s)
                     
                     # col_tow_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, empty_cell_col_array, col_tow_values_to_use_array, col_values_to_use_array)
                     
                     error_msg, graphicsWidget, p1 = self.drawThePlot(mode, s, c, c_tow_col, s_prev, col_name_prev, csv_data_dict, cnt_sensor, col_cnt, selected_column_names_dict, \
                                                                      col_tow_values_to_use, col_values_to_use, col_tow_values_to_use_prev, col_values_to_use_prev, rel_time_plot, first_tow_sensor1, \
                                                                      c_week_col, csv_data_week_prev, col_tow_values_to_use_array, col_values_to_use_array)
                  else:
                     print(' *********** s NOT in c_tow_col, s = ' + s)
                     
                     # unix_timestamp_values_to_use = unix_timestamp_dict[c]
                     # unix_timestamp_values_to_use, col_values_to_use = self.processDataForPlot(mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, None, unix_timestamp_values_to_use_array, col_values_to_use_array)
                     
                     # unix_timestamp_values_to_use_prev = []
                     # if (col_name_prev != None and col_name_prev in unix_timestamp_dict_prev):
                        # unix_timestamp_values_to_use_prev = unix_timestamp_dict_prev[col_name_prev]

                     error_msg, graphicsWidget, p1 = self.drawUnixTimestampPlot(mode, s, c, s_prev, col_name_prev, csv_data_dict, cnt_sensor, col_cnt, \
                                                                                selected_column_names_dict, unix_timestamp_values_to_use, col_values_to_use, \
                                                                                unix_timestamp_values_to_use_prev, col_values_to_use_prev, rel_time_plot, first_unix_timestamp_sensor1, \
                                                                                unix_timestamp_values_to_use_array, col_values_to_use_array)
                  # } if (s in c_tow_col)..

                  if (error_msg != ''):
                     QtGui.QMessageBox.about(self, "Msg Box", error_msg)
                     return
                  # } if (error_msg != '').. 

                  if (mode != 3 or (mode == 3 and col_cnt == len(selected_column_names_dict[s]))):
                     self.setLabelsTitleCloseButton(graphicsWidget, mode, p1, rel_time_plot, s, c_tow_col, c, s_prev, col_name_prev, False, False)
                  # } if (mode != 3 or (mode == 3 and col_cnt == len(selected_column_names_dict[s]))..
               # } if (mode == 0 or (..
            # } for c in selected_column_names_dict[s]..

            self.csv_data_dict_of_dicts[s] = csv_data_dict
            if (self.csv_mode == False):
               self.unix_timestamp_dict_of_dicts[s] = unix_timestamp_dict
            
            if ((mode == 1 or mode ==2) and cnt_sensor == 1):
               s_prev = s
               col_name_prev = c
               col_values_to_use_prev = col_values_to_use

               if (s in c_tow_col):
                  if (c_tow_col[s] in csv_data_dict):
                     print(' ******** c_tow_col[s] = ' + c_tow_col[s] + ' in csv_data_dict, will set col_tow_values_to_use_prev')
                     col_tow_values_to_use_prev = col_tow_values_to_use
                  if (c_week_col[s] in csv_data_dict):
                     csv_data_week_prev = csv_data_dict[c_week_col[s]]
                  # } if (c_tow_col[s] in csv_data_dict)..
               elif (self.csv_mode == False):
                  unix_timestamp_dict_prev = unix_timestamp_dict
                  unix_timestamp_values_to_use_prev = unix_timestamp_dict[c]

               # } if (c_tow_col[s] in csv_data_dict)..
            # } if ((mode == 1 or mode ==2) and..
         # } for s in selected_column_names_dict.keys()..
      # } if (lat_lon_plot)..

      # Clear selected sensor(s)/channel(s) (make ready for next set of selections by user):
      self.sensor_list_tree.createCheckboxesForTree()

   def processDataForPlot(self, mode, rel_time_plot, s, c_tow_col, c, csv_data_dict, empty_cell_col_array, unix_timestamp_dict = None, col_tow_values_to_use_array = None, col_values_to_use_array = None):
      col_tow_values_to_use = []
      col_values_to_use = []
      is_empty_col = False
      
      # Remove all dummy (positive infinity) values from column to plot
      if (pos_inf in csv_data_dict[c]):
         col_values_to_use = np.array([x for i,x in enumerate(csv_data_dict[c]) if x !=pos_inf])
      else:
         col_values_to_use = np.array(csv_data_dict[c])
      # } if (pos_inf in csv_data_dict[c])..

      if (mode == 3 and col_values_to_use_array != None):
         col_values_to_use_array.append(col_values_to_use)
      # } if (mode == 3)..

      col_tow_values_to_use = []
      if (s in c_tow_col):
         tow_array_values = []
         if (self.csv_mode and empty_cell_col_array != None and len(empty_cell_col_array) > 0 and c in empty_cell_col_array):
            csv_data_col_indices = [i for i,x in enumerate(csv_data_dict[c]) if x !=pos_inf]
            tow_array_values = [x for i,x in enumerate(csv_data_dict[c_tow_col[s]]) if i in csv_data_col_indices]
            is_empty_col = True
         # } if (self.csv_mode and len(empty_cell_col_array)..

         if (is_empty_col):
            col_tow_values_to_use = np.array(tow_array_values)
         else:
            col_tow_values_to_use = np.array(csv_data_dict[c_tow_col[s]])
         # } if (is_empty_col)..

         if (rel_time_plot and (mode == 0 or mode == 3)):
            col_tow_values_to_use = col_tow_values_to_use - col_tow_values_to_use[0]
         # } if (rel_time_plot ..

         if (mode == 3 and col_tow_values_to_use_array != None):
            col_tow_values_to_use_array.append(col_tow_values_to_use)
         # } if (mode == 3)..
      elif (self.csv_mode == False):
         col_tow_values_to_use = np.array(unix_timestamp_dict[c])
         if (rel_time_plot):
            # col_tow_values_to_use = np.array(col_tow_values_to_use) - col_tow_values_to_use[0]
            col_tow_values_to_use = (col_tow_values_to_use - col_tow_values_to_use[0])/1000000000
         # } if (rel_time_plot ..
         
         if (mode == 3 and col_tow_values_to_use_array != None):
            col_tow_values_to_use_array.append(col_tow_values_to_use)
         # } if (mode == 3 and..
      # } if (s in c_tow_col)..

      # Convert radian-type columns to degrees, using the dictionary of substrings in column names
      # First do for all Lord MIP device columns.  Assume all Lord MIP device csv column names will
      # have descriptor starting with lower-case 'x' (example: 'Pitch [x8201]' or 'Pitch_x8201')
      indx = c.find('x')
      if (indx != -1):
         field_descriptor = c[indx+1:indx+5].upper()
         if (field_descriptor in mip_ekf_rad2deg_conversion_dict):
            col_name_substr_array = mip_ekf_rad2deg_conversion_dict[field_descriptor]
            for c_substr in col_name_substr_array:
               if (c_substr.lower() in c.lower()):
                  col_values_to_use = col_values_to_use * RAD2DEG
               # } if (c_substr in c)..
            # } for c_substr in col_name_substr_array..
         elif (field_descriptor in mip_imu_rad2deg_conversion_dict):
            col_name_substr_array = mip_imu_rad2deg_conversion_dict[field_descriptor]
            for c_substr in col_name_substr_array:
               if (c_substr in c):
                  col_values_to_use = col_values_to_use * RAD2DEG
               # } if (c_substr in c)..
            # } for c_substr in col_name_substr_array..
         # } if (field_descriptor in mip_ekf_rad2deg_conversion_dict)..
      elif ('325' in c and 'deltatheta' in c.lower()):  # Novatel RAWIMU msg
         col_values_to_use = col_values_to_use * RAD2DEG
      # } if (indx != -1)..

      return col_tow_values_to_use, col_values_to_use
      
   def drawThePlot(self, mode, s, c, c_tow_col, s_prev, col_name_prev, csv_data_dict, cnt_sensor, col_cnt, selected_column_names_dict, \
                   col_tow_values_to_use, col_values_to_use, col_tow_values_to_use_prev, col_values_to_use_prev, rel_time_plot, first_tow_sensor1, \
                   c_week_col = None, csv_data_week_prev = None, col_tow_values_to_use_array = None, col_values_to_use_array = None):
      error_msg = ''
      graphicsWidget = None
      p1 = None
      
      if (mode == 1 or mode == 2):
         if (cnt_sensor == 2):
            # Check if the first element in GPS Week arrays are same between the 2 sensors
            if (c_week_col != None and csv_data_week_prev != None):
               gps_week_sensor1 = csv_data_dict[c_week_col[s]][0]
               gps_week_sensor2 = csv_data_week_prev[0]

               if (gps_week_sensor1 == 0 or gps_week_sensor2 == 0 or gps_week_sensor1 != gps_week_sensor2):
                  error_msg = 'GPS Week must be none-zero and same between the 2 sensors for diff plot or 2 sensor plot'
               # } if (gps_week_sensor1 == 0 or..
               
            if ( len(col_tow_values_to_use) != len(col_values_to_use) or \
                 len(col_tow_values_to_use_prev) != len(col_values_to_use_prev) ):
               error_msg = 'TOW column must have the same nbr of points as the column to plot'
            
            if (error_msg == ''):
               if (mode == 2): # (2 sensors in 1 plot):
                  graphicsWidget, p1 = self.setupPlot()
                  
                  legend = pg.LegendItem()
                  legend.setParentItem(p1)

                  legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

                  if (rel_time_plot):
                     if (col_tow_values_to_use[0] > first_tow_sensor1):
                        col_tow_values_to_use = col_tow_values_to_use - first_tow_sensor1
                        col_tow_values_to_use_prev = col_tow_values_to_use_prev - first_tow_sensor1
                     else:
                        first_tow_sensor2 = col_tow_values_to_use[0]
                        col_tow_values_to_use = col_tow_values_to_use - first_tow_sensor2
                        col_tow_values_to_use_prev = col_tow_values_to_use_prev - first_tow_sensor2
                     # } if (col_tow_values_to_use[0] > first_tow_sensor1)..
                  # } if (rel_time_plot)..
                  
                  pdi1 = p1.plot(col_tow_values_to_use_prev, col_values_to_use_prev, pen=defaultPen, name='&nbsp;&nbsp;&nbsp;' + s_prev)  # dark blue
                  pdi2 = p1.plot(col_tow_values_to_use, col_values_to_use, pen=pg.mkPen('#20541B', width=2, style=QtCore.Qt.DotLine), name='&nbsp;&nbsp;&nbsp;' + s)   # dark green

                  legend.addItem(pdi1, name=pdi1.opts['name'])
                  legend.addItem(pdi2, name=pdi2.opts['name'])

               else: # mode = 1 (diff plot)
                  # Check if there is a need to interpolate.  If the time columns are same length
                  # and max difference between individual timestamp pairs is less than 1e-6, then
                  # we consider them to be identical
                  if ((len(col_tow_values_to_use) == len(col_tow_values_to_use_prev)) and \
                     max( abs(np.array(col_tow_values_to_use) - np.array(col_tow_values_to_use_prev)) ) < 1e-6 ):
                     print(' *** TOW columns identical, no need to interpolate')

                     if (rel_time_plot):
                        col_tow_values_to_use = col_tow_values_to_use - col_tow_values_to_use[0]
                     # if (rel_time_plot)..

                     graphicsWidget, p1 = self.setupPlot()

                     if ('lat' in c.lower() or 'lon' in c.lower()):
                        p1.plot(col_tow_values_to_use, (col_values_to_use - col_values_to_use_prev) * DEG2RAD * EARTH_MEAN_RADIUS, pen=defaultPen)
                     else:
                        p1.plot(col_tow_values_to_use, col_values_to_use - col_values_to_use_prev, pen=defaultPen)
                     # } if ('lat' in c.lower() or..
                  else: # interpolate if there is an overlap of at least 20 percent
                     print(' ********* need to interpolate **************** ')
                     tmp_min_tow_sensor = 0
                     tmp_max_tow_sensor = 0

                     min_tow_sensor2 = min( np.array(col_tow_values_to_use) )
                     max_tow_sensor2 = max( np.array(col_tow_values_to_use) )

                     min_tow_sensor1 = min( np.array(col_tow_values_to_use_prev) )
                     max_tow_sensor1 = max( np.array(col_tow_values_to_use_prev) )

                     # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
                     if (min_tow_sensor1 > min_tow_sensor2):
                        tmp_min_tow_sensor = min_tow_sensor1
                        tmp_max_tow_sensor = max_tow_sensor1
                        min_tow_sensor1 = min_tow_sensor2
                        max_tow_sensor1 = max_tow_sensor2
                        min_tow_sensor2 = tmp_min_tow_sensor
                        max_tow_sensor2 = tmp_max_tow_sensor

                     if ( ((max_tow_sensor1 - min_tow_sensor2)/(max_tow_sensor1-min_tow_sensor1) > 0.2) ):

                        csv_curr_data_interp_at_prev_tow = np.interp(col_tow_values_to_use_prev, col_tow_values_to_use, col_values_to_use)

                        if (rel_time_plot):
                           col_tow_values_to_use_prev = col_tow_values_to_use_prev - col_tow_values_to_use_prev[0]
                        # } if (rel_time_plot)..
                        
                        graphicsWidget, p1 = self.setupPlot()
                        
                        if ('lat' in c.lower() or 'lon' in c.lower()):
                           p1.plot(col_tow_values_to_use_prev, (csv_curr_data_interp_at_prev_tow - col_values_to_use_prev) * DEG2RAD * EARTH_MEAN_RADIUS, pen=defaultPen)
                        else:
                           p1.plot(col_tow_values_to_use_prev, csv_curr_data_interp_at_prev_tow - col_values_to_use_prev, pen=defaultPen)
                        # } if ('lat' in c.lower() or..
                     else:
                        return 'TOW columns must have at least 20 percent overlap for diff plot', None, None
                  # } if ((len(col_tow_values_to_use) ..
               # } if (mode == 2).. 
            # } if (error_msg == '').. 
         # } if (cnt_sensor == 2)..
      elif (mode == 3):
         if ( len(col_tow_values_to_use) != len(col_values_to_use) ):
            print(' ***** len(col_tow_values_to_use) = ' + str(len(col_tow_values_to_use)) + ', len(col_values_to_use) = ' + str(len(col_values_to_use)))
            
            return 'TOW column must have the same nbr of points as the column to plot', None, None

         if (col_cnt == len(selected_column_names_dict[s])):
            graphicsWidget, p1 = self.setupPlot()
            
            legend = pg.LegendItem()
            legend.setParentItem(p1)

            legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

            indx = 0
            for c in selected_column_names_dict[s]:
               pdi = p1.plot(col_tow_values_to_use_array[indx], col_values_to_use_array[indx], pen=pen_array[indx], name='&nbsp;&nbsp;&nbsp;' + c)
               legend.addItem(pdi, name=pdi.opts['name'])
               indx += 1
            # } for c in selected_column_names_dict[s]:..
         # } if (col_cnt == len(selected_column_names_dict[s]))..
      else: # mode = 0 (1 plot / tab per column or channel)
         if (len(col_tow_values_to_use) != len(col_values_to_use)):
            return 'TOW column must have the same nbr of points as the column to plot', None, None
         else:
            graphicsWidget, p1 = self.setupPlot()
            p1.plot(col_tow_values_to_use, col_values_to_use, pen=defaultPen)
         # } if (len(col_tow_values_to_use) !=..
      # } if (mode == 1 or mode == 2)..
      
      return error_msg, graphicsWidget, p1

   def drawLatLonDiffPlot(self, lat_col_tow_values_to_use_prev, lat_lon_diff_array):
      # error_msg = ''
      graphicsWidget = None
      p1 = None
   
      graphicsWidget, p1 = self.setupPlot()

      # p1.plot(lat_lon_data_prev.lat_col_tow_values_to_use, lat_lon_data_prev.lat_lon_diff_array, pen=defaultPen)
      p1.plot(lat_col_tow_values_to_use_prev, lat_lon_diff_array, pen=defaultPen)
      
      return graphicsWidget, p1
      # return error_msg, graphicsWidget, p1

   def getInterpData(self, lat_lon_data_prev, lat_lon_data, rel_time_plot):
      
      error_msg, lat_col_tow_values_to_use_prev, lat_csv_curr_data_interp_at_prev_tow = self.getInterpDataLatOrLon(lat_lon_data_prev, lat_lon_data, rel_time_plot, 'lat')
      
      if (error_msg == ''):
         error_msg, lon_col_tow_values_to_use_prev, lon_csv_curr_data_interp_at_prev_tow = self.getInterpDataLatOrLon(lat_lon_data_prev, lat_lon_data, rel_time_plot, 'lon')
         
         if (error_msg == ''):
            lat_diff_array = (np.array(lat_csv_curr_data_interp_at_prev_tow) - np.array(lat_lon_data_prev.lat_col_values_to_use)) * DEG2RAD * EARTH_MEAN_RADIUS
            lon_diff_array = (np.array(lon_csv_curr_data_interp_at_prev_tow) - np.array(lat_lon_data_prev.lon_col_values_to_use)) * DEG2RAD * EARTH_MEAN_RADIUS
            lat_lon_diff_array = np.sqrt(np.power(np.array(lat_diff_array), 2) + np.power(np.array(lon_diff_array), 2))
         # } if (error_msg == '').. 
      # } if (error_msg == '')..
      
      return error_msg, lat_col_tow_values_to_use_prev, lat_lon_diff_array

   def getInterpDataLatOrLon(self, lat_lon_data_prev, lat_lon_data, rel_time_plot, type):
   
      error_msg = ''
      tmp_min_tow_sensor = 0
      tmp_max_tow_sensor = 0
      
      if (type == 'lat'):
         col_tow_values_to_use = lat_lon_data.lat_col_tow_values_to_use
         col_values_to_use = lat_lon_data.lat_col_values_to_use
         
         col_tow_values_to_use_prev = lat_lon_data_prev.lat_col_tow_values_to_use
         col_values_to_use_prev = lat_lon_data_prev.lat_col_values_to_use
      else:
         col_tow_values_to_use = lat_lon_data.lon_col_tow_values_to_use
         col_values_to_use = lat_lon_data.lon_col_values_to_use
         
         col_tow_values_to_use_prev = lat_lon_data_prev.lon_col_tow_values_to_use
         col_values_to_use_prev = lat_lon_data_prev.lon_col_values_to_use
      # } if (type == 'lat')..
      
      min_tow_sensor2 = min( np.array(col_tow_values_to_use) )
      max_tow_sensor2 = max( np.array(col_tow_values_to_use) )

      min_tow_sensor1 = min( np.array(col_tow_values_to_use_prev) )
      max_tow_sensor1 = max( np.array(col_tow_values_to_use_prev) )

      # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
      if (min_tow_sensor1 > min_tow_sensor2):
         tmp_min_tow_sensor = min_tow_sensor1
         tmp_max_tow_sensor = max_tow_sensor1
         min_tow_sensor1 = min_tow_sensor2
         max_tow_sensor1 = max_tow_sensor2
         min_tow_sensor2 = tmp_min_tow_sensor
         max_tow_sensor2 = tmp_max_tow_sensor

      if ( ((max_tow_sensor1 - min_tow_sensor2)/(max_tow_sensor1-min_tow_sensor1) > 0.2) ):
         csv_curr_data_interp_at_prev_tow = np.interp(col_tow_values_to_use_prev, col_tow_values_to_use, col_values_to_use)
         
         if (rel_time_plot):
            col_tow_values_to_use_prev = col_tow_values_to_use_prev - col_tow_values_to_use_prev[0]
         # } if (rel_time_plot)..
      else:
         return 'TOW columns must have at least 20 percent overlap for diff plot'
      
      if (type == 'lat'):
         lat_lon_data_prev.lat_csv_curr_data_interp_at_prev_tow = csv_curr_data_interp_at_prev_tow
         lat_lon_data_prev.lat_col_tow_values_to_use = col_tow_values_to_use_prev
      else:
         lat_lon_data_prev.lon_csv_curr_data_interp_at_prev_tow = csv_curr_data_interp_at_prev_tow
         lat_lon_data_prev.lon_col_tow_values_to_use = col_tow_values_to_use_prev
      # } if (type == 'lat')..
      
      return error_msg, col_tow_values_to_use_prev, csv_curr_data_interp_at_prev_tow
      
   def setupPlot(self):
      pg.setConfigOption('background', 'w')
      # pg.setConfigOption('background', '#A2C3F3')
      pg.setConfigOption('foreground', 'k')

      graphicsWidget = pg.GraphicsLayoutWidget()
      graphicsWidget.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

      # Enable antialiasing for prettier plots
      pg.setConfigOptions(antialias=True)

      # Generate the figure parameters for plotting output data
      p1 = graphicsWidget.addPlot()
      
      return graphicsWidget, p1
      
   def setLabelsTitleCloseButton(self, graphicsWidget, mode, p1, rel_time_plot, s, c_tow_col, c, s_prev, col_name_prev, lat_lon_plot, lat_lon_diff_plot, x_col_name = None):
   
      p1.enableAutoRange('xy', False)
      # p1.setXRange(0, data_rate/2.0, padding=0)

      p1.showGrid(x=True, y=True)
      
      xlabel = ''
      
      if (lat_lon_plot and lat_lon_diff_plot == False):
         y_unit_str = ' [deg]'
         # xlabel = selected_llh_dict[s]['lon'] + ' [deg]'
         
         if (x_col_name != None):
            xlabel = x_col_name
         # } if (x_col_name != None)..
         
         xlabel += ' [deg]'
      elif (lat_lon_diff_plot == False):
         if (rel_time_plot):
            xlabel = 'Relative Time (sec)'
         elif (s in c_tow_col):
            xlabel = 'TOW (sec)'
         else:
            xlabel = 'Unix Time (Nanosec)'
         
         # Find exact units of column being plotted, using the column units dictionaries
         unit_str = ''
      
         # First, determine if it is a MIP column being plotted
         indx = c.find('x')
         if (indx != -1): # assume MIP
            field_descriptor = c[indx+1:indx+5].upper()
            if (field_descriptor[:2] == '80'):
               col_unit_dict_to_use = mip_imu_column_units_dict
            elif (field_descriptor[:2] == '81'):
               col_unit_dict_to_use = mip_gps_column_units_dict
            elif (field_descriptor[:2] == '82'):
               col_unit_dict_to_use = mip_ekf_column_units_dict

            if (field_descriptor in col_unit_dict_to_use):
               col_unit_dict = col_unit_dict_to_use[field_descriptor]

               for (ky, val) in col_unit_dict.iteritems():
                  if (ky.lower() in c.lower()):
                     y_unit_str = ' [' + val + '] '
                     break
                  # } if (ky.lower() in c.lower())..
               # } for (ky, val) in col_unit_dict.items()..
            # } if (field_descriptor in col_unit_dict_to_use)..
         else: # is it a Novatel column
            for (ky, val) in novatel_column_units_dict.iteritems():
               if (ky.lower() in c.lower()):
                  y_unit_str = ' [' + val + '] '
                  break
               # } if (ky.lower() in c.lower())..
            # } for (ky, val) in col_unit_dict.items()..
         # } if (indx != -1)..
      # } if (lat_lon_plot and ..

      if (lat_lon_diff_plot):
         if (rel_time_plot):
            xlabel = 'Relative Time (sec)'
         elif (s in c_tow_col):
            xlabel = 'TOW (sec)'
         else:
            xlabel = 'Unix Time (Nanosec)'
         # } if (rel_time_plot)..   
      # } if (lat_lon_diff_plot)..
         
      ylabel = ''
      if (mode == 1):
         ylabel = 'Diff: '
      # } if (mode == 1)..
      
      if (lat_lon_diff_plot):
         ylabel += ' Lat/lon'
         y_unit_str = ' [m]'
      elif (mode == 1 or mode == 2):
         if (col_name_prev != c):
            ylabel += c + '/' + col_name_prev
         else:
            ylabel += c
         # } if (col_name_prev != c)..
      else:
         ylabel += c
      # } if (col_name_prev != c)..

      # Use meters in lat/lon diff plots:
      if (mode == 1 and ('lat' in c.lower() or 'lon' in c.lower())):
         y_unit_str = ' [m]'

      ylabel_wUnits = ylabel + y_unit_str

      p1.setLabel('bottom', xlabel)
      p1.setLabel('left', ylabel_wUnits)

      title = ''

      if (mode == 1 or mode == 2):
         title += str(s) + ' vs ' + str(s_prev) + ': '
      else:
         title = s + ': '

      title += ylabel

      if (mode == 0):
         title += ' vs ' + xlabel

      p1.setTitle(title)

      if (self.csv_mode == True):
         tabLabel = "CSV Plot"
      else:
         tabLabel = "Channel Plot"

      closeButton = QtGui.QPushButton()
      closeButton.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon.png")))
      closeButton.clicked.connect(lambda:self.parent_obj.whichbtn(closeButton))
      closeButton.setFixedWidth(15)
      closeButton.setFixedHeight(15)

      self.parent_obj.plot_tab_cnt += 1

      tabIndex = self.parent_obj.plot_tab_cnt
      if (self.parent_obj.sensor_cloud_enabled == True):
         tabIndex += 1

      self.parent_obj.tabs.addTab(graphicsWidget, tabLabel)

      self.parent_obj.plot_tab_dict[closeButton] = self.parent_obj.plot_tab_cnt
      self.parent_obj.plot_tab_push_button_dict[closeButton] = self.parent_obj.tabs.indexOf(graphicsWidget)
      self.parent_obj.tabs.tabBar().setTabButton(self.parent_obj.tabs.indexOf(graphicsWidget), QtGui.QTabBar.RightSide, closeButton)
      self.parent_obj.tabs.setCurrentIndex(self.parent_obj.tabs.indexOf(graphicsWidget))
   
   def drawUnixTimestampPlot(self, mode, s, c, s_prev, col_name_prev, csv_data_dict, cnt_sensor, col_cnt, selected_column_names_dict, \
                             unix_timestamp_values_to_use, col_values_to_use, unix_timestamp_values_to_use_prev, col_values_to_use_prev, \
                             rel_time_plot, first_unix_timestamp_sensor1, unix_timestamp_values_to_use_array, col_values_to_use_array):
      error_msg = ''
      graphicsWidget = None
      p1 = None

      if (mode == 1 or mode == 2):
         if (cnt_sensor == 2):
            if (mode == 2): # (2 sensors in 1 plot):
               graphicsWidget, p1 = setupPlot()
               
               legend = pg.LegendItem()
               legend.setParentItem(p1)

               legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

               if (rel_time_plot):
                  if (col_tow_values_to_use[0] > first_unix_timestamp_sensor1):
                     unix_timestamp_values_to_use = unix_timestamp_values_to_use - first_unix_timestamp_sensor1
                     unix_timestamp_values_to_use_prev = unix_timestamp_values_to_use_prev - first_unix_timestamp_sensor1
                  else:
                     first_unix_timestamp_sensor2 = unix_timestamp_values_to_use[0]
                     unix_timestamp_values_to_use = unix_timestamp_values_to_use - first_unix_timestamp_sensor2
                     unix_timestamp_values_to_use_prev = unix_timestamp_values_to_use_prev - first_unix_timestamp_sensor2
                  # } if (col_tow_values_to_use[0] > first_unix_timestamp_sensor1)..
               # } if (rel_time_plot)..

               pdi1 = p1.plot(unix_timestamp_values_to_use_prev, col_values_to_use_prev, pen=defaultPen, name='&nbsp;&nbsp;&nbsp;' + s_prev)
               pdi2 = p1.plot(unix_timestamp_values_to_use, col_values_to_use, pen=pg.mkPen('#20541B', width=2, style=QtCore.Qt.DotLine), name='&nbsp;&nbsp;&nbsp;' + s)

               legend.addItem(pdi1, name=pdi1.opts['name'])
               legend.addItem(pdi2, name=pdi2.opts['name'])

            else: # mode = 1 (diff plot)
               # if ((len(unix_timestamp_dict[c]) == len(unix_timestamp_dict_prev[col_name_prev])) and \
               if ((len(unix_timestamp_values_to_use) == len(unix_timestamp_values_to_use_prev)) and \
                  max( abs(np.array(unix_timestamp_values_to_use) - np.array(unix_timestamp_values_to_use_prev)) ) < 1e-6 ):
                  print(' *** Unix timestamp columns identical, no need to interpolate')

                  if (rel_time_plot):
                     unix_timestamp_values_to_use = unix_timestamp_values_to_use - unix_timestamp_values_to_use[0]
                  # if (rel_time_plot)..
                  
                  graphicsWidget, p1 = setupPlot()
                  
                  if ('lat' in c.lower() or 'lon' in c.lower()):
                     p1.plot(unix_timestamp_values_to_use, (col_values_to_use - col_values_to_use_prev) * DEG2RAD * EARTH_MEAN_RADIUS, pen=defaultPen)
                  else:
                     p1.plot(unix_timestamp_values_to_use, col_values_to_use - col_values_to_use_prev, pen=defaultPen)
                  # } if ('lat' in c.lower() or..
               else: # interpolate
                  tmp_min_unix_timestamp_sensor = 0
                  tmp_max_unix_timestamp_sensor = 0

                  min_unix_timestamp_sensor2 = min( np.array(unix_timestamp_values_to_use) )
                  max_unix_timestamp_sensor2 = max( np.array(unix_timestamp_values_to_use) )
                  min_unix_timestamp_sensor1 = min( np.array(unix_timestamp_dict_prev[col_name_prev]) )
                  max_unix_timestamp_sensor1 = max( np.array(unix_timestamp_dict_prev[col_name_prev]) )

                  # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
                  if (min_unix_timestamp_sensor1 > min_unix_timestamp_sensor2):
                     tmp_min_unix_timestamp_sensor = min_unix_timestamp_sensor1
                     tmp_max_unix_timestamp_sensor = max_unix_timestamp_sensor1
                     min_unix_timestamp_sensor1 = min_unix_timestamp_sensor2
                     max_unix_timestamp_sensor1 = max_unix_timestamp_sensor2
                     min_unix_timestamp_sensor2 = tmp_min_unix_timestamp_sensor
                     max_unix_timestamp_sensor2 = tmp_max_unix_timestamp_sensor

                  if ( ((max_unix_timestamp_sensor1 - min_unix_timestamp_sensor2)/(max_unix_timestamp_sensor1-min_unix_timestamp_sensor1) > 0.2) ):

                     csv_curr_data_at_prev_timestamp_interp = np.interp(unix_timestamp_dict_prev[col_name_prev], unix_timestamp_values_to_use, csv_data_dict[c])

                     if (rel_time_plot):
                        unix_timestamp_values_to_use_prev = unix_timestamp_values_to_use_prev - unix_timestamp_values_to_use_prev[0]
                     # } if (rel_time_plot)..
                     
                     graphicsWidget, p1 = setupPlot()
                     
                     if ('lat' in c.lower() or 'lon' in c.lower()):
                        p1.plot(unix_timestamp_values_to_use_prev, (csv_curr_data_at_prev_timestamp_interp - col_values_to_use_prev) * DEG2RAD * EARTH_MEAN_RADIUS, pen=defaultPen)
                     else:
                        p1.plot(unix_timestamp_values_to_use_prev, csv_curr_data_at_prev_timestamp_interp - col_values_to_use_prev, pen=defaultPen)
                     # } if ('lat' in c.lower() or..
                     
                     return 'Unix timestamp columns must have at least 20 percent overlap for diff plot', None, None
               # } if (len(col_tow_values_to_use)..
         # } if (cnt_sensor == 2)..
      elif (mode == 3):
         if (col_cnt == len(selected_column_names_dict[s])):
            print(' *********** mode = 3: Multi column plot: col_cnt = ' + str(col_cnt) + ' len(selected_column_names_dict[s]) = ' + str(len(selected_column_names_dict[s])) )

            graphicsWidget, p1 = self.setupPlot()

            legend = pg.LegendItem()
            legend.setParentItem(p1)

            legend.anchor(itemPos=(1,0), parentPos=(1,0), offset=(-20,40))

            indx = 0
            for c in selected_column_names_dict[s]:
               pdi = p1.plot(unix_timestamp_values_to_use_array[indx], col_values_to_use_array[indx], pen=pen_array[indx], name='&nbsp;&nbsp;&nbsp;' + c)

               legend.addItem(pdi, name=pdi.opts['name'])
               indx += 1
            # } for c in selected_column_names_dict[s]:..
         # } if (col_cnt == len(selected_column_names_dict[s]))..
      else: # mode = 0 (1 plot / tab per column or channel)
         # if (rel_time_plot):
            # unix_timestamp_values_to_use = (unix_timestamp_values_to_use - unix_timestamp_values_to_use[0])/1000000000
         # } if (rel_time_plot)..
         
         graphicsWidget, p1 = self.setupPlot()
         
         p1.plot(unix_timestamp_values_to_use, col_values_to_use, pen=defaultPen)
      # } if (mode == 1 or mode == 2)..

      return error_msg, graphicsWidget, p1
      
   def submitDeleteAllSensors(self):
      self.from_delete_selected = False

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()

      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to delete')
      else:
         command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
         command_line += '" -sv "' + self.parent_obj.server
         command_line += '" -t "' + self.parent_obj.token
         command_line += '" -a das'

         if (self.csv_mode == False):
            self.outputFile.write('\n ******** Starting Sensor Cloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
            self.outputFile.write(' ******* Deleted ALL Sensors: Command = ' + command_line + '\n')

         print(' ********* DELETE ALL: command_line = ' + command_line)

         self.process_delete_all.start(command_line)

      return

   def __layout(self):
      self.v1box = QtGui.QVBoxLayout()
      # self.v1box.addWidget(self.sensor_list_table)
      self.v1box.addWidget(self.sensor_list_tree)

      self.h2box = QtGui.QHBoxLayout()
      self.h2box.addWidget(self.lbl_space_small)

      self.h2box.addWidget(self.plot_diff_selected_cols_button)
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.plot_2_sensors_on_same_plot_button)
      self.h2box.addWidget(self.lbl_space_small)

      self.v2box = QtGui.QVBoxLayout()

      if (self.csv_mode):
         self.h2box.addWidget(self.chkbx_rel_time)

         self.h2bbox = QtGui.QHBoxLayout()
         self.h2bbox.addWidget(self.lbl_space_small)
         self.h2bbox.addWidget(self.plot_new_tab_each_col_button)
         self.h2bbox.addWidget(self.lbl_space_small)
         self.h2bbox.addWidget(self.plot_multi_cols_button)
         self.h2bbox.addWidget(self.lbl_space_small)

         self.v2box.addLayout(self.h2box)
         self.v2box.addLayout(self.h2bbox)
      else:
         self.h2box.addWidget(self.plot_new_tab_each_col_button)
         self.h2box.addWidget(self.lbl_space_small)
         self.h2box.addWidget(self.chkbx_rel_time)
         self.v2box.addLayout(self.h2box)

         self.h3box = QtGui.QHBoxLayout()
         self.h3box.addWidget(self.lbl_space_small)
         self.h3box.addWidget(self.plot_multi_cols_button)
         self.h3box.addWidget(self.lbl_space_small)

         self.h3box.addWidget(self.lbl_space_medium)
         self.h3box.addWidget(self.delete_selected_sensors_button)
         self.h3box.addWidget(self.lbl_space_small)
         self.h3box.addWidget(self.delete_all_sensors_button)
         self.h3box.addWidget(self.lbl_space_medium)

         self.v3box = QtGui.QVBoxLayout()
         self.v3box.addLayout(self.h3box)

         self.h4box = QtGui.QHBoxLayout()
         self.h4box.addWidget(self.lbl_status)
         self.h4box.addWidget(self.clear_status_text_button)

         self.v4box = QtGui.QVBoxLayout()
         self.v4box.addLayout(self.h4box)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.v1box)
      self.vbox.addLayout(self.v2box)

      if (self.csv_mode == False):
         self.vbox.addLayout(self.v3box)
         self.vbox.addLayout(self.v4box)

      self.setLayout(self.vbox)

