import sys
import os
import visa
import numpy
import serial
import csv

from gpstime import *

from time import sleep           #sleep
from time import time  #import time library
from time import clock

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)
from async_user_input_thread import AsyncUserInput # Asynchronous User Input thread

from gsg_user_input import *

def print_usage_message():
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("  ERROR(S) FOUND: IMU data rate must be one of 100 Hz, 250 Hz, and 500 Hz")
 print("-------------------------------------------------------------------------- " )
 print("Usage: python save_10Hz_gsg_to_file.py -what_to_save which_10Hz_data_to_save -ir imu_data_rate -save_folder save_folder_path\n")
 print("which_10Hz_data_to_save\t: Optional: Use 'i' if 10 Hz IVI IMU data needs to be saved to a csv file (default), use 'g' is 10 Hz GPS RF out data needs to be saved")
 print("imu_data_rate\t\t: Optional: The rate of input IMU data [use one of: 100 Hz, 250 Hz and 500 Hz (default)].  Example: for 250 Hz, use: -ir 250.]")
 print("save_folder_path\t: Optional: The folder where files need to be saved.  Defaults to current folder where this script runs from.")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""

    # default IMU input data rate to 500Hz
    imu_data_rate = 500

    # default to saving IMU data
    which_10Hz_data_to_save = 'i'

    # default folder to save files
    save_folder_path = '.'

    #parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-what_to_save' and len(argv) > i+1):
         which_10Hz_data_to_save = argv[i+1].lower()
       elif(argv[i] == '-ir' and len(argv) > i+1):
         imu_data_rate = int(argv[i+1])
       elif(argv[i] == '-save_folder' and len(argv) > i+1):
         save_folder_path = argv[i+1]

    # if command line arguments were not properly specified tell the user and exit
    if (imu_data_rate <> 100 and imu_data_rate <> 250 and imu_data_rate <> 500):
       print_usage_message()
       sys.exit()

    rm = None

    if (os.name == 'nt'):
       rm = visa.ResourceManager()       # for Windows
    elif (os.name == 'posix'):
       rm = visa.ResourceManager('@py')  # for Ubuntu

    # inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
    inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

    print("****** SOUR:SCEN:CONT?")
    str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

    scenario_started = False

    if (str_scen_running[0:5] == 'START'):
       scenario_started = True
    else:
       print(' *********** No scenario running, will start scenario ***********')

       print("SOUR:SCEN:CONT start; *WAI;")
       str_start_scen = "%s" %(str(inst.write("SOUR:SCEN:CONT start; *WAI;")))
       print('********* str_start_scen: ' + str_start_scen)

       if (str_start_scen[0:2] == 'Ok'):
          print('********* SCENARIO STARTED: ')
       else:
          # Typically, GSG takes about 20 sec to start a scenario.  So we wait for 14 sec (to be on the safe side)
          # then check every second if the scenario has started.  We don't want to miss the exact start of the scenario.
          sleep(14)
          cnt = 0
          while(cnt < 20):
             cnt = cnt + 1

             str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))
             print(' ******* Checking for scenario start; cnt: ' + str(cnt))

             if (str_scen_running[0:5] == 'START'):
                print('******** SCENARIO STARTED' )
                scenario_started = True
                break
             else:
                sleep(1)
             # } if (str_scen_running[0:5]...
          # } while(cnt < 20)...
       # } if (str_start_scen[0:2]...
    # } if (str_scen_running[0:5]...

    if (scenario_started == True):
       print("SOUR:SCEN:SENS:REG ACC")
       print(str(inst.write("SOUR:SCEN:SENS:REG ACC")))

       print("SOUR:SCEN:SENS:REG? ACC")
       print(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

       str_acc_reg_status = "%s" %(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

       print("SOUR:SCEN:SENS:REG GYR")
       print(str(inst.write("SOUR:SCEN:SENS:REG GYR")))

       print("***** SOUR:SCEN:SENS:REG? GYR")
       print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))
       str_gyr_reg_status = "%s" %(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

       # Proceed further only if ACC and GYR sensors are both registered with GSG
       if (str_acc_reg_status[0:2] == 'ON' and str_gyr_reg_status[0:2] == 'ON'):
          dt_imu = numpy.double(1)/imu_data_rate

          # Create altitude array (in feet above sea level)
          # altitude_array = [0, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000 ]

          # Create altitude array (in meters above sea level)
          altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

          # Create ambient pressure array (in bar)
          ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]

          ambient_pressure = 0

          fout_imu_10Hz_hil = None
          fout_gps_hil = None

          if (which_10Hz_data_to_save == 'i'):
             fout_imu_10Hz_hil = open(os.path.join(save_folder_path, "GSG_10Hz_IMU.csv"), "w")
             fout_imu_10Hz_hil.write('DATA_START\n')
             fout_imu_10Hz_hil.write('IMU interp loops,Scen Run Time,GPS Week,GPS TOW,X Accel,Y Accel,Z Accel,X Gyro,Y Gyro,Z Gyro,Ambient Pressure\n')
          else: # which_10Hz_data_to_save = 'g'
             fout_gps_hil = open(os.path.join(save_folder_path, "GSG_GPS_and_PRY.csv"), "w")
             fout_gps_hil.write('DATA_START\n')
             fout_gps_hil.write('Run Time,TOW Using Start,TOD Using Start,Lat, Lon, Ht, ECEF_POS_x, ECEF_POS_y, ECEF_POS_z, Heading, Speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, Pitch, Roll, Yaw, Pitch Rate, Roll Rate, Yaw Rate\n')
          # }

          cnt = 0

          str_gyr_acc  = ''
          str_utc = ''

          # str_start_utc = '03-14-2016 10:54:43.0 UTC'
          str_start_utc = "%s" %(str(inst.query("SOUR:SCEN:DATE? UTC")))

          str_runtime = "%s" %(str(inst.query("SOUR:SCEN:RUN?")))
          runtime = numpy.double(str_runtime)

          cntStr = 0
          dateSplitStrings = str_start_utc.split('-')
          for s in dateSplitStrings:
             if (cntStr == 0):
                month = int(s)
             elif (cntStr == 1):
                day = int(s)
             elif (cntStr == 2):
                year = int(s[0:4])
                timeStr = s[5:]
                timeSplitStrings = timeStr.split(':')
                cntTimeStr = 0
                for st in timeSplitStrings:
                   if (cntTimeStr == 0):
                      hr = int(st)
                   elif (cntTimeStr == 1):
                      min = int(st)
                   elif (cntTimeStr == 2):
                      sec = numpy.double(st[0:4])

                   cntTimeStr = cntTimeStr + 1
                # }
             # }
             cntStr = cntStr + 1
          # } for s in dateSplitStrings..

          # Subtract runtime from current UTC time to get the scenario start time (UTC)
          total_sec = 3600 * hr + 60 * min + sec
          total_sec_minus_runtime = total_sec - runtime

          new_hr = int(total_sec_minus_runtime / 3600)
          new_min = int((total_sec_minus_runtime - new_hr * 3600) / 60)
          new_sec = (total_sec_minus_runtime - new_hr * 3600 - new_min * 60) % 60

          # Convert scenario start time (UTC) to scenario start time (GPS)
          (w_start, tow_start, d_start, tod_start) = gpsFromUTC(year, month, day, new_hr, new_min, new_sec)

          # Scenario start Time of Week (TOW) and Time of Day (TOD)
          tow = tow_start
          tod = tod_start

          print(' **************************************************************************************** ')
          print(' **** START GPS VALUES: Week: ' + str(w_start) + ' TOW: ' + str(tow_start) + ' TOD: ' + str(tod_start))
          print(' **************************************************************************************** ')

          imu_data_row_cnt =  0

          runtime = 0

          llh_lat = 0
          llh_lon = 0
          llh_ht = 0

          imu_tow_prev = 0
          runtime_prev = 0
          imu_interp_loops = 0
          packet_process_start_time_10Hz = 0
          packet_process_start_time = 0

          accel_x = 0
          accel_y = 0
          accel_z = 0

          gyro_x = 0
          gyro_y = 0
          gyro_z = 0

          user_input_object = GSG_USER_INPUT()

          #set up background process to accept user input such as pressing Enter key (to exit this script)
          background_user_input = AsyncUserInput(user_input_object, 10000)

          #start the user input thread
          background_user_input.start()

          while(True):
             # Check if user pressed Enter key to stop recording
             if (user_input_object.stop_recording == True):
                break

             if (os.name == 'nt'):                     # Windows
                packet_process_start_time_10Hz = clock()
                packet_process_start_time = clock()
             elif (os.name == 'posix'):                # Ubuntu
                packet_process_start_time_10Hz = time()
                packet_process_start_time = time()

             str_runtime = "%s" %(str(inst.query("SOUR:SCEN:RUN?")))
             runtime = numpy.double(str_runtime)
             tow_using_start = tow_start + runtime
             tod_using_start = tod_start + runtime

             # LLH:
             str_llh = "%s" %(str(inst.query("SOUR:SCEN:POS?")))
             splitStrings = str_llh.split(',')

             cntData = 0
             for st in splitStrings:
                if (cntData == 0):
                   time_LLH = numpy.double(st)
                elif (cntData == 1):
                   llh_lat = numpy.double(st)
                elif (cntData == 2):
                   llh_lon = numpy.double(st)
                   # GSG uses 0 - 360 for Lon; Lord uses +/- 180 deg:
                   if (llh_lon > 180.0):
                      llh_lon = llh_lon - 360.0
                elif (cntData == 3):
                   llh_ht = numpy.double(st)

                cntData = cntData + 1
             # } for .....

             if (which_10Hz_data_to_save == 'i'):
                imu_data_row_cnt = imu_data_row_cnt + 1

                if (imu_data_row_cnt > 1):
                   dt = tow_using_start - imu_tow_prev
                   if (dt > 0):
                      imu_interp_loops = int(dt/dt_imu)   # Interpolation loops based on 500 Hz (0.002 sec) IMU required rate, dt_imu = 0.002
                # }

                str_gyr_acc = "%s" %(str(inst.query("SOUR:SCEN:SENS:DAT?")))
                cntImuLine = 0
                accSplitStrings = str_gyr_acc.splitlines()

                for s in accSplitStrings:
                   if (s == ''):
                     break

                   isGyro = 0
                   if (s[0:3].lower() == 'gyr'):
                      isGyro = 1

                   if (isGyro == 1):
                      startCol = 6
                   else:
                      startCol = 7

                   splitStrings = s[startCol:].split(',')
                   cntInertialStr = 0

                   # GSG sometimes sends some weird values of Gyro data, such as 3600 deg/s, 450 deg/s, -360 deg/s, etc.  The following code
                   # attempts to clean the incoming data of such anomalies.

                   for st in splitStrings:
                      if (isGyro == 1):
                         if (cntInertialStr == 0):
                            orig_gyro_x = math.degrees(numpy.double(st))

                            tmp = int(math.floor(abs(orig_gyro_x)));
                            tmp_rem = tmp % 360
                            tmp_frac = abs(orig_gyro_x) - tmp;

                            # Convert values between 359.0 and 360.0 (and between -359.0 and -360.0) to 0.0.
                            if (tmp_rem == 359):
                               gyro_x = 0.0
                            elif (orig_gyro_x > 0):
                               gyro_x = tmp_rem + tmp_frac;
                            else:
                               gyro_x = -(tmp_rem + tmp_frac);

                            gyro_x = math.radians(gyro_x)

                         elif (cntInertialStr == 1):
                            orig_gyro_y = math.degrees(numpy.double(st))
                            tmp = int(math.floor(abs(orig_gyro_y)));
                            tmp_rem = tmp % 360
                            tmp_frac = abs(orig_gyro_y) - tmp;

                            # Convert values between 359.0 and 360.0 (and between -359.0 and -360.0) to 0.0.
                            if (tmp_rem == 359):
                               gyro_y = 0.0
                            elif (orig_gyro_y > 0):
                               gyro_y = tmp_rem + tmp_frac;
                            else:
                               gyro_y = -(tmp_rem + tmp_frac);

                            gyro_y = math.radians(gyro_y)

                         elif (cntInertialStr == 2):
                            orig_gyro_z = math.degrees(numpy.double(st))
                            tmp = int(math.floor(abs(orig_gyro_z)));
                            tmp_rem = tmp % 360
                            tmp_frac = abs(orig_gyro_z) - tmp;

                            # Convert values between 359.0 and 360.0 (and between -359.0 and -360.0) to 0.0.
                            if (tmp_rem == 359):
                               gyro_z = 0.0
                            elif (orig_gyro_z > 0):
                               gyro_z = tmp_rem + tmp_frac;
                            else:
                               gyro_z = -(tmp_rem + tmp_frac);

                            gyro_z = math.radians(gyro_z)
                         # } if (cntInertialStr == 0)..
                      else:
                         if (cntInertialStr == 0):
                            accel_x = numpy.double(st)
                         elif (cntInertialStr == 1):
                            accel_y = numpy.double(st)
                         elif (cntInertialStr == 2):
                            accel_z = numpy.double(st)
                      # } if (isGyro == 1)..

                      cntInertialStr = cntInertialStr + 1
                   # } for st in splitStrings..

                   cntImuLine = cntImuLine + 1
                # } for s in accSplitStrings..

                if (os.name == 'nt'):
                   packet_process_end_time_acc_gyro_10Hz = clock()    # Windows
                elif (os.name == 'posix'):
                   packet_process_end_time_acc_gyro_10Hz = time()     # Ubuntu

                # print(' ************ str_runtime : ' + str_runtime + ', imu_data_row_cnt: ' + str(imu_data_row_cnt) + ' acc_gyro_time = ' + str(packet_process_end_time_acc_gyro_10Hz - packet_process_start_time_10Hz))

                # Determine ambient pressure from current altitude output by the GSG
                altitude_prev = 0
                altitude = 0
                for altitude_array_index in range(len(altitude_array)):
                   altitude = numpy.int32(altitude_array[altitude_array_index])
                   if (altitude > llh_ht):
                       index_alt_match = altitude_array_index-1
                       altitude_prev = numpy.int32(altitude_array[index_alt_match])
                       break;

                ambient_pressure_prev = ambient_pressure_array[index_alt_match]
                ambient_pressure_next = ambient_pressure_array[index_alt_match+1]

                x = numpy.double(llh_ht - altitude_prev)/(altitude - altitude_prev)
                delta = (ambient_pressure_next - ambient_pressure_prev) * x
                ambient_pressure = ambient_pressure_prev + delta

                fout_imu_10Hz_hil.write('%2d,%10.4f,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(imu_interp_loops, runtime, w_start, tow_using_start, accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z, ambient_pressure * 1000))

                imu_tow_prev = tow_using_start
                runtime_prev = runtime

             elif (which_10Hz_data_to_save == 'g'):

                # ECEF POS:
                str_ecefpos = "%s" %(str(inst.query("SOUR:SCEN:ECEFPOS?")))
                splitStrings = str_ecefpos.split(',')

                cntData = 0
                for st in splitStrings:
                   if (cntData == 0):
                      time_ECEFPos = numpy.double(st)
                   elif (cntData == 1):
                      ecef_pos_x = numpy.double(st)
                   elif (cntData == 2):
                      ecef_pos_y = numpy.double(st)
                   elif (cntData == 3):
                      ecef_pos_z = numpy.double(st)

                   cntData = cntData + 1

                # Heading (GSG definition, meaning angle made by vel vector wrt North, measured clockwise):
                str_heading = "%s" %(str(inst.query("SOUR:SCEN:HEAD?")))
                splitStrings = str_heading.split(',')

                cntData = 0
                heading = 0

                for st in splitStrings:
                   if (cntData == 0):
                      time_heading = numpy.double(st)
                   elif (cntData == 1):
                      heading = numpy.double(st)
                      if (heading < 360.00001 and heading > 359.99999):
                         heading = 0

                   cntData = cntData + 1

                # Speed:
                str_speed = "%s" %(str(inst.query("SOUR:SCEN:SPE?")))
                splitStrings = str_speed.split(',')

                cntData = 0
                for st in splitStrings:
                   if (cntData == 0):
                      time_speed = numpy.double(st)
                   elif (cntData == 1):
                      speed = numpy.double(st)

                   cntData = cntData + 1

                # ENU Vel:
                str_ENUVel = "%s" %(str(inst.query("SOUR:SCEN:ENUVEL?")))
                splitStrings = str_ENUVel.split(',')

                cntData = 0
                for st in splitStrings:
                   if (cntData == 0):
                     time_ENUVel = numpy.double(st)
                   elif (cntData == 1):
                     ENUVel_x = numpy.double(st)
                   elif (cntData == 2):
                     ENUVel_y = numpy.double(st)
                   elif (cntData == 3):
                     ENUVel_z = numpy.double(st)

                   cntData = cntData + 1

                # ECEF Vel:
                str_ECEFVel = "%s" %(str(inst.query("SOUR:SCEN:ECEFVEL?")))
                splitStrings = str_ECEFVel.split(',')

                cntData = 0
                for st in splitStrings:
                   if (cntData == 0):
                     time_ECEFVel = numpy.double(st)
                   elif (cntData == 1):
                     ECEFVel_x = numpy.double(st)
                   elif (cntData == 2):
                     ECEFVel_y = numpy.double(st)
                   elif (cntData == 3):
                     ECEFVel_z = numpy.double(st)

                   cntData = cntData + 1

                # PRY:
                str_PRY = "%s" %(str(inst.query("SOUR:SCEN:PRY?")))
                splitStrings = str_PRY.split(',')

                cntData = 0
                for st in splitStrings:
                   if (cntData == 0):
                     time_PRY = numpy.double(st)
                   elif (cntData == 1):
                     pitch = numpy.double(st)
                   elif (cntData == 2):
                     roll = numpy.double(st)
                   elif (cntData == 3):
                     yaw = numpy.double(st)

                   cntData = cntData + 1

                # PRYR:
                str_PRYR = "%s" %(str(inst.query("SOUR:SCEN:PRYR?")))
                # print('******* str_PRYR : ' + str_PRYR)
                splitStrings = str_PRYR.split(',')

                cntData = 0
                for st in splitStrings:
                   if (cntData == 0):
                     time_PRYR = numpy.double(st)
                   elif (cntData == 1):
                     pitch_rate = numpy.double(st)
                   elif (cntData == 2):
                     roll_rate = numpy.double(st)
                   elif (cntData == 3):
                     yaw_rate = numpy.double(st)

                   cntData = cntData + 1

                fout_gps_hil.write('%10.4f,%10.4f,%10.4f,    %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,                 %14.8f,%14.8f,    %14.8f,%14.8f,%14.8f,          %14.8f,%14.8f,%14.8f,               %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f\n'%(runtime, tow_using_start, tod_using_start, llh_lat, llh_lon, llh_ht, ecef_pos_x, ecef_pos_y, ecef_pos_z, heading, speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, pitch, roll, yaw, pitch_rate, roll_rate, yaw_rate))
             # } if (save_10Hz_imu_to_file == 'y')..

             if (os.name == 'nt'):
                packet_process_end_time = clock()  # Windows
             elif (os.name == 'posix'):
                packet_process_end_time = time()   # Ubuntu

             deltaT = packet_process_end_time - packet_process_start_time

             # Sleep only for the remainder of the 10 ms time step (after deducting the time taken to save data to file)
             # Note: Sleep call itself needs about 0.1 millisec (= 0.0001 sec), so use (0.1 - 0.0001) = 0.0999 sec (instead of 0.1 sec) as 10Hz time available
             if (deltaT < 0.0999):
                 sleep(0.0999 - deltaT)
             # }

             cnt = cnt + 1

             if (os.name == 'nt'):
                packet_process_end_time_10Hz = clock()  # Windows
             elif (os.name == 'posix'):
                packet_process_end_time_10Hz = time()   # Ubuntu

             deltaT_10Hz = packet_process_end_time_10Hz - packet_process_start_time_10Hz
             # print(' ************ str_runtime : ' + str_runtime + ', imu_data_row_cnt: ' + str(imu_data_row_cnt) + ', imu_interp_loops: ' + str(imu_interp_loops) + ', sum_deltaT = ' + str(sum_deltaT) + ', sum_deltaT_500Hz = ' + str(sum_deltaT_500Hz) + ', deltaT_10Hz = ' + str(deltaT_10Hz))

             # Force all IVI SCPI calls to be called at next 0.1 sec (100 ms) epoch [not used because it doesn't seem to work properly. Instead we use Python's sleep() function]:
             # inst.query("*OPC?")

          # } while(True)..

          if (which_10Hz_data_to_save == 'i'):
             fout_imu_10Hz_hil.close()
          elif (which_10Hz_data_to_save == 'g'):
             fout_gps_hil.close()

          # Stop background user input thread
          background_user_input.stop()

          # Stop the scenario
          inst.write("SOUR:SCEN:CONT stop")

       else:
          print(' *********** COULD NOT REGISTER ACCEL AND GYRO SENSORS WITH GSG, EXITING....')
       # } if (str_acc_reg_status[0:2] == 'ON' and..
    # } if (scenario_started == True)..

if(__name__ == "__main__"):
  main_line(sys.argv)

