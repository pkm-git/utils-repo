import visa
import numpy
from gpstime import *

from time import sleep           #sleep
from time import time  #import time library

rm = visa.ResourceManager()

# inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

# print(' ********* inst.query: ' + str(inst.query("*IDN?")))
# print(' ********* query SOUR:SCEN:SENS:DAT? ')

print("****** SOUR:SCEN:CONT?")
print(str(inst.query("SOUR:SCEN:CONT?")))

str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

print(' ********* RESPONSE: ' + str_scen_running)

if (str_scen_running[0:5] == 'START'):

   print("SOUR:SCEN:SENS:REG ACC")
   print(str(inst.write("SOUR:SCEN:SENS:REG ACC")))

   print("SOUR:SCEN:SENS:REG? ACC")
   print(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

   print("****** BEFORE: SOUR:SCEN:SENS:REG? GYR")
   print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

   print("SOUR:SCEN:SENS:REG GYR")
   print(str(inst.write("SOUR:SCEN:SENS:REG GYR")))

   print("***** AFTER: SOUR:SCEN:SENS:REG? GYR")
   print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

   # print(' ********* query SOUR:SCEN:SENS:DAT? ')
   # print(str(inst.query("SOUR:SCEN:SENS:DAT?")))

   # Create a file to log the IMU data that was supplied as input to the HIL
   fout_imu_hil = open("U:/Lord/GSG GNSS Simulator/GSG_IMU_HIL_Input.csv", "w")

   # fout_imu_hil.write('GPS Week, GPS TOW, TOD, UTC Year, UTC Month, UTC Day, UTC Hr, UTC Min, UTC Sec, Accel_x, Accel_y, Accel_z, Gyro_x (deg/s), Gyro_y (deg/s), Gyro_z (deg/s), Lat, Lon, Ht, ECEF_POS_x, ECEF_POS_y, ECEF_POS_z, Heading, Speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, Pitch (deg), Roll (deg), Yaw (deg), Pitch Rate (deg/s), Roll Rate (deg/s), Yaw Rate (deg/s)\n')
   # fout_imu_hil.write('Run Time,TOW Using Start,TOD Using Start,GPS Week, GPS TOW, TOD, UTC Year, UTC Month, UTC Day, UTC Hr, UTC Min, UTC Sec, Accel_x, Accel_y, Accel_z, Mag Accel, Orig_Gyro_x (deg/s), Gyro_x (deg/s), Orig_Gyro_y (deg/s),Gyro_y (deg/s), Orig_Gyro_z (deg/s), Gyro_z (deg/s), Lat, Lon, Ht, ECEF_POS_x, ECEF_POS_y, ECEF_POS_z, Heading, Speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, Pitch (deg), Roll (deg), Yaw (deg), Pitch Rate (deg/s), Roll Rate (deg/s), Yaw Rate (deg/s)\n')
   fout_imu_hil.write('Run Time,TOW Using Start,TOD Using Start,Accel_x, Accel_y, Accel_z, Orig_Gyro_x (deg/s), Gyro_x (deg/s), Orig_Gyro_y (deg/s),Gyro_y (deg/s), Orig_Gyro_z (deg/s), Gyro_z (deg/s)\n')

   cnt = 0

   str_gyr_acc  = ''
   str_utc = ''

   # 02-25-2016 13:35:33.8 UTC
   # str_start_utc = '02-25-2016 13:33:00.0 UTC'
   str_start_utc = '02-25-2016 13:32:43.0 UTC'

   cntStr = 0
   dateSplitStrings = str_start_utc.split('-')
   for s in dateSplitStrings:
       # print(' ***** cntStr: ' + str(cntStr) + ', s = ' + s)
       if (cntStr == 0):
           month = int(s)
       elif (cntStr == 1):
           day = int(s)
       elif (cntStr == 2):
           year = int(s[0:4])
           timeStr = s[5:]
           timeSplitStrings = timeStr.split(':')
           cntTimeStr = 0
           for st in timeSplitStrings:
               if (cntTimeStr == 0):
                   hr = int(st)
               elif (cntTimeStr == 1):
                   min = int(st)
               elif (cntTimeStr == 2):
                   sec = numpy.double(st[0:4])

               cntTimeStr = cntTimeStr + 1

       cntStr = cntStr + 1

   # print(' ***** cnt: ' + str(cnt) + ', day = ' + str(day) + ', month: ' + str(month) + ', year: ' + str(year) + ', hr: ' + str(hr) + ', min: ' + str(min) + ', sec: ' + str(sec))

   (w_start, tow_start, d_start, tod_start) = gpsFromUTC(year, month, day, hr, min, sec)

   tow = tow_start
   tod = tod_start

   print(' **************************************************************************************** ')
   print(' **** START GPS VALUES: Week: ' + str(w_start) + ' TOW: ' + str(tow_start) + ' TOD: ' + str(tod_start))
   print(' **************************************************************************************** ')

   if (1):
     # while(cnt < 15):
     while(cnt < 100):
       # print(str(inst.query("SOUR:SCEN:SENS:DAT?")))
       # print(str(inst.query("SOUR:SCEN:DATE? UTC")))

       str_runtime = "%s" %(str(inst.query("SOUR:SCEN:RUN?")))
       # print('******* str_runtime : ' + str_runtime)
       runtime = numpy.double(str_runtime)
       tow_using_start = tow_start + runtime
       tod_using_start = tod_start + runtime

       if (0):
          str_utc = "%s" %(str(inst.query("SOUR:SCEN:DATE? UTC")))
          # print('******* str_utc : ' + str_utc)

          # 02-25-2016 13:35:33.8 UTC
          cntStr = 0
          dateSplitStrings = str_utc.split('-')
          for s in dateSplitStrings:
              # print(' ***** cntStr: ' + str(cntStr) + ', s = ' + s)
              if (cntStr == 0):
                  month = int(s)
              elif (cntStr == 1):
                  day = int(s)
              elif (cntStr == 2):
                  year = int(s[0:4])
                  timeStr = s[5:]
                  timeSplitStrings = timeStr.split(':')
                  cntTimeStr = 0
                  for st in timeSplitStrings:
                      if (cntTimeStr == 0):
                          hr = int(st)
                      elif (cntTimeStr == 1):
                          min = int(st)
                      elif (cntTimeStr == 2):
                          sec = numpy.double(st[0:4])

                      cntTimeStr = cntTimeStr + 1

              cntStr = cntStr + 1

          # print(' ***** cnt: ' + str(cnt) + ', day = ' + str(day) + ', month: ' + str(month) + ', year: ' + str(year) + ', hr: ' + str(hr) + ', min: ' + str(min) + ', sec: ' + str(sec))

          (w, tow, d, tod) = gpsFromUTC(year, month, day, hr, min, sec)
          # print(' **** RETURNED GPS VALUES: Week: ' + str(w) + ' TOW: ' + str(tow) + ' TOD: ' + str(tod))


       # str_gyr_acc = inst.query("SOUR:SCEN:SENS:DAT")
       # Accel: 0.427415, -0.0817233, -0.900354
       # Gyro: 0.0174533, 0.00523599, 0.00349066

       str_gyr_acc = "%s" %(str(inst.query("SOUR:SCEN:SENS:DAT?")))
       # print('******* str_gyr_acc : ' + str_gyr_acc)
       cntImuLine = 0
       accSplitStrings = str_gyr_acc.splitlines()
       for s in accSplitStrings:
           if (s == ''):
             break

           # print(' ***** cntImuLine: ' + str(cntImuLine) + ', s = ' + s)

           isGyro = 0
           if (s[0:3].lower() == 'gyr'):
              isGyro = 1

           if (isGyro == 1):
              startCol = 6
           else:
              startCol = 7
        
           splitStrings = s[startCol:].split(',')
        
           cntInertialStr = 0
           for st in splitStrings:
              # print('****** cntImuLine = ' + str(cntImuLine) + ', s = ' + s + ', st = ' + st + ' isGyro = ' + str(isGyro))
              # if (cntImuLine == 0):
              if (isGyro == 1):
                  if (cntInertialStr == 0):
                      orig_gyro_x = math.degrees(numpy.double(st))
                
                      tmp = int(math.floor(abs(orig_gyro_x)));
                      tmp_rem = tmp % 360
                      tmp_frac = abs(orig_gyro_x) - tmp;

                      if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
                        gyro_x = 0.0
                      elif (orig_gyro_x > 0):
                        gyro_x = tmp_rem + tmp_frac;
                      else:
                        gyro_x = -(tmp_rem + tmp_frac);
                  elif (cntInertialStr == 1):
                      orig_gyro_y = math.degrees(numpy.double(st))
                      tmp = int(math.floor(abs(orig_gyro_y)));
                      tmp_rem = tmp % 360
                      tmp_frac = abs(orig_gyro_y) - tmp;

                      if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
                        gyro_y = 0.0
                      elif (orig_gyro_y > 0):
                        gyro_y = tmp_rem + tmp_frac;
                      else:
                        gyro_y = -(tmp_rem + tmp_frac);
                  elif (cntInertialStr == 2):
                      orig_gyro_z = math.degrees(numpy.double(st))
                      tmp = int(math.floor(abs(orig_gyro_z)));
                      tmp_rem = tmp % 360
                      tmp_frac = abs(orig_gyro_z) - tmp;

                      if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
                        gyro_z = 0.0
                      elif (orig_gyro_z > 0):
                        gyro_z = tmp_rem + tmp_frac;
                      else:
                        gyro_z = -(tmp_rem + tmp_frac);
              else:
                  if (cntInertialStr == 0):
                      accel_x = numpy.double(st)
                  elif (cntInertialStr == 1):
                      accel_y = numpy.double(st)
                  elif (cntInertialStr == 2):
                      accel_z = numpy.double(st)

              cntInertialStr = cntInertialStr + 1

           cntImuLine = cntImuLine + 1

       if (0):
          # LLH:
          # print("***** SOUR:SCEN:POS?")
          # print(str(inst.query("SOUR:SCEN:POS?")))

          str_llh = "%s" %(str(inst.query("SOUR:SCEN:POS?")))
          # print('******* str_llh : ' + str_llh)
          splitStrings = str_llh.split(',')

          cntData = 0
          for st in splitStrings:
             if (cntData == 0):
                time_LLH = numpy.double(st)
             elif (cntData == 1):
                llh_lat = numpy.double(st)
             elif (cntData == 2):
                llh_lon = numpy.double(st)
                if (llh_lon > 270.0):
                   llh_lon = llh_lon - 360.0
             elif (cntData == 3):
                llh_ht = numpy.double(st)
        
             cntData = cntData + 1

          # ECEF POS:
          # print("***** SOUR:SCEN:ECEFPOS?")
          # print(str(inst.query("SOUR:SCEN:ECEFPOS?")))

          str_ecefpos = "%s" %(str(inst.query("SOUR:SCEN:ECEFPOS?")))
          # print('******* str_ecefpos : ' + str_ecefpos)
          splitStrings = str_ecefpos.split(',')

          cntData = 0
          for st in splitStrings:
             if (cntData == 0):
                time_ECEFPos = numpy.double(st)
             elif (cntData == 1):
                ecef_pos_x = numpy.double(st)
             elif (cntData == 2):
                ecef_pos_y = numpy.double(st)
             elif (cntData == 3):
                ecef_pos_z = numpy.double(st)
        
             cntData = cntData + 1

          # Heading:
          # print("***** SOUR:SCEN:HEAD?")
          # print(str(inst.query("SOUR:SCEN:HEAD?")))

          str_heading = "%s" %(str(inst.query("SOUR:SCEN:HEAD?")))
          # print('******* str_heading : ' + str_heading)
          splitStrings = str_heading.split(',')

          cntData = 0
          heading = 0

          for st in splitStrings:
             if (cntData == 0):
                time_heading = numpy.double(st)
             elif (cntData == 1):
                heading = numpy.double(st)
                if (heading < 360.00001 and heading > 359.99999):
                   heading = 0
        
             cntData = cntData + 1

          # Speed:
          # print("***** SOUR:SCEN:SPE?")
          # print(str(inst.query("SOUR:SCEN:SPE?")))

          str_speed = "%s" %(str(inst.query("SOUR:SCEN:SPE?")))
          # print('******* str_speed : ' + str_speed)
          splitStrings = str_speed.split(',')

          cntData = 0
          for st in splitStrings:
             if (cntData == 0):
                time_speed = numpy.double(st)
             elif (cntData == 1):
                speed = numpy.double(st)
        
             cntData = cntData + 1

          # ENU Vel:
          # print("***** SOUR:SCEN:ENUVEL?")
          # print(str(inst.query("SOUR:SCEN:ENUVEL?")))

          str_ENUVel = "%s" %(str(inst.query("SOUR:SCEN:ENUVEL?")))
          # print('******* str_ENUVel : ' + str_ENUVel)
          splitStrings = str_ENUVel.split(',')

          cntData = 0
          for st in splitStrings:
            if (cntData == 0):
              time_ENUVel = numpy.double(st)
            elif (cntData == 1):
              ENUVel_x = numpy.double(st)
            elif (cntData == 2):
              ENUVel_y = numpy.double(st)
            elif (cntData == 3):
              ENUVel_z = numpy.double(st)
        
            cntData = cntData + 1

          # ECEF Vel:
          # print("***** SOUR:SCEN:ECEFVEL?")
          # print(str(inst.query("SOUR:SCEN:ECEFVEL?")))

          str_ECEFVel = "%s" %(str(inst.query("SOUR:SCEN:ECEFVEL?")))
          # print('******* str_ECEFVel : ' + str_ECEFVel)
          splitStrings = str_ECEFVel.split(',')

          cntData = 0
          for st in splitStrings:
            if (cntData == 0):
              time_ECEFVel = numpy.double(st)
            elif (cntData == 1):
              ECEFVel_x = numpy.double(st)
            elif (cntData == 2):
              ECEFVel_y = numpy.double(st)
            elif (cntData == 3):
              ECEFVel_z = numpy.double(st)
        
            cntData = cntData + 1

          # print("***** SOUR:SCEN:PRY?")
          # print(str(inst.query("SOUR:SCEN:PRY?")))

          # print("***** SOUR:SCEN:DPRY?")
          # print(str(inst.query("SOUR:SCEN:DPRY?")))

          str_PRY = "%s" %(str(inst.query("SOUR:SCEN:PRY?")))
          # print('******* str_PRY : ' + str_PRY)
          splitStrings = str_PRY.split(',')

          cntData = 0
          for st in splitStrings:
            if (cntData == 0):
              time_PRY = numpy.double(st)
            elif (cntData == 1):
              pitch = numpy.double(st)
            elif (cntData == 2):
              roll = numpy.double(st)
            elif (cntData == 3):
              yaw = numpy.double(st)
        
            cntData = cntData + 1

          # print("***** SOUR:SCEN:PRYR?")
          # print(str(inst.query("SOUR:SCEN:PRYR?")))

          str_PRYR = "%s" %(str(inst.query("SOUR:SCEN:PRYR?")))
          # print('******* str_PRYR : ' + str_PRYR)
          splitStrings = str_PRYR.split(',')

          cntData = 0
          for st in splitStrings:
            if (cntData == 0):
              time_PRYR = numpy.double(st)
            elif (cntData == 1):
              pitch_rate = numpy.double(st)
            elif (cntData == 2):
              roll_rate = numpy.double(st)
            elif (cntData == 3):
              yaw_rate = numpy.double(st)
        
            cntData = cntData + 1

       # fout_imu_hil.write('%4d,%10.4f,%10.4f,    %4d,%2d,%2d,%2d,%2d,%10.4f,              %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,                         %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,                 %14.8f,%14.8f,    %14.8f,%14.8f,%14.8f,          %14.8f,%14.8f,%14.8f,               %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f\n'%(w, tow, tod, year, month, day, hr, min, sec, accel_x, accel_y, accel_z, gyro_x, gyro_y, gyro_z, llh_lat, llh_lon, llh_ht, ecef_pos_x, ecef_pos_y, ecef_pos_z, heading, speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, math.degrees(pitch), math.degrees(roll), math.degrees(yaw), pitch_rate, roll_rate, yaw_rate))
       # fout_imu_hil.write('%4d,%10.4f,%10.4f,    %4d,%2d,%2d,%2d,%2d,%10.4f,              %14.8f,%14.8f,%14.8f,%14.8f,   %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,                 %14.8f,%14.8f,    %14.8f,%14.8f,%14.8f,          %14.8f,%14.8f,%14.8f,               %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f\n'%(w_start, tow, tod, year, month, day, hr, min, sec, accel_x, accel_y, accel_z, math.sqrt(accel_x**2 + accel_y**2 + accel_z**2), orig_gyro_x, gyro_x, orig_gyro_y, gyro_y, orig_gyro_z, gyro_z, llh_lat, llh_lon, llh_ht, ecef_pos_x, ecef_pos_y, ecef_pos_z, heading, speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, math.degrees(pitch), math.degrees(roll), math.degrees(yaw), math.degrees(pitch_rate), math.degrees(roll_rate), math.degrees(yaw_rate)))
       # fout_imu_hil.write('%10.4f,%10.4f,%10.4f,%4d,%10.4f,%10.4f,    %4d,%2d,%2d,%2d,%2d,%10.4f,              %14.8f,%14.8f,%14.8f,%14.8f,   %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f,                 %14.8f,%14.8f,    %14.8f,%14.8f,%14.8f,          %14.8f,%14.8f,%14.8f,               %14.8f,%14.8f,%14.8f,      %14.8f,%14.8f,%14.8f\n'%(runtime, tow_using_start, tod_using_start, w_start, tow, tod, year, month, day, hr, min, sec, accel_x, accel_y, accel_z, math.sqrt(accel_x**2 + accel_y**2 + accel_z**2), orig_gyro_x, gyro_x, orig_gyro_y, gyro_y, orig_gyro_z, gyro_z, llh_lat, llh_lon, llh_ht, ecef_pos_x, ecef_pos_y, ecef_pos_z, heading, speed, ENUVel_x, ENUVel_y, ENUVel_z, ECEFVel_x, ECEFVel_y, ECEFVel_z, math.degrees(pitch), math.degrees(roll), math.degrees(yaw), math.degrees(pitch_rate), math.degrees(roll_rate), math.degrees(yaw_rate)))
       fout_imu_hil.write('%10.4f,%10.4f,%10.4f,  %14.8f,%14.8f,%14.8f,       %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(runtime, tow_using_start, tod_using_start, accel_x, accel_y, accel_z, orig_gyro_x, gyro_x, orig_gyro_y, gyro_y, orig_gyro_z, gyro_z))
                          # %4d %10.4f %10.4f    %4d   %2d   %2d   %2d   %2d  %10.4f      %14.8f   %14.8f   %14.8f     %14.8f  %14.8f  %14.8f                          %14.8f  %14.8f  %14.8f     %14.8f  %14.8f  %14.8f                %14.8f  %14.8f    %14.8f  %14.8f  %14.8f         %14.8f  %14.8f  %14.8f              %14.8f  %14.8f  %14.8f     %14.8f  %14.8f  %14.8f

                          #  w, tow, tod,        year, month, day, hr, min, sec,          accel_x, accel_y, accel_z,   orig_gyro_x, gyro_x, orig_gyro_y, gyro_y, orig_gyro_z, gyro_z,  llh_lat, llh_lon, llh_ht,  ecef_pos_x, ecef_pos_y, ecef_pos_z,   heading, speed,   ENUVel_x, ENUVel_y, ENUVel_z,  ECEFVel_x, ECEFVel_y, ECEFVel_z,    pitch, roll, yaw,          pitch_rate, roll_rate, yaw_rate

       if (0):
          print("***** SOUR:SCEN:DPRYR?")
          print(str(inst.query("SOUR:SCEN:DPRYR?")))

          print("***** SOUR:SCEN:ACC?")
          print(str(inst.query("SOUR:SCEN:ACC?")))

          print("***** SOUR:SCEN:ENUACC?")
          print(str(inst.query("SOUR:SCEN:ENUACC?")))

          print("***** SOUR:SCEN:ECEFACC?")
          print(str(inst.query("SOUR:SCEN:ECEFACC?")))

       cnt = cnt + 1
       # sleep(0.1)

       # Force a wait of 0.1 sec (100 ms) before next loop (to get data at 10 Hz):
       inst.query("*OPC?")

# ********* query SOUR:SCEN:SENS:DAT?
# Accel: 0.427415, -0.0817233, -0.900354
# Gyro: 0.0174533, 0.00523599, 0.00349066

# ********* query: SOUR:SCEN:DATE?
# 02-25-2016 13:34:01.7 GPS

# ********* query: SOUR:SCEN:DATE? UTC
# 02-25-2016 13:33:44.7 UTC

   fout_imu_hil.close()

else:
   print(' *********** No scenario running ***********')

