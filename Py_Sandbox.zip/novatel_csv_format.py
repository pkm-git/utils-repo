NOVATEL_CSV_FORMAT_UNINITIALIZED               = 0

class Novatel_CSV_format(object):

 #default 'constructor'
 def __init__(self):
    """Class default initialization function"""
    try:
       self.init()
    except:
       self.state = NOVATEL_CSV_FORMAT_UNINITIALIZED

 #class initializer function
 def init(self):
    """Class initialization function"""

    [self.gps_week, self.gps_tow, self.message_length, self.message_type, self.imu_status, self.ins_status] = [0,0,0,0,0,0]
    [self.ins_lat, self.ins_lon, self.ins_ht_abv_ellip] = [0,0,0]
    [self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation] = [0,0,0,0]
    [self.ins_vned_N, self.ins_vned_E, self.ins_vned_D] = [0,0,0]
    [self.ekf_latency, self.diff_age, self.ins_horiz_speed, self.ins_vert_speed, self.ins_grnd_trc] = [0,0,0,0,0]
    [self.ekf_horiz_speed, self.ekf_vert_speed, self.ekf_grnd_trc] = [0,0,0]
    [self.p_sol_status, self.pos_type, self.ecef_pos_x, self.ecef_pos_y, self.ecef_pos_z, self.ecef_pos_x_sd, self.ecef_pos_y_sd, self.ecef_pos_z_sd, v_sol_status, vel_type, self.ecef_vel_x, self.ecef_vel_y, self.ecef_vel_z, self.ecef_vel_x_sd, self.ecef_vel_y_sd, self.ecef_vel_z_sd, self.vel_time_latency] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    [self.roll, self.pitch, self.azimuth] = [0,0,0]
    [self.x_accel, self.y_accel, self.z_accel] = [0,0,0]
    [self.x_gyro, self.y_gyro, self.z_gyro] = [0,0,0]
    [self.rcvr_clock_status, self.rcvr_clock_offset, self.rcvr_clock_offset_sd, self.utc_offset, self.utc_year, self.utc_month, self.utc_day, self.utc_hour, self.utc_min, self.utc_ms, self.utc_status] = [0,0,0,0,0,0,0,0,0,0,0]
    [self.x_veh2body_angle, self.y_veh2body_angle, self.z_veh2body_angle, self.x_veh2body_angle_unc, self.y_veh2body_angle_unc, self.z_veh2body_angle_unc] = [0,0,0,0,0,0]

 # } def init(self)..

 # Master Format (subset of 'important' or 'min' columns from DCP, in a 'master sequence'):
 # GPS Week,GPS TOW,     INS Lat [321],INS Lon [321],INS Ht Abv Ellips [321],   EKF Lat [42],EKF Lon [42],EKF Ht Abv MSL [42],Undulation [42],    Vel N [324],Vel E [324],Vel D [324],   INS Horiz Speed [323],INS Vert Speed [323],INS Grnd Trc [323],  EKF Latency[99], EKF Diff Age[99],EKF Horiz Speed [99],EKF Vert Speed [99],EKF Grnd Trc [99],   Pos Soln Status [241],Pos Type [241],ECEF Pos X[241],ECEF Pos Y[241],ECEF Pos Z[241],ECEF Pos X Sigma[241],ECEF Pos Y Sigma [241],ECEF Pos Z Sigma [241],Vel Soln Status [241],Vel Type [241],ECEF Vel X[241],ECEF Vel Y[241],ECEF Vel Z[241],ECEF Vel X Sigma[241],ECEF Vel Y Sigma[241],ECEF Vel Z Sigma[241],Vel Time Latency[241],   Roll [319],Pitch [319],Azimuth [319],    X_Accel [325],Y_Accel [325],Z_Accel [325],X_Gyro [325],Y_Gyro [325],Z_Gyro [325]
 # %4d,%12.4f,           %14.8f,%14.8f,%14.8f,                                  %14.8f,%14.8f,%14.8f,%14.8f,                                      %14.8f,%14.8f,%14.8f,                  %14.8f,%14.8f,%14.8f,                                           %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                             %4d,%4d,%14.8f,14.8f,14.8f,14.8f,14.8f,14.8f,4d,4d,14.8f,14.8f,14.8f,14.8f,14.8f,14.8f,14.8f,                                                                                                                                                                                                                                            %14.8f,%14.8f,%14.8f,                    %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f
 # gps_week, gps_tow,    ins_lat, ins_lon, ins_ht_abv_ellip,                    ekf_lat, ekf_lon, ekf_ht_abv_MSL, undulation,                     ins_vned_N, ins_vned_E, ins_vned_D,    ins_horiz_speed, ins_vert_speed, ins_grnd_trc                   ekf_latency, diff_age, ekf_horiz_speed, ekf_vert_speed, ekf_grnd_trc                            p_sol_status, self.pos_type, self.ecef_pos_x, self.ecef_pos_y, self.ecef_pos_z, self.ecef_pos_x_sd, self.ecef_pos_y_sd, self.ecef_pos_z_sd, self.v_sol_status, self.vel_type, self.ecef_vel_x, self.ecef_vel_y, self.ecef_vel_z, self.ecef_vel_x_sd, self.ecef_vel_y_sd, self.ecef_vel_z_sd, self.vel_time_latency                       roll,pitch,azimuth,                      x_accel,y_accel,z_accel,x_gyro,y_gyro,z_gyro

 # 'Master Sequence' Message ID's:
 # min_gps_default_cols_dict = {321:1, 42:2, 324:3, 323:4, 99:5, 241:6, 319:7, 508:8, 325:9, 101:10, 642:11}
 # min_gps_default_long2shorthdr_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

 def format(self, format_in, out_file_type = None):
    if (format_in == 0):
       if (out_file_type != None):
          if (out_file_type.lower() == 'i'):
             return '{:-4d},{:-12.4f},{:-4d},'.format(self.gps_week, self.gps_tow, self.ins_status)
          elif (out_file_type.lower() == 'r'):
             return '{:-4d},{:-12.4f},{:-4d},'.format(self.gps_week, self.gps_tow, self.imu_status)
          else:
             return '{:-4d},{:-12.4f},'.format(self.gps_week, self.gps_tow)
       else:
          return '{:-4d},{:-12.4f},'.format(self.gps_week, self.gps_tow)
    elif (format_in == 1):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_lat, self.ins_lon, self.ins_ht_abv_ellip)
    elif (format_in == 2):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation)
    elif (format_in == 3):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_vned_N, self.ins_vned_E, self.ins_vned_D)
    elif (format_in == 4):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_horiz_speed, self.ins_vert_speed, self.ins_grnd_trc)
    elif (format_in == 5):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ekf_latency, self.diff_age, self.ekf_horiz_speed, self.ekf_vert_speed, self.ekf_grnd_trc)
    elif (format_in == 6):
       return '{:-4d},{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.p_sol_status, self.pos_type, self.ecef_pos_x, self.ecef_pos_y, self.ecef_pos_z, self.ecef_pos_x_sd, self.ecef_pos_y_sd, self.ecef_pos_z_sd, self.v_sol_status, self.vel_type, self.ecef_vel_x, self.ecef_vel_y, self.ecef_vel_z, self.ecef_vel_x_sd, self.ecef_vel_y_sd, self.ecef_vel_z_sd, self.vel_time_latency)
    elif (format_in == 7):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.roll, self.pitch, self.azimuth)
    elif (format_in == 8):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_pva_lat, self.ins_pva_lon, self.ins_pva_ht_abv_ellips, self.ins_pva_vned_N, self.ins_pva_vned_E, self.ins_pva_vned_D, self.ins_pva_roll, self.ins_pva_pitch, self.ins_pva_azimuth)
    elif (format_in == 9):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.x_accel, self.y_accel, self.z_accel, self.x_gyro, self.y_gyro, self.z_gyro)
    elif (format_in == 10):
       return '{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},{:-2d},{:-2d},{:-2d},{:-2d},{:-4d},{:-4d},'.format(self.rcvr_clock_status, self.rcvr_clock_offset, self.rcvr_clock_offset_sd, self.utc_offset, self.utc_year, self.utc_month, self.utc_day, self.utc_hour, self.utc_min, self.utc_ms, self.utc_status)
    elif (format_in == 11):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.x_veh2body_angle, self.y_veh2body_angle, self.z_veh2body_angle, self.x_veh2body_angle_unc, self.y_veh2body_angle_unc, self.z_veh2body_angle_unc)

    return 'Novatel_GPS_format'

 # } def format(self, format_in)..

 def format_header(self, format_in, out_file_type = None):
    if (format_in == 0):
       if (out_file_type != None):
          if (out_file_type.lower() == 'i'):
             return 'INS_Week,INS_TOW,INS_Status,'
          elif (out_file_type.lower() == 'e'):
             return 'EKF_Week,EKF_TOW,'
          elif (out_file_type.lower() == 'r'):
             return 'RAWIMU_Week,RAWIMU_TOW,IMU_Status,'
          else:
             return 'GPS_Week,GPS_TOW,'
       else:
          return 'GPS_Week,GPS_TOW,'
    elif (format_in == 1):
       return 'INS Lat [321/265],INS Lon [321/265],INS Height Abv Ellips [321/265],'
    elif (format_in == 2):
       return 'EKF Lat [42],EKF Lon [42],EKF Height Abv MSL [42],Undulation[42],'
    elif (format_in == 3):
       return 'Vel N [324/267],Vel E [324/267],Vel D [324/267],'
    elif (format_in == 4):
       return 'INS Horiz Speed [323/266],INS Vert Speed [323/266],INS Grnd Trc [323/266],'
    elif (format_in == 5):
       return 'EKF Latency [99],EKF Diff Age [99],EKF Horiz Speed [99],EKF Vert Speed [99],EKF Grnd Trc [99],'
    elif (format_in == 6):
       return 'Pos Soln Status [241],Pos Type [241],ECEF Pos X[241],ECEF Pos Y[241],ECEF Pos Z[241],ECEF Pos X Sigma[241],ECEF Pos Y Sigma [241],ECEF Pos Z Sigma [241],Vel Soln Status [241],Vel Type [241],ECEF Vel X[241],ECEF Vel Y[241],ECEF Vel Z[241],ECEF Vel X Sigma[241],ECEF Vel Y Sigma[241],ECEF Vel Z Sigma[241],Vel Time Latency[241],'
    elif (format_in == 7):
       return 'Roll [319/263],Pitch [319/263],Azimuth [319/263],'
    elif (format_in == 8):
       return 'INS_PVA_Lat [508/507], INS_PVA_Lon [508/507], INS_PVA_Ht_abv_ellips [508/507], INS_PVA_vned_N [508/507], INS_PVA_vned_E [508/507], INS_PVA_vned_D [508/507], INS_PVA_roll [508/507], INS_PVA_pitch [508/507], INS_PVA_azimuth [508/507],'
    elif (format_in == 9):
       return 'DeltaV_X [325/268],DeltaV_Y [325/268],DeltaV_Z [325/268],DeltaTheta_X [325/268],DeltaTheta_Y [325/268],DeltaTheta_Z [325/268],'
    elif (format_in == 10):
       return 'Rcvr Clock Status [101], Rcvr Clock Offset [101], Rcvr Clock Offset SD [101], UTC_Offset [101], UTC_Year [101], UTC_Month [101], UTC_Day [101], UTC_Hour [101], UTC_Min [101], UTC_TOW_ms [101], UTC_status [101],'
    elif (format_in == 11):
       return 'X_Veh2Body_Angle [642],Y_Veh2Body_Angle [642],Z_Veh2Body_Angle [642],X_Veh2Body_Angle_Unc [642],Y_Veh2Body_Angle_Unc [642],Z_Veh2Body_Angle_Unc [642],'

    return 'Novatel_GPS_format_header'

 # } def format_header(self, format_in)..

 def format_channel_name(self, format_in, out_file_type = None):
    if (format_in == 0):
       if (out_file_type == None or out_file_type.lower() == 'g'):
          return ['GPS_Week','GPS_TOW']
       elif (out_file_type.lower() == 'i'):
          return ['INS_Week','INS_TOW','INS_Status']
       elif (out_file_type.lower() == 'e'):
          return ['EKF_Week','EKF_TOW']
       elif (out_file_type.lower() == 'r'):
          return ['RAWIMU_Week','RAWIMU_TOW','IMU_Status']
    elif (format_in == 1):
       return ['INS_Lat_321_265','INS_Lon_321_265','INS_Height_Abv_Ellips_321_265']
    elif (format_in == 2):
       return ['EKF_Lat_42','EKF_Lon_42','EKF_Height_Abv_MSL_42','Undulation42']
    elif (format_in == 3):
       return ['Vel_N_324_267','Vel_E_324_267','Vel_D_324_267']
    elif (format_in == 4):
       return ['INS_Horiz_Speed_323_266','INS_Vert_Speed_323_266','INS_Grnd_Trc_323_266']
    elif (format_in == 5):
       return ['EKF_Latency_99','EKF_Diff_Age_99','EKF_Horiz_Speed_99','EKF_Vert_Speed_99','EKF_Grnd_Trc_99']
    elif (format_in == 6):
       return ['Pos_Soln_Status_241','Pos_Type_241','ECEF_Pos_X241','ECEF_Pos_Y241','ECEF_Pos_Z241','ECEF_Pos_X_Sigma241','ECEF_Pos_Y_Sigma_241','ECEF_Pos_Z_Sigma_241','Vel_Soln_Status_241','Vel_Type_241','ECEF_Vel_X241','ECEF_Vel_Y241','ECEF_Vel_Z241','ECEF_Vel_X_Sigma241','ECEF_Vel_Y_Sigma241','ECEF_Vel_Z_Sigma241','Vel_Time_Latency241']
    elif (format_in == 7):
       return ['Roll_319_263','Pitch_319_263','Azimuth_319_263']
    elif (format_in == 8):
       return ['INS_PVA_Lat_508_507','INS_PVA_Lon_508_507','INS_PVA_Ht_abv_ellips_508_507','INS_PVA_vned_N_508_507','INS_PVA_vned_E_508_507','INS_PVA_vned_D_508_507','INS_PVA_roll_508_507','INS_PVA_pitch_508_507','INS_PVA_azimuth_508_507']
    elif (format_in == 9):
       return ['DeltaV_X_325_268','DeltaV_Y_325_268','DeltaV_Z_325_268','DeltaTheta_X_325_268','DeltaTheta_Y_325_268','DeltaTheta_Z_325_268']
    elif (format_in == 10):
       return ['Rcvr_Clock_Status_101','Rcvr_Clock_Offset_101','Rcvr_Clock_Offset_SD_101','UTC_Offset_101','UTC_Year_101','UTC_Month_101','UTC_Day_101','UTC_Hour_101','UTC_Min_101','UTC_TOW_ms_101','UTC_status_101']
    elif (format_in == 11):
       return ['X_Veh2Body_Angle_642','Y_Veh2Body_Angle_642','Z_Veh2Body_Angle_642','X_Veh2Body_Angle_Unc_642','Y_Veh2Body_Angle_Unc_642','Z_Veh2Body_Angle_Unc_642']

    return []

 def format_channel_value(self, format_in, out_file_type = None):
    if (format_in == 0):
       if (out_file_type != None):
          if (out_file_type.lower() == 'i'):
             return [self.gps_week, self.gps_tow, self.ins_status]
          elif (out_file_type.lower() == 'r'):
             return [self.gps_week, self.gps_tow, self.imu_status]
          else:
             return [self.gps_week, self.gps_tow]
       else:
          return [self.gps_week, self.gps_tow]
    elif (format_in == 1):
       return [self.ins_lat, self.ins_lon, self.ins_ht_abv_ellip]
    elif (format_in == 2):
       return [self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation]
    elif (format_in == 3):
       return [self.ins_vned_N, self.ins_vned_E, self.ins_vned_D]
    elif (format_in == 4):
       return [self.ins_horiz_speed, self.ins_vert_speed, self.ins_grnd_trc]
    elif (format_in == 5):
       return [self.ekf_latency, self.diff_age, self.ekf_horiz_speed, self.ekf_vert_speed, self.ekf_grnd_trc]
    elif (format_in == 6):
       return [self.p_sol_status, self.pos_type, self.ecef_pos_x, self.ecef_pos_y, self.ecef_pos_z, self.ecef_pos_x_sd, self.ecef_pos_y_sd, self.ecef_pos_z_sd, self.v_sol_status, self.vel_type, self.ecef_vel_x, self.ecef_vel_y, self.ecef_vel_z, self.ecef_vel_x_sd, self.ecef_vel_y_sd, self.ecef_vel_z_sd, self.vel_time_latency]
    elif (format_in == 7):
       return [self.roll, self.pitch, self.azimuth]
    elif (format_in == 8):
       return [self.ins_pva_lat, self.ins_pva_lon, self.ins_pva_ht_abv_ellips, self.ins_pva_vned_N, self.ins_pva_vned_E, self.ins_pva_vned_D, self.ins_pva_roll, self.ins_pva_pitch, self.ins_pva_azimuth]
    elif (format_in == 9):
       return [self.x_accel, self.y_accel, self.z_accel, self.x_gyro, self.y_gyro, self.z_gyro]
    elif (format_in == 10):
       return [self.rcvr_clock_status, self.rcvr_clock_offset, self.rcvr_clock_offset_sd, self.utc_offset, self.utc_year, self.utc_month, self.utc_day, self.utc_hour, self.utc_min, self.utc_ms, self.utc_status]
    elif (format_in == 11):
       return [self.x_veh2body_angle, self.y_veh2body_angle, self.z_veh2body_angle, self.x_veh2body_angle_unc, self.y_veh2body_angle_unc, self.z_veh2body_angle_unc]

    return []

