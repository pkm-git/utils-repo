# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

GPS_FORMAT_DICT_UNINITIALIZED = 0

class GPS_8109_struct:
   def __init__(self):
      [self.gps_tow, self.gps_week, self.flags_81_09] = [0,0,0]

class GPS_8103_struct:
   def __init__(self):
      [self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc, self.flags_81_03] = [0,0,0,0,0,0,0]

class GPS_8105_struct:
   def __init__(self):
      [self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc, self.flags_81_05] = [0,0,0,0,0,0,0,0,0]

class GPS_8104_struct:
   def __init__(self):
      [self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC, self.flags_81_04] = [0,0,0,0,0]

class GPS_8106_struct:
   def __init__(self):
      [self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC, self.flags_81_06] = [0,0,0,0,0]

class GPS_810B_struct:
   def __init__(self):
      [self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags, self.flags_81_0b] = [0,0,0,0]

class GPS_810A_struct:
   def __init__(self):
      [self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate, self.flags_81_0a] = [0,0,0,0]

class GPS_810D_struct:
   def __init__(self):
      [self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power, self.flags_81_0d] = [0,0,0,0]

class GPS_8107_struct:
   def __init__(self):
      [self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop, self.flags_81_07] = [0,0,0,0,0,0,0,0]

class GPS_8108_struct:
   def __init__(self):
      [self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec, self.utc_msec, self.flags_81_08] = [0,0,0,0,0,0,0,0]

class GPS_810C_struct:
   def __init__(self):
      [self.channel_nbr, self.sv_id, self.carrier_to_noise_ratio, self.azimuth, self.elevation, self.sv_flags, self.valid_flags_81_0c] = [0,0,0,0,0,0,0]

# Define "Master columns" (i.e. all available columns in DCP) in a "master sequence"
gps_default_cols_seq_array = ["8109", "8103", "8105", "8104", "8106", "810B", "810A", "810D", "8107", "8108", "810C"]

class GPS_format_using_dict(object):

 #default 'constructor'
 def __init__(self, gps_format_dict = None, visible_channel_nbr_array = None):
    """Class default initialization function"""
    try:
       self.init(gps_format_dict, visible_channel_nbr_array)
    except:
       self.state = GPS_FORMAT_DICT_UNINITIALIZED

 #class initializer function
 def init(self, gps_format_dict, visible_channel_nbr_array):
    """Class initialization function"""

    [self.gps_8109_struct, self.gps_8103_struct, self.gps_8105_struct, self.gps_8104_struct, self.gps_8106_struct] = [None, None, None, None, None]
    [self.gps_810B_struct, self.gps_810A_struct, self.gps_810D_struct, self.gps_8107_struct, self.gps_8108_struct, self.gps_810C_dict] = [None, None, None, None, None, None]

    self.visible_channel_nbr_array = visible_channel_nbr_array

    if (self.visible_channel_nbr_array != None):
       self.channel_nbr_array_to_use = self.visible_channel_nbr_array
    else:
       self.channel_nbr_array_to_use = range(32)
    # } if (self.visible_channel_nbr_array != None)..

    if (gps_format_dict != None):
       for k in gps_default_cols_seq_array:
          if (k in gps_format_dict):
             if (k == "8109"):
                self.gps_8109_struct = gps_format_dict[k]
             elif (k == "8103"):
                self.gps_8103_struct = gps_format_dict[k]
             elif (k == "8105"):
                self.gps_8105_struct = gps_format_dict[k]
             elif (k == "8104"):
                self.gps_8104_struct = gps_format_dict[k]
             elif (k == "8106"):
                self.gps_8106_struct = gps_format_dict[k]
             elif (k == "810B"):
                self.gps_810B_struct = gps_format_dict[k]
             elif (k == "810A"):
                self.gps_810A_struct = gps_format_dict[k]
             elif (k == "810D"):
                self.gps_810D_struct = gps_format_dict[k]
             elif (k == "8107"):
                self.gps_8107_struct = gps_format_dict[k]
             elif (k == "8108"):
                self.gps_8108_struct = gps_format_dict[k]
             elif (k == "810C"):
                self.gps_810C_dict = gps_format_dict[k]
             # } if (k == "8109")..
          # } if (k in gps_format_dict)..
       # } for k in gps_default_cols_seq_array..
    # } if (gps_format_dict != None)..

 def setVisibleChannelNbrArray(self, visible_channel_nbr_array):
    self.visible_channel_nbr_array = visible_channel_nbr_array

 def format_header(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       ret_str = 'GPS TFlags,GPS Week,GPS TOW,'
    elif (format_in == 1):
       ret_str = 'Lat [x8103],Lon [x8103],Ht Abv Ellips [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],'
    elif (format_in == 2):
       ret_str = 'Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],'
    elif (format_in == 3):
       ret_str = 'ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Pos Acc [x8104],Flags [x8104],'
    elif (format_in == 4):
       ret_str = 'ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],'
    elif (format_in == 5):
       ret_str = 'GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B],'
    elif (format_in == 6):
       ret_str = 'Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],Flags [x810A],'
    elif (format_in == 7):
       ret_str = 'HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D],'
    elif (format_in == 8):
       ret_str = 'Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],'
    elif (format_in == 9):
       ret_str = 'UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],'
    elif (format_in == 10):
       for k in self.channel_nbr_array_to_use:
          ret_str += 'Channel Nbr ' + str(k) + ' [x810C],SV ID ' + str(k) + ' [x810C],C/N Ratio ' + str(k) + ' [x810C],Azimuth ' + str(k) + ' [x810C],Elevation ' + str(k) + ' [x810C],SV Flags ' + str(k) + ' [x810C],Valid Flags ' + str(k) + ' [x810C],'
       # } for k in range(self.channel_nbr_array_to_use)..
    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 # Master Format (all available columns from DCP, in a 'master sequence'):
 # GPS TFlags,GPS Week,GPS TOW,     Lat [x8103],Lon [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],      Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],   ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],       ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],     GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B]    Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],Flags [x810A],    HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D]                            Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],  UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],    Channel Nbr [x810C],SV ID [x810C],C/N Ratio [x810C],Azimuth [x810C],Elevation [x810C],SV Flags [x810C],Valid Flags [x810C] [Repeat for 'n' satellites]
 # %d,%4d,%12.4f,                   %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                   %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                      %14.8f,%14.8f,%14.8f,%14.8f,%d,                                                    %14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                  %d,%d,%d,%d                                                                 %14.8f,%14.8f,%14.8f,%d,                                                   %d,%d,%d,%d,                                                                                           %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                       %4d,%d,%d,%d,%d,%d,%d,%d,                                                                                                                           %d,%d,%2d,%2d,%2d,%2d,%2d,
 # flags_81_09,gps_week, gps_tow,   gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03,                   gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05,                         gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04,      gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06,                    gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b               gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a,      gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d,     geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07,                                                  utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08,                                                                           sv.channel_nbr, sv.sv_id, sv.carrier_to_noise_ratio, sv.azimuth, sv.elevation, sv.sv_flags, sv.valid_flags_81_0c

 def format(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       if (self.gps_8109_struct != None):
          ret_str = '{:-2d},{:-2d},{:-12.4f},'.format(self.gps_8109_struct.flags_81_09, self.gps_8109_struct.gps_week, self.gps_8109_struct.gps_tow)
       else:
          ret_str = ',,,'
    elif (format_in == 1):
       if (self.gps_8103_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_8103_struct.gps_lat, self.gps_8103_struct.gps_lon, self.gps_8103_struct.gps_ht_abv_ellip, self.gps_8103_struct.gps_ht_abv_MSL, self.gps_8103_struct.gps_horiz_acc, self.gps_8103_struct.gps_vert_acc, self.gps_8103_struct.flags_81_03)
       else:
          ret_str = ',,,,,,,'
    elif (format_in == 2):
       if (self.gps_8105_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_8105_struct.gps_vned_N, self.gps_8105_struct.gps_vned_E, self.gps_8105_struct.gps_vned_D, self.gps_8105_struct.gps_speed, self.gps_8105_struct.gps_grnd_speed, self.gps_8105_struct.gps_heading, self.gps_8105_struct.gps_speed_acc, self.gps_8105_struct.gps_heading_acc, self.gps_8105_struct.flags_81_05)
       else:
          ret_str = ',,,,,,,,,'
    elif (format_in == 3):
       if (self.gps_8104_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_8104_struct.gps_pos_ecef_x, self.gps_8104_struct.gps_pos_ecef_y, self.gps_8104_struct.gps_pos_ecef_z, self.gps_8104_struct.gps_pos_ecef_UC, self.gps_8104_struct.flags_81_04)
       else:
          ret_str = ',,,,,'
    elif (format_in == 4):
       if (self.gps_8106_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_8106_struct.gps_vel_ecef_x, self.gps_8106_struct.gps_vel_ecef_y, self.gps_8106_struct.gps_vel_ecef_z, self.gps_8106_struct.gps_vel_ecef_UC, self.gps_8106_struct.flags_81_06)
       else:
          ret_str = ',,,,,'
    elif (format_in == 5):
       if (self.gps_810B_struct != None):
          ret_str = '{:-d},{:-d},{:-d},{:-d},'.format(self.gps_810B_struct.gps_fix_type, self.gps_810B_struct.gps_nbr_of_svs_used, self.gps_810B_struct.gps_fix_flags, self.gps_810B_struct.flags_81_0b)
       else:
          ret_str = ',,,,'
    elif (format_in == 6):
       if (self.gps_810A_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_810A_struct.gps_clock_bias, self.gps_810A_struct.gps_clock_drift, self.gps_810A_struct.gps_clock_acc_estimate, self.gps_810A_struct.flags_81_0a)
       else:
          ret_str = ',,,,'
    elif (format_in == 7):
       if (self.gps_810D_struct != None):
          ret_str = '{:-d},{:-d},{:-d},{:-d},'.format(self.gps_810D_struct.gps_hw_status_sensor_state, self.gps_810D_struct.gps_hw_status_antenna_state, self.gps_810D_struct.gps_hw_status_antenna_power, self.gps_810D_struct.flags_81_0d)
       else:
          ret_str = ',,,,'
    elif (format_in == 8):
       if (self.gps_8107_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_8107_struct.geom_dop, self.gps_8107_struct.pos_dop, self.gps_8107_struct.horiz_dop, self.gps_8107_struct.vert_dop, self.gps_8107_struct.time_dop, self.gps_8107_struct.northing_dop, self.gps_8107_struct.easting_dop, self.gps_8107_struct.flags_81_07)
       else:
          ret_str = ',,,,,,,,'
    elif (format_in == 9):
       if (self.gps_8108_struct != None):
          ret_str = '{:-4d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},'.format(self.gps_8108_struct.utc_yr, self.gps_8108_struct.utc_mo, self.gps_8108_struct.utc_day, self.gps_8108_struct.utc_hr, self.gps_8108_struct.utc_min, self.gps_8108_struct.utc_sec, self.gps_8108_struct.utc_msec, self.gps_8108_struct.flags_81_08)
       else:
          ret_str = ',,,,,,,,'
    elif (format_in == 10):
       for k in self.channel_nbr_array_to_use:
          if (self.gps_810C_dict != None and k in self.gps_810C_dict.keys()):
             tmp_gps_810C_struct = self.gps_810C_dict[k]
             ret_str += '{:-d},{:-d},{:-2d},{:-2d},{:-2d},{:-2d},{:-2d},'.format(tmp_gps_810C_struct.channel_nbr, tmp_gps_810C_struct.sv_id, tmp_gps_810C_struct.carrier_to_noise_ratio, tmp_gps_810C_struct.azimuth, tmp_gps_810C_struct.elevation, tmp_gps_810C_struct.sv_flags, tmp_gps_810C_struct.valid_flags_81_0c)
          else:
             ret_str += ',,,,,,,'
          # } if (self.gps_810C_dict != None and k in self.gps_810C_dict.keys())..
       # } for k in self.channel_nbr_array_to_use..
    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format_channel_name(self, format_in):
    if (format_in == 0):
       return ['GPS_TFlags', 'GPS_Week', 'GPS_TOW']
    elif (format_in == 1):
       return ['Lat_x8103', 'Lon_x8103', 'Ht_Abv_Ellips_x8103', 'MSL_Height_x8103', 'Horz_Acc_x8103', 'Vert_Acc_x8103', 'Flags_x8103']
    elif (format_in == 2):
       return ['Vel_N_x8105', 'Vel_E_x8105', 'Vel_D_x8105', 'Speed_x8105', 'Gnd_Speed_x8105', 'Heading_x8105', 'Speed_Acc_x8105', 'Heading_Acc_x8105', 'Flags_x8105']
    elif (format_in == 3):
       return ['ECEF_X_x8104', 'ECEF_Y_x8104', 'ECEF_Z_x8104', 'ECEF_Acc_x8104', 'Flags_x8104']
    elif (format_in == 4):
       return ['ECEF_Vel_X_x8106', 'ECEF_Vel_Y_x8106', 'ECEF_Vel_Z_x8106', 'ECEF_Vel_Acc_x8106', 'Flags_x8106']
    elif (format_in == 5):
       return ['GPS_Fix_x810B','GPS_SVs_Used_x810B','GPS_Fix_Flags_x810B','Flags_x810B']
    elif (format_in == 6):
       return ['Clock_Bias_x810A','Clock_Drift_x810A','Clock_Acc_x810A','Flags_x810A']
    elif (format_in == 7):
       return ['HW_Sensor_Stat_x810D','HW_Ant_Stat_x810D','HW_Ant_Pwr_x810D','Flags_x810D']
    elif (format_in == 8):
       return ['Geo_DOP_x8107','Pos_DOP_x8107','Hor_DOP_x8107','Vert_DOP_x8107','Time_DOP_x8107','Northing_DOP_x8107','Easting_DOP_x8107','Flags_x8107']
    elif (format_in == 9):
       return ['UTC_Year_x8108', 'UTC_Month_x8108', 'UTC_Day_x8108', 'UTC_Hour_x8108', 'UTC_Minute_x8108', 'UTC_Second_x8108', 'UTC_Millisecond_x8108', 'Flags_x8108']
    elif (format_in == 10):
       channel_name_array_per_sv = ['Channel_Nbr_x810C', 'SV_ID_x810C', 'C_N_Ratio_x810C', 'Azimuth_x810C', 'Elevation_x810C', 'SV_Flags_x810C', 'Valid_Flags_x810C']
       ret_channel_name_array = []

       for k in self.channel_nbr_array_to_use:
          for channel_name in channel_name_array_per_sv:
             ret_channel_name_array.append(channel_name + '_' + str(int(k)))
          # } for channel_name in channel_name_array_per_sv..
       # } for k in range(self.channel_nbr_array_to_use)..
       
       return ret_channel_name_array

    return []

 def format_channel_value(self, format_in):
    if (format_in == 0):
       if (self.gps_8109_struct != None):
          return [self.gps_8109_struct.flags_81_09, self.gps_8109_struct.gps_week, self.gps_8109_struct.gps_tow]
       else:
          return None
    elif (format_in == 1):
       if (self.gps_8103_struct != None):
          return [self.gps_8103_struct.gps_lat, self.gps_8103_struct.gps_lon, self.gps_8103_struct.gps_ht_abv_ellip, self.gps_8103_struct.gps_ht_abv_MSL, self.gps_8103_struct.gps_horiz_acc, self.gps_8103_struct.gps_vert_acc, self.gps_8103_struct.flags_81_03]
       else:
          return None
    elif (format_in == 2):
       if (self.gps_8105_struct != None):
          return [self.gps_8105_struct.gps_vned_N, self.gps_8105_struct.gps_vned_E, self.gps_8105_struct.gps_vned_D, self.gps_8105_struct.gps_speed, self.gps_8105_struct.gps_grnd_speed, self.gps_8105_struct.gps_heading, self.gps_8105_struct.gps_speed_acc, self.gps_8105_struct.gps_heading_acc, self.gps_8105_struct.flags_81_05]
       else:
          return None
    elif (format_in == 3):
       if (self.gps_8104_struct != None):
          return [self.gps_8104_struct.gps_pos_ecef_x, self.gps_8104_struct.gps_pos_ecef_y, self.gps_8104_struct.gps_pos_ecef_z, self.gps_8104_struct.gps_pos_ecef_UC, self.gps_8104_struct.flags_81_04]
       else:
          return None
    elif (format_in == 4):
       if (self.gps_8106_struct != None):
          return [self.gps_8106_struct.gps_vel_ecef_x, self.gps_8106_struct.gps_vel_ecef_y, self.gps_8106_struct.gps_vel_ecef_z, self.gps_8106_struct.gps_vel_ecef_UC, self.gps_8106_struct.flags_81_06]
       else:
          return None
    elif (format_in == 5):
       if (self.gps_810B_struct != None):
          return [self.gps_810B_struct.gps_fix_type, self.gps_810B_struct.gps_nbr_of_svs_used, self.gps_810B_struct.gps_fix_flags, self.gps_810B_struct.flags_81_0b]
       else:
          return None
    elif (format_in == 6):
       if (self.gps_810A_struct != None):
          return [self.gps_810A_struct.gps_clock_bias, self.gps_810A_struct.gps_clock_drift, self.gps_810A_struct.gps_clock_acc_estimate, self.gps_810A_struct.flags_81_0a]
       else:
          return None
    elif (format_in == 7):
       if (self.gps_810D_struct != None):
          return [self.gps_810D_struct.gps_hw_status_sensor_state, self.gps_810D_struct.gps_hw_status_antenna_state, self.gps_810D_struct.gps_hw_status_antenna_power, self.gps_810D_struct.flags_81_0d]
       else:
          return None
    elif (format_in == 8):
       if (self.gps_8107_struct != None):
          return [self.gps_8107_struct.geom_dop, self.gps_8107_struct.pos_dop, self.gps_8107_struct.horiz_dop, self.gps_8107_struct.vert_dop, self.gps_8107_struct.time_dop, self.gps_8107_struct.northing_dop, self.gps_8107_struct.easting_dop, self.gps_8107_struct.flags_81_07]
       else:
          return None
    elif (format_in == 9):
       if (self.gps_8108_struct != None):
          return [self.gps_8108_struct.utc_yr, self.gps_8108_struct.utc_mo, self.gps_8108_struct.utc_day, self.gps_8108_struct.utc_hr, self.gps_8108_struct.utc_min, self.gps_8108_struct.utc_sec, self.gps_8108_struct.utc_msec, self.gps_8108_struct.flags_81_08]
       else:
          return None
    elif (format_in == 10):
       ret_array = []
       pos_inf = float("+inf")
      
       for k in self.channel_nbr_array_to_use:
          if (self.gps_810C_dict != None and k in self.gps_810C_dict.keys()):
             tmp_gps_810C_struct = self.gps_810C_dict[k]
             ret_array.extend([tmp_gps_810C_struct.channel_nbr, tmp_gps_810C_struct.sv_id, tmp_gps_810C_struct.carrier_to_noise_ratio, tmp_gps_810C_struct.azimuth, tmp_gps_810C_struct.elevation, tmp_gps_810C_struct.sv_flags, tmp_gps_810C_struct.valid_flags_81_0c])
          else:
             ret_array.extend([pos_inf, pos_inf, pos_inf, pos_inf, pos_inf, pos_inf, pos_inf])
          # } if (self.gps_810C_dict != None and k in self.gps_810C_dict.keys())..
       # } for k in range(self.channel_nbr_array_to_use)..

       return ret_array

    return []
