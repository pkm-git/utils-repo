from ublx import *

from binascii import hexlify

packet_data = bytearray.fromhex('2A895F')

ublxp = ublx_create_ublx_message(0x01, 0x02, 3, packet_data)

print "************ BEFORE finalize, len(ublxp) = " + str(len(ublxp))

print "Ublox Packet [2:len(ublxp)] BEFORE finalize: " + hexlify(ublxp[2:len(ublxp)]).upper()

#finalize packet
ublx_finalize(ublxp)

print "Ublox Packet after finalize: " + hexlify(ublxp).upper()

print "************ AFTER finalize, len(ublxp) = " + str(len(ublxp))



