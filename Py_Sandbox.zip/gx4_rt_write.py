#import libraries used
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_rt_usb_parse_thread import AsyncRTDataParser #Asynchronous RealTime (RT)
                                                        #data parsing thread

MIP_SYNC_BYTE1 = 0x75
MIP_SYNC_BYTE2 = 0x65

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM4'
port_baud = 115200

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-p' and len(argv) > i+1):
  port_name = argv[i+1]
 elif(argv[i] == '-b' and len(argv) > i+1):
  port_baud = int(argv[i+1])

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name, port_baud)

#Close port in case it was left open by other process
port.close()

#generate command bytearrays

#Set up rt packet response parser
# rt_parser = RTParser(10000, 0, rt_parser_callback)

rt_port_name = 'COM4'
#port_baud = 230400
# rt_port_baud = 115200
rt_port_baud = 921600

#Assign serial port object
rt_port = serial.Serial(rt_port_name, rt_port_baud)

#Close port in case it was left open by other process
# rt_port.close()

#open specified port
# rt_port.open()
# rt_port.flushInput()
# rt_port.flushOutput()

# test_packet = bytearray.fromhex('7565800E0E047565800E0E047565800E0E047565800E0E047565800E0E047565800E0E047565800E0E047565800E0E047565800E0E047565800E0E04')
# test_packet = bytearray.fromhex('7565800E0E04')

# background_data_update = AsyncRTDataParser(rt_port, 10000)

#start the response parsing thread
# background_data_update.start()

# rt_port.write(test_packet)
# rt_port.flush()

#sleep while waiting for response
sleep(0.003)

# out = ''

packet_data = bytearray([])

#k = 1
while rt_port.inWaiting() > 0:
  # out += rt_port.read(1)
  byte_reply = bytearray(rt_port.read(rt_port.inWaiting()))
  print('********************** byte_reply: ' + hexlify(bytearray(byte_reply)).upper())
  packet_data.extend(bytearray(byte_reply));
  # print('********* while loop, k = ' + str(k) + ', out = ' + out)
  # k = k + 1

print('********************** Packet: ' + hexlify(bytearray(packet_data)).upper())
        
# if out != '':  # loop over
#   print ">>" + out
                        
# print('********************** Packet written: ' + hexlify(bytearray(out)).upper())

#stop background response parsing thread
# background_data_update.stop()

#close port
rt_port.close()

