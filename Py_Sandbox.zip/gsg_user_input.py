GSG_USER_INPUT_UNINITIALIZED               = 0

class GSG_USER_INPUT(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = GSG_USER_INPUT_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""
   
   self.start_streaming = False
   self.stop_streaming = False
   self.recording_on = False


