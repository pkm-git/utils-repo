import sys
import platform

print('********* sys.maxsize method: ')
is_64bits = sys.maxsize > 2**32
print(' ********** is_64bits: ' + str(is_64bits))

print('********* platform.architecture method: ')
print(platform.architecture()[0])
#'32bit'
