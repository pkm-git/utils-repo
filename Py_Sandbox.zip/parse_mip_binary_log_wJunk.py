import sys
import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder

from time import sleep           #sleep
from time import time  #import time library

from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

from struct import * #import all objects and functions from the struct library

import numpy

def print_usage_message():
 """Output usage instructions"""

 print("usage: python parse_mip_binary_log.py -i input_file_name -d descriptor_string\n")
 print("input_file_name\t\t-- the name of the input file including the path")
 print("descriptor_string\t-- hex character string representing a series of descriptor-set/field-descriptor pairs (e.g. 800480058006)")

def main_line(argv):
 """Main line program"""

 # initialize command line arguments
 in_file_name = None

 # fin_bin = open("U:\\Lord\\Python_HIL_Sim_From_File\\Vehicle_Logs\\10_01_2015\\RTSIM\\GX4-45\\2015_11_12\\3DM-GX4-45 6236.46589 Data Log 11-12-2015 4.46.23 PM.bin", "rb")

 # fout_imu = open("U:\\Lord\\Python_HIL_Sim_From_File\\Vehicle_Logs\\10_01_2015\\RTSIM\\GX4-45\\2015_11_12\\GX4-45_Veh_IMU_Log_wHeaders_11-12-2015 4.46.23 PM_None.csv", "w")
 # fout_gps = open("U:\\Lord\\Python_HIL_Sim_From_File\\Vehicle_Logs\\10_01_2015\\RTSIM\\GX4-45\\2015_11_12\\GX4-45_Veh_GPS_Log_wHeaders_11-12-2015 4.46.23 PM_None.csv", "w")
 # fout_ekf = open("U:\\Lord\\Python_HIL_Sim_From_File\\Vehicle_Logs\\10_01_2015\\RTSIM\\GX4-45\\2015_11_12\\GX4-45_Veh_EKF_Log_wHeaders_11-12-2015 4.46.23 PM_None.csv", "w")

 in_file_name = None

 if (argv != None):
   # parse command line arguements
   for i in range(len(argv)):
     # assign specified filenames
     if(argv[i] == '-i' and len(argv) > i+1):
      in_file_name = argv[i+1]
     elif(argv[i] == '-d' and len(argv) > i+1):
      #is this only 1 descriptor?
      if(len(argv[i+1]) == 4):
       #split up the 2 bytes into DS and FD
       output_descriptors.append((bytearray.fromhex(argv[i+1])[0], \
                                  bytearray.fromhex(argv[i+1])[1]))
      #is this more than one descriptor?
      elif(len(argv[i+1]) % 4 == 0 and len(argv[i+1]) > 0):
       #loop over the specified bytes
       for j in range(0,len(argv[i+1]),4):
        output_descriptors.append((bytearray.fromhex(argv[i+1][j:j+4])[0], \
                                   bytearray.fromhex(argv[i+1][j:j+4])[1]))
      #is this a badly specified descriptor list?
      else:
       output_descriptors = []

 # if command line arguments were not properly specified tell the user and exit
 if(in_file_name == None):
   print_usage_message()
   sys.exit()

 fin_bin = open(in_file_name, "rb")

 fout_imu = open("IMU_Log.csv", "w")
 fout_gps = open("GPS_Log.csv", "w")
 fout_ekf = open("EKF_Log.csv", "w")

 fout_imu.write('GPS Week,GPS TOW,GPS TFlags,X Accel [x8004],Y Accel [x8004],Z Accel [x8004],X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],X Mag [x8006],Y Mag [x8006],Z Mag [x8006],Pressure [x8017]\n')
 fout_gps.write('GPS Week,GPS TOW,GPS TFlags,UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],Clock Bias [x810A],Clock Drift [x810A],Clock Acc,Flags [x810A],HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D],GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B]\n')
 fout_ekf.write('GPS Week,GPS TOW,GPS TFlags,EKF State [x8210],EKF Mode [x8210],Flags [x8210],Lat [x8201],Long [x8201],Height [x8201],Flags [x8201],LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],WGS84 Gravity [x820F],Flags [x820F],True North [x8214],North UC [x8214],Head Src [x8214],Flags [x8214],WMM N [x8215],WMM E [x8215],WMM D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],Pressure Alt [x8221],Flags [x8221],X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231]\n')

 start_time = time()

 print('\n------------------------------------------------------------------')
 print(' ************* Parse MIP Binary Log: start_time = ' + str(start_time) );

 k_start = 0

 # bytes_read = bytearray([])

 bytes_read = fin_bin.read();

 print(' ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

 for k in range(0, len(bytes_read)):
    if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
       print(' ***** Found first 7565 pair at k = ' + str(k))
       k_start = k;
       break;

 # for k in range(k_start,len(bytes_read)):

 # print(' ************ k_start = ' + str(k_start) )

 [ekf_state, ekf_mode, flags_82_10] = [0,0,0]
 [ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01] = [0,0,0,0]
 [ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08] = [0,0,0,0]
 [ekf_ned_vel_x, ekf_ned_vel_y, ekf_ned_vel_z, flags_82_02] = [0,0,0,0]
 [ekf_ned_vel_UC_x, ekf_ned_vel_UC_y, ekf_ned_vel_UC_z, flags_82_09] = [0,0,0,0]
 [euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05] = [0,0,0,0]
 [euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a] = [0,0,0,0]
 [quat_0, quat_1, quat_2, quat_3, flags_82_03] = [0,0,0,0,0]
 [quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12] = [0,0,0,0,0]
 [accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07] = [0,0,0,0]
 [accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c] = [0,0,0,0]
 [accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17] = [0,0,0,0]
 [accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19] = [0,0,0,0]
 [gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06] = [0,0,0,0]
 [gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b] = [0,0,0,0]
 [gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16] = [0,0,0,0]
 [gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18] = [0,0,0,0]
 [lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d] = [0,0,0,0]
 [comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c] = [0,0,0,0]
 [comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e] = [0,0,0,0]
 [grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13] = [0,0,0,0]
 [grav_mag, flags_82_0f] = [0,0]
 [heading, heading_UC, heading_source, flags_82_14] = [0,0,0,0]
 [inten_N, inten_E, inten_D, inclination, declination, flags_82_15] = [0,0,0,0,0,0]
 [pressure_altitude, flags_82_21] = [0,0]
 [geom_alt, geopot_alt, temp, pressure, density, flags_82_20] = [0,0,0,0,0,0]
 [gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30] = [0,0,0,0]
 [gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31] = [0,0,0,0]

 [gps_tow, gps_week, flags_81_09] = [0,0,0]
 [utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08] = [0,0,0,0,0,0,0,0]
 [gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03] = [0,0,0,0,0,0,0]
 [gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05] = [0,0,0,0,0,0,0,0,0]
 [gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04] = [0,0,0,0,0]
 [gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06] = [0,0,0,0,0]
 [gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b] = [0,0,0,0]
 [gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a] = [0,0,0,0]
 [gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d] = [0,0,0,0]
 [geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07] = [0,0,0,0,0,0,0,0]

 [imu_tow, imu_week, flags_80_12] = [0,0,0]
 [scaled_accel_x, scaled_accel_y, scaled_accel_z] = [0,0,0]
 [scaled_gyro_x, scaled_gyro_y, scaled_gyro_z] = [0,0,0]
 [delta_theta_roll, delta_theta_pitch, delta_theta_yaw] = [0,0,0]
 [delta_vel_x, delta_vel_y, delta_vel_z] = [0,0,0]
 [ambient_pr] = [0]
 [mag_x, mag_y, mag_z] = [0,0,0]

 """
 Multi line comment
 """
 i = 0
 packet_size = 0
 bad_packets = 0
 k = k_start

 found_imu = False
 found_gps = False
 found_ekf = False

 output_EKF = False

 ekf_packet_cnt = 0
 found_timestamp_ekf_packet_1 = False
 found_timestamp_ekf_packet_2 = False

 # Look for beginning of a valid packet (Bytes: 0x7565):
 while (k < len(bytes_read) and i < 15):

   if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
      # # packet_size = numpy.int32(hexlify( bytearray(bytes_read[k+3]) ) );
      # packet_size = numpy.int32(bytes_read[k+3]);

      # print('\n------------------------------------------------------------------')
      # print(' ********** hexlify( bytearray(bytes_read[k+3]) ) = ' + hexlify( bytearray(bytes_read[k+3]) ) + ' and packet size = ' + str(numpy.int32( bytearray(bytes_read[k+3])) ))

      packet_size = numpy.int32( bytearray(bytes_read[k+3]))

      print(' ************ Packet bytes: ' + hexlify(bytearray( bytes_read[k:k+packet_size] )) )
      print(' ************ Start 2 bytes of next packet: (' + hexlify( bytearray( bytes_read[k+packet_size+6] ) ) + ', ' + hexlify( bytearray( bytes_read[k+packet_size+7] )) + ')' )

      # Check for valid packet by looking at first 2 bytes of next packet:
      # if (hexlify(bytearray(bytes_read[k+packet_size+6])) == '75' and hexlify(bytearray(bytes_read[k+packet_size+7])) == '65'):
      packet_bytes = bytearray( bytes_read[k:k+packet_size+6] )

      print(' ************** Descriptor Set = ' + hexlify( bytearray(bytes_read[k+2]) ) )

      desc_set = hexlify( bytearray(bytes_read[k+2]) )

      k_field_start = 4

      # Check if it is EKF packet with no timestamp (when user selects several EKF fields, the output gets distributed in 2 separate EKF packets, one of them containing the timestamp):

      if (desc_set == '82'):
         ekf_packet_cnt = ekf_packet_cnt + 1
         j = k+k_field_start

         while(j < k+packet_size+4):
           field_size = numpy.int32( bytearray(bytes_read[j:j+1]))
           field_desc = hexlify( bytearray(bytes_read[j+1:j+2]) )
           if (field_desc == '11'):
              if (ekf_packet_cnt == 1):
                 found_timestamp_ekf_packet_1 = True
              else:
                 found_timestamp_ekf_packet_2 = True
                
           j = j + field_size

         # Reset ekf_packet_cnt to 0 for next pair of EKF packets
         if (ekf_packet_cnt == 2):
           # Exclude EKF packet pairs that both contain a timestamp, otherwise print output for EKF:
           if ((found_timestamp_ekf_packet_1 == True and found_timestamp_ekf_packet_2 == False) or (found_timestamp_ekf_packet_1 == False and found_timestamp_ekf_packet_2 == True) ):
              output_EKF = True
           ekf_packet_cnt = 0
        
      # Reset back to read from beginning of the field packet

      j = k+k_field_start

      while(j < k+packet_size+4):
        field_size = numpy.int32( bytearray(bytes_read[j:j+1]))
        field_bytes = bytes_read[j+2:j+field_size]
        field_desc = hexlify( bytearray(bytes_read[j+1:j+2]) )

        print(' ********** j = ' + str(j) + ' Field size = ' + str(field_size) + ', field_desc = ' + hexlify( bytearray(bytes_read[j+1:j+2]) ) + ' and field_bytes = ' + hexlify( bytearray(field_bytes) )   )

        if (desc_set == '82'):
           found_ekf = True
           if (field_desc == '11'):
              [ekf_tow, ekf_week, flags_82_11] = unpack('>dHH', bytearray(field_bytes) )
           elif (field_desc == '10'):
              [ekf_state, ekf_mode, flags_82_10] = unpack('>HHH', bytearray(field_bytes) )
           elif (field_desc == '01'):
              [ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01] = unpack('>dddH', bytearray(field_bytes) )
           elif (field_desc == '08'):
              [ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '02'):
              [ekf_ned_vel_x, ekf_ned_vel_y, ekf_ned_vel_z, flags_82_02] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '09'):
              [ekf_ned_vel_UC_x, ekf_ned_vel_UC_y, ekf_ned_vel_UC_z, flags_82_09] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '05'):
              [euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '0a'):
              [euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '03'):
              [quat_0, quat_1, quat_2, quat_3, flags_82_03] = unpack('>ffffH', bytearray(field_bytes) )
           elif (field_desc == '12'):
              [quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12] = unpack('>ffffH', bytearray(field_bytes) )
           elif (field_desc == '07'):
              [accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '0c'):
              [accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '17'):
              [accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '19'):
              [accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '06'):
              [gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '0b'):
              [gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '16'):
              [gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '18'):
              [gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '0d'):
              [lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '1c'):
              [comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '1e'):
              [comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '13'):
              [grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '0f'):
              [grav_mag, flags_82_0f] = unpack('>fH', bytearray(field_bytes) )
           elif (field_desc == '14'):
              [heading, heading_UC, heading_source, flags_82_14] = unpack('>ffHH', bytearray(field_bytes) )
           elif (field_desc == '15'):
              [inten_N, inten_E, inten_D, inclination, declination, flags_82_15] = unpack('>fffffH', bytearray(field_bytes) )
           elif (field_desc == '21'):
              [pressure_altitude, flags_82_21] = unpack('>fH', bytearray(field_bytes) )
           elif (field_desc == '20'):
              [geom_alt, geopot_alt, temp, pressure, density, flags_82_20] = unpack('>fffffH', bytearray(field_bytes) )
           elif (field_desc == '30'):
              [gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30] = unpack('>fffH', bytearray(field_bytes) )
           elif (field_desc == '31'):
              [gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31] = unpack('>fffH', bytearray(field_bytes) )

        elif (desc_set == '81'):
           found_gps = True
           if (field_desc == '09'):
              [gps_tow, gps_week, flags_81_09] = unpack('>dHH', bytearray(field_bytes) )
           elif (field_desc == '08'):
              [utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08] = unpack('>HBBBBBIH', bytearray(field_bytes) )
           elif (field_desc == '03'):
              [gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03] = unpack('>ddddffH', bytearray(field_bytes) )
           elif (field_desc == '05'):
              [gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05] = unpack('>ffffffffH', bytearray(field_bytes) )
           elif (field_desc == '04'):
              [gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04] = unpack('>dddfH', bytearray(field_bytes) )
           elif (field_desc == '06'):
              [gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06] = unpack('>ffffH', bytearray(field_bytes) )
           elif (field_desc == '0b'):
              [gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b] = unpack('>BBHH', bytearray(field_bytes) )
           elif (field_desc == '0a'):
              [gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a] = unpack('>dddH', bytearray(field_bytes) )
           elif (field_desc == '0d'):
              [gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d] = unpack('>BBBH', bytearray(field_bytes) )
           elif (field_desc == '07'):
              [geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07] = unpack('>fffffffH', bytearray(field_bytes) )

        elif (desc_set == '80'):
           found_imu = True
           if (field_desc == '12'):
              [imu_tow, imu_week, flags_80_12] = unpack('>dHH', bytearray(field_bytes) )
           elif (field_desc == '04'):
              [scaled_accel_x, scaled_accel_y, scaled_accel_z] = unpack('>fff', bytearray(field_bytes) )
           elif (field_desc == '05'):
              [scaled_gyro_x, scaled_gyro_y, scaled_gyro_z] = unpack('>fff', bytearray(field_bytes) )
           elif (field_desc == '07'):
              [delta_theta_roll, delta_theta_pitch, delta_theta_yaw] = unpack('>fff', bytearray(field_bytes) )
           elif (field_desc == '08'):
              [delta_vel_x, delta_vel_y, delta_vel_z] = unpack('>fff', bytearray(field_bytes) )
           elif (field_desc == '17'):
              [ambient_pr] = unpack('>f', bytearray(field_bytes) )
           elif (field_desc == '06'):
              [mag_x, mag_y, mag_z] = unpack('>fff', bytearray(field_bytes) )

        j = j + field_size

      if (found_imu):
        # GPS Week,GPS TOW,GPS TFlags,       X Accel [x8004],Y Accel [x8004],Z Accel [x8004],    X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],      Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],    Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],     X Mag [x8006],Y Mag [x8006],Z Mag [x8006],    Pressure [x8017]
        # %4d,%12.4f,%d,                     %14.8f,%14.8f,%14.8f,                               %14.8f,%14.8f,%14.8f,                              %14.8f,%14.8f,%14.8f,                                                 %14.8f,%14.8f,%14.8f,                                            %14.8f,%14.8f,%14.8f,                         %14.8f
        # imu_week, imu_tow, flags_80_12,    scaled_accel_x, scaled_accel_y, scaled_accel_z,     scaled_gyro_x, scaled_gyro_y, scaled_gyro_z,       delta_theta_roll, delta_theta_pitch, delta_theta_yaw,                 delta_vel_x, delta_vel_y, delta_vel_z,                           mag_x, mag_y, mag_z,                          ambient_pr
        #
        # 'Packed':
        # GPS Week,GPS TOW,GPS TFlags,X Accel [x8004],Y Accel [x8004],Z Accel [x8004],X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],X Mag [x8006],Y Mag [x8006],Z Mag [x8006],Pressure [x8017]
        # %4d,%12.4f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f
        # imu_week, imu_tow, flags_80_12, scaled_accel_x, scaled_accel_y, scaled_accel_z, scaled_gyro_x, scaled_gyro_y, scaled_gyro_z, delta_theta_roll, delta_theta_pitch, delta_theta_yaw, delta_vel_x, delta_vel_y, delta_vel_z, mag_x, mag_y, mag_z, ambient_pr

        fout_imu.write('%4d,%12.4f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(imu_week, imu_tow, flags_80_12, scaled_accel_x, scaled_accel_y, scaled_accel_z, scaled_gyro_x, scaled_gyro_y, scaled_gyro_z, delta_theta_roll, delta_theta_pitch, delta_theta_yaw, delta_vel_x, delta_vel_y, delta_vel_z, mag_x, mag_y, mag_z, ambient_pr))
      if (found_gps):
        # GPS Week,GPS TOW,GPS TFlags,    UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108]     Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],      Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],    ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],       ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],     Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],    Clock Bias [x810A],Clock Drift [x810A],Clock Acc,Flags [x810A],          HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D]                            GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B]
        # %4d,%12.4f,%d,                   %4d,%d,%d,%d,%d,%d,%d,%d,                                                                                                                           %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                     %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                      %14.8f,%14.8f,%14.8f,%14.8f,%d,                                                    %14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                  %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                         %14.8f,%14.8f,%14.8f,%d,                                                 %d,%d,%d,%d,                                                                                           %d,%d,%d,%d
        # gps_week, gps_tow, flags_81_09,  utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08,                                                                           gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03,                    gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05,                          gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04,      gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06,                    geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07,                                                    gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a,    gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d,     gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b
        #
        # 'Packed':
        # 'GPS Week,GPS TOW,GPS TFlags,UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],Clock Bias [x810A],Clock Drift [x810A],Clock Acc,Flags [x810A],HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D],GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B]
        # %4d,%12.4f,%d,%4d,%d,%d,%d,%d,%d,%d,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%d,%d,%d,%d,%d,%d,%d,%d
        # gps_week, gps_tow, flags_81_09, utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08, gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03, gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05, gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04, gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06, geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07, gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a,    gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d, gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b

        fout_gps.write('%4d,%12.4f,%d,%4d,%d,%d,%d,%d,%d,%d,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%d,%d,%d,%d,%d,%d,%d,%d\n'%(gps_week, gps_tow, flags_81_09, utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08, gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03, gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05, gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04, gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06, geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07, gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a,    gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d, gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b))

      if (found_ekf and output_EKF):
        # print(' ************ WILL OUTPUT EKF ************** ')

        # GPS Week,GPS TOW,GPS TFlags,     EKF State [x8210],EKF Mode [x8210],Flags [x8210],   Lat [x8201],Long [x8201],Height [x8201],Flags [x8201],            LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],           Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],     Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],     Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],                 Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],                  q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],   q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],   X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],   X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],   X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],   X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],    X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],   X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],   X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],    X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],   X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],      X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],   X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],    X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],    WGS84 Gravity [x820F],Flags [x820F],   True North [x8214],North UC [x8214],Head Src [x8214],Flags [x8214],   WMM N [x8215],WMM E [x8215],WMM D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],   SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],    Pressure Alt [x8221],Flags [x8221],   X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],    X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231]
        # ekf_week, ekf_tow, flags_82_11,   ekf_state, ekf_mode, flags_82_10,                   ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01,    ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08,     ekf_ned_vel_x, ekf_ned_vel_y, ekf_ned_vel_z, flags_82_02,    ekf_ned_vel_UC_x, ekf_ned_vel_UC_y, ekf_ned_vel_UC_z, flags_82_09,    euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05,    euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a,     quat_0, quat_1, quat_2, quat_3, flags_82_03,                 quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12,                  accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07,                  accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c,                     accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17,                    accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19,                    gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06,                            gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b,                         gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16,                           gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18,                          lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d,                       comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c,                    comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e,                           grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13,                     grav_mag, flags_82_0f,                 heading, heading_UC, heading_source, flags_82_14,                      inten_N, inten_E, inten_D, inclination, declination, flags_82_15,                  geom_alt, geopot_alt, temp, pressure, density, flags_82_20,                                                                       pressure_altitude, flags_82_21,      gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30,    gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31
        # %4d,%12.4f,%d,                    %d,%d,%d,                                           %14.8f,%14.8f,%14.8f,%d,                                          %14.8f,%14.8f,%14.8f,%d,                                                    %14.8f,%14.8f,%14.8f,%d,                                     %14.8f,%14.8f,%14.8f,%d,                                              %14.8f,%14.8f,%14.8f,%d,                                              %14.8f,%14.8f,%14.8f,%d,                                                        %14.8f,%14.8f,%14.8f,%14.8f,%d,                               %14.8f,%14.8f,%14.8f,%14.8f,%d,                                          %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%14.8f,%14.8f,%d,                                                            %14.8f,%14.8f,%14.8f,%d,                                             %14.8f,%14.8f,%14.8f,%d,                                                     %14.8f,%14.8f,%14.8f,%d,                                                      %14.8f,%14.8f,%14.8f,%d,                                                             %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%14.8f,%14.8f,%d,                                                        %14.8f,%14.8f,%14.8f,%d,                                                  %14.8f,%14.8f,%14.8f,%d,                                                  %14.8f,%14.8f,%14.8f,%d,                                                      %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%d,                             %14.8f,%14.8f,%d,%d,                                                   %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                             %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                            %14.8f,%d,                            %14.8f,%14.8f,%14.8f,%d,                                                             %14.8f,%14.8f,%14.8f,%d
        #
        # 'Packed':
        # 'GPS Week,GPS TOW,GPS TFlags,EKF State [x8210],EKF Mode [x8210],Flags [x8210],Lat [x8201],Long [x8201],Height [x8201],Flags [x8201],LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],WGS84 Gravity [x820F],Flags [x820F],True North [x8214],North UC [x8214],Head Src [x8214],Flags [x8214],WMM N [x8215],WMM E [x8215],WMM D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],Pressure Alt [x8221],Flags [x8221],X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231]'
        # ekf_week, ekf_tow, flags_82_11,ekf_state, ekf_mode, flags_82_10, ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01, ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08, ekf_ned_vel_x, ekf_ned_vel_y, ekf_ned_vel_z, flags_82_02, ekf_ned_vel_UC_x, ekf_ned_vel_UC_y, ekf_ned_vel_UC_z, flags_82_09, euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05, euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a, quat_0, quat_1, quat_2, quat_3, flags_82_03, quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12, accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07, accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c, accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17, accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19, gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06, gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b, gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16, gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18, lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d, comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c, comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e, grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13, grav_mag, flags_82_0f, heading, heading_UC, heading_source, flags_82_14, inten_N, inten_E, inten_D, inclination, declination, flags_82_15, geom_alt, geopot_alt, temp, pressure, density, flags_82_20, pressure_altitude, flags_82_21, gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30, gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31
        # %4d,%12.4f,%d,%d,%d,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%d,%14.8f,%14.8f,%d,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d

        fout_ekf.write('%4d,%12.4f,%d,%d,%d,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%d,%14.8f,%14.8f,%d,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d,%14.8f,%14.8f,%14.8f,%d\n'%(ekf_week, ekf_tow, flags_82_11,ekf_state, ekf_mode, flags_82_10, ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01, ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08, ekf_ned_vel_x, ekf_ned_vel_y, ekf_ned_vel_z, flags_82_02, ekf_ned_vel_UC_x, ekf_ned_vel_UC_y, ekf_ned_vel_UC_z, flags_82_09, euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05, euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a, quat_0, quat_1, quat_2, quat_3, flags_82_03, quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12, accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07, accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c, accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17, accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19, gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06, gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b, gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16, gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18, lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d, comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c, comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e, grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13, grav_mag, flags_82_0f, heading, heading_UC, heading_source, flags_82_14, inten_N, inten_E, inten_D, inclination, declination, flags_82_15, geom_alt, geopot_alt, temp, pressure, density, flags_82_20, pressure_altitude, flags_82_21, gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30, gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31))

        output_EKF = False
        found_ekf = False

      i = i + 1
      k = k + packet_size + 6

      found_imu = False
      found_gps = False

      # else:
         # bad_data = 1
         # bad_packets = bad_packets + 1
         # print(' ******** k = ' + str(k) + ', Bad Data found')
         # k = k + packet_size + 7
   else:
      k = k + 1

 # fout_bin.read(bytearray(bytes_read))

 # print('\n------------------------------------------------------------------')

 print ('\n ****************** Nbr of valid packets = ' + str(i) + ', Nbr of bad packets = ' + str(bad_packets))

 end_time = time()
 print(' ************* Parse MIP Binary Log: end_time = ' + str(end_time) );

 print('\n------------------------------------------------------------------')

 fin_bin.close()
 fout_imu.close()
 fout_gps.close()
 fout_ekf.close()

if(__name__ == "__main__"):
  main_line(sys.argv)




