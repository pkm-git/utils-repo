import os
import sys
import visa
from time import sleep           #sleep

def main_line(argv):
   """Main line program"""

   rm = None

   print(' ***** os.name = ' + os.name )

   if (os.name == 'nt'):
      rm = visa.ResourceManager()       # for Windows
   elif (os.name == 'posix'):
      rm = visa.ResourceManager('@py')  # for Ubuntu

   # print(' *********** rm.list_resources(): ' + str(rm.list_resources()))

   # rm.list_resources()('ASRL1::INSTR', 'ASRL2::INSTR', 'GPIB0::12::INSTR')

   # inst = rm.open_resource('GPIB0::12::INSTR')

   # inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
   inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

   # print(' ********* inst.query: ' + str(inst.query("*IDN?")))

   print(' ********* query SOUR:SCEN:CONT?')
   str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

   if (str_scen_running[0:5] == 'START'):
       print("SOUR:SCEN:SENS:REG ACC")
       print(str(inst.write("SOUR:SCEN:SENS:REG ACC")))

       print("SOUR:SCEN:SENS:REG? ACC")
       print(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

       print("SOUR:SCEN:SENS:REG GYR")
       print(str(inst.write("SOUR:SCEN:SENS:REG GYR")))

       print("***** SOUR:SCEN:SENS:REG? GYR")
       print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

       print(' ********* query SOUR:SCEN:SENS:DAT? ')
       print(str(inst.query("SOUR:SCEN:SENS:DAT?")))

   else:
       print(' *********** No scenario running, will start scenario ***********')

       print("SOUR:SCEN:CONT start; *WAI;")
       # print(str(inst.write("SOUR:SCEN:CONT start; *WAI;")))
       # inst.write("SOUR:SCEN:CONT start; *WAI;")

       str_start_scen = "%s" %(str(inst.write("SOUR:SCEN:CONT start; *WAI;")))
       print('********* str_start_scen: ' + str_start_scen)
       if (str_start_scen[0:2] == 'Ok'):
          print('********* SCENARIO STARTED: ')
       else:
          sleep(22)
          cnt = 0
          while(cnt < 5):
             cnt = cnt + 1

             str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

             if (str_scen_running[0:5] == 'START'):
                print(' ******** SCENARIO STARTED' )
             else:
                sleep(2)

if(__name__ == "__main__"):
  main_line(sys.argv)

