import numpy

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]

ambient_pressure = 0
llh_ht = 978
altitude_prev = 0
altitude = 0

for altitude_array_index in range(len(altitude_array[0:4])):
   altitude = numpy.int32(altitude_array[altitude_array_index])
   print(' *********** altitude_array_index = ' + str(altitude_array_index) + ' altitude = ' + str(altitude))


