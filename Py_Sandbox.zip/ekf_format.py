EKF_FORMAT_UNINITIALIZED               = 0

class EKF_format(object):

 #default 'constructor'
 def __init__(self):
    """Class default initialization function"""
    try:
     self.init()
    except:
     self.state = EKF_FORMAT_UNINITIALIZED

 #class initializer function
 def init(self):
    """Class initialization function"""

    [self.ekf_week, self.ekf_tow, self.flags_82_11] = [0,0,0]
    [self.ekf_state, self.ekf_mode, self.flags_82_10] = [0,0,0]
    [self.ekf_pos_llh_lat, self.ekf_pos_llh_lon, self.ekf_pos_llh_ht, self.flags_82_01] = [0,0,0,0]
    [self.ekf_pos_llh_UC_lat, self.ekf_pos_llh_UC_lon, self.ekf_pos_llh_UC_ht, self.flags_82_08] = [0,0,0,0]
    [self.ekf_ned_vel_x, self.ekf_ned_vel_y, self.ekf_ned_vel_z, self.flags_82_02] = [0,0,0,0]
    [self.ekf_ned_vel_UC_x, self.ekf_ned_vel_UC_y, self.ekf_ned_vel_UC_z, self.flags_82_09] = [0,0,0,0]
    [self.euler_angle_roll, self.euler_angle_pitch, self.euler_angle_yaw, self.flags_82_05] = [0,0,0,0]
    [self.euler_angle_UC_roll, self.euler_angle_UC_pitch, self.euler_angle_UC_yaw, self.flags_82_0a] = [0,0,0,0]
    [self.quat_0, self.quat_1, self.quat_2, self.quat_3, self.flags_82_03] = [0,0,0,0,0]
    [self.quat_UC_0, self.quat_UC_1, self.quat_UC_2, self.quat_UC_3, self.flags_82_12] = [0,0,0,0,0]
    [self.accel_bias_x, self.accel_bias_y, self.accel_bias_z, self.flags_82_07] = [0,0,0,0]
    [self.accel_bias_UC_x, self.accel_bias_UC_y, self.accel_bias_UC_z, self.flags_82_0c] = [0,0,0,0]
    [self.accel_SF_x, self.accel_SF_y, self.accel_SF_z, self.flags_82_17] = [0,0,0,0]
    [self.accel_SF_UC_x, self.accel_SF_UC_y, self.accel_SF_UC_z, self.flags_82_19] = [0,0,0,0]
    [self.gyro_bias_x, self.gyro_bias_y, self.gyro_bias_z, self.flags_82_06] = [0,0,0,0]
    [self.gyro_bias_UC_x, self.gyro_bias_UC_y, self.gyro_bias_UC_z, self.flags_82_0b] = [0,0,0,0]
    [self.gyro_SF_x, self.gyro_SF_y, self.gyro_SF_z, self.flags_82_16] = [0,0,0,0]
    [self.gyro_SF_UC_x, self.gyro_SF_UC_y, self.gyro_SF_UC_z, self.flags_82_18] = [0,0,0,0]
    [self.lin_accel_x, self.lin_accel_y, self.lin_accel_z, self.flags_82_0d] = [0,0,0,0]
    [self.comp_accel_x, self.comp_accel_y, self.comp_accel_z, self.flags_82_1c] = [0,0,0,0]
    [self.comp_gyro_x, self.comp_gyro_y, self.comp_gyro_z, self.flags_82_0e] = [0,0,0,0]
    [self.grav_vect_x, self.grav_vect_y, self.grav_vect_z, self.flags_82_13] = [0,0,0,0]
    [self.grav_mag, self.flags_82_0f] = [0,0]
    [self.heading, self.heading_UC, self.heading_source, self.flags_82_14] = [0,0,0,0]
    [self.inten_N, self.inten_E, self.inten_D, self.inclination, self.declination, self.flags_82_15] = [0,0,0,0,0,0]
    [self.pressure_altitude, self.flags_82_21] = [0,0]
    [self.geom_alt, self.geopot_alt, self.temp, self.pressure, self.density, self.flags_82_20] = [0,0,0,0,0,0]
    [self.gps_ant_offset_corr_x, self.gps_ant_offset_corr_y, self.gps_ant_offset_corr_z, self.flags_82_30] = [0,0,0,0]
    [self.gps_ant_offset_corr_UC_x, self.gps_ant_offset_corr_UC_y, self.gps_ant_offset_corr_UC_z, self.flags_82_31] = [0,0,0,0]
    [self.matrix_m11, self.matrix_m12, self.matrix_m13, self.matrix_m21, self.matrix_m22, self.matrix_m23, self.matrix_m31, self.matrix_m32, self.matrix_m33, self.flags_82_04] = [0,0,0,0,0,0,0,0,0,0]

    [self.ekf_week_copy, self.ekf_tow_copy, self.flags_82_11_copy] = [0,0,0]
    [self.ekf_state_copy, self.ekf_mode_copy, self.flags_82_10_copy] = [0,0,0]
    [self.ekf_pos_llh_lat_copy, self.ekf_pos_llh_lon_copy, self.ekf_pos_llh_ht_copy, self.flags_82_01_copy] = [0,0,0,0]
    [self.ekf_pos_llh_UC_lat_copy, self.ekf_pos_llh_UC_lon_copy, self.ekf_pos_llh_UC_ht_copy, self.flags_82_08_copy] = [0,0,0,0]
    [self.ekf_ned_vel_x_copy, self.ekf_ned_vel_y_copy, self.ekf_ned_vel_z_copy, self.flags_82_02_copy] = [0,0,0,0]
    [self.ekf_ned_vel_UC_x_copy, self.ekf_ned_vel_UC_y_copy, self.ekf_ned_vel_UC_z_copy, self.flags_82_09_copy] = [0,0,0,0]
    [self.euler_angle_roll_copy, self.euler_angle_pitch_copy, self.euler_angle_yaw_copy, self.flags_82_05_copy] = [0,0,0,0]
    [self.euler_angle_UC_roll_copy, self.euler_angle_UC_pitch_copy, self.euler_angle_UC_yaw_copy, self.flags_82_0a_copy] = [0,0,0,0]
    [self.quat_0_copy, self.quat_1_copy, self.quat_2_copy, self.quat_3_copy, self.flags_82_03_copy] = [0,0,0,0]
    [self.quat_UC_0_copy, self.quat_UC_1_copy, self.quat_UC_2_copy, self.quat_UC_3_copy, self.flags_82_12_copy] = [0,0,0,0]
    [self.accel_bias_x_copy, self.accel_bias_y_copy, self.accel_bias_z_copy, self.flags_82_07_copy] = [0,0,0,0]
    [self.accel_bias_UC_x_copy, self.accel_bias_UC_y_copy, self.accel_bias_UC_z_copy, self.flags_82_0c_copy] = [0,0,0,0]
    [self.accel_SF_x_copy, self.accel_SF_y_copy, self.accel_SF_z_copy, self.flags_82_17_copy] = [0,0,0,0]
    [self.accel_SF_UC_x_copy, self.accel_SF_UC_y_copy, self.accel_SF_UC_z_copy, self.flags_82_19_copy] = [0,0,0,0]
    [self.gyro_bias_x_copy, self.gyro_bias_y_copy, self.gyro_bias_z_copy, self.flags_82_06_copy] = [0,0,0,0]
    [self.gyro_bias_UC_x_copy, self.gyro_bias_UC_y_copy, self.gyro_bias_UC_z_copy, self.flags_82_0b_copy] = [0,0,0,0]
    [self.gyro_SF_x_copy, self.gyro_SF_y_copy, self.gyro_SF_z_copy, self.flags_82_16_copy] = [0,0,0,0]
    [self.gyro_SF_UC_x_copy, self.gyro_SF_UC_y_copy, self.gyro_SF_UC_z_copy, self.flags_82_18_copy] = [0,0,0,0]
    [self.lin_accel_x_copy, self.lin_accel_y_copy, self.lin_accel_z_copy, self.flags_82_0d_copy] = [0,0,0,0]
    [self.comp_accel_x_copy, self.comp_accel_y_copy, self.comp_accel_z_copy, self.flags_82_1c_copy] = [0,0,0,0]
    [self.comp_gyro_x_copy, self.comp_gyro_y_copy, self.comp_gyro_z_copy, self.flags_82_0e_copy] = [0,0,0,0]
    [self.grav_vect_x_copy, self.grav_vect_y_copy, self.grav_vect_z_copy, self.flags_82_13_copy] = [0,0,0,0]
    [self.grav_mag_copy, self.flags_82_0f_copy] = [0,0]
    [self.heading_copy, self.heading_UC_copy, self.heading_source_copy, self.flags_82_14_copy] = [0,0,0,0]
    [self.inten_N_copy, self.inten_E_copy, self.inten_D_copy, self.inclination_copy, self.declination_copy, self.flags_82_15_copy] = [0,0,0,0,0,0]
    [self.pressure_altitude_copy, self.flags_82_21_copy] = [0,0]
    [self.geom_alt_copy, self.geopot_alt_copy, self.temp_copy, self.pressure_copy, self.density_copy, self.flags_82_20_copy] = [0,0,0,0,0,0]
    [self.gps_ant_offset_corr_x_copy, self.gps_ant_offset_corr_y_copy, self.gps_ant_offset_corr_z_copy, self.flags_82_30_copy] = [0,0,0,0]
    [self.gps_ant_offset_corr_UC_x_copy, self.gps_ant_offset_corr_UC_y_copy, self.gps_ant_offset_corr_UC_z_copy, self.flags_82_31_copy] = [0,0,0,0]
    [self.matrix_m11_copy, self.matrix_m12_copy, self.matrix_m13_copy, self.matrix_m21_copy, self.matrix_m22_copy, self.matrix_m23_copy, self.matrix_m31_copy, self.matrix_m32_copy, self.matrix_m33_copy, self.flags_82_04_copy] = [0,0,0,0,0,0,0,0,0,0]

 # Master Format (all available columns from DCP, in a 'master sequence'):
 # GPS TFlags,GPS Week,GPS TOW,      EKF State [x8210],EKF Mode [x8210],Flags [x8210],   Lat [x8201],Long [x8201],Height [x8201],Flags [x8201],            LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],           Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],     Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],     Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],                 Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],                  q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],   q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],   X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],   X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],   X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],   X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],   X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],   X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],  X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],    X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],   X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],      X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],   X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],    X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],    WGS84 Gravity [x820F],Flags [x820F],   True North [x8214],North UC [x8214],Head Src [x8214],Flags [x8214],   WMM N [x8215],WMM E [x8215],WMM D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],   SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],    Pressure Alt [x8221],Flags [x8221],   X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],    X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231]     Matrix M11[x8204],Matrix M12[x8204],Matrix M13[x8204],Matrix M21[x8204],Matrix M22[x8204],Matrix M23[x8204],Matrix M31[x8204],Matrix M32[x8204],Matrix M33[x8204],Flags [x8204]
 # flags_82_11,ekf_week, ekf_tow,    ekf_state, ekf_mode, flags_82_10,                   ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01,    ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08,     ekf_ned_vel_x, ekf_ned_vel_y, ekf_ned_vel_z, flags_82_02,    ekf_ned_vel_UC_x, ekf_ned_vel_UC_y, ekf_ned_vel_UC_z, flags_82_09,    euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05,    euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a,     quat_0, quat_1, quat_2, quat_3, flags_82_03,                 quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12,                  accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07,                  accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c,                     accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17,                    accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19,                    gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06,                          gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b,                         gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16,                           gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18,                          lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d,                       comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c,                    comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e,                           grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13,                     grav_mag, flags_82_0f,                 heading, heading_UC, heading_source, flags_82_14,                     inten_N, inten_E, inten_D, inclination, declination, flags_82_15,                    geom_alt, geopot_alt, temp, pressure, density, flags_82_20,                                                                      pressure_altitude, flags_82_21,       gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30,   gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31    matrix_m11, matrix_m12, matrix_m13, matrix_m21, matrix_m22, matrix_m23, matrix_m31, matrix_m32, matrix_m33, flags_82_04
 # %d,%4d,%12.4f,                    %d,%d,%d,                                           %14.8f,%14.8f,%14.8f,%d,                                          %14.8f,%14.8f,%14.8f,%d,                                                    %14.8f,%14.8f,%14.8f,%d,                                     %14.8f,%14.8f,%14.8f,%d,                                              %14.8f,%14.8f,%14.8f,%d,                                              %14.8f,%14.8f,%14.8f,%d,                                                        %14.8f,%14.8f,%14.8f,%14.8f,%d,                               %14.8f,%14.8f,%14.8f,%14.8f,%d,                                          %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%14.8f,%14.8f,%d,                                                            %14.8f,%14.8f,%14.8f,%d,                                            %14.8f,%14.8f,%14.8f,%d,                                                     %14.8f,%14.8f,%14.8f,%d,                                                     %14.8f,%14.8f,%14.8f,%d,                                                             %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%14.8f,%14.8f,%d,                                                        %14.8f,%14.8f,%14.8f,%d,                                                  %14.8f,%14.8f,%14.8f,%d,                                                  %14.8f,%14.8f,%14.8f,%d,                                                      %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%d,                             %14.8f,%14.8f,%d,%d,                                                  %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                               %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                           %14.8f,%d,                            %14.8f,%14.8f,%14.8f,%d,                                                            %14.8f,%14.8f,%14.8f,%d                                                                      %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d

 def format(self, format_in):
    if (format_in == 1):
       return '{:-4d},{:-4d},{:-12.4f},'.format(self.flags_82_11, self.ekf_week, self.ekf_tow)
    elif (format_in == 2):
       return '{:-d},{:-d},{:-d},'.format(self.ekf_state, self.ekf_mode, self.flags_82_10)
    elif (format_in == 3):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_pos_llh_lat, self.ekf_pos_llh_lon, self.ekf_pos_llh_ht, self.flags_82_01)
    elif (format_in == 4):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_pos_llh_UC_lat, self.ekf_pos_llh_UC_lon, self.ekf_pos_llh_UC_ht, self.flags_82_08)
    elif (format_in == 5):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_ned_vel_x, self.ekf_ned_vel_y, self.ekf_ned_vel_z, self.flags_82_02)
    elif (format_in == 6):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_ned_vel_UC_x, self.ekf_ned_vel_UC_y, self.ekf_ned_vel_UC_z, self.flags_82_09)
    elif (format_in == 7):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.euler_angle_roll, self.euler_angle_pitch, self.euler_angle_yaw, self.flags_82_05)
    elif (format_in == 8):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.euler_angle_UC_roll, self.euler_angle_UC_pitch, self.euler_angle_UC_yaw, self.flags_82_0a)
    elif (format_in == 9):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.quat_0, self.quat_1, self.quat_2, self.quat_3, self.flags_82_03)
    elif (format_in == 10):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.quat_UC_0, self.quat_UC_1, self.quat_UC_2, self.quat_UC_3, self.flags_82_12)
    elif (format_in == 11):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_bias_x, self.accel_bias_y, self.accel_bias_z, self.flags_82_07)
    elif (format_in == 12):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_bias_UC_x, self.accel_bias_UC_y, self.accel_bias_UC_z, self.flags_82_0c)
    elif (format_in == 13):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_SF_x, self.accel_SF_y, self.accel_SF_z, self.flags_82_17)
    elif (format_in == 14):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_SF_UC_x, self.accel_SF_UC_y, self.accel_SF_UC_z, self.flags_82_19)
    elif (format_in == 15):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_bias_x, self.gyro_bias_y, self.gyro_bias_z, self.flags_82_06)
    elif (format_in == 16):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_bias_UC_x, self.gyro_bias_UC_y, self.gyro_bias_UC_z, self.flags_82_0b)
    elif (format_in == 17):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_SF_x, self.gyro_SF_y, self.gyro_SF_z, self.flags_82_16)
    elif (format_in == 18):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_SF_UC_x, self.gyro_SF_UC_y, self.gyro_SF_UC_z, self.flags_82_18)
    elif (format_in == 19):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.lin_accel_x, self.lin_accel_y, self.lin_accel_z, self.flags_82_0d)
    elif (format_in == 20):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.comp_accel_x, self.comp_accel_y, self.comp_accel_z, self.flags_82_1c)
    elif (format_in == 21):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.comp_gyro_x, self.comp_gyro_y, self.comp_gyro_z, self.flags_82_0e)
    elif (format_in == 22):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.grav_vect_x, self.grav_vect_y, self.grav_vect_z, self.flags_82_13)
    elif (format_in == 23):
       return '{:-14.8f},{:-d},'.format(self.grav_mag, self.flags_82_0f)
    elif (format_in == 24):
       return '{:-14.8f},{:-14.8f},{:-d},{:-d},'.format(self.heading, self.heading_UC, self.heading_source, self.flags_82_14)
    elif (format_in == 25):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.inten_N, self.inten_E, self.inten_D, self.inclination, self.declination, self.flags_82_15)
    elif (format_in == 26):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.geom_alt, self.geopot_alt, self.temp, self.pressure, self.density, self.flags_82_20)
    elif (format_in == 27):
       return '{:-14.8f},{:-d},'.format(self.pressure_altitude, self.flags_82_21)
    elif (format_in == 28):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_ant_offset_corr_x, self.gps_ant_offset_corr_y, self.gps_ant_offset_corr_z, self.flags_82_30)
    elif (format_in == 29):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_ant_offset_corr_UC_x, self.gps_ant_offset_corr_UC_y, self.gps_ant_offset_corr_UC_z, self.flags_82_31)
    elif (format_in == 30):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.matrix_m11, self.matrix_m12, self.matrix_m13, self.matrix_m21, self.matrix_m22, self.matrix_m23, self.matrix_m31, self.matrix_m32, self.matrix_m33, self.flags_82_04)

    return 'EKF_format'

 def format_using_copy(self, format_in):
    if (format_in == 1):
       return '{:-4d},{:-4d},{:-12.4f},'.format(self.flags_82_11_copy, self.ekf_week_copy, self.ekf_tow_copy)
    elif (format_in == 2):
       return '{:-d},{:-d},{:-d},'.format(self.ekf_state_copy, self.ekf_mode_copy, self.flags_82_10_copy)
    elif (format_in == 3):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_pos_llh_lat_copy, self.ekf_pos_llh_lon_copy, self.ekf_pos_llh_ht_copy, self.flags_82_01_copy)
    elif (format_in == 4):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_pos_llh_UC_lat_copy, self.ekf_pos_llh_UC_lon_copy, self.ekf_pos_llh_UC_ht_copy, self.flags_82_08_copy)
    elif (format_in == 5):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_ned_vel_x_copy, self.ekf_ned_vel_y_copy, self.ekf_ned_vel_z_copy, self.flags_82_02_copy)
    elif (format_in == 6):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_ned_vel_UC_x_copy, self.ekf_ned_vel_UC_y_copy, self.ekf_ned_vel_UC_z_copy, self.flags_82_09_copy)
    elif (format_in == 7):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.euler_angle_roll_copy, self.euler_angle_pitch_copy, self.euler_angle_yaw_copy, self.flags_82_05_copy)
    elif (format_in == 8):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.euler_angle_UC_roll_copy, self.euler_angle_UC_pitch_copy, self.euler_angle_UC_yaw_copy, self.flags_82_0a_copy)
    elif (format_in == 9):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.quat_0_copy, self.quat_1_copy, self.quat_2_copy, self.quat_3_copy, self.flags_82_03_copy)
    elif (format_in == 10):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.quat_UC_0_copy, self.quat_UC_1_copy, self.quat_UC_2_copy, self.quat_UC_3_copy, self.flags_82_12_copy)
    elif (format_in == 11):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_bias_x_copy, self.accel_bias_y_copy, self.accel_bias_z_copy, self.flags_82_07_copy)
    elif (format_in == 12):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_bias_UC_x_copy, self.accel_bias_UC_y_copy, self.accel_bias_UC_z_copy, self.flags_82_0c_copy)
    elif (format_in == 13):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_SF_x_copy, self.accel_SF_y_copy, self.accel_SF_z_copy, self.flags_82_17_copy)
    elif (format_in == 14):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.accel_SF_UC_x_copy, self.accel_SF_UC_y_copy, self.accel_SF_UC_z_copy, self.flags_82_19_copy)
    elif (format_in == 15):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_bias_x_copy, self.gyro_bias_y_copy, self.gyro_bias_z_copy, self.flags_82_06_copy)
    elif (format_in == 16):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_bias_UC_x_copy, self.gyro_bias_UC_y_copy, self.gyro_bias_UC_z_copy, self.flags_82_0b_copy)
    elif (format_in == 17):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_SF_x_copy, self.gyro_SF_y_copy, self.gyro_SF_z_copy, self.flags_82_16_copy)
    elif (format_in == 18):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gyro_SF_UC_x_copy, self.gyro_SF_UC_y_copy, self.gyro_SF_UC_z_copy, self.flags_82_18_copy)
    elif (format_in == 19):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.lin_accel_x_copy, self.lin_accel_y_copy, self.lin_accel_z_copy, self.flags_82_0d_copy)
    elif (format_in == 20):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.comp_accel_x_copy, self.comp_accel_y_copy, self.comp_accel_z_copy, self.flags_82_1c_copy)
    elif (format_in == 21):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.comp_gyro_x_copy, self.comp_gyro_y_copy, self.comp_gyro_z_copy, self.flags_82_0e_copy)
    elif (format_in == 22):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.grav_vect_x_copy, self.grav_vect_y_copy, self.grav_vect_z_copy, self.flags_82_13_copy)
    elif (format_in == 23):
       return '{:-14.8f},{:-d},'.format(self.grav_mag_copy, self.flags_82_0f_copy)
    elif (format_in == 24):
       return '{:-14.8f},{:-14.8f},{:-d},{:-d},'.format(self.heading_copy, self.heading_UC_copy, self.heading_source_copy, self.flags_82_14_copy)
    elif (format_in == 25):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.inten_N_copy, self.inten_E_copy, self.inten_D_copy, self.inclination_copy, self.declination_copy, self.flags_82_15_copy)
    elif (format_in == 26):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.geom_alt_copy, self.geopot_alt_copy, self.temp_copy, self.pressure_copy, self.density_copy, self.flags_82_20_copy)
    elif (format_in == 27):
       return '{:-14.8f},{:-d},'.format(self.pressure_altitude_copy, self.flags_82_21_copy)
    elif (format_in == 28):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_ant_offset_corr_x_copy, self.gps_ant_offset_corr_y_copy, self.gps_ant_offset_corr_z_copy, self.flags_82_30_copy)
    elif (format_in == 29):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_ant_offset_corr_UC_x_copy, self.gps_ant_offset_corr_UC_y_copy, self.gps_ant_offset_corr_UC_z_copy, self.flags_82_31_copy)
    elif (format_in == 30):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.matrix_m11_copy, self.matrix_m12_copy, self.matrix_m13_copy, self.matrix_m21_copy, self.matrix_m22_copy, self.matrix_m23_copy, self.matrix_m31_copy, self.matrix_m32_copy, self.matrix_m33_copy, self.flags_82_04)

    return 'EKF_format'

 def format_header(self, format_in):
    if (format_in == 1):
       return 'GPS TFlags,GPS Week,GPS TOW,'
    elif (format_in == 2):
       return 'EKF State [x8210],EKF Mode [x8210],Flags [x8210],'
    elif (format_in == 3):
       return 'Lat [x8201],Long [x8201],Height [x8201],Flags [x8201],'
    elif (format_in == 4):
       return 'LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],'
    elif (format_in == 5):
       return 'Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],'
    elif (format_in == 6):
       return 'Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],'
    elif (format_in == 7):
       return 'Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],'
    elif (format_in == 8):
       return 'Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],'
    elif (format_in == 9):
       return 'q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],'
    elif (format_in == 10):
       return 'q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],'
    elif (format_in == 11):
       return 'X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],'
    elif (format_in == 12):
       return 'X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],'
    elif (format_in == 13):
       return 'X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],'
    elif (format_in == 14):
       return 'X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],'
    elif (format_in == 15):
       return 'X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],'
    elif (format_in == 16):
       return 'X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],'
    elif (format_in == 17):
       return 'X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],'
    elif (format_in == 18):
       return 'X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],'
    elif (format_in == 19):
       return 'X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],'
    elif (format_in == 20):
       return 'X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],'
    elif (format_in == 21):
       return 'X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],'
    elif (format_in == 22):
       return 'X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],'
    elif (format_in == 23):
       return 'WGS84 Gravity [x820F],Flags [x820F],'
    elif (format_in == 24):
       return 'True North [x8214],North UC [x8214],Head Src [x8214],Flags [x8214],'
    elif (format_in == 25):
       return 'WMM N [x8215],WMM E [x8215],WMM D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],'
    elif (format_in == 26):
       return 'SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],'
    elif (format_in == 27):
       return 'Pressure Alt [x8221],Flags [x8221],'
    elif (format_in == 28):
       return 'X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],'
    elif (format_in == 29):
       return 'X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231],'
    elif (format_in == 30):
       return 'M11 [x8204],M12 [x8204],M13 [x8204],M21 [x8204],M22 [x8204],M23 [x8204],M31 [x8204],M32 [x8204],M33 [x8204],Flags [x8204],'

    return 'EKF_format_header'

 def format_channel_name(self, format_in):
    if (format_in == 1):
       return ['EKF_TFlags', 'EKF_Week', 'EKF_TOW']
    elif (format_in == 2):
       return ['EKF_State_x8210','EKF_Mode_x8210','Flags_x8210']
    elif (format_in == 3):
       return ['Lat_x8201','Long_x8201','Height_x8201','Flags_x8201']
    elif (format_in == 4):
       return ['LLH_UC_N_x8208','LLH_UC_E_x8208','LLH_UC_D_x8208','Flags_x8208']
    elif (format_in == 5):
       return ['Vel_N_x8202','Vel_E_x8202','Vel_D_x8202','Flags_x8202']
    elif (format_in == 6):
       return ['Vel_UC_N_x8209','Vel_UC_E_x8209','Vel_UC_D_x8209','Flags_x8209']
    elif (format_in == 7):
       return ['Roll_x8205','Pitch_x8205','Yaw_x8205','Flags_x8205']
    elif (format_in == 8):
       return ['Roll_UC_x820A','Pitch_UC_x820A','Yaw_UC_x820A','Flags_x820A']
    elif (format_in == 9):
       return ['q0_x8203','q1_x8203','q2_x8203','q3_x8203','Flags_x8203']
    elif (format_in == 10):
       return ['q0_UC_x8212','q1_UC_x8212','q2_UC_x8212','q3_UC_x8212','Flags_x8212']
    elif (format_in == 11):
       return ['X_Acc_Bias_x8207','Y_Acc_Bias_x8207','Z_Acc_Bias_x8207','Flags_x8207']
    elif (format_in == 12):
       return ['X_Acc_Bias_UC_x820C','Y_Acc_Bias_UC_x820C','Z_Acc_Bias_UC_x820C','Flags_x820C']
    elif (format_in == 13):
       return ['X_Acc_SF_x8217','Y_Acc_SF_x8217','Z_Acc_SF_x8217','Flags_x8217']
    elif (format_in == 14):
       return ['X_Acc_SF_UC_x8219','Y_Acc_SF_UC_x8219','Z_Acc_SF_UC_x8219','Flags_x8219']
    elif (format_in == 15):
       return ['X_Gyro_Bias_x8206','Y_Gyro_Bias_x8206','Z_Gyro_Bias_x8206','Flags_x8206']
    elif (format_in == 16):
       return ['X_Gyro_Bias_UC_x820B','Y_Gyro_Bias_UC_x820B','Z_Gyro_Bias_UC_x820B','Flags_x820B']
    elif (format_in == 17):
       return ['X_Gyro_SF_x8216','Y_Gyro_SF_x8216','Z_Gyro_SF_x8216','Flags_x8216']
    elif (format_in == 18):
       return ['X_Gyro_SF_UC_x8218','Y_Gyro_SF_UC_x8218','Z_Gyro_SF_UC_x8218','Flags_x8218']
    elif (format_in == 19):
       return ['X_Acc_Lin_x820D','Y_Acc_Lin_x820D','Z_Acc_Lin_x820D','Flags_x820D']
    elif (format_in == 20):
       return ['X_Acc_Comp_x821C','Y_Acc_Comp_x821C','Z_Acc_Comp_x821C','Flags_x821C']
    elif (format_in == 21):
       return ['X_Gyro_Comp_x820E','Y_Gyro_Comp_x820E','Z_Gyro_Comp_x820E','Flags_x820E']
    elif (format_in == 22):
       return ['X_Gravity_x8213','Y_Gravity_x8213','Z_Gravity_x8213','Flags_x8213']
    elif (format_in == 23):
       return ['WGS84_Gravity_x820F','Flags_x820F']
    elif (format_in == 24):
       return ['True_North_x8214','North_UC_x8214','Head_Src_x8214','Flags_x8214']
    elif (format_in == 25):
       return ['WMM_N_x8215','WMM_E_x8215','WMM_D_x8215','Incl_x8215','Decl_x8215','Flags_x8215']
    elif (format_in == 26):
       return ['SAM_Geomet_Alt_x8220','SAM_Geopot_Alt_x8220','SAM_Temperature_x8220','SAM_Pressure_x8220','SAM_Density_x8220','Flags_x8220']
    elif (format_in == 27):
       return ['Pressure_Alt_x8221','Flags_x8221']
    elif (format_in == 28):
       return ['X_Ant_Off_Err_x8230','Y_Ant_Off_Err_x8230','Z_Ant_Off_Err_x8230','Flags_x8230']
    elif (format_in == 29):
       return ['X_Ant_Off_Err_UC_x8231','Y_Ant_Off_Err_UC_x8231','Z_Ant_Off_Err_UC_x8231','Flags_x8231']
    elif (format_in == 30):
       return ['M11_x8204','M12_x8204','M13_x8204','M21_x8204','M22_x8204','M23_x8204','M31_x8204','M32_x8204','M33_x8204','Flags_x8204']

    return 'EKF_format_channel_name'

 def format_channel_value(self, format_in):
    if (format_in == 1):
       return [self.flags_82_11, self.ekf_week, self.ekf_tow]
    elif (format_in == 2):
       return [self.ekf_state, self.ekf_mode, self.flags_82_10]
    elif (format_in == 3):
       return [self.ekf_pos_llh_lat, self.ekf_pos_llh_lon, self.ekf_pos_llh_ht, self.flags_82_01]
    elif (format_in == 4):
       return [self.ekf_pos_llh_UC_lat, self.ekf_pos_llh_UC_lon, self.ekf_pos_llh_UC_ht, self.flags_82_08]
    elif (format_in == 5):
       return [self.ekf_ned_vel_x, self.ekf_ned_vel_y, self.ekf_ned_vel_z, self.flags_82_02]
    elif (format_in == 6):
       return [self.ekf_ned_vel_UC_x, self.ekf_ned_vel_UC_y, self.ekf_ned_vel_UC_z, self.flags_82_09]
    elif (format_in == 7):
       return [self.euler_angle_roll, self.euler_angle_pitch, self.euler_angle_yaw, self.flags_82_05]
    elif (format_in == 8):
       return [self.euler_angle_UC_roll, self.euler_angle_UC_pitch, self.euler_angle_UC_yaw, self.flags_82_0a]
    elif (format_in == 9):
       return [self.quat_0, self.quat_1, self.quat_2, self.quat_3, self.flags_82_03]
    elif (format_in == 10):
       return [self.quat_UC_0, self.quat_UC_1, self.quat_UC_2, self.quat_UC_3, self.flags_82_12]
    elif (format_in == 11):
       return [self.accel_bias_x, self.accel_bias_y, self.accel_bias_z, self.flags_82_07]
    elif (format_in == 12):
       return [self.accel_bias_UC_x, self.accel_bias_UC_y, self.accel_bias_UC_z, self.flags_82_0c]
    elif (format_in == 13):
       return [self.accel_SF_x, self.accel_SF_y, self.accel_SF_z, self.flags_82_17]
    elif (format_in == 14):
       return [self.accel_SF_UC_x, self.accel_SF_UC_y, self.accel_SF_UC_z, self.flags_82_19]
    elif (format_in == 15):
       return [self.gyro_bias_x, self.gyro_bias_y, self.gyro_bias_z, self.flags_82_06]
    elif (format_in == 16):
       return [self.gyro_bias_UC_x, self.gyro_bias_UC_y, self.gyro_bias_UC_z, self.flags_82_0b]
    elif (format_in == 17):
       return [self.gyro_SF_x, self.gyro_SF_y, self.gyro_SF_z, self.flags_82_16]
    elif (format_in == 18):
       return [self.gyro_SF_UC_x, self.gyro_SF_UC_y, self.gyro_SF_UC_z, self.flags_82_18]
    elif (format_in == 19):
       return [self.lin_accel_x, self.lin_accel_y, self.lin_accel_z, self.flags_82_0d]
    elif (format_in == 20):
       return [self.comp_accel_x, self.comp_accel_y, self.comp_accel_z, self.flags_82_1c]
    elif (format_in == 21):
       return [self.comp_gyro_x, self.comp_gyro_y, self.comp_gyro_z, self.flags_82_0e]
    elif (format_in == 22):
       return [self.grav_vect_x, self.grav_vect_y, self.grav_vect_z, self.flags_82_13]
    elif (format_in == 23):
       return [self.grav_mag, self.flags_82_0f]
    elif (format_in == 24):
       return [self.heading, self.heading_UC, self.heading_source, self.flags_82_14]
    elif (format_in == 25):
       return [self.inten_N, self.inten_E, self.inten_D, self.inclination, self.declination, self.flags_82_15]
    elif (format_in == 26):
       return [self.geom_alt, self.geopot_alt, self.temp, self.pressure, self.density, self.flags_82_20]
    elif (format_in == 27):
       return [self.pressure_altitude, self.flags_82_21]
    elif (format_in == 28):
       return [self.gps_ant_offset_corr_x, self.gps_ant_offset_corr_y, self.gps_ant_offset_corr_z, self.flags_82_30]
    elif (format_in == 29):
       return [self.gps_ant_offset_corr_UC_x, self.gps_ant_offset_corr_UC_y, self.gps_ant_offset_corr_UC_z, self.flags_82_31]
    elif (format_in == 30):
       return [self.matrix_m11, self.matrix_m12, self.matrix_m13, self.matrix_m21, self.matrix_m22, self.matrix_m23, self.matrix_m31, self.matrix_m32, self.matrix_m33, self.flags_82_04]

    return []

 def format_channel_value_from_copy(self, format_in):
    if (format_in == 1):
       return [self.flags_82_11_copy, self.ekf_week_copy, self.ekf_tow_copy]
    elif (format_in == 2):
       return [self.ekf_state_copy, self.ekf_mode_copy, self.flags_82_10_copy]
    elif (format_in == 3):
       return [self.ekf_pos_llh_lat_copy, self.ekf_pos_llh_lon_copy, self.ekf_pos_llh_ht_copy, self.flags_82_01_copy]
    elif (format_in == 4):
       return [self.ekf_pos_llh_UC_lat_copy, self.ekf_pos_llh_UC_lon_copy, self.ekf_pos_llh_UC_ht_copy, self.flags_82_08_copy]
    elif (format_in == 5):
       return [self.ekf_ned_vel_x_copy, self.ekf_ned_vel_y_copy, self.ekf_ned_vel_z_copy, self.flags_82_02_copy]
    elif (format_in == 6):
       return [self.ekf_ned_vel_UC_x_copy, self.ekf_ned_vel_UC_y_copy, self.ekf_ned_vel_UC_z_copy, self.flags_82_09_copy]
    elif (format_in == 7):
       return [self.euler_angle_roll_copy, self.euler_angle_pitch_copy, self.euler_angle_yaw_copy, self.flags_82_05_copy]
    elif (format_in == 8):
       return [self.euler_angle_UC_roll_copy, self.euler_angle_UC_pitch_copy, self.euler_angle_UC_yaw_copy, self.flags_82_0a_copy]
    elif (format_in == 9):
       return [self.quat_0_copy, self.quat_1_copy, self.quat_2_copy, self.quat_3_copy, self.flags_82_03_copy]
    elif (format_in == 10):
       return [self.quat_UC_0_copy, self.quat_UC_1_copy, self.quat_UC_2_copy, self.quat_UC_3_copy, self.flags_82_12_copy]
    elif (format_in == 11):
       return [self.accel_bias_x_copy, self.accel_bias_y_copy, self.accel_bias_z_copy, self.flags_82_07_copy]
    elif (format_in == 12):
       return [self.accel_bias_UC_x_copy, self.accel_bias_UC_y_copy, self.accel_bias_UC_z_copy, self.flags_82_0c_copy]
    elif (format_in == 13):
       return [self.accel_SF_x_copy, self.accel_SF_y_copy, self.accel_SF_z_copy, self.flags_82_17_copy]
    elif (format_in == 14):
       return [self.accel_SF_UC_x_copy, self.accel_SF_UC_y_copy, self.accel_SF_UC_z_copy, self.flags_82_19_copy]
    elif (format_in == 15):
       return [self.gyro_bias_x_copy, self.gyro_bias_y_copy, self.gyro_bias_z_copy, self.flags_82_06_copy]
    elif (format_in == 16):
       return [self.gyro_bias_UC_x_copy, self.gyro_bias_UC_y_copy, self.gyro_bias_UC_z_copy, self.flags_82_0b_copy]
    elif (format_in == 17):
       return [self.gyro_SF_x_copy, self.gyro_SF_y_copy, self.gyro_SF_z_copy, self.flags_82_16_copy]
    elif (format_in == 18):
       return [self.gyro_SF_UC_x_copy, self.gyro_SF_UC_y_copy, self.gyro_SF_UC_z_copy, self.flags_82_18_copy]
    elif (format_in == 19):
       return [self.lin_accel_x_copy, self.lin_accel_y_copy, self.lin_accel_z_copy, self.flags_82_0d_copy]
    elif (format_in == 20):
       return [self.comp_accel_x_copy, self.comp_accel_y_copy, self.comp_accel_z_copy, self.flags_82_1c_copy]
    elif (format_in == 21):
       return [self.comp_gyro_x_copy, self.comp_gyro_y_copy, self.comp_gyro_z_copy, self.flags_82_0e_copy]
    elif (format_in == 22):
       return [self.grav_vect_x_copy, self.grav_vect_y_copy, self.grav_vect_z_copy, self.flags_82_13_copy]
    elif (format_in == 23):
       return [self.grav_mag_copy, self.flags_82_0f_copy]
    elif (format_in == 24):
       return [self.heading_copy, self.heading_UC_copy, self.heading_source_copy, self.flags_82_14_copy]
    elif (format_in == 25):
       return [self.inten_N_copy, self.inten_E_copy, self.inten_D_copy, self.inclination_copy, self.declination_copy, self.flags_82_15_copy]
    elif (format_in == 26):
       return [self.geom_alt_copy, self.geopot_alt_copy, self.temp_copy, self.pressure_copy, self.density_copy, self.flags_82_20_copy]
    elif (format_in == 27):
       return [self.pressure_altitude_copy, self.flags_82_21_copy]
    elif (format_in == 28):
       return [self.gps_ant_offset_corr_x_copy, self.gps_ant_offset_corr_y_copy, self.gps_ant_offset_corr_z_copy, self.flags_82_30_copy]
    elif (format_in == 29):
       return [self.gps_ant_offset_corr_UC_x_copy, self.gps_ant_offset_corr_UC_y_copy, self.gps_ant_offset_corr_UC_z_copy, self.flags_82_31_copy]
    elif (format_in == 30):
       return [self.matrix_m11_copy, self.matrix_m12_copy, self.matrix_m13_copy, self.matrix_m21_copy, self.matrix_m22_copy, self.matrix_m23_copy, self.matrix_m31_copy, self.matrix_m32_copy, self.matrix_m33_copy, self.flags_82_04_copy]

    return []

 #copy attributes function
 def copy(self):
    """Copy attributes function"""

    [self.ekf_week_copy, self.ekf_tow_copy, self.flags_82_11_copy] = [self.ekf_week, self.ekf_tow, self.flags_82_11]
    [self.ekf_state_copy, self.ekf_mode_copy, self.flags_82_10_copy] = [self.ekf_state, self.ekf_mode, self.flags_82_10]
    [self.ekf_pos_llh_lat_copy, self.ekf_pos_llh_lon_copy, self.ekf_pos_llh_ht_copy, self.flags_82_01_copy] = [self.ekf_pos_llh_lat, self.ekf_pos_llh_lon, self.ekf_pos_llh_ht, self.flags_82_01]
    [self.ekf_pos_llh_UC_lat_copy, self.ekf_pos_llh_UC_lon_copy, self.ekf_pos_llh_UC_ht_copy, self.flags_82_08_copy] = [self.ekf_pos_llh_UC_lat, self.ekf_pos_llh_UC_lon, self.ekf_pos_llh_UC_ht, self.flags_82_08]
    [self.ekf_ned_vel_x_copy, self.ekf_ned_vel_y_copy, self.ekf_ned_vel_z_copy, self.flags_82_02_copy] = [self.ekf_ned_vel_x, self.ekf_ned_vel_y, self.ekf_ned_vel_z, self.flags_82_02]
    [self.ekf_ned_vel_UC_x_copy, self.ekf_ned_vel_UC_y_copy, self.ekf_ned_vel_UC_z_copy, self.flags_82_09_copy] = [self.ekf_ned_vel_UC_x, self.ekf_ned_vel_UC_y, self.ekf_ned_vel_UC_z, self.flags_82_09]
    [self.euler_angle_roll_copy, self.euler_angle_pitch_copy, self.euler_angle_yaw_copy, self.flags_82_05_copy] = [self.euler_angle_roll, self.euler_angle_pitch, self.euler_angle_yaw, self.flags_82_05]
    [self.euler_angle_UC_roll_copy, self.euler_angle_UC_pitch_copy, self.euler_angle_UC_yaw_copy, self.flags_82_0a_copy] = [self.euler_angle_UC_roll, self.euler_angle_UC_pitch, self.euler_angle_UC_yaw, self.flags_82_0a]
    [self.quat_0_copy, self.quat_1_copy, self.quat_2_copy, self.quat_3_copy, self.flags_82_03_copy] = [self.quat_0, self.quat_1, self.quat_2, self.quat_3, self.flags_82_03]
    [self.quat_UC_0_copy, self.quat_UC_1_copy, self.quat_UC_2_copy, self.quat_UC_3_copy, self.flags_82_12_copy] = [self.quat_UC_0, self.quat_UC_1, self.quat_UC_2, self.quat_UC_3, self.flags_82_12]
    [self.accel_bias_x_copy, self.accel_bias_y_copy, self.accel_bias_z_copy, self.flags_82_07_copy] = [self.accel_bias_x, self.accel_bias_y, self.accel_bias_z, self.flags_82_07]
    [self.accel_bias_UC_x_copy, self.accel_bias_UC_y_copy, self.accel_bias_UC_z_copy, self.flags_82_0c_copy] = [self.accel_bias_UC_x, self.accel_bias_UC_y, self.accel_bias_UC_z, self.flags_82_0c]
    [self.accel_SF_x_copy, self.accel_SF_y_copy, self.accel_SF_z_copy, self.flags_82_17_copy] = [self.accel_SF_x, self.accel_SF_y, self.accel_SF_z, self.flags_82_17]
    [self.accel_SF_UC_x_copy, self.accel_SF_UC_y_copy, self.accel_SF_UC_z_copy, self.flags_82_19_copy] = [self.accel_SF_UC_x, self.accel_SF_UC_y, self.accel_SF_UC_z, self.flags_82_19]
    [self.gyro_bias_x_copy, self.gyro_bias_y_copy, self.gyro_bias_z_copy, self.flags_82_06_copy] = [self.gyro_bias_x, self.gyro_bias_y, self.gyro_bias_z, self.flags_82_06]
    [self.gyro_bias_UC_x_copy, self.gyro_bias_UC_y_copy, self.gyro_bias_UC_z_copy, self.flags_82_0b_copy] = [self.gyro_bias_UC_x, self.gyro_bias_UC_y, self.gyro_bias_UC_z, self.flags_82_0b]
    [self.gyro_SF_x_copy, self.gyro_SF_y_copy, self.gyro_SF_z_copy, self.flags_82_16_copy] = [self.gyro_SF_x, self.gyro_SF_y, self.gyro_SF_z, self.flags_82_16]
    [self.gyro_SF_UC_x_copy, self.gyro_SF_UC_y_copy, self.gyro_SF_UC_z_copy, self.flags_82_18_copy] = [self.gyro_SF_UC_x, self.gyro_SF_UC_y, self.gyro_SF_UC_z, self.flags_82_18]
    [self.lin_accel_x_copy, self.lin_accel_y_copy, self.lin_accel_z_copy, self.flags_82_0d_copy] = [self.lin_accel_x, self.lin_accel_y, self.lin_accel_z, self.flags_82_0d]
    [self.comp_accel_x_copy, self.comp_accel_y_copy, self.comp_accel_z_copy, self.flags_82_1c_copy] = [self.comp_accel_x, self.comp_accel_y, self.comp_accel_z, self.flags_82_1c]
    [self.comp_gyro_x_copy, self.comp_gyro_y_copy, self.comp_gyro_z_copy, self.flags_82_0e_copy] = [self.comp_gyro_x, self.comp_gyro_y, self.comp_gyro_z, self.flags_82_0e]
    [self.grav_vect_x_copy, self.grav_vect_y_copy, self.grav_vect_z_copy, self.flags_82_13_copy] = [self.grav_vect_x, self.grav_vect_y, self.grav_vect_z, self.flags_82_13]
    [self.grav_mag_copy, self.flags_82_0f_copy] = [self.grav_mag, self.flags_82_0f]
    [self.heading_copy, self.heading_UC_copy, self.heading_source_copy, self.flags_82_14_copy] = [self.heading, self.heading_UC, self.heading_source, self.flags_82_14]
    [self.inten_N_copy, self.inten_E_copy, self.inten_D_copy, self.inclination_copy, self.declination_copy, self.flags_82_15_copy] = [self.inten_N, self.inten_E, self.inten_D, self.inclination, self.declination, self.flags_82_15]
    [self.pressure_altitude_copy, self.flags_82_21_copy] = [self.pressure_altitude, self.flags_82_21]
    [self.geom_alt_copy, self.geopot_alt_copy, self.temp_copy, self.pressure_copy, self.density_copy, self.flags_82_20_copy] = [self.geom_alt, self.geopot_alt, self.temp, self.pressure, self.density, self.flags_82_20]
    [self.gps_ant_offset_corr_x_copy, self.gps_ant_offset_corr_y_copy, self.gps_ant_offset_corr_z_copy, self.flags_82_30_copy] = [self.gps_ant_offset_corr_x, self.gps_ant_offset_corr_y, self.gps_ant_offset_corr_z, self.flags_82_30]
    [self.gps_ant_offset_corr_UC_x_copy, self.gps_ant_offset_corr_UC_y_copy, self.gps_ant_offset_corr_UC_z_copy, self.flags_82_31_copy] = [self.gps_ant_offset_corr_UC_x, self.gps_ant_offset_corr_UC_y, self.gps_ant_offset_corr_UC_z, self.flags_82_31]
    [self.matrix_m11_copy, self.matrix_m12_copy, self.matrix_m13_copy, self.matrix_m21_copy, self.matrix_m22_copy, self.matrix_m23_copy, self.matrix_m31_copy, self.matrix_m32_copy, self.matrix_m33_copy, self.flags_82_04_copy] = [self.matrix_m11, self.matrix_m12, self.matrix_m13, self.matrix_m21, self.matrix_m22, self.matrix_m23, self.matrix_m31, self.matrix_m32, self.matrix_m33, self.flags_82_04]
