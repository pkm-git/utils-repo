# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import sys
import numpy as np

class gnss_timestamp_data:
   def __init__(self):
      [self.gnss_tflags, self.gnss_week_from_rcvr, self.gnss_tow_from_rcvr, self.cumul_time] = [0,0,0,0]
      [self.lat, self.lon, self.ht, self.ht_MSL, self.ambient_pr] = [0,0,0,0,0]
      [self.vned_n, self.vned_e, self.vned_d] = [0,0,0]
      [self.horizontal_accuracy, self.vertical_accuracy, self.flags_8103] = [0,0,0]
      [self.speed, self.ground_speed, self.heading] = [0,0,0]
      [self.speed_accuracy, self.heading_accuracy, self.flags_8105] = [0,0,0]

class imu_timestamp_data:
   def __init__(self):
      [self.imu_tflags, self.imu_week, self.imu_tow, self.cumul_time] = [0,0,0,0]
      [self.x_accel, self.y_accel, self.z_accel] = [0,0,0]
      [self.x_gyro, self.y_gyro, self.z_gyro] = [0,0,0]
      [self.x_mag, self.y_mag, self.z_mag] = [0,0,0]

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]
      
def print_gnss_array(gps_array, gps_header_array):

   i = 0
   for c in gps_header_array:
      i += 1
      
      if (i == 19):
         fout_csv_gnss_file.write(c)
      else:
         fout_csv_gnss_file.write(c + ',')
      # } if (i == len(data_row))..

      if (i == 3):
         fout_csv_gnss_file.write('GPS Cumul Time,')
      elif (i == 7):
         fout_csv_gnss_file.write('Ambient Pressure,')
      
      if (i == 19):
         break
   # } for c in gps_header_array..
      
   fout_csv_gnss_file.write('\n')

   for g in gps_array:
      data_row = [str(g.gnss_tflags), str(g.gnss_week_from_rcvr), str(g.gnss_tow_from_rcvr), str(g.cumul_time), str(g.lat), str(g.lon), str(g.ht), str(g.ht_MSL), str(g.ambient_pr), str(g.horizontal_accuracy), str(g.vertical_accuracy), str(g.flags_8103), str(g.vned_n), str(g.vned_e), str(g.vned_d), str(g.speed), str(g.ground_speed), str(g.heading), str(g.speed_accuracy), str(g.heading_accuracy), str(g.flags_8105)]
      
      i = 0
      for v in data_row:
         i += 1
         if (v.strip() != '' and v.strip().lower() != 'nan'):
            if (i == len(data_row)):
               if ('.' in v or 'e' in v):
	          if (i == 3):
		     fout_csv_gnss_file.write('%12.3f'%(float(v)))
		  else:   
   	             fout_csv_gnss_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_gnss_file.write('%1d'%(int(v)))        
               # } if ('.' in v)..		  
	       
	    elif ('.' in v or 'e' in v):
               fout_csv_gnss_file.write('%14.8f,'%(float(v)))
   	    else:
               fout_csv_gnss_file.write('%1d,'%(int(v)))
   	    # } if (i == len(..   
         else:
            fout_csv_gnss_file.write(',')
         # } if (v.strip() != '')..
      # } for v in data_row..
      fout_csv_gnss_file.write('\n')
   # } for g in gps_array..

def print_row(data_row_cnt, data_row, imu_cumul_time, found_gps_crossover, gps_array, gps_cnt):
   
   i = 0
   gps_cnt_ret = gps_cnt
   
   try:
      for v in data_row:
         i += 1
	 
         if (v.strip() != '' and v.strip().lower() != 'nan'):
            if (i == len(data_row)):
               if ('.' in v or 'e' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))        
               # } if ('.' in v)..		  
	       
	    elif ('.' in v or 'e' in v):
               # fout_csv_file.write('%14.8f,'%(float(v)))
	       	  
	       if (i == 3): # If column is IMU TOW, insert extra column value on right for IMU Cumul Time
	          fout_csv_file.write('%12.3f,'%(float(v)))
	          fout_csv_file.write('%14.8f,'%(imu_cumul_time))
               else:
	          fout_csv_file.write('%14.8f,'%(float(v)))
	       # } if (i == 3)..
   	    else:
               fout_csv_file.write('%1d,'%(int(v)))
   	    # } if (i == len(..   
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..
      # } for v in data_row..
      
      if (gps_cnt >= len(gps_array)):
         return gps_cnt
         
      gnss_data = gps_array[gps_cnt]
      
      gps_cumul_time = gnss_data.cumul_time
      
      if (found_gps_crossover and imu_cumul_time > gps_cumul_time): # IMU crossed GNSS TOW
	 if (data_row_cnt < 25):
            print(' ***** IMU CROSS OVER AT data_row_cnt: ' + str(data_row_cnt) + ', imu_cumul_time: ' + str(imu_cumul_time) + ', gps_cumul_time: ' + str(gps_cumul_time))
	 
	 gps_cnt_ret = gps_cnt + 1
	 
	 fout_csv_file.write(',%1d,%1d,%1d,%12.4f,%12.4f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%1d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%1d'%(1,\
	     gnss_data.gnss_tflags, gnss_data.gnss_week_from_rcvr, gnss_data.gnss_tow_from_rcvr, gnss_data.cumul_time,\
	     gnss_data.lat, gnss_data.lon, gnss_data.ht, gnss_data.ht_MSL,
	     gnss_data.ambient_pr, gnss_data.horizontal_accuracy, gnss_data.vertical_accuracy, gnss_data.flags_8103,\
	     gnss_data.vned_n, gnss_data.vned_e, gnss_data.vned_d, gnss_data.speed,
	     gnss_data.ground_speed, gnss_data.heading, gnss_data.speed_accuracy, gnss_data.heading_accuracy, gnss_data.flags_8105))
      else:
         fout_csv_file.write(',%1d,,,,,,,,,,,,,,,,,,,,,'%(0))   #  GPS_Available_Flag
      # } if (imu_cumul_time > gps_cumul_time)..

      fout_csv_file.write('\n')
   
      return gps_cnt_ret
      
   except ValueError:
      print(' ******* ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))
   
   except IndexError:     																									       
      print(' ****** IndexError: at data_row_cnt = ' + str(data_row_cnt) + ', gps_cnt = ' + str(gps_cnt))

   except TypeError:
      print(' ******* TypeError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value[2]: ' + str(data_row[2]))
      
def print_imu_array(data_row_cnt, imu_array, imu_cumul_time, begin_data_gap_week, begin_data_gap_tow, end_data_gap_tow, found_gps_crossover, gps_array, gps_cnt):
   
   size = len(imu_array)
   
   print(' **** inside print_imu_array: data_row_cnt = ' + str(data_row_cnt) + ', size: ' + str(size) + '\n')
   
   cnt = 0
   
   for i in imu_array:
      cnt += 1
      i.imu_tow = begin_data_gap_tow + (end_data_gap_tow - begin_data_gap_tow) * cnt /(size+1)
      imu_cumul_time += (end_data_gap_tow - begin_data_gap_tow)/(size+1)
      data_row = [str(i.imu_tflags), str(i.imu_week), str(i.imu_tow), str(i.x_accel), str(i.y_accel), str(i.z_accel), str(i.x_gyro), str(i.y_gyro), str(i.z_gyro), str(i.x_mag), str(i.y_mag), str(i.z_mag)]
      gps_cnt = print_row(data_row_cnt, data_row, imu_cumul_time, found_gps_crossover, gps_array, gps_cnt)
      
   # } for i in imu_array..
   
   return imu_cumul_time, gps_cnt

def process_csv_file(imu_csvreader, gps_csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0
   imu_array = []
   gps_header_array = []
   gps_array = []
   gps_cumul_time = -1
   diff_gps_tow = 0

   n_data_columns = 0
   prev_lat = 0
   prev_lon = 0
   prev_ht = 0
   
   prev_ht_MSL = 0

   prev_vned_n = 0
   prev_vned_e = 0
   prev_vned_d = 0

   prev_horizontal_accuracy = 0
   prev_vertical_accuracy = 0
   
   prev_speed = 0
   prev_ground_speed = 0
   
   prev_heading = 0
   prev_speed_accuracy = 0
   prev_heading_accuracy = 0
   prev_ambient_pr = 0
   
   prev_gps_week = 0
   prev_gps_tow = 0

   for data_row in gps_csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

         gps_header_array = data_row
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1

         gnss_tflags = int(data_row[0])
	 curr_gps_week = int(data_row[1])
         curr_gps_tow = float(data_row[2])
         
         curr_lat = np.double(data_row[3])
         curr_lon = np.double(data_row[4])
         curr_ht = np.double(data_row[5])
         curr_ht_MSL = float(data_row[6])
     
         curr_vned_n = float(data_row[10])
         curr_vned_e = float(data_row[11])
         curr_vned_d = float(data_row[12])
     
         curr_horizontal_accuracy = float(data_row[7])
         curr_vertical_accuracy = float(data_row[8])
         flags_8103 = int(data_row[9])
         
         curr_speed = float(data_row[13])
         curr_ground_speed = float(data_row[14])
         
         curr_heading = float(data_row[15])
         curr_speed_accuracy = float(data_row[16])
         curr_heading_accuracy = float(data_row[17])
         curr_ambient_pr = np.interp(curr_ht_MSL, altitude_array, ambient_pressure_array) * 1000
         
         flags_8105 = int(data_row[18])
	 
	 if (data_row_cnt == 1):
            gnss_data = gnss_timestamp_data()
	    
	    gnss_data.gnss_tflags = gnss_tflags
            gnss_data.gnss_week_from_rcvr = curr_gps_week
            gnss_data.gnss_tow_from_rcvr = curr_gps_tow
            gnss_data.cumul_time = 0.0
	    
	    gps_cumul_time += 1.0
            
            gnss_data.lat = curr_lat
            gnss_data.lon = curr_lon
            gnss_data.ht = curr_ht
            gnss_data.ht_MSL = curr_ht_MSL
            
            gnss_data.vned_n = curr_vned_n
            gnss_data.vned_e = curr_vned_e
            gnss_data.vned_d = curr_vned_d
            
            gnss_data.horizontal_accuracy = curr_horizontal_accuracy
            gnss_data.vertical_accuracy = curr_vertical_accuracy
            gnss_data.flags_8103 = flags_8103
            
            gnss_data.speed = curr_speed
            gnss_data.ground_speed = curr_ground_speed
            
            gnss_data.heading = curr_heading
            gnss_data.speed_accuracy = curr_speed_accuracy
            gnss_data.heading_accuracy = curr_heading_accuracy
            gnss_data.ambient_pr = curr_ambient_pr
            
	    gnss_data.flags_8105 = flags_8105
	    
	    gps_array.append(gnss_data)
	 
	 elif (len(data_row) > 0 and int(data_row[1]) != 0): # GPS Week != 0
	    
            if (prev_gps_week != 0):
	       if (curr_gps_week != prev_gps_week):
                  diff_gps_tow = 604800.00 + curr_gps_tow - prev_gps_tow
               else:
                  diff_gps_tow = curr_gps_tow - prev_gps_tow
		  
               # } if (curr_gps_week != prev_gps_week)..
	    # } if (prev_gps_week != 0)..
	    
            if (interp):
	       nbr_gnss_rows = int(round(diff_gps_tow))
            else:	       
	       nbr_gnss_rows = 1 # no interpolated rows
	       
	    gnss_delta_t = diff_gps_tow/nbr_gnss_rows
	       
	    gps_tow_to_use = 0
	    interp_begin_index_to_use = 1
	    
	    if (nbr_gnss_rows == 1):
	       gps_tow_to_use = curr_gps_tow
	    else:
	       gps_tow_to_use = prev_gps_tow
	    # } if (nbr_gnss_rows == 1)..
	    
	    # if (curr_gps_tow > 598359.49 and curr_gps_tow < 598359.55):
	       # print(' ****** curr gps tow = 598359.4999: ' + str(curr_gps_tow) + ', nbr_gnss_rows: ' + str(nbr_gnss_rows) + ', diff_gps_tow: ' + str(diff_gps_tow) + ', data_row:\n ')
	       # for v in data_row:
	          # print(v + '\t'),
	       # print('\n')
	       
	    for gnss_interp_cnt in range(nbr_gnss_rows):
	       gps_cumul_time += gnss_delta_t
	       
	       interp_ratio = float(gnss_interp_cnt + interp_begin_index_to_use)/nbr_gnss_rows

	       # if (data_row_cnt < 5):
	          # print(' **** data_row_cnt = ' + str(data_row_cnt) + ', gnss_interp_cnt: ' + str(gnss_interp_cnt) + ', prev_gps_week: ' + str(prev_gps_week) + ', curr_gps_week: ' + str(curr_gps_week) + ', curr_gps_tow = ' + str(curr_gps_tow) + ', prev_gps_tow = ' + str(prev_gps_tow) + ', diff_gps_tow = ' + str(diff_gps_tow) + ', nbr_gnss_rows: ' + str(nbr_gnss_rows) + ', gnss_delta_t = ' + str(gnss_delta_t) + ', gps_cumul_time = ' + str(gps_cumul_time) + '\n')

               gnss_data = gnss_timestamp_data()
   	    
   	       gnss_data.gnss_tflags = gnss_tflags
               gnss_data.gnss_week_from_rcvr = curr_gps_week # gnss_week_from_rcvr
	       gnss_data.gnss_tow_from_rcvr = prev_gps_tow + (curr_gps_tow - prev_gps_tow) * interp_ratio
               gnss_data.cumul_time = gps_cumul_time
               
	       # if (data_row_cnt > 296 and data_row_cnt < 302):
	         # print(' **** gps_cumul_time: ' + str(gps_cumul_time) + ', curr_gnss_tow_from_rcvr: ' + str(curr_gnss_tow_from_rcvr) + ', prev_gnss_tow_from_rcvr: ' + str(prev_gnss_tow_from_rcvr) + ', gnss_data.gnss_tow_from_rcvr: ' + str(gnss_data.gnss_tow_from_rcvr))
		 
               gnss_data.lat = prev_lat + (curr_lat - prev_lat) * interp_ratio
	       gnss_data.lon = prev_lon + (curr_lon - prev_lon) * interp_ratio
	       gnss_data.ht = prev_ht + (curr_ht - prev_ht) * interp_ratio
	       gnss_data.ht_MSL = prev_ht_MSL + (curr_ht_MSL - prev_ht_MSL) * interp_ratio
	       
	       gnss_data.vned_n = prev_vned_n + (curr_vned_n - prev_vned_n) * interp_ratio
	       gnss_data.vned_e = prev_vned_e + (curr_vned_e - prev_vned_e) * interp_ratio
	       gnss_data.vned_d = prev_vned_d + (curr_vned_d - prev_vned_d) * interp_ratio
	       
	       gnss_data.horizontal_accuracy = prev_horizontal_accuracy + (curr_horizontal_accuracy - prev_horizontal_accuracy) * interp_ratio
	       gnss_data.vertical_accuracy = prev_vertical_accuracy + (curr_vertical_accuracy - prev_vertical_accuracy) * interp_ratio
	       gnss_data.flags_8103 = flags_8103
	       
	       gnss_data.speed = prev_speed + (curr_speed - prev_speed) * interp_ratio
	       gnss_data.ground_speed = prev_ground_speed + (curr_ground_speed - prev_ground_speed) * interp_ratio
               
	       gnss_data.heading = prev_heading + (curr_heading - prev_heading) * interp_ratio
	       gnss_data.speed_accuracy = prev_speed_accuracy + (curr_speed_accuracy - prev_speed_accuracy) * interp_ratio
	       gnss_data.heading_accuracy = prev_heading_accuracy + (curr_heading_accuracy - prev_heading_accuracy) * interp_ratio
	       gnss_data.ambient_pr = prev_ambient_pr + (curr_ambient_pr - prev_ambient_pr) * interp_ratio
	       
   	       gnss_data.flags_8105 = flags_8105
   	    
   	       gps_array.append(gnss_data)
	    
	    # } for gnss_interp_cnt in nbr_gnss_rows..

         # } if (data_row_cnt == 1)..
	 
         prev_lat = curr_lat
         prev_lon = curr_lon
         prev_ht = curr_ht
         prev_ht_MSL = curr_ht_MSL
     
         prev_vned_n = curr_vned_n
         prev_vned_e = curr_vned_e
         prev_vned_d = curr_vned_d
     
         prev_horizontal_accuracy = curr_horizontal_accuracy
         prev_vertical_accuracy = curr_vertical_accuracy
         
         prev_speed = curr_speed
         prev_ground_speed = curr_ground_speed
         
         prev_heading = curr_heading
         prev_speed_accuracy = curr_speed_accuracy
         prev_heading_accuracy = curr_heading_accuracy
         prev_ambient_pr = curr_ambient_pr
         
         prev_gps_week = curr_gps_week
         prev_gps_tow = curr_gps_tow

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in gps_csvreader..

   print(' ********** LENGTH OF GPS ARRAY: ' + str(len(gps_array)))
   
   print_gnss_array(gps_array, gps_header_array)
   
   total_gps_rows = len(gps_array)

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   
   gps_cnt = 0
   gps_object = None

   prev_imu_week = 0
   prev_imu_tow = 0
   imu_cumul_time = 0
   gpsWeekChanged = False
   cnt = 0
   found_gps_crossover = False
   begin_data_gap = False
   begin_data_gap_tow = 0
   end_data_gap_tow = 0

   prev_imu_x_accel = 0
   prev_imu_y_accel = 0
   prev_imu_z_accel = 0
   
   prev_imu_x_gyro = 0
   prev_imu_y_gyro = 0
   prev_imu_z_gyro = 0

   prev_imu_x_mag = 0
   prev_imu_y_mag = 0
   prev_imu_z_mag = 0
   
   diff_imu_tow = 0
   
   for data_row in imu_csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         i = 0
         for c in data_row:
	    i += 1
            fout_csv_file.write(c + ',')
            
            if (i == 3): # IMU TOW
     	       fout_csv_file.write('IMU Cumul Time,')
	    elif (i == 12): # Mag Z.  Need to insert GPS_Available_Flag
	       fout_csv_file.write('GPS Available Flag,')
            # } if (i == 3)..   
         # } for c in data_row..
	 
	 i = 0
         for c in gps_header_array:
	    i += 1
	    
   	    # if (i == len(data_row)):
	    if (i == 19):
   	       fout_csv_file.write(c)
   	    else:
	       fout_csv_file.write(c + ',')
	    # } if (i == len(data_row))..

	    if (i == 3):
	       fout_csv_file.write('GPS Cumul Time,')
	    elif (i == 7):
	       fout_csv_file.write('Ambient Pressure,')
	    
	    if (i == 19):
	       break
	 # } for c in gps_header_array..
	    
         fout_csv_file.write('\n')
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1

	 imu_tflags = int(data_row[0])
         curr_imu_week = int(data_row[1])
         curr_imu_tow = float(data_row[2])

         if (not found_gps_crossover and curr_imu_tow >= gps_array[0].gnss_tow_from_rcvr):
	    found_gps_crossover = True

	 curr_imu_x_accel = float(data_row[3])
	 curr_imu_y_accel = float(data_row[4])
	 curr_imu_z_accel = float(data_row[5])
	 
	 curr_imu_x_gyro = float(data_row[6])
	 curr_imu_y_gyro = float(data_row[7])
	 curr_imu_z_gyro = float(data_row[8])

	 curr_imu_x_mag = float(data_row[9])
	 curr_imu_y_mag = float(data_row[10])
	 curr_imu_z_mag = float(data_row[11])

	 if (not found_gps_crossover):
         
            imu_data = imu_timestamp_data()
	    
	    imu_data.imu_tflags = imu_tflags
            imu_data.imu_week = curr_imu_week
	    imu_data.imu_tow = curr_imu_tow
	    
            imu_data.cumul_time = imu_cumul_time

	    imu_data.x_accel = curr_imu_x_accel
	    imu_data.y_accel = curr_imu_y_accel
	    imu_data.z_accel = curr_imu_z_accel
	    
	    imu_data.x_gyro = curr_imu_x_gyro
	    imu_data.y_gyro = curr_imu_y_gyro
	    imu_data.z_gyro = curr_imu_z_gyro
	    
	    imu_data.x_mag = curr_imu_x_mag
	    imu_data.y_mag = curr_imu_y_mag
	    imu_data.z_mag = curr_imu_z_mag
	    
	    imu_interp_data_row = [str(imu_data.imu_tflags), str(imu_data.imu_week), str(imu_data.imu_tow), str(imu_data.x_accel), str(imu_data.y_accel), str(imu_data.z_accel), str(imu_data.x_gyro), str(imu_data.y_gyro), str(imu_data.z_gyro), str(imu_data.x_mag), str(imu_data.y_mag), str(imu_data.z_mag)]
	    
	    gps_cnt = print_row(data_row_cnt, imu_interp_data_row, imu_cumul_time, found_gps_crossover, gps_array, gps_cnt)

       	    prev_imu_week = curr_imu_week
       	    prev_imu_tow = curr_imu_tow

       	    prev_imu_x_accel = curr_imu_x_accel
       	    prev_imu_y_accel = curr_imu_y_accel
       	    prev_imu_z_accel = curr_imu_z_accel
       	 
       	    prev_imu_x_gyro = curr_imu_x_gyro
       	    prev_imu_y_gyro = curr_imu_y_gyro
       	    prev_imu_z_gyro = curr_imu_z_gyro

       	    prev_imu_x_mag = curr_imu_x_mag
       	    prev_imu_y_mag = curr_imu_y_mag
       	    prev_imu_z_mag = curr_imu_z_mag
	    
	    continue
	    
	 elif (not begin_data_gap and curr_imu_week == 0):
	    begin_data_gap = True
	    begin_data_gap_week = prev_imu_week
	    begin_data_gap_tow = prev_imu_tow
	    
	    print('***** FOUND DATA GAP, BEGAN AT: data_row_cnt: ' + str(data_row_cnt) + ', begin_data_gap_tow = ' + str(begin_data_gap_tow))
	    
            imu_data = imu_timestamp_data()
   	    
   	    imu_data.imu_tflags = int(data_row[0])
            imu_data.imu_week = prev_imu_week
	    # imu_data.imu_tow = float(data_row[2])
	    
	    imu_data.x_accel = curr_imu_x_accel
	    imu_data.y_accel = curr_imu_y_accel
	    imu_data.z_accel = curr_imu_z_accel
	    
	    imu_data.x_gyro = curr_imu_x_gyro
	    imu_data.y_gyro = curr_imu_y_gyro
	    imu_data.z_gyro = curr_imu_z_gyro
	    
	    imu_data.x_mag = curr_imu_x_mag
	    imu_data.y_mag = curr_imu_y_mag
	    imu_data.z_mag = curr_imu_z_mag
	    
            imu_array.append(imu_data)
	    
	    continue
	 
	 elif (begin_data_gap and curr_imu_week == 0):
	 
            imu_data = imu_timestamp_data()
   	    
   	    imu_data.imu_tflags = int(data_row[0])
            imu_data.imu_week = prev_imu_week
	    
	    imu_data.x_accel = curr_imu_x_accel
	    imu_data.y_accel = curr_imu_y_accel
	    imu_data.z_accel = curr_imu_z_accel
	    
	    imu_data.x_gyro = curr_imu_x_gyro
	    imu_data.y_gyro = curr_imu_y_gyro
	    imu_data.z_gyro = curr_imu_z_gyro
	    
	    imu_data.x_mag = curr_imu_x_mag
	    imu_data.y_mag = curr_imu_y_mag
	    imu_data.z_mag = curr_imu_z_mag
	    
            imu_array.append(imu_data)
	    
	    continue
	 
	 elif (begin_data_gap and curr_imu_week != 0):
	    end_data_gap = True
	    end_data_gap_week = curr_imu_week
	    end_data_gap_tow = curr_imu_tow
	    begin_data_gap = False
	    
	    print('***** END DATA GAP AT: data_row_cnt: ' + str(data_row_cnt) + ', end_data_gap_tow = ' + str(end_data_gap_tow) + ', len(imu_array) = ' + str(len(imu_array)))
	    
	    # Uncomment following line if IMU rows with Week = 0 need to be retained and their Week and TOW replaced with interpolated TOW
	    if (interp_imu_tow):
	       imu_cumul_time, gps_cnt = print_imu_array(data_row_cnt, imu_array, imu_cumul_time, begin_data_gap_week, begin_data_gap_tow, end_data_gap_tow, found_gps_crossover, gps_array, gps_cnt)
	    else:
	       # Uncomment following line if IMU rows with Week = 0 need to be discarded
	       imu_cumul_time +=  end_data_gap_tow - begin_data_gap_tow
	    # } if (interp)..
	    
	    imu_array = []

	    gps_cnt = print_row(data_row_cnt, data_row, imu_cumul_time, found_gps_crossover, gps_array, gps_cnt)
	    
     	    prev_imu_week = curr_imu_week
     	    prev_imu_tow = curr_imu_tow

     	    prev_imu_x_accel = curr_imu_x_accel
     	    prev_imu_y_accel = curr_imu_y_accel
     	    prev_imu_z_accel = curr_imu_z_accel
     	 
     	    prev_imu_x_gyro = curr_imu_x_gyro
     	    prev_imu_y_gyro = curr_imu_y_gyro
     	    prev_imu_z_gyro = curr_imu_z_gyro

     	    prev_imu_x_mag = curr_imu_x_mag
     	    prev_imu_y_mag = curr_imu_y_mag
     	    prev_imu_z_mag = curr_imu_z_mag
	    
	    continue
	    
	 # } if (not begin_data_gap and..

         if (prev_imu_week != 0 and curr_imu_week != 0):
            if (curr_imu_week != prev_imu_week):
               diff_imu_tow = 604800.00 + curr_imu_tow - prev_imu_tow
	       gpsWeekChanged = True
	       print(' ****** GPS WEEK CHANGED: diff_imu_tow = ' + str(diff_imu_tow) + ', curr_imu_tow = ' + str(curr_imu_tow)) 
            else:
               diff_imu_tow = curr_imu_tow - prev_imu_tow
            # } if (curr_imu_week != prev_imu_week)..
	    
	    # nbr_imu_rows = int(round(diff_imu_tow/0.1))  # 10 Hz IMU rate (Canadian Space Agency)
	    nbr_imu_interp_rows = int(round(diff_imu_tow/0.1)) - 1  # 10 Hz IMU rate (Canadian Space Agency)
	    
	    if (nbr_imu_interp_rows > 0):
	       imu_delta_t = diff_imu_tow/(nbr_imu_interp_rows+1)

            if ((curr_imu_tow > 14904.95 and curr_imu_tow < 14905.25) or (curr_imu_tow > 14942.07 and curr_imu_tow < 14942.3)):
               print(' ****** curr imu tow = ' + str(curr_imu_tow) + ', nbr_imu_interp_rows: ' + str(nbr_imu_interp_rows) + ', diff_imu_tow: ' + str(diff_imu_tow) + ', imu_delta_t = ' + str(imu_delta_t) + ', data_row:\n ')
               for v in data_row:
                  print(v + '\t'),
               print('\n')
	    
	    # Suppress IMU interp for now
	    if (not interp):
	       nbr_imu_interp_rows = 0
	    # } if (interp)..
	    
            # Print the interpolated IMU rows, if any
            for imu_interp_cnt in range(nbr_imu_interp_rows):
	       imu_cumul_time += imu_delta_t
	       interp_ratio = float(imu_interp_cnt + 1)/(nbr_imu_interp_rows+1)
         
               imu_data = imu_timestamp_data()
	    
	       imu_data.imu_tflags = imu_tflags
               imu_data.imu_week = curr_imu_week
	       imu_data.imu_tow = prev_imu_tow + (curr_imu_tow - prev_imu_tow) * interp_ratio
	       
	       if ((curr_imu_tow > 14904.95 and curr_imu_tow < 14905.25) or (curr_imu_tow > 14942.07 and curr_imu_tow < 14942.3)):
                  print(' **** curr_imu_tow: ' + str(curr_imu_tow) + ', prev_imu_tow: ' + str(prev_imu_tow) + ', imu_cumul_time: ' + str(imu_cumul_time) + ', interp_ratio: ' + str(interp_ratio) + ', imu_interp_cnt: ' + str(imu_interp_cnt) + ', interp tow: ' + str(imu_data.imu_tow))

               imu_data.cumul_time = imu_cumul_time

	       imu_data.x_accel = prev_imu_x_accel + (curr_imu_x_accel - prev_imu_x_accel) * interp_ratio
	       imu_data.y_accel = prev_imu_y_accel + (curr_imu_y_accel - prev_imu_y_accel) * interp_ratio
	       imu_data.z_accel = prev_imu_z_accel + (curr_imu_z_accel - prev_imu_z_accel) * interp_ratio
	    
	       imu_data.x_gyro = prev_imu_x_gyro + (curr_imu_x_gyro - prev_imu_x_gyro) * interp_ratio
	       imu_data.y_gyro = prev_imu_y_gyro + (curr_imu_y_gyro - prev_imu_y_gyro) * interp_ratio
	       imu_data.z_gyro = prev_imu_z_gyro + (curr_imu_z_gyro - prev_imu_z_gyro) * interp_ratio
	    
	       imu_data.x_mag = prev_imu_x_mag + (curr_imu_x_mag - prev_imu_x_mag) * interp_ratio
	       imu_data.y_mag = prev_imu_y_mag + (curr_imu_y_mag - prev_imu_y_mag) * interp_ratio
	       imu_data.z_mag = prev_imu_z_mag + (curr_imu_z_mag - prev_imu_z_mag) * interp_ratio
	    
	       imu_interp_data_row = [str(imu_data.imu_tflags), str(imu_data.imu_week), str(imu_data.imu_tow), str(imu_data.x_accel), str(imu_data.y_accel), str(imu_data.z_accel), str(imu_data.x_gyro), str(imu_data.y_gyro), str(imu_data.z_gyro), str(imu_data.x_mag), str(imu_data.y_mag), str(imu_data.z_mag)]
	    
	       gps_cnt = print_row(data_row_cnt, imu_interp_data_row, imu_cumul_time, found_gps_crossover, gps_array, gps_cnt)
	    
            # } for imu_interp_cnt in range(nbr_imu_interp_rows)..
	    
	    if (nbr_imu_interp_rows == 0):
	       imu_cumul_time += diff_imu_tow
	    else:
	       imu_cumul_time += imu_delta_t

            if ((curr_imu_tow > 14904.95 and curr_imu_tow < 14905.25) or (curr_imu_tow > 14942.07 and curr_imu_tow < 14942.3)):
               print(' ****** Now will print curr imu row from csv: curr_imu_tow = ' + str(curr_imu_tow) + ', diff_imu_tow: ' + str(diff_imu_tow) + ', imu_cumul_time = ' + str(imu_cumul_time) + ', data_row:\n ')
               for v in data_row:
                  print(v + '\t'),
               print('\n')
	       
	    # Now print the current IMU row from csv
	    gps_cnt = print_row(data_row_cnt, data_row, imu_cumul_time, found_gps_crossover, gps_array, gps_cnt)
	 
	    if (gps_cnt >= total_gps_rows):
	       break
	 
   	 # } if (prev_imu_week != 0 ..
	 
	 prev_imu_week = curr_imu_week
	 prev_imu_tow = curr_imu_tow

	 prev_imu_x_accel = curr_imu_x_accel
	 prev_imu_y_accel = curr_imu_y_accel
	 prev_imu_z_accel = curr_imu_z_accel
	 
	 prev_imu_x_gyro = curr_imu_x_gyro
	 prev_imu_y_gyro = curr_imu_y_gyro
	 prev_imu_z_gyro = curr_imu_z_gyro

	 prev_imu_x_mag = curr_imu_x_mag
	 prev_imu_y_mag = curr_imu_y_mag
	 prev_imu_z_mag = curr_imu_z_mag
	 
      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in imu_csvreader..
   

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_woBadData_Orig_Data_for_NRTSIM_Part1.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_woBadData_Orig_Data_for_NRTSIM_Part1.csv'

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM.csv'

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM_Part1_18300_18930.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM_Part1_18300_18930.csv'

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_woBadData.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_woBadData.csv'

imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_woBadData_Orig_Data_for_NRTSIM_Full_Length.csv'
gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_woBadData_Orig_Data_for_NRTSIM_Full_Length.csv'

(fin_filepath, fin_filename) = os.path.split(imu_in_file_name)

# interp = False
interp = True

interp_imu_tow = False
# interp_imu_tow = True

if (interp):
   fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_IMU_GNSS_Merged_noGaps.csv"), "w")
else:
   fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_IMU_GNSS_Merged_wGaps.csv"), "w")

fout_csv_gnss_file = open(os.path.join(fin_filepath, "GNSS_Array_No_Gaps.csv"), "w")

fout_csv_file.write('DATA_START\n')
fout_csv_gnss_file.write('DATA_START\n')

imu_in_csvfile = open(imu_in_file_name,'r')
imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')
gps_in_csvfile = open(gps_in_file_name,'r')
gps_csvreader = csv.reader(gps_in_csvfile, delimiter=',')

process_csv_file(imu_csvreader, gps_csvreader)

imu_in_csvfile.close()
gps_in_csvfile.close()
fout_csv_file.close()
fout_csv_gnss_file.close()
