#Python struct example, for more information visit:
#                                https://docs.python.org/2/library/struct.html

#First Character (Endianness)
#Character      Byte order              Size            Alignment
#-----------------------------------------------------------------------------
# @             native                  native          native
# =             native                  standard        none
# <             little-endian           standard        none
# >             big-endian              standard        none
# !             network (= big-endian)  standard        none

#*IF FIRST CHARACTER IS LEFT OUT @ IS ASSUMED

#Type Characers
#Format         C Type          Python type             Standard size (Bytes)
#-----------------------------------------------------------------------------
# x             pad byte        no value
# c             char            string of length        1
# b             signed char     integer                 1
# B             unsigned char   integer                 1
# ?             _Bool           bool                    1
# h             short           integer                 2
# H             unsigned short  integer                 2
# i             int             integer                 4
# I             unsigned int    integer                 4
# l             long            integer                 4
# L             unsigned long   integer                 4
# q             long long       integer                 8
# Q             unsigned        long long integer       8
# f             float           float                   4
# d             double          float                   8
# s             char[]          string
# p             char[]          string
# P             void *          integer

#
from struct import * #import all objects and functions from the struct library
from binascii import hexlify #hexlify is a function to print bytearrays as 
                             #ascii strings for debugging (NOT NECESSARY FOR
                             #DATA CONVERSTIONS)

#Convert float to bytearray

#pack 3 floats in big-endian format
x_data = 4.5
y_data = 3.75
z_data = 7e-36
float_bytes = pack('>fff',x_data, y_data, z_data);

#print the byte arrays for each of the data members
print("x_data = "+str(x_data)+" is represented by the byte array: "\
                                           +hexlify(float_bytes[0:4]).upper())
                                         #NOTE: python array interval is upper
                                         #end exclusive so [0:4] = [0:4)

print("y_data = "+str(y_data)+" is represented by the byte array: "\
                                           +hexlify(float_bytes[4:8]).upper())
                                         #NOTE: python array interval is upper
                                         #end exclusive so [0:4] = [0:4)

print("z_data = "+str(z_data)+" is represented by the byte array: "\
                                          +hexlify(float_bytes[8:12]).upper())
                                         #NOTE: python array interval is upper
                                         #end exclusive so [0:4] = [0:4)

#retrieve the data from byte arrays

[x_unpacked, y_unpacked, z_unpacked] = unpack('>fff',float_bytes)

#print the byte arrays for each of the data members
print("x_unpacked = "+str(x_unpacked)+" is represented by the byte array: "\
                                           +hexlify(float_bytes[0:4]).upper())
                                         #NOTE: python array interval is upper
                                         #end exclusive so [0:4] = [0:4)

print("y_unpacked = "+str(y_unpacked)+" is represented by the byte array: "\
                                           +hexlify(float_bytes[4:8]).upper())
                                         #NOTE: python array interval is upper
                                         #end exclusive so [0:4] = [0:4)

print("z_unpacked = "+str(z_unpacked)+" is represented by the byte array: "\
                                          +hexlify(float_bytes[8:12]).upper())
                                         #NOTE: python array interval is upper
                                         #end exclusive so [0:4] = [0:4)




