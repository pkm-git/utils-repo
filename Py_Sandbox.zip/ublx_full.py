import numpy

from fletcher_check import fletcher_check16
from binascii import hexlify

#Sync Bytes
UBLX_SYNC_BYTE1 = 0xB5
UBLX_SYNC_BYTE2 = 0x62

#UBLX Packet Sizes
UBLX_HEADER_SIZE = 6
UBLX_CHECKSUM_SIZE = 2
UBLX_MAX_PAYLOAD_SIZE = 255
UBLX_MAX_PACKET_SIZE = (UBLX_HEADER_SIZE + UBLX_MAX_PAYLOAD_SIZE + UBLX_CHECKSUM_SIZE)
UBLX_MIN_PACKET_SIZE = 9 #This is a valid packet length, but not a practical packet

#UBLX Packet Header Data Locations
UBLX_HEADER_PAYLOAD_LENGTH_INDEX = 4
UBLX_HEADER_ID_INDEX = 3
UBLX_HEADER_CLASS_INDEX = 2
UBLX_HEADER_SYNC2_BYTE_INDEX = 1
UBLX_HEADER_SYNC1_BYTE_INDEX = 0

UBLX_PAYLOAD_START_INDEX = 6

########################################
# Function Return Codes
########################################

UBLX_OK = 0
UBLX_ERROR = 1
UBLX_MEMORY_ERROR = 2
UBLX_FIELD_NOT_AVAILABLE = 3
UBLX_INVALID_PACKET = 4
UBLX_CHECKSUM_ERROR = 5

########################################
# Miscellaneous Data widths
########################################

UBLX_DESCRIPTOR_SIZE = 1
UBLX_DECIMATION_SIZE = 2


def ublx_is_checksum_valid(ublx_packet):
    """Some Information Here"""
    if(len(ublx_packet)<UBLX_MIN_PACKET_SIZE or len(ublx_packet)>UBLX_MAX_PACKET_SIZE):
     return False

    #force into bytearray
    ublx_packet = bytearray(ublx_packet)

    #Calculate expected checksum
    expected_checksum = fletcher_check16(ublx_packet[0:len(ublx_packet)-2])

    #Compare with current checksum
    if( expected_checksum == ublx_packet[-2:] ):
        return True
    else:
        return False

def ublx_create_ublx_message(class_type, id_descriptor, len_packet_data, packet_data=bytearray([])):
    """Some Information Here"""

    packet = bytearray([])

    packet.append(UBLX_SYNC_BYTE1);
    packet.append(UBLX_SYNC_BYTE2);
    packet.append(class_type);
    packet.append(id_descriptor);
    packet.append(pack('>H', numpy.ushort(len_packet_data)));

    #print "******** ublx add field: str(len(packet_data)) = " + str(len(packet_data))
    #print "******** ublx add field: id_descriptor = " + str(id_descriptor)
    print "******** ublx add field,before adding packet_data: packet = " + hexlify(packet).upper()

    #add the field data
    packet.extend(bytearray(packet_data))

    print "******** ublx add field: AFTER extend, packet = " + hexlify(packet).upper()

    #would the addition of this field make the packet grow too large
    if (len(packet) + UBLX_CHECKSUM_SIZE > UBLX_MAX_PACKET_SIZE):
        return UBLX_MEMORY_ERROR

    return packet;

def ublx_finalize(ublx_packet):
    """Some Information Here"""
    #test for a packet of valid length
    if ( len(bytearray(ublx_packet) < UBLX_MIN_PACKET_SIZE or \
         len(bytearray(ublx_packet) > UBLX_MAX_PACKET_SIZE ):
     return 0

    print(" *************** ublx_finalize: ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX] = " + str(ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX]));

    #test if payload indicated is consistent with the packet length
    #if (ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX] + UBLX_HEADER_SIZE > len(ublx_packet)):
        #return 0

    #calculate the checksum
    checksum = fletcher_check16(ublx_packet)

    #add the checksum to the packet
    ublx_packet.extend(checksum)

    #return the length of the packet
    return len(ublx_packet)

def ublx_is_initialized(ublx_packet, class_type):
    """Some Information Here"""
    #test for necessary length for initialized packet
    if (len(ublx_packet)+2 < UBLX_MIN_PACKET_SIZE):
     return UBLX_ERROR

    #test for valid sync bytes and that the descriptor set matches
    if (ublx_packet[UBLX_HEADER_SYNC1_BYTE_INDEX] == UBLX_SYNC_BYTE1 and \
        ublx_packet[UBLX_HEADER_SYNC2_BYTE_INDEX] == UBLX_SYNC_BYTE2 and \
        ublx_packet[UBLX_HEADER_CLASS_INDEX] == class_type):
     return UBLX_OK

    return UBLX_ERROR

def ublx_is_ublx_packet(ublx_packet):
    """Some Information Here"""
    #test for a packet of valid length
    if ( len(bytearray(ublx_packet) < UBLX_MIN_PACKET_SIZE or \
         len(bytearray(ublx_packet) > UBLX_MAX_PACKET_SIZE ):
     return UBLX_ERROR

    #test for valid sync bytes
    if ( ublx_packet[UBLX_HEADER_SYNC1_BYTE_INDEX] != UBLX_SYNC_BYTE1 or \
         ublx_packet[UBLX_HEADER_SYNC2_BYTE_INDEX] != UBLX_SYNC_BYTE2 ):
     return UBLX_INVALID_PACKET

    #test if payload indicated matches length
    if ( (len(ublx_packet) - UBLX_CHECKSUM_SIZE - UBLX_HEADER_SIZE ) != \
                                       ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX]):
     return UBLX_INVALID_PACKET

    #test for valid checksum
    if ( not( ublx_is_checksum_valid(ublx_packet) ) ):
     return UBLX_INVALID_PACKET

    return UBLX_OK

def ublx_get_packet_descriptor_set(ublx_packet):
    """Some Information Here"""
    # if(ublx_is_ublx_packet(ublx_packet) != UBLX_OK):
    #  return 0

    return ublx_packet[UBLX_HEADER_CLASS_INDEX]

def ublx_get_payload_size(ublx_packet):
    """Some Information Here"""
    # if(ublx_is_ublx_packet(ublx_packet) != UBLX_OK):
    #  return 0

    return ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX]

def ublx_get_payload(ublx_packet):
    """Some Information Here"""
    # if(ublx_is_ublx_packet(ublx_packet) != UBLX_OK):
    #  return 0

    return ublx_packet[UBLX_PAYLOAD_START_INDEX:UBLX_PAYLOAD_START_INDEX + ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX]]

def ublx_get_packet_size(ublx_packet):
    """Some Information Here"""
    # if(ublx_is_ublx_packet(ublx_packet) != UBLX_OK):
    #  return 0

    return len(bytearray(ublx_packet))

def ublx_get_next_field_offset(ublx_packet, field_offset):
    """Some Information Here"""
    # if(ublx_is_ublx_packet(ublx_packet) != UBLX_OK):
    #  return 0

    if (field_offset == 0):
        return UBLX_HEADER_SIZE

    try:
        next_offset = field_offset+ublx_packet[field_offset]
    except:
        return 0

    if ( (next_offset >= UBLX_HEADER_SIZE + ublx_packet[UBLX_HEADER_PAYLOAD_LENGTH_INDEX] )\
         or (next_offset == field_offset) ):
        return 0

    return next_offset

def ublx_get_first_field_offset(ublx_packet):
    """Some Information Here"""
    return ublx_get_next_field_offset(ublx_packet,0)

def ublx_get_field_at_offset(ublx_packet,offset):
    """Some Information Here"""
    # if(ublx_is_ublx_packet(ublx_packet) != UBLX_OK):
    #  return 0

    try:
        return ublx_packet[offset:offset+ublx_packet[offset]]
    except:
        return 0

def ublx_get_next_field(ublx_packet):
    """
    Generator Function to generate iterable of Mip Fields. If used as an iterable
    will iterate over fields, otherwise just returns first field on 'next' call
    """
    local_packet = bytearray(ublx_packet)
    #get offset of first field
    offset = ublx_get_first_field_offset(local_packet)
    while(offset != 0):
        yield ublx_get_field_at_offset(local_packet, offset)
        #get offset of next field
        offset = ublx_get_next_field_offset(local_packet, offset)

#assign this call to the fletcher_check16 function
ublx_calculate_checksum = fletcher_check16


