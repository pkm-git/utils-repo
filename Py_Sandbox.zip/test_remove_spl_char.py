import re

str = "how much for the maple_syrup? - [$20.99]? That's ridiculous!!!"
tmp_str = str.strip().replace(" ", "_")
str_no_spl = re.sub(r'[^a-zA-Z0-9_.-]', r'', tmp_str)

print('  Orig str: ' + str + '\n  str_no_spl: ' + str_no_spl)

row_header = 'Lat [x8103]'
# tmp_channel_name = row_header.strip().replace(" ", "_")

row_header = row_header.strip().replace(" ", "_")

# All characters other than AlphaNumeric, _, -, and .: Replace with empty char:
row_hdr_no_spl = re.sub(r'[^a-zA-Z0-9_.-]', r'', row_header)

print(' *********** AFTER row_header = ' + row_hdr_no_spl)

str2 = 'DeltaTheta_Z [325/268]'
tmp_str = str2.strip().replace(" ", "_")
tmp_str = tmp_str.replace("/", "_")
str_no_spl = re.sub(r'[^a-zA-Z0-9_.-]', r'', tmp_str)

print('********  Orig str: ' + str2 + '\n  str_no_spl: ' + str_no_spl)
