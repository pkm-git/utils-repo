GPS_FORMAT_UNINITIALIZED               = 0

class sv_data_struct:
   def __init__(self):
      self.channel_nbr = 0
      self.sv_id = 0
      self.carrier_to_noise_ratio = 0
      self.azimuth = 0
      self.elevation = 0
      self.sv_flags = 0
      self.flags_81_0c = 0

class GPS_format(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = GPS_FORMAT_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""

   [self.gps_tow, self.gps_week, self.flags_81_09] = [0,0,0]
   [self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc, self.flags_81_03] = [0,0,0,0,0,0,0]
   [self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc, self.flags_81_05] = [0,0,0,0,0,0,0,0,0]
   [self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC, self.flags_81_04] = [0,0,0,0,0]
   [self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC, self.flags_81_06] = [0,0,0,0,0]
   [self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags, self.flags_81_0b] = [0,0,0,0]
   [self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate, self.flags_81_0a] = [0,0,0,0]
   [self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power, self.flags_81_0d] = [0,0,0,0]
   [self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop, self.flags_81_07] = [0,0,0,0,0,0,0,0]
   [self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec, self.utc_msec, self.flags_81_08] = [0,0,0,0,0,0,0,0]
   [self.channel_nbr, self.sv_id, self.carrier_to_noise_ratio, self.azimuth, self.elevation, self.sv_flags, self.flags_81_0c] = [0,0,0,0,0,0,0]
   
   [self.gps_tow_copy, self.gps_week_copy, self.flags_81_09_copy] = [0,0,0]
   [self.gps_lat_copy, self.gps_lon_copy, self.gps_ht_abv_ellip_copy, self.gps_ht_abv_MSL_copy, self.gps_horiz_acc_copy, self.gps_vert_acc_copy, self.flags_81_03_copy] = [0,0,0,0,0,0,0]
   [self.gps_vned_N_copy, self.gps_vned_E_copy, self.gps_vned_D_copy, self.gps_speed_copy, self.gps_grnd_speed_copy, self.gps_heading_copy, self.gps_speed_acc_copy, self.gps_heading_acc_copy, self.flags_81_05_copy] = [0,0,0,0,0,0,0,0,0]
   [self.gps_pos_ecef_x_copy, self.gps_pos_ecef_y_copy, self.gps_pos_ecef_z_copy, self.gps_pos_ecef_UC_copy, self.flags_81_04_copy] = [0,0,0,0,0]
   [self.gps_vel_ecef_x_copy, self.gps_vel_ecef_y_copy, self.gps_vel_ecef_z_copy, self.gps_vel_ecef_UC_copy, self.flags_81_06_copy] = [0,0,0,0,0]
   [self.gps_fix_type_copy, self.gps_nbr_of_svs_used_copy, self.gps_fix_flags_copy, self.flags_81_0b_copy] = [0,0,0,0]
   [self.gps_clock_bias_copy, self.gps_clock_drift_copy, self.gps_clock_acc_estimate_copy, self.flags_81_0a_copy] = [0,0,0,0]
   [self.gps_hw_status_sensor_state_copy, self.gps_hw_status_antenna_state_copy, self.gps_hw_status_antenna_power_copy, self.flags_81_0d_copy] = [0,0,0,0]
   [self.geom_dop_copy, self.pos_dop_copy, self.horiz_dop_copy, self.vert_dop_copy, self.time_dop_copy, self.northing_dop_copy, self.easting_dop_copy, self.flags_81_07_copy] = [0,0,0,0,0,0,0,0]
   [self.utc_yr_copy, self.utc_mo_copy, self.utc_day_copy, self.utc_hr_copy, self.utc_min_copy, self.utc_sec_copy, self.utc_msec_copy, self.flags_81_08_copy] = [0,0,0,0,0,0,0,0]
   [self.channel_nbr_copy, self.sv_id_copy, self.carrier_to_noise_ratio_copy, self.azimuth_copy, self.elevation_copy, self.sv_flags_copy, self.flags_81_0c_copy] = [0,0,0,0,0,0,0]
   
   self.sv_data_struct_array = []
   self.sv_data_struct_array_copy = []
   
 # Master Format (all available columns from DCP, in a 'master sequence'):
 # GPS TFlags,GPS Week,GPS TOW,     Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],      Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],   ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],       ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],     Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],    Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],Flags [x810A],    HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D]                            GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B]    UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108]
 # %d,%4d,%12.4f,                   %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                    %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                      %14.8f,%14.8f,%14.8f,%14.8f,%d,                                                    %14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                  %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                         %14.8f,%14.8f,%14.8f,%d,                                                   %d,%d,%d,%d,                                                                                           %d,%d,%d,%d                                                                 %4d,%d,%d,%d,%d,%d,%d,%d,
 # flags_81_09,gps_week, gps_tow,   gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc, flags_81_03,                    gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc, flags_81_05,                         gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC, flags_81_04,      gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC, flags_81_06,                    geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop, flags_81_07,                                                    gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate, flags_81_0a,      gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power, flags_81_0d,     gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags, flags_81_0b               utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec, utc_msec, flags_81_08,

 def add_sv(self, sv):
     sv_data_struct_array.append(sv)

 def clear_sv_array(self):
     sv_data_struct_array = []

 def format(self, format_in):
     if (format_in == 1):
         return '{:-2d},{:-2d},{:-12.4f},'.format(self.flags_81_09, self.gps_week, self.gps_tow)
     elif (format_in == 2):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc, self.flags_81_03)
     elif (format_in == 3):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc, self.flags_81_05)
     elif (format_in == 4):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC, self.flags_81_04)
     elif (format_in == 5):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC, self.flags_81_06)
     elif (format_in == 6):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop, self.flags_81_07)
     elif (format_in == 7):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate, self.flags_81_0a)
     elif (format_in == 8):
         return '{:-d},{:-d},{:-d},{:-d},'.format(self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power, self.flags_81_0d)
     elif (format_in == 9):
         return '{:-d},{:-d},{:-d},{:-d},'.format(self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags, self.flags_81_0b)
     elif (format_in == 10):
         return '{:-4d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},'.format(self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec, self.utc_msec, self.flags_81_08)
     elif (format_in == 11):
         ret_str = ''
         
         for sv in sv_data_struct_array:
            ret_str += '{:-d},{:-d},{:-2d},{:-2d},{:-2d},{:-2d},{:-2d},'.format(sv.channel_nbr, sv.sv_id, sv.carrier_to_noise_ratio, sv.azimuth, sv.elevation, sv.sv_flags, sv.flags_81_0c)
         
         return ret_str
         
     return 'GPS_format'

 def format_using_copy(self, format_in):
     if (format_in == 1):
         return '{:-4d},{:-4d},{:-12.4f},'.format(self.flags_81_09_copy, self.gps_week_copy, self.gps_tow_copy)
     elif (format_in == 2):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_lat_copy, self.gps_lon_copy, self.gps_ht_abv_ellip_copy, self.gps_ht_abv_MSL_copy, self.gps_horiz_acc_copy, self.gps_vert_acc_copy, self.flags_81_03_copy)
     elif (format_in == 3):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_vned_N_copy, self.gps_vned_E_copy, self.gps_vned_D_copy, self.gps_speed_copy, self.gps_grnd_speed_copy, self.gps_heading_copy, self.gps_speed_acc_copy, self.gps_heading_acc_copy, self.flags_81_05_copy)
     elif (format_in == 4):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_pos_ecef_x_copy, self.gps_pos_ecef_y_copy, self.gps_pos_ecef_z_copy, self.gps_pos_ecef_UC_copy, self.flags_81_04_copy)
     elif (format_in == 5):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_vel_ecef_x_copy, self.gps_vel_ecef_y_copy, self.gps_vel_ecef_z_copy, self.gps_vel_ecef_UC_copy, self.flags_81_06_copy)
     elif (format_in == 6):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.geom_dop_copy, self.pos_dop_copy, self.horiz_dop_copy, self.vert_dop_copy, self.time_dop_copy, self.northing_dop_copy, self.easting_dop_copy, self.flags_81_07_copy)
     elif (format_in == 7):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.gps_clock_bias_copy, self.gps_clock_drift_copy, self.gps_clock_acc_estimate_copy, self.flags_81_0a_copy)
     elif (format_in == 8):
         return '{:-d},{:-d},{:-d},{:-d},'.format(self.gps_hw_status_sensor_state_copy, self.gps_hw_status_antenna_state_copy, self.gps_hw_status_antenna_power_copy, self.flags_81_0d_copy)
     elif (format_in == 9):
         return '{:-d},{:-d},{:-d},{:-d},'.format(self.gps_fix_type_copy, self.gps_nbr_of_svs_used_copy, self.gps_fix_flags_copy, self.flags_81_0b_copy)
     elif (format_in == 10):
         return '{:-4d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},'.format(self.utc_yr_copy, self.utc_mo_copy, self.utc_day_copy, self.utc_hr_copy, self.utc_min_copy, self.utc_sec_copy, self.utc_msec_copy, self.flags_81_08_copy)
     elif (format_in == 11):
         # return '{:-u},{:-u},{:-2u},{:-2d},{:-2d},{:-2u},{:-2u},'.format(self.channel_nbr_copy, self.sv_id_copy, self.carrier_to_noise_ratio_copy, self.azimuth_copy, self.elevation_copy, self.sv_flags_copy, self.flags_81_0c_copy)
         ret_str = ''
         for sv in sv_data_struct_array_copy:
            ret_str += '{:-d},{:-d},{:-2d},{:-2d},{:-2d},{:-2d},{:-2d},'.format(sv.channel_nbr, sv.sv_id, sv.carrier_to_noise_ratio, sv.azimuth, sv.elevation, sv.sv_flags, sv.flags_81_0c)
         
         return ret_str

     return 'GPS_format'

 def format_header(self, format_in):
     if (format_in == 1):
         return 'GPS TFlags,GPS Week,GPS TOW,'
     elif (format_in == 2):
         return 'Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],'
     elif (format_in == 3):
         return 'Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],'
     elif (format_in == 4):
         return 'ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],'
     elif (format_in == 5):
         return 'ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],'
     elif (format_in == 6):
         return 'Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],'
     elif (format_in == 7):
         return 'Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],Flags [x810A],'
     elif (format_in == 8):
         return 'HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D],'
     elif (format_in == 9):
         return 'GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B],'
     elif (format_in == 10):
         return 'UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],'
     elif (format_in == 11):
         ret_str = ''
         for sv in sv_data_struct_array:
            ret_str += 'Channel Nbr [x810C],SV ID [x810C],C/N Ratio [x810C],Azimuth [x810C],Elevation [x810C],SV Flags [x810C],Flags [x810C],'
         
         return ret_str
   
     return 'GPS_format_header'

 def format_channel_name(self, format_in):
     if (format_in == 1):
         return ['GPS_TFlags', 'GPS_Week', 'GPS_TOW']
     elif (format_in == 2):
         return ['Lat_x8103', 'Lon_x8103', 'Height_x8103', 'MSL_Height_x8103', 'Horz_Acc_x8103', 'Vert_Acc_x8103', 'Flags_x8103']
     elif (format_in == 3):
         return ['Vel_N_x8105', 'Vel_E_x8105', 'Vel_D_x8105', 'Speed_x8105', 'Gnd_Speed_x8105', 'Heading_x8105', 'Speed_Acc_x8105', 'Heading_Acc_x8105', 'Flags_x8105']
     elif (format_in == 4):
         return ['ECEF_X_x8104', 'ECEF_Y_x8104', 'ECEF_Z_x8104', 'ECEF_Acc_x8104', 'Flags_x8104']
     elif (format_in == 5):
         return ['ECEF_Vel_X_x8106', 'ECEF_Vel_Y_x8106', 'ECEF_Vel_Z_x8106', 'ECEF_Vel_Acc_x8106', 'Flags_x8106']
     elif (format_in == 6):
         return ['Geo_DOP_x8107','Pos_DOP_x8107','Hor_DOP_x8107','Vert_DOP_x8107','Time_DOP_x8107','Northing_DOP_x8107','Easting_DOP_x8107','Flags_x8107']
     elif (format_in == 7):
         return ['Clock_Bias_x810A','Clock_Drift_x810A','Clock_Acc_x810A','Flags_x810A']
     elif (format_in == 8):
         return ['HW_Sensor_Stat_x810D','HW_Ant_Stat_x810D','HW_Ant_Pwr_x810D','Flags_x810D']
     elif (format_in == 9):
         return ['GPS_Fix_x810B','GPS_SVs_Used_x810B','GPS_Fix_Flags_x810B','Flags_x810B']
     elif (format_in == 10):
         return ['UTC_Year_x8108', 'UTC_Month_x8108', 'UTC_Day_x8108', 'UTC_Hour_x8108', 'UTC_Minute_x8108', 'UTC_Second_x8108', 'UTC_Millisecond_x8108', 'Flags_x8108']
     elif (format_in == 11):
         return ['Channel_Nbr_x810C', 'SV_ID_x810C', 'C/N_Ratio_x810C', 'Azimuth_x810C', 'Elevation_x810C', 'SV_Flags_x810C', 'Flags_x810C']

     return []

 def format_channel_value(self, format_in):
     if (format_in == 1):
         return [self.flags_81_09, self.gps_week, self.gps_tow]
     elif (format_in == 2):
         return [self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc, self.flags_81_03]
     elif (format_in == 3):
         return [self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc, self.flags_81_05]
     elif (format_in == 4):
         return [self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC, self.flags_81_04]
     elif (format_in == 5):
         return [self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC, self.flags_81_06]
     elif (format_in == 6):
         return [self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop, self.flags_81_07]
     elif (format_in == 7):
         return [self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate, self.flags_81_0a]
     elif (format_in == 8):
         return [self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power, self.flags_81_0d]
     elif (format_in == 9):
         return [self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags, self.flags_81_0b]
     elif (format_in == 10):
         return [self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec, self.utc_msec, self.flags_81_08]
     elif (format_in == 11):
         return [self.channel_nbr, self.sv_id, self.carrier_to_noise_ratio, self.azimuth, self.elevation, self.sv_flags, self.flags_81_0c]
   
     return []

 def format_channel_value_from_copy(self, format_in):
     if (format_in == 1):
         return [self.flags_81_09_copy, self.gps_week_copy, self.gps_tow_copy]
     elif (format_in == 2):
         return [self.gps_lat_copy, self.gps_lon_copy, self.gps_ht_abv_ellip_copy, self.gps_ht_abv_MSL_copy, self.gps_horiz_acc_copy, self.gps_vert_acc_copy, self.flags_81_03_copy]
     elif (format_in == 3):
         return [self.gps_vned_N_copy, self.gps_vned_E_copy, self.gps_vned_D_copy, self.gps_speed_copy, self.gps_grnd_speed_copy, self.gps_heading_copy, self.gps_speed_acc_copy, self.gps_heading_acc_copy, self.flags_81_05_copy]
     elif (format_in == 4):
         return [self.gps_pos_ecef_x_copy, self.gps_pos_ecef_y_copy, self.gps_pos_ecef_z_copy, self.gps_pos_ecef_UC_copy, self.flags_81_04_copy]
     elif (format_in == 5):
         return [self.gps_vel_ecef_x_copy, self.gps_vel_ecef_y_copy, self.gps_vel_ecef_z_copy, self.gps_vel_ecef_UC_copy, self.flags_81_06_copy]
     elif (format_in == 6):
         return [self.geom_dop_copy, self.pos_dop_copy, self.horiz_dop_copy, self.vert_dop_copy, self.time_dop_copy, self.northing_dop_copy, self.easting_dop_copy, self.flags_81_07_copy]
     elif (format_in == 7):
         return [self.gps_clock_bias_copy, self.gps_clock_drift_copy, self.gps_clock_acc_estimate_copy, self.flags_81_0a_copy]
     elif (format_in == 8):
         return [self.gps_hw_status_sensor_state_copy, self.gps_hw_status_antenna_state_copy, self.gps_hw_status_antenna_power_copy, self.flags_81_0d_copy]
     elif (format_in == 9):
         return [self.gps_fix_type_copy, self.gps_nbr_of_svs_used_copy, self.gps_fix_flags_copy, self.flags_81_0b_copy]
     elif (format_in == 10):
         return [self.utc_yr_copy, self.utc_mo_copy, self.utc_day_copy, self.utc_hr_copy, self.utc_min_copy, self.utc_sec_copy, self.utc_msec_copy, self.flags_81_08_copy]
     elif (format_in == 11):
         return [self.channel_nbr_copy, self.sv_id_copy, self.carrier_to_noise_ratio_copy, self.azimuth_copy, self.elevation_copy, self.sv_flags_copy, self.flags_81_0c_copy]

     return []

 #copy attributes function
 def copy(self):
   """Copy attributes function"""

   [self.gps_tow_copy, self.gps_week_copy, self.flags_81_09_copy] = [self.gps_tow, self.gps_week, self.flags_81_09]
   [self.gps_lat_copy, self.gps_lon_copy, self.gps_ht_abv_ellip_copy, self.gps_ht_abv_MSL_copy, self.gps_horiz_acc_copy, self.gps_vert_acc_copy, self.flags_81_03_copy] = [self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc, self.flags_81_03]
   [self.gps_vned_N_copy, self.gps_vned_E_copy, self.gps_vned_D_copy, self.gps_speed_copy, self.gps_grnd_speed_copy, self.gps_heading_copy, self.gps_speed_acc_copy, self.gps_heading_acc_copy, self.flags_81_05_copy] = [self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc, self.flags_81_05]
   [self.gps_pos_ecef_x_copy, self.gps_pos_ecef_y_copy, self.gps_pos_ecef_z_copy, self.gps_pos_ecef_UC_copy, self.flags_81_04_copy] = [self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC, self.flags_81_04]
   [self.gps_vel_ecef_x_copy, self.gps_vel_ecef_y_copy, self.gps_vel_ecef_z_copy, self.gps_vel_ecef_UC_copy, self.flags_81_06_copy] = [self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC, self.flags_81_06]
   [self.gps_fix_type_copy, self.gps_nbr_of_svs_used_copy, self.gps_fix_flags_copy, self.flags_81_0b_copy] = [self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags, self.flags_81_0b]
   [self.gps_clock_bias_copy, self.gps_clock_drift_copy, self.gps_clock_acc_estimate_copy, self.flags_81_0a_copy] = [self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate, self.flags_81_0a]
   [self.gps_hw_status_sensor_state_copy, self.gps_hw_status_antenna_state_copy, self.gps_hw_status_antenna_power_copy, self.flags_81_0d_copy] = [self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power, self.flags_81_0d]
   [self.geom_dop_copy, self.pos_dop_copy, self.horiz_dop_copy, self.vert_dop_copy, self.time_dop_copy, self.northing_dop_copy, self.easting_dop_copy, self.flags_81_07_copy] = [self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop, self.flags_81_07]
   [self.utc_yr_copy, self.utc_mo_copy, self.utc_day_copy, self.utc_hr_copy, self.utc_min_copy, self.utc_sec_copy, self.utc_msec_copy, self.flags_81_08_copy] = [self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec, self.utc_msec, self.flags_81_08]
   [self.channel_nbr_copy, self.sv_id_copy, self.carrier_to_noise_ratio_copy, self.azimuth_copy, self.elevation_copy, self.sv_flags_copy, self.flags_81_0c_copy] = [self.channel_nbr, self.sv_id, self.carrier_to_noise_ratio, self.azimuth, self.elevation, self.sv_flags, self.flags_81_0c]
   self.sv_data_struct_array_copy = []
   for sv in self.sv_data_struct_array:
      self.sv_data_struct_array_copy.append(sv)
