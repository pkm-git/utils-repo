import numpy

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

# Create ambient pressure array (in bar)
ambient_name_array = ['Name1', 'Name2', 'Name3', 'Name4', 'Name5', 'Name6', 'Name7', 'Name8', 'Name9', 'Name10', 'Name11', 'Name12', 'Name13', 'Name14', 'Name15', 'Name16', 'Name17', 'Name18', 'Name19', 'Name20', 'Name21', 'Name22', 'Name23', 'Name24']

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]

# Create ambient pressure array (in bar)
ambient_pressure_array2 = [4.0133, 5.9949, 5.9763, 5.9591, 6.9419, 6.9246, 6.9081, 6.8915, 6.8749, 7.8591, 7.8433, 7.8122, 7.7819, 8.7522, 8.7240, 8.6964, 8.5716, 9.4661, 9.3765, 9.3013, 10.2393, 10.1882, 10.1482, 10.1165]

ambient_pressure = 0
llh_ht = 978
altitude_prev = 0
altitude = 0

# channel_data = {sensor_name:{}}
# channel_data[sensor_name][total_channel_cnt] = []
# index_range_array.append(total_channel_cnt)
# channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)

# Matrix = [[0 for y in xrange(5)] for x in xrange(2)]
# Matrix[1][4] = 2 # valid

# alt_pr_2d_array = [[]]
# alt_pr_2d_array = [[0 for y in xrange(4)] for x in xrange(2)]

alt_pr_2d_array = {}

# for altitude_array_index in range(len(altitude_array[0:4])):
for altitude_array_index in range(len(altitude_array)):
   alt_pr_2d_array[altitude_array[altitude_array_index]] = [ambient_name_array[altitude_array_index], ambient_pressure_array[altitude_array_index]]
   # alt_pr_2d_array[altitude_array[altitude_array_index]] = ambient_pressure_array[altitude_array_index]

print(' ********* after adding, len(alt_pr_2d_array) = ' + str(len(alt_pr_2d_array)) + ' len(alt_pr_2d_array[0]) = ' + str(len(alt_pr_2d_array[0])) )

# for index in range(len(alt_pr_2d_array)):
for altitude_array_index in range(len(altitude_array[0:4])):
   print(' *********** altitude_array_index = ' + str(altitude_array_index) + ' altitude_array[altitude_array_index] = ' + str(altitude_array[altitude_array_index]) + ' alt_pr_2d_array[altitude_array[altitude_array_index]] = ' + str(alt_pr_2d_array[altitude_array[altitude_array_index]]))

# row = [0, 1.0133]
# alt_pr_2d_array.append(row)

# row = [153, 0.9949]
# alt_pr_2d_array.append(row)

# row = [305, 0.9763]
# alt_pr_2d_array.append(row)

# row = [458, 0.9591]
# alt_pr_2d_array.append(row)

# print( ' ****** len(alt_pr_2d_array[0]) = ' + str(len(alt_pr_2d_array[0])))
# print( ' ****** len(alt_pr_2d_array) = ' + str(len(alt_pr_2d_array)))

# for i in range(len(alt_pr_2d_array[0])):
   # for j in range(len(alt_pr_2d_array)):
      # print(' ************ alt_pr_2d_array[i][j] = ' + str(alt_pr_2d_array[i][j]))

# for altitude_array_index in range(len(altitude_array[0:4])):
# for altitude_array_index in range(len(altitude_array)):
   # altitude = numpy.int32(altitude_array[altitude_array_index])
   # print(' *********** altitude_array_index = ' + str(altitude_array_index) + ' altitude = ' + str(altitude))
   


