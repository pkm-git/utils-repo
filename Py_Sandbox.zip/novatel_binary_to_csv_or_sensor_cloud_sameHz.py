import sys
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from novatel_csv_format import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

from sensor_cloud_api import *

import numpy
import os
import re

NBR_OF_LEAP_SECONDS = 17 # (as of July 2016)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

def novatel_binary_to_csv_or_sensor_cloud_fn(in_file_name, destination, output_category = None, server = None, token = None, device_id = None, sensor_name = None, sensor_label = None, sampleRate = 0, sampleRateType = HERTZ):

   print('\n------------------------------------------------------------------')

   short_header_length = 12
   long_header_length = 28

   # Grouping of Messages:

   # ----------
   # EKF Group:
   # ----------
   # 42: BESTPOS
   # 99: BESTVEL
   # 241: BESTXYZ

   # --------------------------------------------
   # INS Group: [Long/Short Header Message Pairs]
   # --------------------------------------------
   # 263: INSATT
   # 319: INSATTS

   # 265: INSPOS
   # 321: INSPOSS

   # 266: INSSPD
   # 323: INSSPDS

   # 267: INSVEL
   # 324: INSVELS

   # 507: INSPVA
   # 508: INSPVAS

   # -------------
   # RAWIMU Group:
   # -------------
   # 268: RAWIMU
   # 325: RAWIMUS

   # ----------
   # GPS Group:
   # ----------
   # 101: TIME (UTC-related)

   # Message Id 642 not included in output because it's GPS TOW is invalid

   # 642: VEHICLEBODYROTATION

   # Define "Master columns" (i.e. subset, consisting of 'minimum' or 'important' columns in DCP) in a "master sequence"
   min_gps_default_cols_dict = {321:1, 42:2, 324:3, 323:4, 99:5, 241:6, 319:7, 508:8, 325:9, 101:10, 642:11}

   # Map message id's of long header messages to message id of corresponding short header message (and use only the short header msg id beyond that point)
   min_gps_default_long2shorthdr_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

   out_type_file_name_dict = {'i':"INS_Log.csv", 'e':"EKF_Log.csv", 'r':"RAWIMU_Log.csv", 'g':"GPS_Log.csv"}
   output_category_dict = {'i':"INS", 'e':"EKF", 'r':"RAWIMU", 'g':"GPS"}

   gyro_scale_factor = 0.1/(3600.0 * 256.0)
   accel_scale_factor = 0.05/(2**15)

   print('**************** in Novatel binary to csv or sensor cloud fn ************* ')

   # if arguments sent in were not properly specified, tell the user and exit
   if (in_file_name == None or (output_category != None and output_category not in ['i', 'e', 'r', 'g'])):
      print('Input file name cannot be empty and output_category must be one of: i, e, r, g')
      sys.exit()

   sensStatus = 0
   if (destination != None):
      if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
         if (sensor_name == None):
            print(' ***** Must provide valid Sensor Name for Sensor Cloud Upload')
            sys.exit()
         else:
            # Spaces not allowed in Sensor Name, replace with _:
            sensor_name.strip().replace(" ", "_")
            sensor_name.replace("/", "_")

            # All characters other than (AlphaNumeric, _, -, and .): Replace with empty char:
            sensor_name = re.sub(r'[^a-zA-Z0-9_.-]', r'', sensor_name)

            if(sensor_label != None):
               sensStatus = addSensor(server, token, device_id, sensor_name, "", sensor_label)
            else:
               sensStatus = addSensor(server, token, device_id, sensor_name)

            print(' ********** addSensor: status = ' + str(sensStatus))
         # } if (sensor_name == None)..
      # } if (destination.upper() == 'CLOUD'..
      if (destination.upper() != 'CSV' and destination.upper() != 'CLOUD' and destination.upper() != 'BOTH'):
         print(' ******* Destination must be either CSV, CLOUD or BOTH (case-insensitive) ********')
         sys.exit()
      # } if (destination.upper() != 'CSV'..
   else:
      print(' ******* Destination cannot be None; must be CSV, CLOUD or BOTH (case-insensitive) ********')
      sys.exit()
   # } if (destination != None)..

   # Create an array of output categories (INS, EKF, RAWIMU, GPS)
   out_category_array = []

   if (output_category == None):
      out_category_array.append('i')  # INS (INSATT, INSPOS, INSVEL, INSPVA)
      out_category_array.append('e')  # EKF (BESTPOS, BESTVEL, BESTXYZ)
      out_category_array.append('r')  # RAWIMU
      out_category_array.append('g')  # GPS (TIME)
   else:
      out_category_array.append(output_category)

   # Loop thro binary input file for each output category (INS, EKF, RAWIMU and GPS):
   for output_category in out_category_array:
      print(' ******************************************************* ')
      print(' **************** output_category = ' + output_category_dict[output_category])
      print(' ******************************************************* ')

      # Array of channel names and channel data to send to Sensor Cloud (for this output_category)
      channel_names = []
      channel_data = {sensor_name:{}}

      # Dictionary to store array of range of indices of channels by message master sequence index
      channel_index_range_dict = {}

      # Array to store the order of columns requested by the user:
      gps_output_order = []

      # Add GPS Week, GPS TOW for every category
      gps_output_order.append(0)

      no_desc_list_supplied_gps_headers_printed = False

      csv_format_obj = Novatel_CSV_format()

      fin_bin = open(in_file_name, "rb")

      if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
         out_file_name = out_type_file_name_dict[output_category]

         (fin_filepath, fin_filename) = os.path.split(in_file_name)
         fout_gps = open(os.path.join(fin_filepath, out_file_name), "w")

      message_id_array = []
      if (output_category == 'i'):
         message_id_array = [321, 323, 324, 319, 508]
      elif (output_category == 'g'):
         message_id_array = [101]
      elif (output_category == 'e'):
         message_id_array = [42, 99, 241]
      elif (output_category == 'r'):
         message_id_array = [325]

      total_channel_cnt = 0

      k_start = 0
      packet_cnt = 0

      bytes_read = fin_bin.read();

      print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

      for k in range(0, len(bytes_read)):
         if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])) == '44' and \
            (hexlify(bytearray(bytes_read[k+2])) == '12' or hexlify(bytearray(bytes_read[k+2])) == '13')):
            print(' ***** Found first SYNC BYTE trio (AA 44 12 or AA 44 13) at byte index: ' + str(k) + '\n')
            k_start = k;
            break;

      packet_size = 0
      bad_packets = 0

      message_length = 0
      k = k_start

      message_cnt = 0
      packet_set_cnt = 1
      [temp_week, temp_tow_ms, temp_tow_ms_prev, crc_length] = [0,0,0,4]
      [message_id, port_address, sequence, idle_time, time_status, rcvr_status, res1, res2] = [0,0,0,0,0,0,0,0]

      [temp_soln_status, temp_pos_type, res3, res4, res5, sig_mask, temp_ext_sol_status] = [0,0,0,0,0,0,0]
      [temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age] = [0,0,0,0,0,0]
      [temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used] = [0,0,0,0,0]

      [gps_week, gps_tow] = [0,0]
      [ins_vned_N, ins_vned_E, ins_vned_D] = [0,0,0]
      [gps_lat, gps_lon, gps_ht_ellip] = [0,0,0]
      [temp_ins_lat, temp_ins_lon, temp_ins_ht_abv_ellips, temp_ins_vned_N, temp_ins_vned_E, temp_ins_vned_D, temp_roll, temp_pitch, temp_azimuth, temp_ins_status] = [0,0,0,0,0,0,0,0,0,0]
      [temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_heading] = [0,0,0,0,0]

      # Look for beginning of a valid Novatel packet (Bytes: 0xAA4412):
      while (k < len(bytes_read)):
        # print('********  k = ' + str(k))

        if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])).upper() == '44'):
           # print(' ********* packet_cnt = ' + str(packet_cnt))

           if (hexlify(bytearray(bytes_read[k+2])).upper() == '12'): # Long header
              packet_cnt += 1

              # print(' ********* LONG header')

              [header_length] = unpack('<B', bytearray(bytes_read[k+3]))
              [message_length] = unpack('<H', bytearray(bytes_read[k+8:k+10]) )

              # Parse the remaining part of header:
              [message_id, csv_format_obj.message_type, port_address, csv_format_obj.message_length, sequence, idle_time, time_status, temp_week, temp_tow_ms, rcvr_status, res1, res2] = unpack('<HbBHHBBHLLHH', bytearray(bytes_read[k+4:k+header_length]) )

              # Revert the GPS TOW if it is the VEHICLEBODYROTATION message (because it's GPS TOW is invalid)
              if (message_id == 642):
                 temp_tow_ms = temp_tow_ms_prev
              else:
                 csv_format_obj.gps_week = temp_week

           elif (hexlify(bytearray(bytes_read[k+2])).upper() == '13'): # Short header
              packet_cnt += 1

              # print(' ********* SHORT header')

              # Check if it is a message with short header (in this case, message_length becomes equal to header_length read before):
              [message_length] = unpack('<B', bytearray(bytes_read[k+3]))
              header_length = short_header_length

              # Parse the remaining part of header:
              [message_id, csv_format_obj.gps_week, temp_tow_ms] = unpack('<HHL', bytearray(bytes_read[k+4:k+header_length]) )
           else:
              k = k + 1
              continue
           # } if (hexlify(bytearray(bytes_read[k+2])).upper() == '12')..

           csv_format_obj.gps_tow = temp_tow_ms/1000.0

           if (message_id in message_id_array):
              # If GPS TOW changed, a new packet set begins. So, print current packet set to csv and/or add channel data for Sensor Cloud, before
              # setting the new packet set values:
              if (temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms and temp_tow_ms > temp_tow_ms_prev):
                 # First time in, create csv headers and/or channel names:
                 if (no_desc_list_supplied_gps_headers_printed == False):
                    gps_output_order.sort()

                    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                       fout_gps.write('DATA_START\n')
                    for gps_output_index in range(len(gps_output_order)):
                       input_index = gps_output_order[gps_output_index]
                       if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                          fout_gps.write(csv_format_obj.format_header(input_index, output_category))
                       if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                          tmp_channel_name_array = csv_format_obj.format_channel_name(input_index, output_category)

                          index_range_array = []

                          for c in tmp_channel_name_array:
                             channel_names.append(c)
                             chStatus = addChannel(server, token, device_id, sensor_name, c)
                             channel_data[sensor_name][total_channel_cnt] = []
                             index_range_array.append(total_channel_cnt)

                             total_channel_cnt += 1
                          # } for c in tmp_channel_name_array..

                          # print('\n ******** gps_output_index = ' + str(gps_output_index) + ', input_index = ' + str(input_index) + ', adding index_range_array of len = ' + str(len(index_range_array)))
                          # for j in index_range_array:
                              # print(' ***** j in index_range_array = ' + str(j))

                          # print('\n')

                          channel_index_range_dict[input_index] = index_range_array

                       # } if (destination.upper() == 'CLOUD'..
                    # } for gps_output_index in range(len(gps_output_order))..

                    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                       fout_gps.write('\n')

                    no_desc_list_supplied_gps_headers_printed = True
                 # } if (no_desc_list_supplied_gps_headers_printed == False)..

                 # Print values of previous packet set, before updating 'csv_format_obj' with new set of values:
                 input_index = 0
                 for gps_output_index in range(len(gps_output_order)):
                    input_index = gps_output_order[gps_output_index]
                    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                       fout_gps.write(csv_format_obj.format(input_index, output_category))
                    if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                       gps_week = int(csv_format_obj.gps_week)
                       gps_tow = numpy.double(csv_format_obj.gps_tow)

                       gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                       utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                       # Convert UTC sec from UTC Epoch into unix nanosecond time
                       ts = utc_sec_from_utc_epoch * 1000000000

                       tmp_channel_value_array = csv_format_obj.format_channel_value(input_index, output_category)

                       tmp_channel_index_range_array = channel_index_range_dict[input_index]

                       indx = 0

                       # print(' ******** gps_tow = ' + str(gps_tow) + ', gps_output_index = ' + str(gps_output_index) + ', input_index = ' + str(input_index) + ', len(tmp_channel_value_array) = ' + str(len(tmp_channel_value_array)) + ', len(tmp_channel_index_range_array) = ' + str(len(tmp_channel_index_range_array)) )

                       # for j in tmp_channel_index_range_array:
                          # print(' ***** j in tmp_channel_index_range_array = ' + str(j))

                       for c in tmp_channel_value_array:
                          try:
                             ch = channel_data_struct()
                             ch.ts = numpy.int64(ts)
                             ch.value = float(c)
                             channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                          except ValueError as err:
                             print(" ******** ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " gps_tow: " + str(gps_tow) + " 0-based column index = " + str(indx) + ", Channel Name: " + channel_names[tmp_channel_index_range_array[indx]] + ", Value = " + c + ", Error Msg: {0}".format(err))

                          indx = indx + 1
                       # } for c in tmp_channel_value_array..
                    # } if (destination.upper() == 'CLOUD'..
                 # } for gps_output_index in range(len(gps_output_order))..

                 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                    fout_gps.write('\n')

                 # Track the number of 'packet sets' (i.e. set of Novatel packets at same GPS Timestamp)
                 packet_set_cnt = packet_set_cnt + 1

              # } if (temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms)..

              # Add index of Message ID to final output order array.  If Message has a long header, convert to equivalent short header message ID.
              # Include only those message ID's that are in 'min_gps_default_cols_dict' or 'min_gps_default_long2shorthdr_cols_dict' and not already added to 'gps_output_order':
              if (packet_set_cnt == 1 and (message_id in min_gps_default_cols_dict or (message_id in min_gps_default_long2shorthdr_cols_dict))):
                 if (message_id in min_gps_default_long2shorthdr_cols_dict):
                    message_id = min_gps_default_cols_dict[min_gps_default_long2shorthdr_cols_dict[message_id]]

                 index = min_gps_default_cols_dict[message_id]
                 print(' *********** packet_set_cnt = 1, adding message_id: ' + str(message_id) + ', index = ' + str(index) + ', temp_tow_ms = ' + str(temp_tow_ms))

                 # Exclude indices of Message ID's already added to 'gps_output_order':
                 if (index not in gps_output_order):
                    gps_output_order.append(index)
                 else:
                    print(' ************ DID NOT add to gps_output_order because index already in it' )
                 # } if (index not in gps_output_order)..
              # } if (packet_set_cnt == 1)..

              message_cnt = message_cnt + 1

              full_message_bytes = bytearray( bytes_read[k:k+message_length+header_length+crc_length] )
              message_bytes = bytearray( bytes_read[k+header_length:k+header_length+message_length] )

              if (message_id == 319):  # INSATTS [INS Attitude]
                 [temp_gps_week, temp_tow_ms2, csv_format_obj.roll, csv_format_obj.pitch, csv_format_obj.azimuth, csv_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

              elif (message_id == 42):   # BESTPOS [GPS/INS Blended Position]
                 [temp_soln_status, temp_pos_type, csv_format_obj.ekf_lat, csv_format_obj.ekf_lon, csv_format_obj.ekf_ht_abv_MSL, csv_format_obj.undulation, temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfIfffIffBBBBBBBB', message_bytes )

              elif (message_id == 321):   # INSPOSS [INS Position]
                 [temp_gps_week, temp_tow_ms2, csv_format_obj.ins_lat, csv_format_obj.ins_lon, csv_format_obj.ins_ht_abv_ellip, csv_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

              elif (message_id == 508):   # INSPVAS [INS Position, Velocity and Attitude]
                 [temp_gps_week, temp_tow_ms2, csv_format_obj.ins_pva_lat, csv_format_obj.ins_pva_lon, csv_format_obj.ins_pva_ht_abv_ellips, csv_format_obj.ins_pva_vned_N, csv_format_obj.ins_pva_vned_E, csv_format_obj.ins_pva_vned_D, csv_format_obj.ins_pva_roll, csv_format_obj.ins_pva_pitch, csv_format_obj.ins_pva_azimuth, temp_ins_status] = unpack('<LddddddddddI', bytearray(message_bytes) )

              elif (message_id == 101):   # TIME
                 [csv_format_obj.rcvr_clock_status, csv_format_obj.rcvr_clock_offset, csv_format_obj.rcvr_clock_offset_sd, csv_format_obj.utc_offset, csv_format_obj.utc_year, csv_format_obj.utc_month, csv_format_obj.utc_day, csv_format_obj.utc_hour, csv_format_obj.utc_min, csv_format_obj.utc_ms, csv_format_obj.utc_status] = unpack('<IdddLBBBBLI', bytearray(message_bytes) )

              elif (message_id == 99):   # BESTVEL [GPS/INS Blended Velocity]
                 [temp_soln_status, temp_vel_type, csv_format_obj.ekf_latency, csv_format_obj.diff_age, csv_format_obj.ekf_horiz_speed, csv_format_obj.ekf_grnd_trc, csv_format_obj.ekf_vert_speed, res5] = unpack('<IIffdddf', bytearray(message_bytes) )

              elif (message_id == 241):   # BESTXYZ [GPS/INS ECEF Position/Velocity]
                 [csv_format_obj.p_sol_status, csv_format_obj.pos_type, csv_format_obj.ecef_pos_x, csv_format_obj.ecef_pos_y, csv_format_obj.ecef_pos_z, csv_format_obj.ecef_pos_x_sd, csv_format_obj.ecef_pos_y_sd, csv_format_obj.ecef_pos_z_sd, csv_format_obj.v_sol_status, csv_format_obj.vel_type, csv_format_obj.ecef_vel_x, csv_format_obj.ecef_vel_y, csv_format_obj.ecef_vel_z, csv_format_obj.ecef_vel_x_sd, csv_format_obj.ecef_vel_y_sd, csv_format_obj.ecef_vel_z_sd, temp_base_station_id, csv_format_obj.vel_time_latency, temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfffIIdddfffIfffBBBBbbbb', bytearray(message_bytes) )

              elif (message_id == 324):   # INSVELS [INS NED Velocity]
                 [temp_gps_week, temp_tow_ms2, csv_format_obj.ins_vned_N, csv_format_obj.ins_vned_E, csv_format_obj.ins_vned_D, csv_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

              elif (message_id == 323):   # INSSPDS [INS Speed]
                 [temp_gps_week, temp_tow_ms2, csv_format_obj.ins_grnd_trc, csv_format_obj.ins_horiz_speed, csv_format_obj.ins_vert_speed, csv_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

              elif (message_id == 325):   # RAWIMUS [IMU Raw values]
                 [temp_gps_week, temp_tow_ms2, csv_format_obj.imu_status, temp_z_accel, temp_y_accel, temp_x_accel, temp_z_gyro, temp_y_gyro, temp_x_gyro] = unpack('<Ldlllllll', bytearray(message_bytes) )

                 csv_format_obj.z_accel = temp_z_accel * accel_scale_factor
                 csv_format_obj.y_accel = -temp_y_accel * accel_scale_factor
                 csv_format_obj.x_accel = temp_x_accel * accel_scale_factor

                 csv_format_obj.z_gyro = temp_z_gyro * gyro_scale_factor
                 csv_format_obj.y_gyro = -temp_y_gyro * gyro_scale_factor
                 csv_format_obj.x_gyro = temp_x_gyro * gyro_scale_factor
              # } if (message_id == 319)..

              temp_tow_ms_prev = temp_tow_ms

           # } if (message_id in message_id_array) ..

           # ************* TEST ONLY **********************
           # if (packet_set_cnt == 15):
              # return

           k = k + header_length + message_length + crc_length

        else:
           k = k + 1
        # } if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and..
      # } while (k < len(bytes_read))..

      # Print the last set of values from the 'csv_format_obj', because there won't be another change in GPS Time at this point:
      # if (packet_set_cnt >= 2):
      input_index = 0
      for gps_output_index in range(len(gps_output_order)):
         input_index = numpy.int32(gps_output_order[gps_output_index])
         if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
            fout_gps.write(csv_format_obj.format(input_index))
         if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
            gps_week = int(csv_format_obj.gps_week)
            gps_tow = numpy.double(csv_format_obj.gps_tow)

            gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
            utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

            # Convert UTC sec from UTC Epoch into unix nanosecond time
            ts = utc_sec_from_utc_epoch * 1000000000

            tmp_channel_value_array = csv_format_obj.format_channel_value(input_index, output_category)

            tmp_channel_index_range_array = channel_index_range_dict[input_index]

            indx = 0
            for c in tmp_channel_value_array:
               try:
                  ch = channel_data_struct()
                  ch.ts = numpy.int64(ts)
                  ch.value = float(c)
                  channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
               except ValueError as err:
                  print(" ******** Last Set: ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " gps_tow: " + str(gps_tow) + " 0-based column index = " + str(indx) + ", Channel Name: " + channel_names[tmp_channel_index_range_array[indx]] + ", Value = " + c + ", Error Msg: {0}".format(err))

               indx = indx + 1
            # } for c in tmp_channel_value_array..
         # } if (destination.upper() == 'CLOUD'..
      # } for gps_output_index in..

      if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
         fout_gps.write('\n')
      # } if (packet_set_cnt >= 2)..

      print('\n------------------------------------------------------------------')

      print ('\n************* output_category = ' + output_category_dict[output_category] + ', Total nbr of Novatel packets: ' + str(message_cnt) + ', Nbr of Packet Sets = ' + str(packet_set_cnt))

      print('\n------------------------------------------------------------------')

      if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
         fout_gps.close()
      if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
         print("******* Novatel Binary to Sensor Cloud: len(channel_data[sensor_name]) = " + str(len(channel_data[sensor_name])))

         # Upload one column (channel) at a time to Sensor Cloud:
         for index in range(len(channel_data[sensor_name])):
            print(' *********** index = ' + str(index) + ' channel_names[index] = ' + channel_names[index] + ' len(channel_data[sensor_name][index]) = ' + str(len(channel_data[sensor_name][index])))

            channel_data_list = channel_data[sensor_name][index]

            addTimeSeriesData(server, token, device_id, sensor_name, channel_names[index], sampleRate, sampleRateType, channel_data_list)
      # } if (destination.upper() == 'CLOUD'..

      fin_bin.close()
   # } for output_category in out_category_array..

if(__name__ == "__main__"):
  main_line(sys.argv)




