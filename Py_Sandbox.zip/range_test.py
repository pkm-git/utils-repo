# for k in range(0, 1):
for k in range(1,10,2):
  if (k == 5):
     continue
  print('*********** k = ' + str(k))

x = 0.05/(2**15)
print(' ******* x = ' + str(x))

message_id_array = [321, 323, 324, 319, 508]

message_id = 329

if (message_id in message_id_array):
   print(' ******* message_id: ' + str(message_id) + ' IS in message_id_array')
else:
   print(' ******* message_id: ' + str(message_id) + ' IS NOT in message_id_array')
