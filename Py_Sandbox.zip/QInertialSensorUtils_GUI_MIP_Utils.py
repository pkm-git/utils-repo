# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

from PyQt4 import QtCore, QtGui
# from PyQt4.QtCore import *
# from PyQt4.QtGui import *

from struct import * #import all objects and functions from the struct library
from binascii import hexlify     #function to display hexadecimal bytes as ascii text

from mip import *              #local file should be in local folder
from time import sleep         #sleep
from datetime import datetime

CMD_STREAM = 1
CMD_READ_FILTER_STREAMING_STATUS = 2

read_current_imu_streaming_command = bytearray.fromhex('75650C0404110201020F');
read_current_gps_streaming_command = bytearray.fromhex('75650C04041102020310');
read_current_filter_streaming_command = bytearray.fromhex('75650C04041102030411');

def parse_mip_packet(bytes_read, cmd_code):

   print(' ****** parse_mip_packet: Length of Bytes Read = ' + str(len(bytes_read)) + ', cmd_code = ' + str(cmd_code));

   # Find first MIP packet index
   k = 0
   foundMIP = False
   k_start = 0
   
   while(k < len(bytes_read)-1):
      if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
         print(' ***** Found first [0x75 0x65] MIP pair at byte index: ' + str(k) + '\n')
         k_start = k;
         foundMIP = True
         break;
      k = k + 1
   # } while(k < len(bytes_read))..
   
   k = k_start
   packet_cnt = 0
   command_echo = ''
   error_code = ''
   fw_version = 0
   model_name = ''
   model_nbr = ''
   serial_nbr = ''
   reserved = ''
   options = ''
   
   device_selector = 0
   current_device_enable_flag = 0
   
   while (k < len(bytes_read)):
      if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
         packet_cnt = packet_cnt + 1
 
         desc_set = hexlify( bytearray(bytes_read[k+2]) ).upper()
         [payload_size] = unpack('<B', bytearray(bytes_read[k+3]))
         packet_bytes = bytearray( bytes_read[k:k+payload_size+6] )

         # print('****** Packet Nbr: ' + str(packet_cnt) + ' Descriptor Set = ' + desc_set + ' Packet size = ' + str(payload_size) )

         mip_check_ret_code = mip_is_mip_packet(packet_bytes)
   
         # print(' ***** Called mip_is_mip_packet: mip_check_ret_code = ' + str(mip_check_ret_code))
 
         if (mip_check_ret_code != MIP_OK):
            if (mip_check_ret_code == MIP_CHECKSUM_ERROR):
               print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has Checksum error')
            elif (mip_check_ret_code == MIP_ERROR):
               print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP error')
            elif (mip_check_ret_code == MIP_INVALID_PACKET):
               print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP Invalid error')
            elif (mip_check_ret_code == MIP_PAYLOAD_LENGTH_MISMATCH_ERROR):
               print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP Payload length mismatch error: ')

               tmp_str = hexlify( bytearray(packet_bytes) ).upper()
               print(' ****** Descriptor Set = ' + desc_set + ' Packet size = ' + str(payload_size) + ', packet_bytes: '),
               for i1 in range(0,len(tmp_str),2):
                  print(tmp_str[i1] + tmp_str[i1+1]),
               print('\n')

            # } if (mip_check_ret_code == MIP_CHECKSUM_ERROR..
    
            k = k + 1
         else: # is a valid MIP packet with no errors
            # Set 'j' to beginning of first field in this packet
            j = k+MIP_HEADER_SIZE
    
            # print('**** Valid MIP Packet: Will start field while loop with j = ' + str(j) + ', payload_size = ' + str(payload_size))
    
            # Get all fields in the packet, and set attributes of appropriate format object:
            while(j < k+MIP_HEADER_SIZE+payload_size):
               [field_size] = unpack('<B', bytearray(bytes_read[j]))
               field_desc = hexlify( bytearray(bytes_read[j+1]) ).upper()
               field_bytes = bytes_read[j+2:j+field_size]
               packet_field_descr = desc_set + field_desc.upper()

               if (desc_set == '01'):  # Get Device Info...
                  if (field_desc == 'F1'):
                     [command_echo, error_code] = unpack('>BB', bytearray(field_bytes) )
                     # print(' ***** got command_echo = ' + str(command_echo) + ', error_code = ' + str(error_code))
                  elif (command_echo == 0x03 and error_code == 0 and field_desc == '81'):
                     [fw_version, model_name, model_nbr, serial_nbr, reserved, options] = unpack('>H16s16s16s16s16s', bytearray(field_bytes) )
                     # print(' ***** got fw_version = ' + str(fw_version) + ', model_name = ' + str(model_name) +', model_nbr = ' + model_nbr + ', serial_nbr = ' + serial_nbr + ', reserved = ' + reserved + ', options = ' + options)
                  # } if (field_desc == 'F1')..
               elif (desc_set == '0C'): # Enable/disable streaming...
                  if (field_desc == 'F1'):
                     [command_echo, error_code] = unpack('>BB', bytearray(field_bytes) )
                     # print(' ***** got command_echo = ' + str(command_echo) + ', error_code = ' + str(error_code))
                  elif (command_echo == 0x11 and error_code == 0 and field_desc == '85'):
                     [device_selector, current_device_enable_flag] = unpack('>BB', bytearray(field_bytes) )
                     # print(' ***** got device_selector = ' + str(device_selector) + ', current_device_enable_flag = ' + str(current_device_enable_flag))
                  # } if (field_desc == 'F1')..
               # } if (desc_set == '01')..

               j = j + field_size

            # } while(j < k+MIP_HEADER_SIZE+payload_size)..
         # } if (mip_check_ret_code != MIP_OK)..
 
         k = k + payload_size + 6
      else:
         k = k + 1
      # } if (hexlify(bytearray(bytes_read[k])) == '75' and..
   # } while (k < len(bytes_read))..

   if (cmd_code == CMD_STREAM):
      return command_echo, error_code, fw_version, model_name, model_nbr, serial_nbr, options
   elif (cmd_code == CMD_READ_FILTER_STREAMING_STATUS):
   # else:
      return device_selector, current_device_enable_flag
   # } if (cmd_code == CMD_STREAM)..
   
def get_filter_status(ComPort = None, port_name = '', baud_rate = 0):
   
   print(' ****** in get_filter_status: port_name = ' + port_name)
   
   str_filter_status = 'Not Connected'
   filter_status = 0
   
   if (ComPort == None):
      try:
         ComPort = Serial(port_name, BAUD_RATE)  # open the COM Port
 
         ComPort.bytesize = 8             # Number of data bits = 8
         ComPort.parity   = 'N'           # No parity
         ComPort.stopbits = 1             # Number of Stop bits = 1
      
         ComPort.close()
         ComPort.open()
 
      except SerialException as err:
         print(" **** SerialException: Port: " + port_name + ", Error Msg: {0}".format(err))
      # } try..
   # } if (ComPort != None)..

   ComPort.reset_input_buffer()
   ComPort.reset_output_buffer()
    
   print('****** Sending Read Current Filter command:')
   ComPort.write(read_current_filter_streaming_command)

   sleep(0.03) 
   
   filter_status_data_left = ComPort.in_waiting    # Get the number of characters ready to be read
       
   # print('****** filter_status_data_left = ' + str(filter_status_data_left))
   
   if (filter_status_data_left > 0):
      filter_status_bytes_read = ComPort.read(filter_status_data_left)
      if (filter_status_bytes_read != None):
         device_selector, filter_status = parse_mip_packet(filter_status_bytes_read, CMD_READ_FILTER_STREAMING_STATUS)
      # } if (filter_status_bytes_read == None)..
   # } if (filter_status_data_left > 0)..
   
   if (filter_status == 1):
      str_filter_status = 'Connected'
   # } if (filter_status == 1)..
   
   return str_filter_status


def get_filename(model_name, serial_nbr, folder_path = None):

   default_filename = '' 
   
   date_str = str(datetime.now())
   
   d = datetime.strptime(date_str[:-7], '%Y-%m-%d %H:%M:%S') 
   date_str = d.strftime('%Y-%m-%d %I.%M.%S %p')
   
   if (folder_path != None and folder_path.strip() != ''):
      default_filename = folder_path + '/'
   # } if (folder_path != None..
      
   default_filename += model_name + ' ' + serial_nbr + ' Data Log ' + date_str + '.bin'

   return default_filename
