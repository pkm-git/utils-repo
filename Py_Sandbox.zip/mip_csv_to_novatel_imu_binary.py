# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import csv
import sys
import numpy
import re
import os

from time import time  #import time library

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from time import sleep         #sleep

from datetime import datetime

from imu_format_using_dict import *

GYRO_SCALE_FACTOR = 360000 # arcsec/deg
ACCEL_SCALE_FACTOR = 1000000  # micro-meter/m
GRAV_ACCEL = 9.80665
RAD2DEG = 180.0 / numpy.pi

def mip_csv_to_novatel_imu_binary_fn(in_file_name, gps_week_col = 2, gps_tow_col = 3):

   if (in_file_name == None):
      print(' ***** Must provide valid input file name')
      sys.exit()
   # } if (in_file_name == None..

   in_csvfile = open(in_file_name,'rUb')
   csvreader = csv.reader(in_csvfile, delimiter=',')

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   col_header_dict = {}
   imu_8007_struct = IMU_8007_struct()
   imu_8008_struct = IMU_8008_struct()
   col_headers = []

   (fin_filepath, fin_filename) = os.path.split(in_file_name)

   fout_imu_bin = open(os.path.join(fin_filepath, fin_filename[:-4] + ".imr"), "wb")

   for row_item in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(row_item)
         print(' ******* len(row_item) = ' + str(len(row_item)) + ', n_data_columns = ' + str(n_data_columns))

         # Create a list of channel names from the headers
         for i in range(n_data_columns):
            col_header = row_item[i].strip()

            if ('x8007' in col_header.lower()):
               if ('deltatheta_x' in col_header.lower()):
                  col_header_dict['DELTA_THETA_X'] = i
               elif ('deltatheta_y' in col_header.lower()):
                  col_header_dict['DELTA_THETA_Y'] = i
               elif ('deltatheta_z' in col_header.lower()):
                  col_header_dict['DELTA_THETA_Z'] = i
            elif ('x8008' in col_header.lower()):
               if ('deltav_x' in col_header.lower()):
                  col_header_dict['DELTA_VEL_X'] = i
               elif ('deltav_y' in col_header.lower()):
                  col_header_dict['DELTA_VEL_Y'] = i
               elif ('deltav_z' in col_header.lower()):
                  col_header_dict['DELTA_VEL_Z'] = i
            # } if ('x8007' in col_header.lower())..

            col_headers.append(col_header)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

      elif (headers_found):
         data_row_cnt = data_row_cnt + 1

         if (len(row_item) > 0):
            # Default values of GPS Week column = 2, GPS TOW column = 3 (counting 1st column as column 1)
            # These defaults are valid for MIP-based csv files created from the 'Inertial Sensor Utils' Python app.
            # If GPS Week and TOW columns are different from the default, send the actual column numbers to this function (counting 1st column as column 1)
            try:
               gps_week = int(row_item[gps_week_col-1])
               gps_tow = numpy.double(row_item[gps_tow_col-1])
   
               index = 0

               # Now iterate the values for all columns
               for i in range(n_data_columns):
                  try:
                     if (i in col_header_dict.values()):
                        key = col_header_dict.keys()[col_header_dict.values().index(i)]
                        if (key == 'DELTA_THETA_X'):
                           imu_8007_struct.delta_theta_roll = float(row_item[i])
                        elif (key == 'DELTA_THETA_Y'):
                           imu_8007_struct.delta_theta_pitch = float(row_item[i])
                        elif (key == 'DELTA_THETA_Z'):
                           imu_8007_struct.delta_theta_yaw = float(row_item[i])
                        elif (key == 'DELTA_VEL_X'):
                           imu_8008_struct.delta_vel_x = float(row_item[i])
                        elif (key == 'DELTA_VEL_Y'):
                           imu_8008_struct.delta_vel_y = float(row_item[i])
                        elif (key == 'DELTA_VEL_Z'):
                           imu_8008_struct.delta_vel_z = float(row_item[i])
                        # } if (key == 'DELTA_THETA_X')..
                     # } if (i in col_header_dict.values())..
                  except ValueError as err:
                     print(" ******** ValueError: gps_tow: " + str(gps_tow) + " 0-based column index i = " + str(i) + ", Col Header: ' + col_headers[i] = ', Value: " + row_item[i] + ", Error Msg: {0}".format(err))
                  # } try..
               # } for i in range(n_data_columns)..
               
               # Convert from radians to degrees
               imu_8007_struct.delta_theta_roll = imu_8007_struct.delta_theta_roll * RAD2DEG
               imu_8007_struct.delta_theta_pitch = imu_8007_struct.delta_theta_pitch * RAD2DEG
               imu_8007_struct.delta_theta_yaw = imu_8007_struct.delta_theta_yaw * RAD2DEG

               # Convert from g-sec to m/s
               imu_8008_struct.delta_vel_x = imu_8008_struct.delta_vel_x * GRAV_ACCEL
               imu_8008_struct.delta_vel_y = imu_8008_struct.delta_vel_y * GRAV_ACCEL
               imu_8008_struct.delta_vel_z = imu_8008_struct.delta_vel_z * GRAV_ACCEL

               try:
                  delta_theta_bytes = pack('<lll', long(imu_8007_struct.delta_theta_roll * GYRO_SCALE_FACTOR), long(imu_8007_struct.delta_theta_pitch * GYRO_SCALE_FACTOR), long(imu_8007_struct.delta_theta_yaw * GYRO_SCALE_FACTOR)) # IMR expects X-Y-Z sequence of euler angles, where XYZ is MIP IMU frame
               except error as err:
                  print(" ******** struct.error: gps_tow: " + str(gps_tow) + " data_row_cnt = " + str(data_row_cnt) + ", delta_theta_roll: " + str(imu_8007_struct.delta_theta_roll) + ", delta_theta_pitch: " + str(imu_8007_struct.delta_theta_pitch) + ", delta_theta_yaw: " + str(imu_8007_struct.delta_theta_yaw) + ", Error Msg: {0}".format(err))
               # } try..
       
               try:
                  delta_vel_bytes = pack('<lll', long(imu_8008_struct.delta_vel_x * ACCEL_SCALE_FACTOR), long(imu_8008_struct.delta_vel_y * ACCEL_SCALE_FACTOR), long(imu_8008_struct.delta_vel_z * ACCEL_SCALE_FACTOR))  # IMR expects X-Y-Z sequence of delta velocity, where XYZ is MIP IMU frame
               except error as err:
                  print(" ******** struct.error: gps_tow: " + str(gps_tow) + " data_row_cnt = " + str(data_row_cnt) + ", delta_vel_x: " + str(imu_8008_struct.delta_vel_x) + ", delta_vel_y: " + str(imu_8008_struct.delta_vel_y) + ", delta_vel_z: " + str(imu_8008_struct.delta_vel_z) + ", Error Msg: {0}".format(err))
               # } try..
   
               novatel_msg_1462_bytes = []
               novatel_msg_1462_bytes.extend(pack('<d', gps_tow-0.009))
               # novatel_msg_1462_bytes.extend(pack('<d', gps_tow))
               novatel_msg_1462_bytes.extend(delta_theta_bytes)
               novatel_msg_1462_bytes.extend(delta_vel_bytes)

               fout_imu_bin.write(bytearray(novatel_msg_1462_bytes))
               fout_imu_bin.flush()

            except ValueError as err:
               print(" ******** ValueError: Invalid GPS Week / TOW: Error Msg: {0}".format(err))
            # } try..

            imu_8007_struct = IMU_8007_struct()
            imu_8008_struct = IMU_8008_struct()
         # } if (len(row_item) > 0)..
 
      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(row_item) > 0 and row_item[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers == True)..

   # } for row_item in csvreader..

   print("******* MIP CSV to Novatel IMU Binary: " + str(n_data_columns) + ' input headers found, ' + str(data_row_cnt) + " input data rows processed")

   fout_imu_bin.close()
