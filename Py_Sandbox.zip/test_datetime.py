import time, math
import calendar

# import datetime
from datetime import datetime
# from datetime import *

time1 = datetime(2016,6,17,15,0,0)

tmktime = time.mktime(time1.utctimetuple())

ts1 = time.mktime(time1.utctimetuple()) * 1000000000
ts2 = ts1 + (1000000000)
ts3 = ts2 + 1000000000
data = [(int(ts1), 55.5), (int(ts2), 15), (int(ts3), 25.5)]

print('*********** time1 = ' + str(time1) + '\ntmktime = ' + str(tmktime) + '\nts1 = ' + str(ts1) + '\ntime1.utctimetuple() = ' + str(time1.utctimetuple()))

dateStr = '2016-06-17T20:46:12Z'
s = datetime.strptime(dateStr, '%Y-%m-%dT%H:%M:%SZ')

print(' ********* strptime s = ' + str(s))

# print(' ********* datetime.time = ' + str(datetime.time()))

print(' ********* time.time() = ' + str(time.time()))

print(' ********* time.gmtime(time.time()) = ' + str(time.gmtime(time.time())))

x = time.gmtime(time.time())
y = calendar.timegm(x)

print(' ******** x = ' + str(x) + ', y = ' + str(y) )

# print(' ********* date.fromtimestamp(time.time()) = ' + str(date.fromtimestamp(time.time())))

# print(' ********* time.clock() = ' + str(time.clock()))

gpsEpoch = (1980, 1, 6, 0, 0, 0)

print(' ********* gpsEpoch = ' + str(gpsEpoch))

aprilFirst = datetime(2012, 04, 01, 0, 0)

z = calendar.timegm(aprilFirst.timetuple())

print(' ********* z = ' + str(z))

zdiff = (datetime(2012,04,01,0,0,0) - datetime(1970,1,1,0,0,0)).total_seconds()

print(' ********* zdiff = ' + str(zdiff))

