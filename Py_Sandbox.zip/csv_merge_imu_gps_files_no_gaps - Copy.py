# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import numpy as np

class gnss_timestamp_data:
   def __init__(self):
      [self.gnss_tflags, self.gnss_week_from_rcvr, self.gnss_tow_from_rcvr, self.cumul_time] = [0,0,0,0]
      [self.lat, self.lon, self.ht, self.ht_MSL, self.ambient_pr] = [0,0,0,0,0]
      [self.vned_n, self.vned_e, self.vned_d] = [0,0,0]
      [self.horizontal_accuracy, self.vertical_accuracy, self.flags_8103] = [0,0,0]
      [self.speed, self.ground_speed, self.heading] = [0,0,0]
      [self.speed_accuracy, self.heading_accuracy, self.flags_8105] = [0,0,0]

class imu_timestamp_data:
   def __init__(self):
      [self.imu_tflags, self.imu_week, self.imu_tow, self.cumul_time] = [0,0,0,0]
      [self.x_accel, self.y_accel, self.z_accel] = [0,0,0]
      [self.x_gyro, self.y_gyro, self.z_gyro] = [0,0,0]
      [self.x_mag, self.y_mag, self.z_mag] = [0,0,0]

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]
      
def print_row(data_row_cnt, data_row, fout_csv_file, imu_cumul_time, gps_array, gps_cnt):
      
   i = 0
   gps_cnt_ret = gps_cnt
   
   try:
      for v in data_row:
         i += 1
	 
         if (v.strip() != '' and v.strip().lower() != 'nan'):
            if (i == len(data_row)):
	       if ('.' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))        
               # } if ('.' in v)..		  
	    elif ('.' in v):
               fout_csv_file.write('%14.8f,'%(float(v)))
	       
	       if (i == 3): # If column is IMU TOW, insert extra column value on right for IMU Cumul Time
	          fout_csv_file.write('%14.8f,'%(imu_cumul_time))
	       # } if (i == 3)..
   	    else:
               fout_csv_file.write('%1d,'%(int(v)))
   	    # } if (i == len(..   
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..
      # } for v in data_row..
      
      if (data_row_cnt < 5):
         print(' ***** data_row_cnt: ' + str(data_row_cnt) + ', gps_cnt = ' + str(gps_cnt) + ', will get next element from gps_array')
      
      if (gps_cnt >= len(gps_array)):
         return gps_cnt
         
      gnss_data = gps_array[gps_cnt]
      
      gps_cumul_time = gnss_data.cumul_time
      
      if (imu_cumul_time > gps_cumul_time): # IMU crossed GNSS TOW
	 if (data_row_cnt < 25):
            print(' ***** IMU CROSS OVER AT data_row_cnt: ' + str(data_row_cnt) + ', imu_cumul_time: ' + str(imu_cumul_time) + ', gps_cumul_time: ' + str(gps_cumul_time))
	 
	 gps_cnt_ret = gps_cnt + 1 

         # if (gps_cnt_ret < 5):
            # print(' ****** gps_cnt_ret: ' + str(gps_cnt_ret) + ', gnss_data.gnss_tflags = ' + str(gnss_data.gnss_tflags) + ', gnss_data.gnss_week_from_rcvr = ' + str(gnss_data.gnss_week_from_rcvr) + ', gnss_data.gnss_tow_from_rcvr = ' + str(gnss_data.gnss_tow_from_rcvr))

	 fout_csv_file.write(',%1d,%1d,%1d,%12.4f,%12.4f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%1d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%1d'%(1, gnss_data.gnss_tflags, gnss_data.gnss_week_from_rcvr, gnss_data.gnss_tow_from_rcvr, gnss_data.cumul_time,\
	     gnss_data.lat, gnss_data.lon, gnss_data.ht, gnss_data.ht_MSL, gnss_data.ambient_pr, gnss_data.horizontal_accuracy, gnss_data.vertical_accuracy, gnss_data.flags_8103,\
	     gnss_data.vned_n, gnss_data.vned_e, gnss_data.vned_d, gnss_data.speed, gnss_data.ground_speed, gnss_data.heading, \
             gnss_data.speed_accuracy, gnss_data.heading_accuracy, gnss_data.flags_8105))
      else:
         fout_csv_file.write(',%1d'%(0))   #  GPS_Available_Flag
      # } if (imu_cumul_time > gps_cumul_time)..

      fout_csv_file.write('\n')
      
      return gps_cnt_ret
      
   except ValueError:
      print(' ******* ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))
   
   except IndexError:     																									       
      print(' ****** IndexError: at data_row_cnt = ' + str(data_row_cnt) + ', gps_cnt = ' + str(gps_cnt))

   except TypeError:
      print(' ******* TypeError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value[2]: ' + str(data_row[2]))
   
def print_imu_array(data_row_cnt, imu_array, fout_csv_file, imu_cumul_time, begin_data_gap_week, begin_data_gap_tow, end_data_gap_tow, gps_array, gps_cnt):
   
   size = len(imu_array)
   
   print(' **** inside print_imu_array: data_row_cnt = ' + str(data_row_cnt) + ', size: ' + str(size) + '\n')
   
   cnt = 0
   
   for i in imu_array:
      cnt += 1
      i.imu_tow = begin_data_gap_tow + (end_data_gap_tow - begin_data_gap_tow) * cnt /(size+1)
      imu_cumul_time += (end_data_gap_tow - begin_data_gap_tow)/(size+1)
      data_row = [str(i.imu_tflags), str(i.imu_week), str(i.imu_tow), str(i.x_accel), str(i.y_accel), str(i.z_accel), str(i.x_gyro), str(i.y_gyro), str(i.z_gyro), str(i.x_mag), str(i.y_mag), str(i.z_mag)]
      gps_cnt = print_row(data_row_cnt, data_row, fout_csv_file, imu_cumul_time, gps_array, gps_cnt)
      
      if (imu_cumul_time < 10000):
        print(' ***** data_row_cnt: ' + str(data_row_cnt) + ', cnt: ' + str(cnt) + ', i.imu_tow = ' + str(i.imu_tow) + ', i.x_accel = ' + str(i.x_accel) )
      
   # } for i in imu_array..

def process_csv_file(imu_csvreader, gps_csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0
   imu_array = []
   gps_header_array = []
   gps_array = []
   prev_gps_week = 0
   prev_gps_tow = 0
   gps_cumul_time = -1
   diff_gps_tow = 0

   n_data_columns = 0
   prev_lat = 0
   prev_lon = 0
   prev_ht = 0
   
   prev_ht_MSL = 0

   prev_vned_n = 0
   prev_vned_e = 0
   prev_vned_d = 0

   prev_horizontal_accuracy = 0
   prev_vertical_accuracy = 0
   
   prev_speed = 0
   prev_ground_speed = 0
   
   prev_heading = 0
   prev_speed_accuracy = 0
   prev_heading_accuracy = 0
   prev_ambient_pr = 0
   
   prev_gps_week = 0
   prev_gps_tow = 0

   for data_row in gps_csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

         gps_header_array = data_row
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
         if (len(data_row) > 0 and int(data_row[1]) != 0): # GPS Week != 0

            curr_gps_week = int(data_row[1])
	    curr_gps_tow = float(data_row[2])
	    
            if (prev_gps_week != 0):
	       if (curr_gps_week != prev_gps_week):
                  diff_gps_tow = 604800.00 + curr_gps_tow - prev_gps_tow
               else:
                  diff_gps_tow = curr_gps_tow - prev_gps_tow
               # } if (curr_gps_week != prev_gps_week)..
	       
	       # gps_cumul_time += diff_gps_tow
	    # } if (prev_gps_week != 0)..
	    
	    if (diff_gps_tow < 1.9):  # Expecting 1 Hz GNSS data [Canadian Space Agency], so allowing consecutive GNSS rows to have max 1.9 sec difference in TOW
	       # gps_cumul_time += diff_gps_tow
	       nbr_gnss_rows = 1
	    else:
	       # gps_cumul_time += diff_gps_tow
	       nbr_gnss_rows = int(diff_gps_tow)      # assuming 1 Hz GNSS data (Canadian Space Agency)
   	    # } if (diff_gps_tow < 1.9)..
	    
	    gnss_tflags = int(data_row[0])
            curr_gnss_tow_from_rcvr = float(data_row[2])
	    gnss_week_from_rcvr = int(data_row[1])
	    
            curr_lat = np.double(data_row[3])
            curr_lon = np.double(data_row[4])
            curr_ht = np.double(data_row[5])
            curr_ht_MSL = float(data_row[6])
        
            curr_vned_n = float(data_row[10])
            curr_vned_e = float(data_row[11])
            curr_vned_d = float(data_row[12])
        
            curr_horizontal_accuracy = float(data_row[7])
            curr_vertical_accuracy = float(data_row[8])
	    flags_8103 = int(data_row[9])
	    
            curr_speed = float(data_row[13])
            curr_ground_speed = float(data_row[14])
	    
	    curr_heading = float(data_row[15])
            curr_speed_accuracy = float(data_row[16])
            curr_heading_accuracy = float(data_row[17])
            curr_ambient_pr = np.interp(curr_ht_MSL, altitude_array, ambient_pressure_array) * 1000
	    
            flags_8105 = int(data_row[18])
	    
	    gnss_tow_from_rcvr_to_use = 0
	    index_delta_to_use = 0
	    
	    if (nbr_gnss_rows == 1):
	       gnss_tow_from_rcvr_to_use = curr_gnss_tow_from_rcvr
	    else:
	       gnss_tow_from_rcvr_to_use = prev_gnss_tow_from_rcvr
	       index_delta_to_use = 1
	    # } if (nbr_gnss_rows == 1)..
	      
	    for gnss_interp_cnt in range(nbr_gnss_rows):
	       gps_cumul_time += gnss_interp_cnt + 1	  # assuming 1 Hz GNSS data (Canadian Space Agency)
	    
               gnss_data = gnss_timestamp_data()
   	    
   	       gnss_data.gnss_tflags = gnss_tflags
               gnss_data.gnss_week_from_rcvr = gnss_week_from_rcvr
               gnss_data.gnss_tow_from_rcvr = gnss_tow_from_rcvr_to_use + float(gnss_interp_cnt + index_delta_to_use)/nbr_gnss_rows
               gnss_data.cumul_time = gps_cumul_time
           
               gnss_data.lat = prev_lat + (curr_lat - prev_lat) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.lon = prev_lon + (curr_lon - prev_lon) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.ht = prev_ht + (curr_ht - prev_ht) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.ht_MSL = prev_ht_MSL + (curr_ht_MSL - prev_ht_MSL) * gnss_interp_cnt/nbr_gnss_rows
	       
	       gnss_data.vned_n = prev_vned_n + (curr_vned_n - prev_vned_n) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.vned_e = prev_vned_e + (curr_vned_e - prev_vned_e) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.vned_d = prev_vned_d + (curr_vned_d - prev_vned_d) * gnss_interp_cnt/nbr_gnss_rows
	       
	       gnss_data.horizontal_accuracy = prev_horizontal_accuracy + (curr_horizontal_accuracy - prev_horizontal_accuracy) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.vertical_accuracy = prev_vertical_accuracy + (curr_vertical_accuracy - prev_vertical_accuracy) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.flags_8103 = flags_8103
	       
	       gnss_data.speed = prev_speed + (curr_speed - prev_speed) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.ground_speed = prev_ground_speed + (curr_ground_speed - prev_ground_speed) * gnss_interp_cnt/nbr_gnss_rows
               
	       gnss_data.heading = prev_heading + (curr_heading - prev_heading) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.speed_accuracy = prev_speed_accuracy + (curr_speed_accuracy - prev_speed_accuracy) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.heading_accuracy = prev_heading_accuracy + (curr_heading_accuracy - prev_heading_accuracy) * gnss_interp_cnt/nbr_gnss_rows
	       gnss_data.ambient_pr = prev_ambient_pr + (curr_ambient_pr - prev_ambient_pr) * gnss_interp_cnt/nbr_gnss_rows
	       
   	       gnss_data.flags_8105 = flags_8105
   	    
   	       gps_array.append(gnss_data)
	    
	    # } for gnss_interp_cnt in nbr_gnss_rows..

            prev_gnss_tow_from_rcvr = curr_gnss_tow_from_rcvr
        
            prev_lat = curr_lat
            prev_lon = curr_lon
            prev_ht = curr_ht
            prev_ht_MSL = curr_ht_MSL
        
            prev_vned_n = curr_vned_n
            prev_vned_e = curr_vned_e
            prev_vned_d = curr_vned_d
        
            prev_horizontal_accuracy = curr_horizontal_accuracy
            prev_vertical_accuracy = curr_vertical_accuracy
	    
            prev_speed = curr_speed
            prev_ground_speed = curr_ground_speed
	    
	    prev_heading = curr_heading
            prev_speed_accuracy = curr_speed_accuracy
            prev_heading_accuracy = curr_heading_accuracy
            prev_ambient_pr = curr_ambient_pr
	    
	    prev_gps_week = curr_gps_week
	    prev_gps_tow = curr_gps_tow

         # } if (len(data_row) > 0 and..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in gps_csvreader..

   print(' ********** LENGTH OF GPS ARRAY: ' + str(len(gps_array)))
   
   total_gps_rows = len(gps_array)
   
   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   
   gps_cnt = 0
   gps_object = None

   prev_imu_week = 0
   prev_imu_tow = 0
   imu_cumul_time = 0
   gpsWeekChanged = False
   cnt = 0
   found_gps_crossover = False
   begin_data_gap = False
   begin_data_gap_tow = 0
   end_data_gap_tow = 0
   
   for data_row in imu_csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         i = 0
         for c in data_row:
	    i += 1
            fout_csv_file.write(c + ',')
            
            if (i == 3): # IMU TOW
     	       fout_csv_file.write('IMU Cumul Time,')
	    elif (i == 12): # Mag Z.  Need to insert GPS_Available_Flag
	       fout_csv_file.write('GPS Available Flag,')
            # } if (i == 3)..   
         # } for c in data_row..
	 
	 i = 0
         for c in gps_header_array:
	    i += 1
	    
   	    # if (i == len(data_row)):
	    if (i == 20):
   	       fout_csv_file.write(c)
   	    else:
	       fout_csv_file.write(c + ',')
	    # } if (i == len(data_row))..

	    if (i == 3):
	       fout_csv_file.write('GPS Cumul Time,')
	    
	    if (i == 20):
	       break
	 # } for c in gps_header_array..
	    
         fout_csv_file.write('\n')
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
         curr_imu_week = int(data_row[1])
         curr_imu_tow = float(data_row[2])
	 
	 if (not begin_data_gap and curr_imu_week == 0):
	    begin_data_gap = True
	    begin_data_gap_week = prev_imu_week
	    begin_data_gap_tow = prev_imu_tow
	    
	    print('***** FOUND DATA GAP BEGAN AT: data_row_cnt: ' + str(data_row_cnt) + ', begin_data_gap_tow = ' + str(begin_data_gap_tow))
	    
            imu_data = imu_timestamp_data()
   	    
   	    imu_data.imu_tflags = int(data_row[0])
            imu_data.imu_week = prev_imu_week
	    # imu_data.imu_tow = float(data_row[2])
	    imu_data.x_accel = float(data_row[3])
	    imu_data.y_accel = float(data_row[4])
	    imu_data.z_accel = float(data_row[5])
	    imu_data.x_gyro = float(data_row[6])
	    imu_data.y_gyro = float(data_row[7])
	    imu_data.z_gyro = float(data_row[8])
	    imu_data.x_mag = float(data_row[9])
	    imu_data.y_mag = float(data_row[10])
	    imu_data.z_mag = float(data_row[11])
	    
            imu_array.append(imu_data)
	    
	    continue
	 
	 elif (begin_data_gap and curr_imu_week == 0):
	 
            imu_data = imu_timestamp_data()
   	    
   	    imu_data.imu_tflags = int(data_row[0])
            imu_data.imu_week = prev_imu_week
	    # imu_data.imu_tow = float(data_row[2])
	    imu_data.x_accel = float(data_row[3])
	    imu_data.y_accel = float(data_row[4])
	    imu_data.z_accel = float(data_row[5])
	    imu_data.x_gyro = float(data_row[6])
	    imu_data.y_gyro = float(data_row[7])
	    imu_data.z_gyro = float(data_row[8])
	    imu_data.x_mag = float(data_row[9])
	    imu_data.y_mag = float(data_row[10])
	    imu_data.z_mag = float(data_row[11])
	    
            imu_array.append(imu_data)
	    
	    continue
	 
	 elif (begin_data_gap and curr_imu_week != 0):
	    end_data_gap = True
	    end_data_gap_week = curr_imu_week
	    end_data_gap_tow = curr_imu_tow
	    begin_data_gap = False
	    
	    print('***** END DATA GAP AT: data_row_cnt: ' + str(data_row_cnt) + ', end_data_gap_tow = ' + str(end_data_gap_tow) + ', len(imu_array) = ' + str(len(imu_array)))
	    
	    print_imu_array(data_row_cnt, imu_array, fout_csv_file, imu_cumul_time, begin_data_gap_week, begin_data_gap_tow, end_data_gap_tow, gps_array, gps_cnt)
	    
	    imu_array = []
	    
	 # } if (not begin_data_gap and..
	    
         if (not found_gps_crossover and curr_imu_tow >= gps_array[0].gnss_tow_from_rcvr):
	    found_gps_crossover = True

	 if (prev_imu_week != 0 and curr_imu_week != 0 and found_gps_crossover):
            if (curr_imu_week != prev_imu_week):
               diff_imu_tow = 604800.00 + curr_imu_tow - prev_imu_tow
	       gpsWeekChanged = True
	       print(' ****** GPS WEEK CHANGED: diff_imu_tow = ' + str(diff_imu_tow) + ', curr_imu_tow = ' + str(curr_imu_tow)) 
            else:
               diff_imu_tow = curr_imu_tow - prev_imu_tow
            # } if (curr_imu_week != prev_imu_week)..
	    
	    imu_cumul_time += diff_imu_tow
	    
         # } if (prev_imu_week != 0)..
	 
	 gps_cnt = print_row(data_row_cnt, data_row, fout_csv_file, imu_cumul_time, gps_array, gps_cnt)
	 
	 if (gps_cnt >= total_gps_rows):
	    break
	    
	 prev_imu_week = curr_imu_week
	 prev_imu_tow = curr_imu_tow
	 
      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in imu_csvreader..
   

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM_Part1.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM_Part1.csv'

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM.csv'

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM_Part1_18300_18930.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM_Part1_18300_18930.csv'

imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_woBadData.csv'
gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_woBadData.csv'

(fin_filepath, fin_filename) = os.path.split(imu_in_file_name)

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_IMU_GNSS_Merged.csv"), "w")

fout_csv_file.write('DATA_START\n')

imu_in_csvfile = open(imu_in_file_name,'r')
imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')
gps_in_csvfile = open(gps_in_file_name,'r')
gps_csvreader = csv.reader(gps_in_csvfile, delimiter=',')

process_csv_file(imu_csvreader, gps_csvreader)

imu_in_csvfile.close()
gps_in_csvfile.close()
fout_csv_file.close()
