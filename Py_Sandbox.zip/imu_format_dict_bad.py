class IMU_8012_struct:
   def __init__(self):
      [self.imu_tow, self.imu_week, self.flags_80_12] = [0,0,0]

class IMU_8004_struct:
   def __init__(self):
      [self.imu_tow, self.scaled_accel_x, self.scaled_accel_y, self.scaled_accel_z] = [0,0,0]

class IMU_8005_struct:
   def __init__(self):
      [self.imu_tow, self.scaled_gyro_x, self.scaled_gyro_y, self.scaled_gyro_z] = [0,0,0]

class IMU_8007_struct:
   def __init__(self):
      [self.imu_tow, self.delta_theta_roll, self.delta_theta_pitch, self.delta_theta_yaw] = [0,0,0]

class IMU_8008_struct:
   def __init__(self):
      [self.imu_tow, self.delta_vel_x, self.delta_vel_y, self.delta_vel_z] = [0,0,0]

class IMU_8006_struct:
   def __init__(self):
      [self.imu_tow, self.mag_x, self.mag_y, self.mag_z] = [0,0,0]

class IMU_8017_struct:
   def __init__(self):
      [self.imu_tow, self.ambient_pr] = [0]

class IMU_8009_struct:
   def __init__(self):
      [self.imu_tow, self.cf_matrix_m11, self.cf_matrix_m12, self.cf_matrix_m13, self.cf_matrix_m21, self.cf_matrix_m22, self.cf_matrix_m23, self.cf_matrix_m31, self.cf_matrix_m32, self.cf_matrix_m33] = [0,0,0,0,0,0,0,0,0]

class IMU_800A_struct:
   def __init__(self):
      [self.imu_tow, self.cf_quat_0, self.cf_quat_1, self.cf_quat_2, self.cf_quat_3] = [0,0,0,0]

class IMU_800C_struct:
   def __init__(self):
      [self.imu_tow, self.cf_euler_angle_roll, self.cf_euler_angle_pitch, self.cf_euler_angle_yaw] = [0,0,0]

class IMU_8010_struct:
   def __init__(self):
      [self.imu_tow, self.cf_stabilized_mag_vector_north_x, self.cf_stabilized_mag_vector_north_y, self.cf_stabilized_mag_vector_north_z] = [0,0,0]

class IMU_8011_struct:
   def __init__(self):
      [self.imu_tow, self.cf_stabilized_accel_vector_up_x, self.cf_stabilized_accel_vector_up_y, self.cf_stabilized_accel_vector_up_z] = [0,0,0]


