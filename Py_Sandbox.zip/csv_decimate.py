# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it

import os
import csv
import numpy as np
    
def print_row(data_row_cnt, data_row, fout_csv_file, gps_tow_calc = False, data_row_cnt_tow_change = 0, tow_first_changed = 0, prev_gps_week_in = 0, change_cnt = 0):
   if (data_row_cnt < 5):
      print(' ****** prev_gps_week_in = ' + str(prev_gps_week_in))
      
   i = 0
   prev_gps_week = 0
   prev_gps_week_changed = False
   try:
      for v in data_row:
         i += 1
         if (v.strip() != '' and v.strip().lower() != 'nan'):
            if (i == len(data_row)):
	       if ('.' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))        
               # } if ('.' in v)..		  
	    elif (gps_tow_calc and i == 28): # GPS TOW
	       interp_val = tow_first_changed + (data_row_cnt - data_row_cnt_tow_change)* 0.01
	       if (data_row_cnt < 40):
	          print(' ****** gps_tow_calc is TRUE, data_row_cnt = ' + str(data_row_cnt) + ', tow_first_changed = ' + str(tow_first_changed) + ', interp_val = ' + str(interp_val) )
	       fout_csv_file.write('%14.8f,'%(interp_val))
	    elif ('.' in v):
	       if (i == 3 and data_row_cnt > 56250 and data_row_cnt < 56290):
	          print(' ******* i = 3 and data_row_cnt: ' + str(data_row_cnt) + '. prev_gps_week_changed = ' + str(prev_gps_week_changed) + ', change_cnt = ' + str(change_cnt) + ', GPS TOW = ' + str(float(v) + 604800 * change_cnt))
	       # if (i == 3 and prev_gps_week_changed):
	       if (i == 3):
		  fout_csv_file.write('%14.8f,'%(float(v) + 604800 * change_cnt))
	       else:   
	          fout_csv_file.write('%14.8f,'%(float(v)))
               # } if (i == 3 and..		  
   	    else:
	       if (i == 2):
	          # print(' ****** data_row_cnt: ' + str(data_row_cnt) + ', prev_gps_week = ' + str(prev_gps_week) + ', current gps_week: ' + v)
	          # Check if GPS Week changed from previous row value:
	          if (prev_gps_week_in != 0 and int(v) != 0 and int(v) != prev_gps_week_in):
		     prev_gps_week_changed = True
		     change_cnt = change_cnt + 1
		     print(' ****** GPS WEEK CHANGED AT: data_row_cnt: ' + str(data_row_cnt) + ', prev_gps_week_in = ' + str(prev_gps_week_in) + ', new gps week = ' + v + ', change_cnt = ' + str(change_cnt))
		     # fout_csv_file.write('%1d,'%(int(v)-change_cnt))
		  # else:
		     # prev_gps_week_changed = False
		     # fout_csv_file.write('%1d,'%(int(v)-change_cnt))
		  # } if (prev_gps_week != 0 and..

	          if (data_row_cnt > 56250 and data_row_cnt < 56290):
		     print(' ****** data_row_cnt: ' + str(data_row_cnt) + ', prev_gps_week_in = ' + str(prev_gps_week_in) + ', curr gps week: ' + v + ', change_cnt = ' + str(change_cnt) + ', printing GPS Week: ' + str(int(v)-change_cnt))
		  
		  fout_csv_file.write('%1d,'%(int(v)-change_cnt))
		  
	          prev_gps_week = int(v)
               else:
	          fout_csv_file.write('%1d,'%(int(v)))		  
               # } if (i == 2).. 		  
   	    # } if (i == len(..   
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..
      # } for v in data_row..

      fout_csv_file.write('\n')
      
      return prev_gps_week, change_cnt
      
   except ValueError:
     print(' ******* ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))

def process_csv_file(csvreader, gps_tow_calc = False, findFirstGPSTOWChange = False, data_row_cnt_tow_change = 0, tow_first_changed = 0):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   prev_gps_week = 0
   change_cnt = 0
   
   for data_row in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         
	 if (not findFirstGPSTOWChange):
            i = 0
            for c in data_row:
               i += 1
      	       if (i == len(data_row)):
      	          fout_csv_file.write(c)
      	       else:
                  fout_csv_file.write(c + ',')
      	       # } if (i == len(data_row))..
	    # } for c in data_row..   
            fout_csv_file.write('\n')
	 # } if (not findFirstGPSTOWChange)..
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
         if (findFirstGPSTOWChange):
	    tow_prev = tow_current
	    tow_current = float(data_row[27])
	    if (tow_prev != 0 and tow_current != tow_prev):
	       print(' ***** FIRST GPS TOW CHANGE AT: ' + str(data_row_cnt) + ', tow_current = ' + str(tow_current))
	       return data_row_cnt, tow_current 
	    # } if (tow_current != tow_prev)..
	 elif (gps_tow_calc):
	    if (data_row_cnt < 20):
	       print(' ***** sending tow_first_changed = ' + str(tow_first_changed) + ' to print_row')
	    print_row(data_row_cnt, data_row, fout_csv_file, True, data_row_cnt_tow_change, tow_first_changed)   
         elif (data_row_cnt % 10 == 1 and len(data_row) > 0 and int(data_row[1]) != 0): # GPS Week != 0
	    if (data_row_cnt < 20):
	       print(' ***** WILL CALL print_row, data_row_cnt = ' + str(data_row_cnt) + ', data_row[0] = ' + data_row[0])
   	    prev_gps_week, change_cnt = print_row(data_row_cnt, data_row, fout_csv_file, False, 0, 0, prev_gps_week, change_cnt)
         # } if (findFirstGPSTOWChange..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in csvreader..
     
# def csv_remove_fn(in_file_name):
   
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Kawasaki/Part2/ImuData_Ref_noEmpty.csv' 
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Kawasaki/Part3/IMU_GPS_Data_Ref.csv' 
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/GrizzlyTest2_corrected.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/GrizzlyTest2_corrected - C_SingleTimeCol.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/LongTruckTest2_corrected - C_SingleTimeCol.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_01_24_CNH/SlopesTest2_corrected.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_EKF_Log.csv'
# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-26T08h09m49s_LORD_FORMAT_EKF_Log.csv'
in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-26T08h25m23s_LORD_FORMAT_EKF_Log.csv'

# if (in_file_name == None):
   # print('Input file name cannot be empty')
   # sys.exit()

# in_csvfile = open(in_file_name,'rUb')
in_csvfile = open(in_file_name,'r')
csvreader = csv.reader(in_csvfile, delimiter=',')

(fin_filepath, fin_filename) = os.path.split(in_file_name)

# Option to create an interpolated TOW column in the csv file (if such column is missing)
gps_tow_calc = False
# gps_tow_calc = True

if (gps_tow_calc):
   fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_TOW_Recalc.csv"), "w")
else:
   fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_10Hz.csv"), "w")
# } if (gps_tow_calc)..

fout_csv_file.write('DATA_START\n')

if (gps_tow_calc):
   data_row_cnt_tow_change, tow_first_changed = process_csv_file(csvreader, gps_tow_calc, True)
   in_csvfile.seek(0)
   print(' ****** sending tow_first_changed = ' + str(tow_first_changed) + ' to second call to process_csv_file') 
   process_csv_file(csvreader, gps_tow_calc, False, data_row_cnt_tow_change, tow_first_changed)
else:
   process_csv_file(csvreader)
# } if (gps_tow_calc)..

fout_csv_file.close()




