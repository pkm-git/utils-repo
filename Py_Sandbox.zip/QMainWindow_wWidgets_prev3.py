import sys
import shlex, subprocess

from subprocess_fn import *
from PyQt4 import QtCore, QtGui

# from PyQt4.QtCore import QString
from time import sleep         #sleep

class MainWindow(QtGui.QMainWindow):

   def __init__(self, parent=None):
      super(MainWindow, self).__init__(parent)
      # self.setWindowIcon(QtGui.QIcon('submit_button.gif'))

      _widget = QtGui.QWidget()
      _layout = QtGui.QVBoxLayout(_widget)

      self.form_widget = MyFormWidget(self)
      _layout.addWidget(self.form_widget)

      self.setCentralWidget(_widget)
      self.setGeometry(400, 300, 500, 150)
      self.setWindowTitle("Sensor Cloud Utils")
      self.setStyleSheet("background-color: #BCE4C6;");
      self.show()

   def closeEvent(self, event):
      print "Closing main window"

      # option #1
      self.form_widget.close()

      # Or Option #3 - emit a custom signal
      # self.closing.emit()

      super(MainWindow, self).closeEvent(event)

# ---------------------------------------------------
class MyFormWidget(QtGui.QWidget):

   def closeEvent(self, event):
      print "Closing MyFormWidget window"

      self.outputFile.close()

      super(MyFormWidget, self).closeEvent(event)

   def __init__(self, parent):
      super(MyFormWidget, self).__init__(parent)
      self.__controls()
      self.__layout()

   def __controls(self):

      labelText = "Sensor Cloud Utils"

      self.lbl_title = QtGui.QLabel(labelText)
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");

      self.lbl_filename = QtGui.QLabel("Binary file name:")
      self.lbl_filename.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_filename = MyLineEdit()
      self.edt_filename.setStyleSheet("background-color: white;");
      self.edt_filename.setText('U:/Lord/Python_HIL_Sim_From_File/Vehicle_Logs/2016_07_12/3DM-GX4-45 6236.46589 Data Log 7-19-2016 4.53.30 PM.bin')

      self.lbl_desired_actions = QtGui.QLabel("Desired Action(s):")
      self.lbl_desired_actions.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_sensor_name = MyLineEdit()
      self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
      self.edt_sensor_name.setReadOnly(True)

      self.lbl_device_id = QtGui.QLabel("Device ID:")
      self.lbl_device_id.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_device_id = MyLineEdit()
      # self.edt_device_id.setText('OAPI00QKJTDKCM0R')
      self.edt_device_id.setStyleSheet("background-color: #E0E0E0;");
      self.edt_device_id.setReadOnly(True)

      self.lbl_key = QtGui.QLabel("Key:")
      self.lbl_key.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_key = MyLineEdit()
      # self.edt_key.setText('d173b6d7662be16a11fd535908e5535656f86594a6b2fa7312091c16e192e5cc')
      self.edt_key.setStyleSheet("background-color: #E0E0E0;");
      self.edt_key.setReadOnly(True)

      self.lbl_binary_file_type = QtGui.QLabel("Binary File Type:")
      self.lbl_binary_file_type.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.cmbox_binary_file_type = MyComboBox()
      self.cmbox_binary_file_type.setFixedWidth(70)
      self.cmbox_binary_file_type.setStyleSheet("background-color: #E0E0E0;");

      self.chkbx_parse_to_csv = MyCheckBox('Parse to CSV')
      self.chkbx_parse_to_csv.setChecked(False)
      self.chkbx_parse_to_csv.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.chkbx_upload_to_sensor_cloud = MyCheckBox('Upload to Sensor Cloud')
      self.chkbx_upload_to_sensor_cloud.setChecked(False)
      self.chkbx_upload_to_sensor_cloud.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_upload_to_sensor_cloud.stateChanged.connect(self.enableSensorCloudFields)

      self.browse_button = QtGui.QPushButton("Browse")
      self.browse_button.setCheckable(True)
      self.browse_button.toggle()
      self.browse_button.clicked.connect(self.selectFile)
      self.browse_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #E1C4B8; border: 1px solid #330019; padding: 5px;");

      self.submit_button = QtGui.QPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(self.validate)
      self.submit_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.delete_all_sensors_button = QtGui.QPushButton("Delete All Sensors")
      self.delete_all_sensors_button.setCheckable(True)
      self.delete_all_sensors_button.toggle()
      self.delete_all_sensors_button.clicked.connect(self.validateDeleteAllSensors)
      self.delete_all_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.clear_console_log_button = QtGui.QPushButton("Clear Console Log")
      self.clear_console_log_button.setCheckable(True)
      self.clear_console_log_button.toggle()
      self.clear_console_log_button.clicked.connect(self.clearConsoleLog)
      self.clear_console_log_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.view_add_sensors_button = QtGui.QPushButton("Add / View Sensor(s)")
      self.view_add_sensors_button.setCheckable(True)
      self.view_add_sensors_button.toggle()
      #self.view_add_sensors_button.clicked.connect(self.createViewSensors)
      self.view_add_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.outputFile = open('Test_FileWrite.txt','w')
      # text = self.textEdit.toPlainText()
      # self.outputFile.write(text)
      # self.outputFile.close()

      # self.logOutput = QtGui.QTextEdit()
      self.logOutput = QtGui.QPlainTextEdit()

      self.logOutput.setReadOnly(True)
      # self.logOutput.setLineWrapMode(QtGui.QTextEdit.NoWrap)
      self.logOutput.setStyleSheet("font-weight: bold; font-size: 12px; background-color: #F2CFC0");

      m = QtGui.QFontMetrics(self.logOutput.font())
      row_height = m.lineSpacing()
      self.logOutput.setFixedHeight(20 * row_height)

      # QProcess object for external app
      self.process = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      self.process.readyRead.connect(self.dataReady)

      # Just to prevent accidentally running multiple times
      # Disable the button when process starts, and enable it when it finishes
      self.process.started.connect(lambda: self.submit_button.setEnabled(False))
      self.process.finished.connect(lambda: self.submit_button.setEnabled(True))

      # self.process.readyReadStandardOutput.connect(self.readyReadStandardOutput)
      # self.process.readyReadStandardError.connect(self.readyReadStandardError)

      self.lbl_space = QtGui.QLabel()

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(5)

   def dataReady(self):
      cursor = self.logOutput.textCursor()
      cursor.movePosition(cursor.End)
      print('******* in dataReady')

      # cursor.insertText(str(self.process.readAll()))
      i = 0
      self.process.setReadChannel(QtCore.QProcess.StandardOutput);
      while (self.process.canReadLine()):
         # self.process.waitForReadyRead()
         current_line = str(self.process.readLine()).rstrip('\n')
         print(' ******** current_line = ' + current_line)
         # cursor.insertText(current_line)
         # self.logOutput.append(current_line)
         self.logOutput.appendPlainText(current_line)
         self.outputFile.write(current_line)
         self.outputFile.flush()
         # cursor.insertText(str(self.process.readAllStandardOutput()))
         # self.logOutput.ensureCursorVisible()
         # self.process.waitForFinished()
         i = i + 1
         # sleep(0.5)

      # sb = self.logOutput.verticalScrollBar()
      # sb.setValue(sb.maximum())

   def readyReadStandardOutput(self):
      cursor = self.logOutput.textCursor()
      cursor.movePosition(cursor.End)
      # line = QtCore.QString.fromLocal8bit(self.process.readAllStandardOutput())
      # cursor.insertText(str(line))
      # cursor.insertText(str(self.process.readLine()))
      cursor.insertText(str(self.process.readAllStandardOutput()))
      self.logOutput.ensureCursorVisible()

   def readyReadStandardError(self):
      cursor = self.logOutput.textCursor()
      cursor.movePosition(cursor.End)
      # line = QtCore.QString.fromLocal8bit(self.process.readAllStandardError())
      # cursor.insertText(str(line))
      # cursor.insertText(str(self.process.readLine()))
      cursor.insertText(str(self.process.readAllStandardError()))
      self.logOutput.ensureCursorVisible()

   def enableSensorCloudFields(self, state):

      if state == QtCore.Qt.Checked:
         self.edt_sensor_name.setStyleSheet("background-color: white;");
         self.edt_sensor_name.setReadOnly(False)

         self.edt_device_id.setStyleSheet("background-color: white;");
         self.edt_device_id.setReadOnly(False)

         self.edt_key.setStyleSheet("background-color: white;");
         self.edt_key.setReadOnly(False)

         self.edt_device_id.setText('OAPI00QKJTDKCM0R')
         self.edt_key.setText('7012045725cebc60dc10592527109066bc81500b00bfaf6da854fde23275ff21')
      else:
         self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
         self.edt_sensor_name.setReadOnly(True)
         self.edt_sensor_name.setText('')

         self.edt_device_id.setStyleSheet("background-color: #E0E0E0;");
         self.edt_device_id.setReadOnly(True)
         self.edt_device_id.setText('')

         self.edt_key.setStyleSheet("background-color: #E0E0E0;");
         self.edt_key.setReadOnly(True)
         self.edt_key.setText('')

   def __layout(self):
      # -------
      # HBox's:
      # -------
      self.h12box = QtGui.QHBoxLayout()
      self.h12box.addWidget(self.edt_filename)
      self.h12box.addWidget(self.browse_button)

      self.h6box = QtGui.QHBoxLayout()
      # self.h6box.addWidget(self.lbl_space)
      self.h6box.addWidget(self.clear_console_log_button)
      # self.h6box.addWidget(self.lbl_space)
      self.h6box.addWidget(self.submit_button)
      self.h6box.addWidget(self.delete_all_sensors_button)
      # self.h6box.addWidget(self.lbl_space)
      # self.h6box.addWidget(self.show_runtime_log_button)
      self.h6box.addWidget(self.view_add_sensors_button)

      # -------
      # VBox's:
      # -------
      self.h0box = QtGui.QHBoxLayout()
      self.h0box.addWidget(self.lbl_space)
      self.h0box.addWidget(self.lbl_title)
      self.h0box.addWidget(self.lbl_space)
      self.v0box = QtGui.QVBoxLayout()
      self.v0box.addLayout(self.h0box)

      self.h2box = QtGui.QHBoxLayout()
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.chkbx_parse_to_csv)
      self.h2box.addWidget(self.chkbx_upload_to_sensor_cloud)
      self.h2box.addWidget(self.lbl_space)

      self.v31box = QtGui.QVBoxLayout()
      self.v31box.addWidget(self.lbl_filename)
      self.v31box.addWidget(self.lbl_binary_file_type)
      self.v31box.addWidget(self.lbl_desired_actions)
      self.v31box.addWidget(self.lbl_sensor_name)
      self.v31box.addWidget(self.lbl_device_id)
      self.v31box.addWidget(self.lbl_key)

      self.v32box = QtGui.QVBoxLayout()
      self.v32box.addLayout(self.h12box)
      self.v32box.addWidget(self.cmbox_binary_file_type)
      self.v32box.addLayout(self.h2box)
      self.v32box.addWidget(self.edt_sensor_name)
      self.v32box.addWidget(self.edt_device_id)
      self.v32box.addWidget(self.edt_key)

      self.h3vbox = QtGui.QHBoxLayout()
      self.h3vbox.addLayout(self.v31box)
      self.h3vbox.addLayout(self.v32box)

      self.v3box = QtGui.QVBoxLayout()
      self.v3box.addLayout(self.h3vbox)

      self.v4box = QtGui.QVBoxLayout()
      self.v4box.addLayout(self.h6box)

      self.v5box = QtGui.QVBoxLayout()
      self.v5box.addWidget(self.logOutput)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.v0box)
      self.vbox.addLayout(self.v3box)
      self.vbox.addLayout(self.v4box)
      self.vbox.addLayout(self.v5box)

      self.setLayout(self.vbox)

   def selectFile(self):
      self.edt_filename.setText(QtGui.QFileDialog.getOpenFileName())

   def validate(self):
      error_msg = ''

      if (self.edt_filename.text() == ''):
         error_msg += 'File name cannot be empty\n'

      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
         if (self.edt_sensor_name.text() == ''):
            error_msg += 'Sensor name cannot be empty\n'
         if (self.edt_device_id.text() == ''):
            error_msg += 'Device ID cannot be empty\n'
         if (self.edt_key.text() == ''):
            error_msg += 'Key cannot be empty\n'

      parse_to_csv_action = ''
      if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):
         parse_to_csv_action += 'p'

      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
         parse_to_csv_action += 'u'

      parse_to_csv_action += 'f'

      if (self.cmbox_binary_file_type.currentText() == 'MIP'):
         parse_to_csv_action += 'mb'
      else:
         parse_to_csv_action += 'nb'

      print(' ******* parse_to_csv_action = ' + parse_to_csv_action)

      if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

         command_line = 'python sensor_cloud_utils.py -d "' + str(self.edt_device_id.text())
         command_line += '" -s "' + str(self.edt_sensor_name.text())
         command_line += '" -k "' + str(self.edt_key.text())
         command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action + ' -i "'
         command_line += str(self.edt_filename.text()) + '"'
         print(' ******* BOTH CHECKED: command_line = ' + command_line)

      elif (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):

         command_line = 'python sensor_cloud_utils.py -i "'
         command_line += str(self.edt_filename.text())
         command_line += '" -a ' + parse_to_csv_action
         # command_line += '" -a pfmb'
         print(' ******* ONLY PARSE TO CSV CHECKED: command_line = ' + command_line)

      elif (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

         command_line = 'python sensor_cloud_utils.py -d "' + str(self.edt_device_id.text())
         command_line += '" -s "' + str(self.edt_sensor_name.text()) + '" -k "' + str(self.edt_key.text())
         command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename.text()) + '"'
         # command_line += '" -r 100 -rt "HERTZ" -a ufmb -i "' + str(self.edt_filename.text()) + '"'
         print(' ******* UPLOAD TO SENSOR CLOUD CHECKED : command_line = ' + command_line)

      else:
         error_msg += 'Must check at least one check-box: Parse to CSV or Sensor Cloud'
      # } if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked)..

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
      else:
         # subprocess.call(command_line)

         # run the process
         # 'start' takes the exec and a list of arguments
         # self.process.start('ping',['127.0.0.1'])
         self.process.start(command_line)
         # self.process.waitForStarted()
         # self.process.waitForReadyRead()

      return

   def validateDeleteAllSensors(self):
      error_msg = ''

      if (self.edt_device_id.text() == ''):
         error_msg += 'Device ID cannot be empty\n'

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
      else:
         command_line = 'python sensor_cloud_utils.py -d "' + str(self.edt_device_id.text())
         command_line += '" -k "' + str(self.edt_key.text())
         command_line += '" -a das'

         self.process.start(command_line)
         # subprocess.call(command_line)

      return

   def clearConsoleLog(self):
      self.logOutput.clear()

      return

# ---------------------------------------------------
class MyLineEdit(QtGui.QLineEdit):

   def __init__(self):
      super(MyLineEdit, self).__init__()

      # self.initUI()

   # def initUI(self):

      # self.move(60, 60)
      # self.textChanged[str].connect(self.onChanged)
      # self.show()

   # def onChanged(self, text):
      # self.adjustSize()

# ---------------------------------------------------
class MyCheckBox(QtGui.QCheckBox):

   def __init__(self, lbl):
      super(MyCheckBox, self).__init__(lbl)

      self.initUI()

   def initUI(self):

      # self.move(20, 20)
      self.toggle()
      # self.stateChanged.connect(self.changeTitle)

      # self.show()

   # def changeTitle(self, state):

      # if state == QtCore.Qt.Checked:
         # self.setText('Parse to CSV Checked')
      # else:
         # self.setText('Parse to CSV Unchecked')

# ---------------------------------------------------
class MyComboBox(QtGui.QComboBox):

   def __init__(self):
      super(MyComboBox, self).__init__()

      self.initUI()

   def initUI(self):

      self.addItem("MIP")
      self.addItem("Novatel")

      self.move(50, 50)

      # self.activated[str].connect(self.onActivated)

   # def onActivated(self, text):
      # self.setStyleSheet("background-color: #E0E0E0;");
      # self.adjustSize()

# ---------------------------------------------------

def main():
   app = QtGui.QApplication(sys.argv)
   win = MainWindow()
   sys.exit(app.exec_())

if __name__ == '__main__':
    main()
