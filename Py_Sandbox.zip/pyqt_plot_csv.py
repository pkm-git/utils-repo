import csv
import numpy
import sys
import struct
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph as pg

def main_line(argv):

   data_rate = 1000.0
   file_name = 'U:/Lord/Python_HIL_Sim_From_File/Vehicle_Logs/2016_07_12/GPS_Log.csv'
   endian_prefix = '<'

   for i in range(len(argv)):
      if (argv[i] == '-r' and len(argv) > i+1):
         data_rate = float(argv[i+1])
      elif (argv[i] == '-f' and len(argv) > i+1):
         file_name = argv[i+1]
      elif (argv[i] == '-e'):
         efficiency_on = True
      elif (argv[i] == '-h'):
         hex_data_format = True
      elif (argv[i] == '-E' and len(argv) > i+1):
         if (argv[i+1].lower() == 'big'):
            endian_prefix = '>'
         elif (argv[i+1].lower() == 'little'):
            endian_prefix = '<'
      elif (argv[i] == '-t' and len(argv) > i+1):
         if(argv[i+1].lower() == 'signed_char'):
            unpack_format_string = 'b'
         elif(argv[i+1].lower() == 'unsigned_char'):
            unpack_format_string = 'B'
         elif(argv[i+1].lower() == 'short'):
            unpack_format_string = 'h'
         elif(argv[i+1].lower() == 'unsigned_short'):
            unpack_format_string = 'H'
         elif(argv[i+1].lower() == 'int'):
            unpack_format_string = 'i'
         elif(argv[i+1].lower() == 'unsigned_int'):
            unpack_format_string = 'I'
         elif(argv[i+1].lower() == 'long'):
            unpack_format_string = 'l'
         elif(argv[i+1].lower() == 'unsigned_long'):
            unpack_format_string = 'L'
         elif(argv[i+1].lower() == 'long_long'):
            unpack_format_string = 'q'
         elif(argv[i+1].lower() == 'unsigned_long_long'):
            unpack_format_string = 'Q'
         elif(argv[i+1].lower() == 'float'):
            unpack_format_string = 'f'
         elif(argv[i+1].lower() == 'double'):
            unpack_format_string = 'd'
      # } if (argv[i] == '-r'..
   # } for i in range(len(argv))..

   gps_week = []
   gps_tow = []
   channel_data = []
   headers = []
   gps_lat = []
   gps_lon = []
   gps_vert_acc = []

   index = 0
   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   in_csvfile = open(file_name,'rUb')
   csvreader = csv.reader(in_csvfile, delimiter=',')

   for row_item in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers == True):
         n_data_columns =  len(row_item)
         print(' ******* len(row_item) = ' + str(len(row_item)) + ', n_data_columns = ' + str(n_data_columns))

         # Create a list of channel names from the headers
         # for i in range(n_data_columns-1):
            # headers[i] = row_item[i]

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

      elif(headers_found == True):

         if (len(row_item) > 0):
            # data_row_cnt = data_row_cnt + 1

            # print(' ******* data_row_cnt = ' + str(data_row_cnt) + ' len(row_item) = ' + str(len(row_item)) )
            # print(' ****** row_item[0] = ' + row_item[0] + ' row_item[1] = ' + row_item[1] + ' row_item[2] = ' + row_item[2])

            # Default values of GPS Week column = 2, GPS TOW column = 3 (counting 1st column as column 1)
            # These defaults are valid for MIP-based csv files created from the 'Sensor_Cloud_utils' Python script.
            # If GPS Week and TOW columns are different from the default, send the actual column numbers to this function (counting 1st column as column 1)
            # gps_week[data_row_cnt] = int(row_item[1])
            # gps_tow[data_row_cnt] = numpy.double(row_item[2])
            # gps_lat[data_row_cnt] = numpy.double(row_item[3])
            # gps_lon[data_row_cnt] = numpy.double(row_item[4])
            # gps_vert_acc[data_row_cnt] = numpy.double(row_item[8])
            gps_week.append(int(row_item[1]))
            gps_tow.append(numpy.double(row_item[2]))
            gps_lat.append(numpy.double(row_item[3]))
            gps_lon.append(numpy.double(row_item[4]))

            data_row_cnt = data_row_cnt + 1
         # } if (len(row_item) > 0)..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(row_item) == 1 and row_item[0] == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers == True)..
   # } for row_item in csvreader..

   print(' ********* Found ' + str(data_row_cnt) + ' rows of data')

   # for m in range(len(gps_tow)):
     # print(' ***** m = ' + str(m) + ' gps_tow[m] = ' + str(gps_tow[m]) + ' gps_lat[m] = ' + str(gps_lat[m]))

   if (1):
      # PyQtGraph Plotting
      app = QtGui.QApplication([])
      pg.setConfigOption('background', 'w')

      win = pg.GraphicsWindow(title="GPS CSV Data Plot")
      win.resize(1000, 600)
      win.setWindowTitle('GPS Lat vs TOW')

      # Enable antialiasing for prettier plots
      pg.setConfigOptions(antialias=True)

      # Generate the figure parameters for plotting output data
      p1 = win.addPlot()

      # p1.plot(output_f, output_x_fft_power, pen='r')
      p1.plot(gps_tow, gps_lat, pen='b')
      # p1.plot(gps_tow, gps_lat)

      # p1.setLogMode(x=False, y=True)
      # p1.enableAutoRange('xy', False)
      # p1.setXRange(0, data_rate/2.0, padding=0)
      p1.showGrid(x=True, y=True)

      p1.setLabel('bottom','GPS TOW')
      p1.setLabel('left','GPS Lat')

   if (0):
      win2 = pg.GraphicsWindow(title="Full Run Time Series: " + file_name)
      win2.resize(1000, 600)

      p5 = win2.addPlot(title="Time Series: " + file_name)

      # p5.plot(range(len(output_series_x)), output_series_x, pen='r')

      p5.showGrid(x=True, y=True)

   QtGui.QApplication.instance().exec_()

if(__name__ == "__main__"):
 main_line(sys.argv)
