import csv
import sys
import numpy
import os

from gpstime import *
from struct import * #import all objects and functions from the struct library

def print_usage_message():
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("Usage: python nmea_to_csv.py -i in_nmea_file_name\n")
 print("in_nmea_file_name\t-- the name of the input NMEA csv data file including the path")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""

    METERS_PER_SEC_TO_KNOTS = 1.94384;

    in_nmea_file_name = None

    #parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-i' and len(argv) > i+1):
         in_nmea_file_name = argv[i+1]

    # if command line arguments were not properly specified tell the user and exit
    if(in_nmea_file_name == None):
      print_usage_message()
      sys.exit()

    nmea_in_csvfile = open(in_nmea_file_name,'rUb')
    nmea_csvreader = csv.reader(nmea_in_csvfile, delimiter=',')

    # Create the output csv file
    (fin_filepath, fin_filename) = os.path.split(in_nmea_file_name)
    # fout_csv_from_nmea = open(os.path.join(fin_filepath, "nmea_gprmc_data.csv"), "w")
    fout_csv_from_nmea = open(os.path.join(fin_filepath, fin_filename[:-4] + "_nmea.csv"), "w")

    fout_csv_from_nmea.write('NMEA UTC Time,NMEA UTC Date,UTC TOD,GPS Week,GPS TOW,GPS SOD,Lat (deg),Lon (deg),Grnd Speed (m/s),Heading (deg)\n')

    nmea_row_cnt = 0
    nmea_gprmc_row_cnt = 0

    # *****************************
    # Write NMEA data into csv file
    # *****************************
    for nmea_row_items in nmea_csvreader:

        nmea_row_cnt = nmea_row_cnt + 1

        # $GPRMC   133246     A   4426.1215   N   7306         W   145.8    0     250216  *1B
	# $GPRMC   133310.00  A   4427.09303  N   07305.99966  W   145.8    0.0   250216  14.5   E   A*1A
	
        lat = 0
        lon = 0
        grnd_spd = 0
        course = 0

        if (nmea_row_items[0] == '$GPRMC'):
           nmea_gprmc_row_cnt = nmea_gprmc_row_cnt + 1

           time = numpy.double(nmea_row_items[1])/10000;

           hr = int(numpy.floor(time))
           min = int(numpy.floor((time - hr) * 100))

           x = (time - hr) * 100
           sec = (x - min) * 100
           sec_from_midnight = hr * 3600 + min * 60 + sec

           if (nmea_row_items[3] != ''):
              x = numpy.double(nmea_row_items[3])/100;
              lat = numpy.floor(x) + (x - numpy.floor(x)) * 100/60;

              if (nmea_row_items[4] == 'S'):
                 lat = -lat;
           # } if (nmea_row_items[3] != '')..

           if (nmea_row_items[5] != ''):
              y = numpy.double(nmea_row_items[5])/100;
              lon = numpy.floor(y) + (y - numpy.floor(y)) * 100/60;
              if (nmea_row_items[6] == 'W'):
                 lon = -lon;
           # } if (nmea_row_items[5] != '')..

           if (nmea_row_items[7] != ''):
               grnd_spd = numpy.double(nmea_row_items[7]) / METERS_PER_SEC_TO_KNOTS;  # in m/s

           if (nmea_row_items[8] != ''):
               course = numpy.double(nmea_row_items[8]) # degrees

           if (nmea_row_items[9] != ''):
               log_date = numpy.double(nmea_row_items[9]);

               day = int(numpy.floor(log_date/10000))
               month = int(numpy.floor(log_date/100) - day * 100)
               year = int(log_date % (day * 100 + month))

               (w, sow, d, sod) = gpsFromUTC(year, month, day, hr, min, int(sec))
           # } if (nmea_row_items[9] != '')..

           fout_csv_from_nmea.write('%s,%s,%11.6f,%4d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(nmea_row_items[1], nmea_row_items[9], sec_from_midnight, w, sow, sod, lat, lon, grnd_spd, course))

    # } for nmea_row_items in nmea_csvreader..

    print('\n------------------------------------------------------------------------------')
    print ('\n************* Total nbr of NMEA rows processed: ' + str(nmea_row_cnt) + '; Nbr of GPRMC rows = ' + str(nmea_gprmc_row_cnt))
    print('\n------------------------------------------------------------------------------')

    fout_csv_from_nmea.close()

if(__name__ == "__main__"):
  main_line(sys.argv)


