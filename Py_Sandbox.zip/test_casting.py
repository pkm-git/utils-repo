import numpy
import math
import sys

orig_gyro_x = -99.6947

x = int(-99.6947)
print( ' ********* x = ' + str(x))

f = math.floor(-99.6947)
print( ' ********* f = ' + str(f))

y = int(math.floor(-99.6947))
print( ' ********* y = ' + str(y))

tmp = int(math.floor(abs(orig_gyro_x)));
print (' ******* tmp = ' + str(tmp))

tmp_rem = tmp % 360
tmp_frac = abs(orig_gyro_x) - tmp;

# if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
if (tmp_rem == 359):
   gyro_x = 0.0
elif (orig_gyro_x > 0):
   gyro_x = tmp_rem + tmp_frac;
else:
   gyro_x = -(tmp_rem + tmp_frac);

print(' ****** orig_gyro_x: ' + str(orig_gyro_x) + ', gyro_x = ' + str(gyro_x))

str_in = raw_input()

print('****** will supply input via program ')

# print raw_input('')
sys.stdin = ''

if (str_in == ''):
   print(' ********* Enter key ')
elif (str_in == '\n'):
   print(' ********* EOL key ')
else:
   print(' ********* Other input: ' + str_in)
