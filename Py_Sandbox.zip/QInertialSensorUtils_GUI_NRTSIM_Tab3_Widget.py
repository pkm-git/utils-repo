import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

class MyNRTSIMTab3FormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyNRTSIMTab3FormWidget, self).__init__(parent)
      self.parent_obj = parent
      
      # self.setFixedSize(550,250)
      # self.setFixedSize(575,200)
      self.setFixedSize(600,175)

      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyNRTSIMTab3FormWidget window"

      super(MyNRTSIMTab3FormWidget, self).closeEvent(event)

   def __controls(self):
      self.declare_spaces()
      
      self.lbl_title = QtGui.QLabel("NRTSIM Tab 2")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(120)
      self.lbl_title.setFixedHeight(25)
      
      self.chkbx_estimate_accel_bias = MyCheckBox('Estimate Accel Bias')
      self.chkbx_estimate_accel_bias.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_estimate_accel_bias.setFixedSize(150,40)
      
      self.chkbx_estimate_gyro_bias = MyCheckBox('Estimate Gyro Bias')
      self.chkbx_estimate_gyro_bias.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_estimate_gyro_bias.setFixedSize(150,40)
      
      self.chkbx_estimate_accel_SF = MyCheckBox('Estimate Accel SF')
      self.chkbx_estimate_accel_SF.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_estimate_accel_SF.setFixedSize(150,40)
      
      self.chkbx_estimate_gyro_SF = MyCheckBox('Estimate Gyro SF')
      self.chkbx_estimate_gyro_SF.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_estimate_gyro_SF.setFixedSize(150,40)
      
      self.chkbx_enable_mag_hard_auto_cal = MyCheckBox('Enable Mag Hard Iron Auto Cal')
      self.chkbx_enable_mag_hard_auto_cal.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_enable_mag_hard_auto_cal.setFixedSize(200,30)
      
      self.chkbx_enable_mag_soft_auto_cal = MyCheckBox('Enable Mag Soft Iron Auto Cal')
      self.chkbx_enable_mag_soft_auto_cal.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_enable_mag_soft_auto_cal.setFixedSize(200,30)
      
      self.chkbx_estimate_gnss_ant_offset = MyCheckBox('Estimate GNSS Antenna Offset')
      self.chkbx_estimate_gnss_ant_offset.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_estimate_gnss_ant_offset.setFixedSize(200,40)
      
      self.chkbx_enable_EF_Vel_ZUPT = MyCheckBox('Enable EF Velocity ZUPT')
      self.chkbx_enable_EF_Vel_ZUPT.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_enable_EF_Vel_ZUPT.stateChanged.connect(self.enableVelZUPT)
      self.chkbx_enable_EF_Vel_ZUPT.setFixedSize(150,30)
      
      self.chkbx_enable_angular_rate_ZUPT = MyCheckBox('Enable Angular Rate ZUPT')
      self.chkbx_enable_angular_rate_ZUPT.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.chkbx_enable_angular_rate_ZUPT.stateChanged.connect(self.enableAngRateZUPT)
      self.chkbx_enable_angular_rate_ZUPT.setFixedSize(175,30)
      
      self.lbl_threshold_vel = QtGui.QLabel("Threshold:")
      # self.lbl_threshold_vel.setFixedWidth(40)
      self.lbl_threshold_vel.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_threshold_vel.setFixedSize(75,30)

      self.lbl_threshold_ang_rate = QtGui.QLabel("Threshold:")
      # self.lbl_threshold_ang_rate.setFixedWidth(40)
      self.lbl_threshold_ang_rate.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_threshold_ang_rate.setFixedSize(75,30)
      
      self.edt_threshold_vel = MyLineEdit()
      self.edt_threshold_vel.setStyleSheet("background-color: #E0E0E0;");
      # self.edt_threshold_vel.setFixedWidth(25)
      self.edt_threshold_vel.setReadOnly(True)
      self.edt_threshold_vel.setFixedSize(40,20)
      
      self.edt_threshold_ang_rate = MyLineEdit()
      self.edt_threshold_ang_rate.setStyleSheet("background-color: #E0E0E0;");
      # self.edt_threshold_ang_rate.setFixedWidth(25)
      self.edt_threshold_ang_rate.setReadOnly(True)
      self.edt_threshold_ang_rate.setFixedSize(40,20)
      
      self.lbl_threshold_ms = QtGui.QLabel("m/s")
      # self.lbl_threshold_ms.setFixedWidth(20)
      self.lbl_threshold_ms.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_threshold_ms.setFixedSize(40,30)
      
      self.lbl_threshold_ds = QtGui.QLabel("deg/s")
      # self.lbl_threshold_ds.setFixedWidth(20)
      self.lbl_threshold_ds.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_threshold_ds.setFixedSize(40,30)

      self.chkbx_enable_angular_rate_ZUPT.setChecked(True)
      self.chkbx_enable_angular_rate_ZUPT.setEnabled(True)
      self.edt_threshold_ang_rate.setText('0.75057')
      
      self.setCheckboxes()
      
   def setCheckboxes(self):

      if (self.parent_obj.nrtsim_form_widget.device_name == 'GX5-45'):
      
         self.chkbx_estimate_accel_bias.setChecked(True)
         self.chkbx_estimate_accel_bias.setEnabled(True)

         self.chkbx_estimate_gyro_bias.setChecked(True)
         self.chkbx_estimate_gyro_bias.setEnabled(True)

         self.chkbx_estimate_accel_SF.setChecked(True)
         self.chkbx_estimate_accel_SF.setEnabled(True)

         self.chkbx_estimate_gyro_SF.setChecked(True)
         self.chkbx_estimate_gyro_SF.setEnabled(True)

         self.chkbx_enable_mag_hard_auto_cal.setChecked(True)
         self.chkbx_enable_mag_hard_auto_cal.setEnabled(True)

         self.chkbx_enable_mag_soft_auto_cal.setChecked(True)
         self.chkbx_enable_mag_soft_auto_cal.setEnabled(True)

         self.chkbx_estimate_gnss_ant_offset.setChecked(False)
         self.chkbx_estimate_gnss_ant_offset.setEnabled(True)

         self.chkbx_enable_EF_Vel_ZUPT.setChecked(False)
         self.chkbx_enable_EF_Vel_ZUPT.setEnabled(True)

      else:
      
         self.chkbx_estimate_accel_bias.setChecked(False)
         self.chkbx_estimate_accel_bias.setEnabled(False)

         self.chkbx_estimate_gyro_bias.setChecked(True)
         self.chkbx_estimate_gyro_bias.setEnabled(True)

         self.chkbx_estimate_accel_SF.setChecked(False)
         self.chkbx_estimate_accel_SF.setEnabled(False)

         self.chkbx_estimate_gyro_SF.setChecked(False)
         self.chkbx_estimate_gyro_SF.setEnabled(False)

         self.chkbx_enable_mag_hard_auto_cal.setChecked(True)
         self.chkbx_enable_mag_hard_auto_cal.setEnabled(True)

         self.chkbx_enable_mag_soft_auto_cal.setChecked(True)
         self.chkbx_enable_mag_soft_auto_cal.setEnabled(True)

         self.chkbx_estimate_gnss_ant_offset.setChecked(False)
         self.chkbx_estimate_gnss_ant_offset.setEnabled(False)

         self.chkbx_enable_EF_Vel_ZUPT.setChecked(False)
         self.chkbx_enable_EF_Vel_ZUPT.setEnabled(False)

      # } if (self.parent_obj..
      
   def enableVelZUPT(self, state):
      if state == QtCore.Qt.Checked:
         self.edt_threshold_vel.setStyleSheet("background-color: white;");
         self.edt_threshold_vel.setText('0.0')
         self.edt_threshold_vel.setReadOnly(False)
      else:
         self.edt_threshold_vel.setStyleSheet("background-color: #E0E0E0;");
         self.edt_threshold_vel.setText('')
         self.edt_threshold_vel.setReadOnly(True)
      # } if state == QtCore.Qt.Checked..

   def enableAngRateZUPT(self, state):
      if state == QtCore.Qt.Checked:
         self.edt_threshold_ang_rate.setStyleSheet("background-color: white;");
         self.edt_threshold_ang_rate.setText('0.0')
         self.edt_threshold_ang_rate.setReadOnly(False)
      else:
         self.edt_threshold_ang_rate.setStyleSheet("background-color: #E0E0E0;");
         self.edt_threshold_ang_rate.setText('')
         self.edt_threshold_ang_rate.setReadOnly(True)
      # } if state == QtCore.Qt.Checked..
   
   def clearStatusText(self):
      self.lbl_status.setText("Status:")
      # self.logOutput.clear()

   def __layout(self):

      self.vNRTSIMFirstColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_accel_bias)
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_gyro_bias)
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_accel_SF)
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_gyro_SF)
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_gnss_ant_offset)

      self.hVelZUPTBox = QtGui.QHBoxLayout()
      self.hVelZUPTBox.addWidget(self.lbl_threshold_vel)
      self.hVelZUPTBox.addWidget(self.edt_threshold_vel)
      self.hVelZUPTBox.addWidget(self.lbl_threshold_ms)
      
      self.hAngRateZUPTBox = QtGui.QHBoxLayout()
      self.hAngRateZUPTBox.addWidget(self.lbl_threshold_ang_rate)
      self.hAngRateZUPTBox.addWidget(self.edt_threshold_ang_rate)
      self.hAngRateZUPTBox.addWidget(self.lbl_threshold_ds)

      self.vNRTSIMSecondColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMSecondColumnBox.addWidget(self.chkbx_enable_mag_hard_auto_cal)
      self.vNRTSIMSecondColumnBox.addWidget(self.chkbx_enable_mag_soft_auto_cal)
      self.vNRTSIMSecondColumnBox.addWidget(self.chkbx_enable_EF_Vel_ZUPT)
      self.vNRTSIMSecondColumnBox.addLayout(self.hVelZUPTBox)
      self.vNRTSIMSecondColumnBox.addWidget(self.chkbx_enable_angular_rate_ZUPT)
      self.vNRTSIMSecondColumnBox.addLayout(self.hAngRateZUPTBox)
      
      self.hNRTSIMOptionsBox = QtGui.QHBoxLayout()
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMFirstColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMSecondColumnBox)

      self.vNRTSIMBottomRowLayout = QtGui.QHBoxLayout()
      self.vNRTSIMBottomRowLayout.addWidget(self.lbl_space_medium)

      self.vNRTSIMBottomRowWidget = QtGui.QWidget()
      self.vNRTSIMBottomRowWidget.setLayout(self.vNRTSIMBottomRowLayout)
      self.vNRTSIMBottomRowWidget.setFixedSize(575,10)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.hNRTSIMOptionsBox)
      self.vbox.addWidget(self.vNRTSIMBottomRowWidget)

      self.setLayout(self.vbox)

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)
