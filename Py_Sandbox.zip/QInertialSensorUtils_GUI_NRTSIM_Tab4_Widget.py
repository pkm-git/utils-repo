import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

class MyNRTSIMTab4FormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyNRTSIMTab4FormWidget, self).__init__(parent)
      self.parent_obj = parent
      
      # self.setFixedSize(550,250)
      # self.setFixedSize(575,200)
      self.setFixedSize(600,175)

      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyNRTSIMTab4FormWidget window"

      super(MyNRTSIMTab4FormWidget, self).closeEvent(event)

   def __controls(self):
      self.declare_spaces()
      
      self.lbl_title = QtGui.QLabel("NRTSIM Tab 2")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(120)
      self.lbl_title.setFixedHeight(25)
      
      self.lbl_mag_noise = QtGui.QLabel("Magnetometer Noise [X/Y/Z] (gauss):")
      self.lbl_mag_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_mag_noise.setFixedSize(225,30)
      
      # self.mag_noise = '0.001' # Value for GX5-45
      # self.grav_noise = '0.1'
      
      # if (self.parent_obj.nrtsim_form_widget.device_name == 'GX5-25'):
         # self.mag_noise = '0.1'
      # } if (self.parent_obj.nrtsim_..
      
      # REF: magwn_x=0.1 magwn_y=0.1 magwn_z=0.1 gravwn_x=0.1 gravwn_y=0.1 gravwn_z=0.1 presswn=1.0 hardironwn_x=0.001 hardironwn_y=0.001 hardironwn_z=0.001 softironwn=0.001
      self.edt_mag_noise_x = MyLineEdit()
      self.edt_mag_noise_x.setStyleSheet("background-color: white;");
      self.edt_mag_noise_x.setFixedSize(60,20)
      self.edt_mag_noise_x.setText(self.parent_obj.noise_data.mag_noise)
      
      self.edt_mag_noise_y = MyLineEdit()
      self.edt_mag_noise_y.setStyleSheet("background-color: white;");
      self.edt_mag_noise_y.setFixedSize(60,20)
      self.edt_mag_noise_y.setText(self.parent_obj.noise_data.mag_noise)
      
      self.edt_mag_noise_z = MyLineEdit()
      self.edt_mag_noise_z.setStyleSheet("background-color: white;");
      self.edt_mag_noise_z.setFixedSize(60,20)
      self.edt_mag_noise_z.setText(self.parent_obj.noise_data.mag_noise)
      
      self.lbl_grav_noise = QtGui.QLabel("Gravity Noise [X/Y/Z] (g):")
      self.lbl_grav_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_grav_noise.setFixedSize(150,30)
      
      self.edt_grav_noise_x = MyLineEdit()
      self.edt_grav_noise_x.setStyleSheet("background-color: white;");
      self.edt_grav_noise_x.setFixedSize(60,20)
      self.edt_grav_noise_x.setText(self.parent_obj.noise_data.grav_noise)

      self.edt_grav_noise_y = MyLineEdit()
      self.edt_grav_noise_y.setStyleSheet("background-color: white;");
      self.edt_grav_noise_y.setFixedSize(60,20)
      self.edt_grav_noise_y.setText(self.parent_obj.noise_data.grav_noise)

      self.edt_grav_noise_z = MyLineEdit()
      self.edt_grav_noise_z.setStyleSheet("background-color: white;");
      self.edt_grav_noise_z.setFixedSize(60,20)
      self.edt_grav_noise_z.setText(self.parent_obj.noise_data.grav_noise)

      self.lbl_pressure_alt_noise = QtGui.QLabel("Pr. Alt. Noise (m):")
      self.lbl_pressure_alt_noise.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_pressure_alt_noise.setFixedSize(120,30)

      self.edt_pr_alt_noise = MyLineEdit()
      self.edt_pr_alt_noise.setStyleSheet("background-color: white;");
      self.edt_pr_alt_noise.setFixedSize(60,20)
      self.edt_pr_alt_noise.setText('1.0')

   def __layout(self):

      self.vNRTSIMFirstColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_mag_noise)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_grav_noise)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_pressure_alt_noise)
      
      self.vNRTSIMSecondColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_mag_noise_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_grav_noise_x)
      self.vNRTSIMSecondColumnBox.addWidget(self.edt_pr_alt_noise)

      self.vNRTSIMThirdColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_mag_noise_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.edt_grav_noise_y)
      self.vNRTSIMThirdColumnBox.addWidget(self.lbl_space_xsmall)

      self.vNRTSIMFourthColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_mag_noise_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.edt_grav_noise_z)
      self.vNRTSIMFourthColumnBox.addWidget(self.lbl_space_xsmall)
      
      self.hNRTSIMOptionsBox = QtGui.QHBoxLayout()
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMFirstColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMSecondColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMThirdColumnBox)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMFourthColumnBox)
      self.hNRTSIMOptionsBox.addWidget(self.lbl_space_large)

      self.vNRTSIMBottomRowLayout = QtGui.QHBoxLayout()
      self.vNRTSIMBottomRowLayout.addWidget(self.lbl_space_medium)

      self.vNRTSIMBottomRowWidget = QtGui.QWidget()
      self.vNRTSIMBottomRowWidget.setLayout(self.vNRTSIMBottomRowLayout)
      self.vNRTSIMBottomRowWidget.setFixedSize(575,30)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.hNRTSIMOptionsBox)
      self.vbox.addWidget(self.vNRTSIMBottomRowWidget)

      self.setLayout(self.vbox)
   
   def setNoiseValues(self):
      self.edt_mag_noise_x.setText(self.parent_obj.noise_data.mag_noise)
      self.edt_mag_noise_y.setText(self.parent_obj.noise_data.mag_noise)
      self.edt_mag_noise_z.setText(self.parent_obj.noise_data.mag_noise)
      
      self.edt_grav_noise_x.setText(self.parent_obj.noise_data.grav_noise)
      self.edt_grav_noise_y.setText(self.parent_obj.noise_data.grav_noise)
      self.edt_grav_noise_z.setText(self.parent_obj.noise_data.grav_noise)

      self.edt_pr_alt_noise.setText('1.0')

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)

