import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

class TabDemo(QTabWidget):
   def __init__(self, parent = None):
      super(TabDemo, self).__init__(parent)
      self.tab1 = QWidget()
      self.addTab(self.tab1,"Tab 1")
      self.tab1UI()
      self.setWindowTitle("tab demo")
      self.show()
      
   def tab1UI(self):
      layout = QFormLayout()
      layout.addRow("Name",QLineEdit())
      layout.addRow("Address",QLineEdit())
      self.setTabText(0,"Contact Details")
      self.tab1.setLayout(layout)


