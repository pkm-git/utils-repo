GSG_IMU_UNINITIALIZED               = 0

class GSG_IMU(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = GSG_IMU_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""

   [self.imu_tow, self.imu_week, self.runtime] = [0,0,0]
   [self.scaled_accel_x, self.scaled_accel_y, self.scaled_accel_z] = [0,0,0]
   [self.scaled_gyro_x, self.scaled_gyro_y, self.scaled_gyro_z] = [0,0,0]
   [self.delta_theta_roll, self.delta_theta_pitch, self.delta_theta_yaw] = [0,0,0]
   [self.delta_vel_x, self.delta_vel_y, self.delta_vel_z] = [0,0,0]


 #copy attributes function
 def copy(self):
   """Copy attributes function"""

   [self.imu_tow_copy, self.imu_week_copy, self.runtime_copy] = [self.imu_tow, self.imu_week, self.runtime]
   [self.scaled_accel_x_copy, self.scaled_accel_y_copy, self.scaled_accel_z_copy] = [self.scaled_accel_x, self.scaled_accel_y, self.scaled_accel_z]
   [self.scaled_gyro_x_copy, self.scaled_gyro_y_copy, self.scaled_gyro_z_copy] = [self.scaled_gyro_x, self.scaled_gyro_y, self.scaled_gyro_z]
   [self.delta_theta_pitch_copy, self.delta_theta_roll_copy, self.delta_theta_yaw_copy] = [self.delta_theta_pitch, self.delta_theta_roll, self.delta_theta_yaw]
   [self.delta_vel_x_copy, self.delta_vel_y_copy, self.delta_vel_z_copy] = [self.delta_vel_x, self.delta_vel_y, self.delta_vel_z]


