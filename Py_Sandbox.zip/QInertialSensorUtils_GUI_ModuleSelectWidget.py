# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

from PyQt4 import QtCore, QtGui
from QInertialSensorUtils_GUI_CommonWidgets import *
from time import sleep         #sleep
from sensor_cloud_api import *

class MySensorUtilsModuleSelectWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MySensorUtilsModuleSelectWidget, self).__init__(parent)
      self.parent_obj = parent
      self.sensor_cloud_login_mode = False
      self.sensor_cloud_device_key_mode = False

      self.__controls()
      self.__layout()

   def __controls(self):

      labelText = "Inertial Sensor Utils"

      self.lbl_title = QtGui.QLabel(labelText)
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019; padding: 3px;");

      self.lbl_title.setFixedWidth(150)
      self.lbl_title.setFixedHeight(25)

      self.lbl_desired_modules = QtGui.QLabel("Desired Module(s):")
      self.lbl_desired_modules.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.chkbx_parse_module = MyCheckBox('Binary/CSV Log File Processing')
      self.chkbx_parse_module.setChecked(True)
      self.chkbx_parse_module.setEnabled(False)
      self.chkbx_parse_module.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.chkbx_sensor_cloud = MyCheckBox('SensorCloud')
      self.chkbx_sensor_cloud.setChecked(False)
      self.chkbx_sensor_cloud.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_sensor_cloud.stateChanged.connect(self.enableSensorCloudFields)

      self.lbl_username = QtGui.QLabel("SensorCloud Username:")
      self.lbl_username.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_username = MyLineEdit()
      self.edt_username.setStyleSheet("background-color: #E0E0E0;");
      self.edt_username.setFixedWidth(200)
      self.edt_username.setReadOnly(True)

      self.lbl_password = QtGui.QLabel("SensorCloud Password:")
      self.lbl_password.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_password = MyLineEdit()
      self.edt_password.setStyleSheet("background-color: #E0E0E0;");
      self.edt_password.setEchoMode(QtGui.QLineEdit.Password)
      self.edt_password.setFixedWidth(200)
      self.edt_password.setReadOnly(True)

      self.lbl_device_id = QtGui.QLabel("Device ID:")
      self.lbl_device_id.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_device_id = MyLineEdit()
      self.edt_device_id.setStyleSheet("background-color: #E0E0E0;");
      self.edt_device_id.setReadOnly(True)
      self.edt_device_id.setFixedWidth(200)

      self.lbl_OR = QtGui.QLabel("OR:")

      self.lbl_key = QtGui.QLabel("Key:")
      self.lbl_key.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_key = MyLineEdit()
      self.edt_key.setStyleSheet("background-color: #E0E0E0;");
      self.edt_key.setReadOnly(True)
      self.edt_key.setFixedWidth(350)

      self.submit_button = MyPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(self.validate)
      self.submit_button.setFixedWidth(100)

      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(60)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(90)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(180)
      self.lbl_space_xlarge.setFixedHeight(25)

   def __layout(self):
      self.h0box = QtGui.QHBoxLayout()
      self.h0box.addWidget(self.lbl_space_small)
      self.h0box.addWidget(self.lbl_title)
      self.h0box.addWidget(self.lbl_space_small)
      self.v0box = QtGui.QVBoxLayout()
      self.v0box.addLayout(self.h0box)

      self.h2box = QtGui.QHBoxLayout()
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.chkbx_parse_module)
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.chkbx_sensor_cloud)
      self.h2box.addWidget(self.lbl_space_small)

      # Username, password fields:
      self.v31box = QtGui.QVBoxLayout()
      self.v31box.addWidget(self.lbl_desired_modules)
      self.v31box.addWidget(self.lbl_username)
      self.v31box.addWidget(self.lbl_password)
      self.v31box.addWidget(self.lbl_OR)
      self.v31box.addWidget(self.lbl_device_id)
      self.v31box.addWidget(self.lbl_key)

      self.v32box = QtGui.QVBoxLayout()
      self.v32box.addLayout(self.h2box)
      self.v32box.addWidget(self.edt_username)
      self.v32box.addWidget(self.edt_password)
      self.v32box.addWidget(self.lbl_space_large)
      self.v32box.addWidget(self.edt_device_id)
      self.v32box.addWidget(self.edt_key)

      self.h3vbox = QtGui.QHBoxLayout()
      self.h3vbox.addLayout(self.v31box)
      self.h3vbox.addLayout(self.v32box)

      self.v3box = QtGui.QVBoxLayout()
      self.v3box.addLayout(self.h3vbox)

      # Submit button:
      self.h4box = QtGui.QHBoxLayout()
      self.h4box.addWidget(self.lbl_space_xlarge)
      self.h4box.addWidget(self.submit_button)
      self.h4box.addWidget(self.lbl_space_xlarge)

      self.v4box = QtGui.QVBoxLayout()
      self.v4box.addLayout(self.h4box)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.v0box)
      self.vbox.addLayout(self.v3box)
      self.vbox.addLayout(self.v4box)

      self.vbox.setSizeConstraint(QtGui.QLayout.SetFixedSize);

      self.setLayout(self.vbox)

   # def sizeHint(self):
      # return QtCore.QSize(550, 250);

   def enableSensorCloudFields(self, state):
      if (state == QtCore.Qt.Checked):
         self.edt_username.setStyleSheet("background-color: white;");
         self.edt_username.setReadOnly(False)

         self.edt_password.setStyleSheet("background-color: white;");
         self.edt_password.setReadOnly(False)
         
         self.edt_device_id.setStyleSheet("background-color: white;");
         self.edt_device_id.setReadOnly(False)

         self.edt_key.setStyleSheet("background-color: white;");
         self.edt_key.setReadOnly(False)

      else:
         self.edt_username.setStyleSheet("background-color: #E0E0E0;");
         self.edt_username.setReadOnly(True)
         self.edt_username.setText('')

         self.edt_password.setStyleSheet("background-color: #E0E0E0;");
         self.edt_password.setReadOnly(True)
         self.edt_password.setText('')

         self.edt_device_id.setStyleSheet("background-color: #E0E0E0;");
         self.edt_device_id.setReadOnly(True)
         self.edt_device_id.setText('')

         self.edt_key.setStyleSheet("background-color: #E0E0E0;");
         self.edt_key.setReadOnly(True)
         self.edt_key.setText('')
   # } if (state == QtCore.Qt.Checked)..

   def validate(self):
      error_msg = ''

      if (self.chkbx_sensor_cloud.checkState() == QtCore.Qt.Checked):
         print('********** in validate, chkbx_sensor_cloud is checked ******* ')

         if ( \
              (self.edt_username.text() == '' and self.edt_password.text() == '' and \
               self.edt_device_id.text() == '' and self.edt_key.text() == '') \
              or \
              ( \
                (self.edt_username.text() == '' and self.edt_password.text() == '') and \
                (self.edt_device_id.text() == '' or self.edt_key.text() == '') \
              ) \
              or \
              ( \
                (self.edt_device_id.text() == '' and self.edt_key.text() == '') and \
                (self.edt_username.text() == '' or self.edt_password.text() == '') \
              ) \
            ):
               print('********** reqd fields missing ******* ')
               error_msg += 'Please provide either: [Username + Password] OR: [Device ID + Key]\n'
               QtGui.QMessageBox.about(self, "Msg Box", error_msg)
               return
         else:
            print('********** reqd fields present ******* ')
            if (self.edt_username.text() != '' and self.edt_password.text() != ''):
               self.sensor_cloud_login_mode = True
               self.sensor_cloud_device_key_mode = False
            elif (self.edt_device_id.text() != '' and self.edt_key.text() != ''):
               self.sensor_cloud_device_key_mode = True
               self.sensor_cloud_login_mode = False
            # } if (self.edt_username.text() != ''..

            self.parent_obj.sensor_cloud_enabled = True

            if (self.sensor_cloud_login_mode):
               self.parent_obj.username = self.edt_username.text()
               self.parent_obj.password = self.edt_password.text()

               devices = getDevices(self.parent_obj.username, self.parent_obj.password)
               
               if (devices == None):
                  QtGui.QMessageBox.about(self, "Msg Box", 'Username / password combination is invalid')
               else:
                  for d in devices:
                     self.parent_obj.device_id = d["serial"]
                     label = d["label"]
                     print(' ********* device_id (serial) = ' + self.parent_obj.device_id + ' label = ' + label)
                     self.parent_obj.server, self.parent_obj.token = authenticate_alternate(self.parent_obj.device_id, self.parent_obj.username, self.parent_obj.password)

                     # Use only the first device (for now):
                     break
                  # } for d in devices..
               # } if (devices != None)..   
            elif (self.sensor_cloud_device_key_mode == True):
               self.parent_obj.device_id = self.edt_device_id.text()
               self.parent_obj.key = self.edt_key.text()

               self.parent_obj.server, self.parent_obj.token = authenticate_key(self.parent_obj.device_id, self.parent_obj.key)
            # } if (self.sensor_cloud_login_mode)..

            if (self.parent_obj.server != None and self.parent_obj.token != None):
               # print(' ********** self.server = ' + self.server + ' self.token = ' + self.token + ', will call switchToLogFileUtils')
               self.parent_obj.switchToLogFileUtils()
            # } if (self.parent_obj.server != None..
         # } if ( \..
      else:
         self.parent_obj.sensor_cloud_enabled = False
         self.parent_obj.switchToLogFileUtils()
      # } if (self.chkbx_sensor_cloud.checkState() == QtCore.Qt.Checked)..

# ---------------------------------------------------

