# import Gpib

# device = Gpib.Gpib(pad=10)
# device.write('*IDN?')
# device.read()

import visa

rm = visa.ResourceManager('@py')

# print(' *********** rm.list_resources(): ' + str(rm.list_resources()))

# rm.list_resources()('ASRL1::INSTR', 'ASRL2::INSTR', 'GPIB0::12::INSTR')

# inst = rm.open_resource('GPIB0::12::INSTR')

# inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

# print(' ********* inst.query: ' + str(inst.query("*IDN?")))

print(' ********* query SOUR:SCEN:CONT?')
str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

if (str_scen_running[0:5] == 'START'):
    print("SOUR:SCEN:SENS:REG ACC")
    print(str(inst.write("SOUR:SCEN:SENS:REG ACC")))

    print("SOUR:SCEN:SENS:REG? ACC")
    print(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

    print("SOUR:SCEN:SENS:REG GYR")
    print(str(inst.write("SOUR:SCEN:SENS:REG GYR")))

    print("***** SOUR:SCEN:SENS:REG? GYR")
    print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

    print(' ********* query SOUR:SCEN:SENS:DAT? ')
    print(str(inst.query("SOUR:SCEN:SENS:DAT?")))

else:
    print(' *********** No scenario running ***********')


