# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import csv

from time import time  #import time library

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from time import sleep         #sleep

from datetime import datetime

from sensor_cloud_api import *

from csv_to_sensor_cloud import *

from mip_binary_to_csv_or_sensor_cloud import *

from novatel_binary_to_csv_or_sensor_cloud import *

def print_usage_message(msg):
   """Output usage instructions"""

   print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
   print("\n ----------- Error(s) found: --------------\n      " + msg)
   print("-----------------------------------------------")
   # print("Usage: python sensor_cloud_utils.py -i in_file_name -dd desired_desc -d device_id -k key -s sensor_name -c channel_name -ls sensor_label -lc channel_label -a desired_action -r data_rate -rt data_rate_type\n")
   print("Usage: python sensor_cloud_utils.py -i in_file_name -dd desired_desc -sv server -t token -k key -d device_id -s sensor_name -c channel_name -ls sensor_label -lc channel_label -a desired_action -r data_rate -rt data_rate_type\n")
   print("server\t-- (required if key is not provided and desired_action other than pfmb or pfnb) the server to use for the sensor cloud util call (example: dsx-dev.sensorcloud.microstrain.com)")
   print("token\t-- (required if key is not provided and desired_action other than pfmb or pfnb) the token to use for the sensor cloud util call (example: ob0f36b03ff0f8b34ff77e7b5a35b8a9afb45be9100192859a2)")
   print("device_id\t-- (required if desired_action other than pfmb or pfnb) the device id to use for the sensor cloud util call")
   print("key\t\t-- (required if server and token not provided and desired_action other than pfmb or pfnb) the key to use for the sensor cloud util call")
   print("sensor_name\t-- (required if desired_action other than das and pfmb) the sensor name to use for the sensor cloud util call")
   print("sensor_label\t-- (required if desired_action=us) the label to use for this sensor name \
         \n\t\t\t[previous value will be retained if user supplies empty string for sensor_label]")
   print("channel_name\t-- (required if desired_action=dc) the channel name to use for the sensor cloud util call")
   print("channel_label\t-- (required if desired_action=uc) the label to use for this channel name \
         \n\t\t\t[previous value will be retained if user supplies empty string for channel_label]")
   print("desired_action\t-- (required) the desired action to perform:\n\t\t\t'as' to add a single sensor\n\t\t\t'ac' to add a single channel\n\t\t\t'us' to update a sensor label \
         \n\t\t\t'uc' to update a channel label\n\t\t\t'dc' to delete a single channel\n\t\t\t'dac' to delete all channels of a sensor \
         \n\t\t\t'ds' to delete a sensor (and all its channels)\n\t\t\t'das' to delete all sensors of a device (and their channels) \
         \n\t\t\t'ufmcsv' to upload a MIP csv log file to sensor cloud \
         \n\t\t\t'ufncsv' to upload a Novatel INS csv log file to sensor cloud \
         \n\t\t\t'ufmb' to upload MIP binary log file to sensor cloud \
         \n\t\t\t'pfmb' to parse MIP binary log file into CSV files \
         \n\t\t\t'pufmb' to parse MIP binary log file into CSV files and also upload to sensor cloud \
         \n\t\t\t'pfnb' to parse a Novatel binary log file into CSV files \
         \n\t\t\t'ufnb' to upload Novatel binary log file to sensor cloud \
         \n\t\t\t'pufnb' to parse Novatel binary log file into CSV files and also upload to sensor cloud" )
   print("in_file_name\t-- (required if desired_action=ufmcsv or ufncsv or ufmb or pfmb or pufmb or pfnb or pufnb) the name of the input csv or binary file to upload or parse, including the path")
   print("data_rate\t-- (required if desired_action=ufmcsv or ufncsv or ufmb or pufmb) the data rate to use for this sensor name: used by SensorCloud to determine data outages and plot differently during those outages")
   print("data_rate_type\t-- (optional) the data rate type (HERTZ or SEC, case-insensitive) to use for this sensor name. Defaults to HERTZ")
   print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""
    server = None
    token = None
    device_id = None
    key = None
    sensor_name = None
    channel_name = None
    desired_action = None
    in_file_name = None
    data_rate = 0
    sensor_label = None
    channel_label = None
    str_data_rate_type = 'hertz'
    desired_desc = None
    submit_timestamp = ''

    # Parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-i' and len(argv) > i+1):
         in_file_name = argv[i+1]
       elif(argv[i] == '-dd' and len(argv) > i+1):
         desired_desc = argv[i+1]
       elif(argv[i] == '-sv' and len(argv) > i+1):
         server = argv[i+1]
       elif(argv[i] == '-t' and len(argv) > i+1):
         token = argv[i+1]
       elif(argv[i] == '-d' and len(argv) > i+1):
         device_id = argv[i+1]
       elif(argv[i] == '-k' and len(argv) > i+1):
         key = argv[i+1]
       elif(argv[i] == '-s' and len(argv) > i+1):
         sensor_name = str(argv[i+1])
       elif(argv[i] == '-c' and len(argv) > i+1):
         channel_name = str(argv[i+1])
       elif(argv[i] == '-a' and len(argv) > i+1):
         desired_action = argv[i+1]
       elif(argv[i] == '-ls' and len(argv) > i+1):
         sensor_label = str(argv[i+1])
       elif(argv[i] == '-lc' and len(argv) > i+1):
         channel_label = str(argv[i+1])
       elif(argv[i] == '-r' and len(argv) > i+1):
         data_rate = int(argv[i+1])
       elif(argv[i] == '-rt' and len(argv) > i+1):
         str_data_rate_type = argv[i+1]
       elif(argv[i] == '-ts' and len(argv) > i+1):
         submit_timestamp = argv[i+1]

    # If command line arguments were not properly specified tell the user and exit
    if ((desired_action != 'pfmb' and desired_action != 'pfnb' and ((key == None and (device_id == None or device_id == '' or server == None or server == '' or token == None or token == '')) or (key != None and (device_id == None or device_id == '')))) or \
        (desired_action != 'das' and desired_action != 'pfmb' and desired_action != 'pfnb' and sensor_name == None) or \
        desired_action == None or \
        ((desired_action == 'ac' or desired_action == 'uc' or desired_action == 'dc') and channel_name == None) or \
        ((desired_action == 'ufmcsv' or desired_action == 'ufmb' or desired_action == 'pfmb' or desired_action == 'pufmb' or desired_action == 'ufncsv' or desired_action == 'ufnb' or desired_action == 'pfnb' or desired_action == 'pufnb') and in_file_name == None) or \
        ((desired_action == 'ufmcsv' or desired_action == 'ufmb' or desired_action == 'pufmb' or desired_action == 'ufncsv' or desired_action == 'ufnb' or desired_action == 'pufnb') and data_rate == 0)):

        if (desired_action != 'pfmb' and desired_action != 'pfnb' and ((key == None and (device_id == None or device_id == '' or server == None or server == '' or token == None or token == '')) or (key != None and (device_id == None or device_id == '')))):
           msg = 'Device ID [-d] AND either: Key [-k] OR: Server AND Token required if desired_action other than pfmb or pfnb'
        elif ((desired_action != 'das' and desired_action != 'pfmb' and desired_action != 'pfmb') and sensor_name == None):
           msg = 'Sensor name [-s] required if desired_action other than das, pfmb and pfnb'
        elif (desired_action == None):
           msg = 'Desired action [-a] required'
        elif ((desired_action == 'ac' or desired_action == 'uc' or desired_action == 'dc') and channel_name == None):
           msg = 'Channel name required if desired_action = ac, uc, or dc'
        elif ((desired_action == 'ufmcsv' or desired_action == 'ufmb' or desired_action == 'pfmb' or desired_action == 'pufmb' or desired_action == 'ufncsv' or desired_action == 'ufnb' or desired_action == 'pfnb' or desired_action == 'pufnb') and in_file_name == None):
           msg = 'Input filename required if desired_action = ufmcsv or ufmb or pfmb or pufmb or ufncsv or ufnb or pfnb or pufnb'
        elif ((desired_action == 'ufmcsv' or desired_action == 'ufmb' or desired_action == 'pufmb' or desired_action == 'ufncsv' or desired_action == 'ufnb' or desired_action == 'pufnb') and data_rate == 0):
           msg = 'Data rate must be non-zero if desired_action = ufmcsv or ufmb or pufmb or ufncsv or ufnb or pufnb'

        print_usage_message(msg)
        sys.exit()
    # } if ((desired_action != 'pfmb' and..

    if (desired_action != 'pfmb' and desired_action != 'pfnb'):
       if (str_data_rate_type.lower() == 'hertz'):
          data_rate_type = HERTZ
       elif (str_data_rate_type.lower() == 'sec'):
          data_rate_type = SECONDS

       if (server == None and token == None and key != None):
          server, token = authenticate_key(device_id, key)
    # } if (desired_action != 'pfmb'..

    if (desired_action == 'as'):
       if (sensor_label != None):
          addSensor(server, token, device_id, sensor_name, sensor_label)
       else:
          addSensor(server, token, device_id, sensor_name)
    elif (desired_action == 'us'):
       if (sensor_label != None):
          updateSensor(server, token, device_id, sensor_name, "", sensor_label)
       else:
          updateSensor(server, token, device_id, sensor_name, "")
    elif (desired_action == 'ac'):
       if (channel_label != None):
          addChannel(server, token, device_id, sensor_name, channel_name, channel_label)
       else:
          addChannel(server, token, device_id, sensor_name, channel_name)
    elif (desired_action == 'uc'):
       if (channel_label != None):
          updateChannel(server, token, device_id, sensor_name, channel_name, channel_label)
       else:
          updateChannel(server, token, device_id, sensor_name, channel_name)
    elif (desired_action == 'ds'):
       deleteSensor(server, token, device_id, sensor_name)
    elif (desired_action == 'dc'):
       deleteChannel(server, token, device_id, sensor_name, channel_name)
    elif (desired_action == 'das'):
       deleteAllSensors(server, token, device_id)
    elif (desired_action == 'dac'):
       deleteAllChannels(server, token, device_id, sensor_name)
    elif (desired_action == 'ufmcsv'):
       csv_to_sensor_cloud_fn(server, token, device_id, submit_timestamp, sensor_name, sensor_label, data_rate, data_rate_type, in_file_name)
    elif (desired_action == 'ufncsv'):
       csv_to_sensor_cloud_fn(server, token, device_id, submit_timestamp, sensor_name, sensor_label, data_rate, data_rate_type, in_file_name, 1, 2)
    elif (desired_action == 'ufmb'):
       mip_binary_to_csv_or_sensor_cloud_fn(in_file_name, 'CLOUD', submit_timestamp, desired_desc, False, server, token, device_id, sensor_name, sensor_label, data_rate, data_rate_type)
    elif (desired_action == 'pfmb'):
       mip_binary_to_csv_or_sensor_cloud_fn(in_file_name, 'CSV', submit_timestamp, desired_desc)
    elif (desired_action == 'pufmb'):
       mip_binary_to_csv_or_sensor_cloud_fn(in_file_name, 'BOTH', submit_timestamp, desired_desc, False, server, token, device_id, sensor_name, sensor_label, data_rate, data_rate_type)
    elif (desired_action == 'pfnb'):
       novatel_binary_to_csv_or_sensor_cloud_fn(in_file_name, 'CSV', None)
    elif (desired_action == 'ufnb'):
       novatel_binary_to_csv_or_sensor_cloud_fn(in_file_name, 'CLOUD', None, server, token, device_id, sensor_name, sensor_label, data_rate, data_rate_type)
    elif (desired_action == 'pufnb'):
       novatel_binary_to_csv_or_sensor_cloud_fn(in_file_name, 'BOTH', None, server, token, device_id, sensor_name, sensor_label, data_rate, data_rate_type)

def dummy_function(msg):
   """Output usage instructions"""
   print(' ******** ' + msg)

if(__name__ == "__main__"):
  main_line(sys.argv)


