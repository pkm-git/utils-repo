import sys

import matlab.engine

from time import time  #import time library
from time import sleep         #sleep
from time import clock  #import time library

def main_line(argv):
    """Main line program"""

    start_time = clock()
    eng = matlab.engine.start_matlab()
    # future = matlab.engine.start_matlab(async=True)

    # eng = future.result()

    start_loop_time = clock()

    print('\n************* Timing test: Time to open matlab engine = ' + str(start_loop_time - start_time) + ' seconds');

    # for i in range(2):
    eng.milliPause(2,nargout=0)
    # sleep(0.002)

    end_time = clock()
    print('\n************* Timing test: Loop time elapsed = ' + str(end_time - start_loop_time) + ' seconds');

    eng.quit()

if(__name__ == "__main__"):
  main_line(sys.argv)

