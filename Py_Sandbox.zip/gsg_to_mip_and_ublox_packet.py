import csv
import sys
import numpy
import serial                  #library for accessing serial ports

from ublx import *

from time import time  #import time library

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from time import sleep         #sleep

def print_usage_message():
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("Usage: python gsg_to_mip_and_ublox_packet.py -gp gps_port_name -gb gps_port_baud -ip imu_port_name -ib imu_port_baud -ig in_gps_file_name -ii in_imu_file_name -ir imu_data_rate -inf infinite_loop\n")
 print("imu_port_name\t\t-- the name of the IMU port (example: COM10)")
 print("imu_port_baud\t\t-- the baud rate of the IMU port (example: -ib 921600)")
 print("in_imu_file_name\t-- the name of the input IMU csv data file including the path")
 print("gps_port_name\t\t-- the name of the GPS port (example: COM6)")
 print("gps_port_baud\t\t-- the baud rate of the GPS port (example: -gb 115200)")
 print("in_gps_file_name\t-- the name of the input GPS csv data file including the path")
 print("imu_data_rate\t\t-- the rate of input IMU data [use one of: 100 Hz, 250 Hz and 500 Hz.  Example: for 250 Hz, use: -ir 250]")
 print("infinite_loop\t-- use 'y' if the file reading loop needs to repeat indefinitely, 'n' if it needs to loop only once")
 print("Note: -ir and -inf clauses are optional.  If not present, it will assume 500 Hz IMU input data rate, and -inf = 'n'.  All other clauses are required.")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""

    imu_data_rate = 500 # Hz

    in_imu_file_name = None
    in_gps_file_name = None

    imu_port_name = None
    # gps_port_name = None
    gps_port_name = 'COM17'

    imu_port_baud = 0
    # gps_port_baud = 115200
    gps_port_baud = 9600

    # imu_in_csvfile = open(in_imu_file_name,'rUb')
    # imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')

    # gps_in_csvfile = open(in_gps_file_name,'rUb')
    # gps_csvreader = csv.reader(gps_in_csvfile, delimiter=',')

    fout = open("GSG_Port_Dump.txt", "w")
    fout_bin = open("GSG_Port_Dump.bin", "wb")

    # cntGlobal = 1

    #Assign serial port object
    gps_port = serial.Serial(gps_port_name, gps_port_baud)

    #Close port in case it was left open by other process
    gps_port.close()

    #open specified port
    gps_port.open()

    # Create a file to log the IMU data that was supplied as input to the HIL
    # fout_imu_hil = open("GSG_IMU_Output.csv", "w")

    # fout_imu_hil.write('GPS TFlags,GPS Week,GPS TOW,X Accel [x8004],Y Accel [x8004],Z Accel [x8004],X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],Pressure [x8017]\n')
    # fout_gps_hil.write('GPS TFlags,GPS Week,GPS TOW,Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],Flags [x810A],GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B],HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D]\n')

    gps_determine_headers = False
    gps_headers_found = False
    gps_n_input_rows = 0
    gps_n_output_rows = 0

    gps_row_cnt = 0
    gps_data_row_cnt = 0

    debug_mode = 0

    # start_time = time()
    # print(' ************* GSP UBLOX Save Binary Dump: start_time = ' + str(start_time) );

    # **********************************************
    # Store GPS data into an array of objects (rows)
    # **********************************************
    gps_row_ublox_data = []
    gps_row_data = []

    bytes_read = bytearray([])

    # for gps_row_items in gps_csvreader:
    packet_cnt = 0

    ublxp = bytearray([])
    packet_data = bytearray([])

    # bytes_read = gps_port.read()
    cnt = 0

    # while(True):
    while(cnt < 25):
       data_left = gps_port.inWaiting()        # Get the number of characters ready to be read
       sleep(0.1)
       # print('******* DATA LEFT OVER ')
       # print('******* cnt = ' + str(cnt) + ' data_left = ' + str(data_left))

       bytes_read += gps_port.read(data_left)  # Do the read and combine it with the first character

       print('******* cnt = ' + str(cnt) + ', len(bytes_read) = ' + str(len(bytes_read)))
       cnt = cnt + 1

       if (len(bytes_read) > 0):
         print(' ****** len(bytes_read) > 0');

         fout.write(hexlify(bytearray(bytes_read)).upper())
         fout_bin.write(bytearray(bytes_read))
         # print('cnt = ' + str(cnt) + ', bytes: ' + hexlify(bytearray(bytes_read)).upper())

         for k in range(0, len(bytes_read)):
            if (hexlify(bytearray(bytes_read[k])) == 'B5' and hexlify(bytearray(bytes_read[k+1])) == '62'):
               print(' ***** Found first [0xB5 0x62] UBLOX pair at byte index: ' + str(k) + '\n')
               k_start = k;
               packet_cnt = packet_cnt + 1
               break;

         # desc_set = hexlify( bytearray(bytes_read[k+2]) ).upper()
         # packet_size = int(hexlify(bytearray(bytes_read[k+3])), 16)
         # packet_bytes = bytearray( bytes_read[k:k+packet_size+6] )

         # gps_row_cnt = gps_row_cnt + 1
         # packet_data = pack('<IiiiiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_items[4]) * 1e+07), numpy.int32(numpy.double(gps_row_items[3]) * 1e+07), numpy.int32(numpy.double(gps_row_items[5]) * 1e+03), numpy.int32(numpy.double(gps_row_items[6]) * 1e+03), numpy.int32(numpy.double(gps_row_items[7]) * 1e+03), numpy.int32(numpy.double(gps_row_items[8]) * 1e+03))
         # print "********* NAV-POSLLH packet_data: " + hexlify(packet_data).upper()
         # ublxp_nav_llh = ublx_create_ublx_message(0x01, 0x02, 28, packet_data)
         #finalize packet
         # ublx_finalize(ublxp_nav_llh)
         # ublxp.extend(bytearray(ublxp_nav_llh))
         # print "\nNAV-POSLLH Packet after finalize: " + hexlify(ublxp_nav_llh).upper()

         # gps_n_input_rows += 1

         # print(" ****** GPS: Week = " + str(gps_row_items[1]) + " TOW = " + str(gps_row_items[2]) );
         # gps_row_ublox_data.append(ublxp)
         # gps_row_data.append(gps_row_items)

         # fout_gps_hil.write('%4d,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(gps_row_items[0], gps_row_items[1], gps_row_items[2], gps_row_items[3], gps_row_items[4], gps_row_items[5], gps_row_items[6], gps_row_items[7], gps_row_items[8], gps_row_items[9], gps_row_items[10], gps_row_items[11], gps_row_items[12], gps_row_items[13], gps_row_items[14], gps_row_items[15], gps_row_items[16], gps_row_items[17], gps_row_items[18], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], ]))

         # print("IMU: " + str(imu_n_input_rows)+" input rows processed")

         #file complete
         # print("GPS: " + str(gps_n_input_rows) + " input rows processed")

    # end_time = time()
    # print('\n************* GSG PORT to UBLOX: end_time = ' + str(end_time) + ', Time elapsed = ' + str(end_time - start_time));

    fout.close()
    fout_bin.close()

    # imu_port.close()
    gps_port.close()

    # fout_imu_hil.close()
    # fout_gps_hil.close()

if(__name__ == "__main__"):
  main_line(sys.argv)


