import csv
import sys
import numpy
import serial                  #library for accessing serial ports
from mip_csv_utils import *

from mip import *

from struct import * #import all objects and functions from the struct library
from binascii import hexlify #hexlify is a function to print bytearrays as
                             #ascii strings for debugging (NOT NECESSARY FOR
                             #DATA CONVERSTIONS)

from time import sleep         #sleep
#from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

def main_line(argv):
    """Main line program"""

    #in_file_name = 'IMU_Log_wHeaders_6-30-2015 10.13.55 AM.csv';
    #in_file_name = 'IMU_Log_wHeaders_6-30-2015 10.13.55 AM_short.csv';
    #in_file_name = 'IMU_Log_wHeaders_7-21-2015 4.49.56 PM.csv';
    in_file_name = 'IMU_Log_wHeaders_7-24-2015 3.33.07 PM.csv';

    in_csvfile = open(in_file_name,'rUb')

    csvreader = csv.reader(in_csvfile, delimiter=',')

    determine_headers = False
    output_descriptors = []
    output_headers = True
    headers_found = False
    headers = []
    n_input_rows = 0
    n_output_rows = 0

    row_cnt = 0
    data_row_cnt = 0

    debug_mode = 0

    #default port settings
    #port_name = 'COM10'
    #port_baud = 230400
    #port_baud = 115200

    port_name = 'COM11'
    port_baud = 921600

    #Assign serial port object
    port = serial.Serial(port_name, port_baud)

    #Close port in case it was left open by other process
    port.close()

    #open specified port
    port.open()

    #set up background process to update data buffers
    # background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

    #start the response parsing thread
    # background_data_update.start()

    #sleep while waiting for response
    #sleep(1)

    #stop background response parsing thread
    # background_data_update.stop()

    for row_items in csvreader:

        row_cnt = row_cnt + 1

        # print(" ***** row: " + str(row_cnt)  );

        # determined that last row in CSV indicated data start (headers are in this row)
        if (determine_headers == True):
            # column headers have been found
            headers_found = True

            # headers no longer need to be determined
            determine_headers = False

        elif(headers_found == True):

            data_row_cnt = data_row_cnt + 1

            if (debug_mode == 1 and data_row_cnt % 500 == 1):
                raw_input("Press Enter to continue...")

            mp = bytearray([])

            #initialize a packet for a base command
            mip_init(mp,0x80)

            #print(" ****** row_items[1] = " + str(row_items[1]) + " row_items[2] = " + str(row_items[2]) + " row_items[15] = " + str(row_items[15]) + " row_items[16] = " + str(row_items[16])  + " row_items[17] = " + str(row_items[17]) );
            print(" ****** IMU: row_items[1] = " + str(row_items[1]) + " row_items[2] = " + str(row_items[2]));

            #print "****** Packet after add field: " + hexlify(mp).upper()

            mip_add_field(mp, 0x12, pack('>dHH', numpy.double(row_items[2]), numpy.ushort(row_items[1]), numpy.ushort(row_items[0])))

            # Accel (0x8004)
            mip_add_field(mp, 0x04, pack('>fff', float(row_items[3]), float(row_items[4]), float(row_items[5])))

            # Gyro (0x8005)
            mip_add_field(mp, 0x05, pack('>fff', float(row_items[6]), float(row_items[7]), float(row_items[8])))

            # Mag (0x8006)
            # mip_add_field(mp, 0x06, pack('>fff', float(row_items[15]), float(row_items[16]), float(row_items[17])))
            mip_add_field(mp, 0x06, pack('>fff', 0, 0, 0))

            # Delta Theta (0x8007)
            mip_add_field(mp, 0x07, pack('>fff', float(row_items[9]), float(row_items[10]), float(row_items[11])))

            # Delta Vel (0x8008)
            mip_add_field(mp, 0x08, pack('>fff', float(row_items[12]), float(row_items[13]), float(row_items[14])))

            # Pressure (0x8017)
            mip_add_field(mp, 0x17, pack('>f', float(row_items[18])))

            # mip_add_field(mp,0x12, bytearray.fromhex('2A895F'))

            # checksum = fletcher_check16(mp)

            #Print the checksum bytes
            #print "Checksum bytes: " + hexlify(checksum).upper()

            #finalize packet
            mip_finalize(mp)

            #print "Packet after finalize: " + hexlify(mp).upper()

            #send IMU MIP packet to device
            port.write(mp)

            sleep(0.002)
            #sleep(0.01)
            #sleep(0.1)
            #sleep(1)

            n_input_rows += 1

        # this row is neither column headers nor data elements
        else:
            # print(" ELSE **************** : len(row_items) = " + str(len(row_items)) + " and row_items[0] = " + row_items[0]);
            # print(row_items)
            # test for DATA_START row (column headers to follow)
            #if(len(row_items) == 1 and row_items[0] == 'DATA_START'):
            if(row_items[0] == 'DATA_START'):
                determine_headers = True
                print("DATA_START found, collecting headers")

    #file complete
    print(str(n_input_rows)+" input rows processed")
    print("Output file generation complete")
    print(str(n_output_rows)+" output rows written.")

    port.close()

if(__name__ == "__main__"):
  main_line(sys.argv)


