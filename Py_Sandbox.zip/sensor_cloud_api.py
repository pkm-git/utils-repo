# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# import web
import json
# import httplib
import http.client
import xdrlib
import time
import numpy as np

AUTH_SERVER = "sensorcloud.microstrain.com"
AUTH_DSX_SERVER = "dsx.sensorcloud.microstrain.com"
# AUTH_SERVER = "dev.sensorcloud.microstrain.com"
# AUTH_DSX_SERVER = "dsx-dev.sensorcloud.microstrain.com"
HERTZ = 1
SECONDS = 0

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

def authenticate_key(device_id, key):
   """
   authenticate with sensorcloud and get the server and auth_key for all subsequent api requests
   """
   print(' ********* Getting HTTP Connection for ' + AUTH_SERVER)

   # conn = httplib.HTTPSConnection(AUTH_SERVER)
   conn = http.client.HTTPSConnection(AUTH_SERVER)

   headers = {"Accept": "application/xdr"}
   url = "/SensorCloud/devices/%s/authenticate/?version=1&key=%s"%(device_id, key)

   print("authenticating...")
   conn.request('GET', url=url, headers=headers)
   response = conn.getresponse()
   print(response.status, response.reason)

   # If response is 200 ok then we can parse the response to get the auth token and server
   if response.status is httplib.OK:
      print("Credentials are correct")

      # Read the body of the response
      data = response.read()

      # Response will be in xdr format. Create an XDR unpacker and extract the token and server as strings
      unpacker = xdrlib.Unpacker(data)
      auth_token = unpacker.unpack_string()
      server = unpacker.unpack_string()

      print("unpacked xdr.  server:%s  token:%s"%(server, auth_token))

      # web.config.debug = False

      return server, auth_token

def authenticate_alternate(device_id, username, password):
   """
   authenticate with sensorcloud and get the server and auth_key for all subsequent api requests
   """
   conn = httplib.HTTPSConnection(AUTH_SERVER)

   headers = {"Accept": "application/xdr"}
   url = "/SensorCloud/devices/%s/authenticate/?version=1&username=%s&password=%s"%(device_id, username, password)

   # print "authenticating..."
   conn.request('GET', url=url, headers=headers)
   response =conn.getresponse()
   print(response.status, response.reason)

   # If response is 200 ok then we can parse the response to get the auth token and server
   if response.status is httplib.OK:
      print("Credentials are correct")

      # Read the body of the response
      data = response.read()

      # Response will be in xdr format. Create an XDR unpacker and extract the token and server as strings
      unpacker = xdrlib.Unpacker(data)
      auth_token = unpacker.unpack_string()
      server = unpacker.unpack_string()

      print("unpacked xdr.  server:%s  token:%s"%(server, auth_token))

      return server, auth_token

# def getDevices(server, username, password):
def getDevices(username, password):
   """
   Get devices for given username and password on sensorcloud
   """
   url = "/SensorCloud/devices/?username=%s&password=%s&version=1"%(username, password)
   conn = httplib.HTTPSConnection(AUTH_DSX_SERVER)

   headers = {"Accept":"application/xdr"}

   conn.request("GET", url, None, headers)
   res = conn.getresponse()
   devices = []

   if (res.status == 200):
      print(' *********** getDevices successful *** ')
      data = res.read()
      unpacker = xdrlib.Unpacker(data)

      # Unpack version
      unpacker.unpack_int()

      # Unpack number of devices
      numDevices = unpacker.unpack_int()

      print(' ****** numDevices = ' + str(numDevices))

      for i in xrange(numDevices):
         serial = unpacker.unpack_string()
         label = unpacker.unpack_string()
         lastHeard = unpacker.unpack_string()
         lastIP = unpacker.unpack_string()
         devices.append({"serial":serial, "label":label, "lastHeard":lastHeard, "lastIP":lastIP})

      return devices
   else:
      print(' ****** res.status = ' + str(res.status))

   # } if (res.status == 200)..

   print(res.status, res.reason)
   print(res.read())

def addSensor(server, auth_token, device_id, sensor_name, sensor_type="", sensor_label="", sensor_desc=""):
   """
   Add a sensor to the device. type, label, and description are optional.
   """
   conn = httplib.HTTPSConnection(server)
   url="/SensorCloud/devices/%s/sensors/%s/?version=1&auth_token=%s"%(device_id, sensor_name, auth_token)
   headers = {"Content-type" : "application/xdr"}

   # addSensor allows you to set the sensor type label and description.  All fields are strings.
   # We need to pack these strings into an xdr structure
   packer = xdrlib.Packer()
   packer.pack_int(1)  #version 1

   if (sensor_type == None):
      sensor_type = ""

   packer.pack_string(sensor_type)

   if (sensor_label == None):
      sensor_label = ""

   packer.pack_string(sensor_label)

   if (sensor_desc == None):
      sensor_desc = ""

   packer.pack_string(sensor_desc)

   data = packer.get_buffer()

   print("adding sensor...")
   conn.request('PUT', url=url, body=data, headers=headers)
   response =conn.getresponse()
   print(response.status, response.reason)

   #if response is 201 created then we know the sensor was added
   if response.status is httplib.CREATED:
      print("Sensor: " + sensor_name + " added successfully")
   else:
      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: Could not add sensor: " + sensor_name + ", Details: ", response_read_dict["message"])

   return response.status

def addChannel(server, auth_token, device_id, sensor_name, channel_name, channel_label="", channel_desc=""):
   """
   Add a channel to the sensor.  Label and description are optional.
   """
   conn = httplib.HTTPSConnection(server)

   url="/SensorCloud/devices/%s/sensors/%s/channels/%s/?version=1&auth_token=%s"%(device_id, sensor_name, channel_name, auth_token)

   headers = {"Content-type" : "application/xdr"}

   # addChannel allows you to set the channel label and description.  All fields are strings.
   # We need to pack these strings into an xdr structure
   packer = xdrlib.Packer()
   packer.pack_int(1)  #version 1
   packer.pack_string(channel_label)
   packer.pack_string(channel_desc)
   data = packer.get_buffer()

   # print "adding channel..."
   conn.request('PUT', url=url, body=data, headers=headers)
   response = conn.getresponse()

   # If response is 201 created then we know the channel was added
   if response.status is httplib.CREATED:
      print("Channel: " + channel_name + " successfully added")
   else:
      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: Could not add channel: " + channel_name + ", Details: ", response_read_dict["message"])

   return response.status

def updateSensor(server, auth_token, device_id, sensor_name, sensor_type="", sensor_label="", sensor_description=""):

   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/%s/?version=1&auth_token=%s" % (device_id, sensor_name, auth_token)
   headers = {"Content-Type":"application/xdr"}

   old_sensor_type = ""
   old_sensor_label = ""
   old_sensor_description = ""

   if (sensor_type == ""):
      old_sensor_type, old_sensor_label, old_sensor_description = getSensorInfo(server, auth_token, device_id, sensor_name)

   print(' ********* updateSensor: OLD old_sensor_type = ' + old_sensor_type + ', old_sensor_label = ' + old_sensor_label + ', old_sensor_description = ' + old_sensor_description)
   print(' ********* updateSensor: NEW sensor_type = ' + sensor_type + ', sensor_label = ' + sensor_label + ', sensor_description = ' + sensor_description)

   # Use old values if new values not supplied or empty:
   if (sensor_type == "" and old_sensor_type != ""):
      sensor_type = old_sensor_type

   if (sensor_label == "" and old_sensor_label != ""):
      sensor_label = old_sensor_label

   if (sensor_description == "" and old_sensor_description != ""):
      sensor_description = old_sensor_description

   packer = xdrlib.Packer()

   packer.pack_int(1)  # Version 1
   packer.pack_string(sensor_type)
   packer.pack_string(sensor_label)
   packer.pack_string(sensor_description)
   data = packer.get_buffer()

   conn.request("POST", url, data, headers)
   response = conn.getresponse()

   if response.status != 201:
      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: Could not update sensor: " + sensor_name + ", Details: ", response_read_dict["message"])
   else:
      print("Sensor successfully updated")

   return response.status

def updateChannel(server, auth_token, device_id, sensor_name, channel_name, channel_label="", channel_description=""):

   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/%s/channels/%s/?version=1&auth_token=%s" % (device_id, sensor_name, channel_name, auth_token)
   headers = {"Content-Type":"application/xdr"}

   old_channel_label = ""
   old_channel_description = ""

   if (channel_label == ""):
      old_channel_label, old_channel_description = getChannelInfo(server, auth_token, device_id, sensor_name, channel_name)

   print(' ********* updateChannel: OLD old_channel_label = ' + old_channel_label + ', old_channel_description = ' + old_channel_description)
   print(' ********* updateChannel: NEW channel_label = ' + channel_label + ', channel_description = ' + channel_description)

   # Use old values if new values not supplied or empty:
   if (channel_label == "" and old_channel_label != ""):
      channel_label = old_channel_label

   if (channel_description == "" and old_channel_description != ""):
      channel_description = old_channel_description

   packer = xdrlib.Packer()

   packer.pack_int(1)  # Version 1
   packer.pack_string(channel_label)
   packer.pack_string(channel_description)
   data = packer.get_buffer()

   conn.request("POST", url, data, headers)
   response = conn.getresponse()

   if response.status != 201:
      # print response.status, response.read()
      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: Could not update channel: " + channel_name + ", Details: ", response_read_dict["message"])
   else:
      print("Channel successfully updated")

   return response.status


def getSensorInfo(server, auth_token, device_id, sensor_name):
   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/%s/?version=1&auth_token=%s" % (device_id, sensor_name, auth_token)

   # headers = {"Content-Type":"application/xdr"}
   headers = {"Accept":"application/xdr"}

   packer = xdrlib.Packer()

   conn.request("GET", url, None, headers)
   response = conn.getresponse()

   sensor_type = ""
   sensor_label = ""
   sensor_description = ""

   if response.status == 200:
      print("getSensorInfo Successful")
      # status_message = "getSensorInfo Successful"

      unpacker = xdrlib.Unpacker(response.read())

      # Unpack version, always first
      unpacker.unpack_int()

      sensor_type = unpacker.unpack_string()
      sensor_label = unpacker.unpack_string()
      sensor_description = unpacker.unpack_string()

   elif response.status == 404:
      # print "getSensorInfo Failed: A sensor name was used that doesn't exist: ", response.status, response.read()

      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: Could not get sensor info: " + sensor_name + ", Details: ", response_read_dict["message"])

   return sensor_type, sensor_label, sensor_description

def getChannelInfo(server, auth_token, device_id, sensor_name, channel_name):
   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/%s/channels/%s/?version=1&auth_token=%s" % (device_id, sensor_name, channel_name, auth_token)

   # headers = {"Content-Type":"application/xdr"}
   headers = {"Accept":"application/xdr"}

   packer = xdrlib.Packer()

   conn.request("GET", url, None, headers)
   response = conn.getresponse()

   channel_label = ""
   channel_description = ""

   if response.status == 200:
      print("getChannelInfo Successful")
      # status_message = "getChannelInfo Successful"

      unpacker = xdrlib.Unpacker(response.read())

      # Unpack version, always first
      unpacker.unpack_int()

      channel_label = unpacker.unpack_string()
      channel_description = unpacker.unpack_string()

   elif response.status == 404:
      # print("getChannelInfo Failed: A channel name was used that doesn't exist: ", response.status, response.read())

      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: Could not get channel info: " + channel_name + ", Details: ", response_read_dict["message"])

   return channel_label, channel_description

def deleteChannel(server, auth_token, device_id, sensor_name, channel_name):
   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/%s/channels/%s/?version=1&auth_token=%s" % (device_id, sensor_name, channel_name, auth_token)

   conn.request("DELETE", url, None)

   response = conn.getresponse()
   if response.status == 204:
      print(' ************* Delete Channel Name: ' + channel_name + ' succeeded!')

   elif response.status == 404:
      print(' ************* Delete Channel Name: ' + channel_name + ' failed -- a channel name was used that does not exist')

   else:
      print(' ************* Delete Channel Name: ' + channel_name + ' failed -- other response status: ' + str(response.status))

   return response.status

def deleteSensor(server, auth_token, device_id, sensor_name):

   # First delete all channels of this sensor:
   deleteChannelStatus = deleteAllChannels(server, auth_token, device_id, sensor_name)

   if (deleteChannelStatus != 204):
      print(' ************* Delete Sensor Name: ' + sensor_name + ' failed -- Cannot delete sensor, sensor currently has existing channels')
      return 400
   else: # all channels of this sensor deleted successfully
      # Now delete the sensor itself:
      conn = httplib.HTTPSConnection(server)
      url = "/SensorCloud/devices/%s/sensors/%s/?version=1&auth_token=%s" % (device_id, sensor_name, auth_token)

      conn.request("DELETE", url, None)

      response = conn.getresponse()
      if response.status == 204:
         print(' ************* Delete Sensor Name: ' + sensor_name + ' succeeded!')
      elif response.status == 404:
         print(' ************* Delete Sensor Name: ' + sensor_name + ' failed -- a sensor name was used that does not exist')
      elif response.status == 400:
         print(' ************* Delete Sensor Name: ' + sensor_name + ' failed -- Cannot delete sensor, sensor currently has existing channels')

      return response.status

def deleteAllChannels(server, auth_token, device_id, sensor_name):
   """
   Sample call:
   deleteStatus = deleteAllChannels(server, auth_token, device_id, sensor_name)
   """
   channels = getChannels(server, auth_token, device_id, sensor_name)

   nbrFailed = 0
   nbrSucceeded = 0

   deleteStatus = 204
   cnt = 0

   for ch in channels:
      deleteStatus = deleteChannel(server, auth_token, device_id, sensor_name, ch)

      if deleteStatus != 204:
         nbrFailed += 1
      else:
         nbrSucceeded += 1
      # } if deleteStatus != 204..
   # } for ch in channels..

   print('\n*********** deleteAllChannels: sensor_name: ' + sensor_name + ' deleteAllChannels call: ' + str(nbrSucceeded) + ' succeeded, and ' + str(nbrFailed) + ' failed.')

   return deleteStatus

def deleteAllSensors(server, auth_token, device_id):
   """
   Sample call:
   deleteStatus = deleteAllSensors(server, auth_token, device_id)
   """
   sensors = getSensors(server, auth_token, device_id)

   nbrFailed = 0
   nbrSucceeded = 0

   deleteStatus = 204
   cnt = 0

   for s in sensors:
      deleteStatus = deleteSensor(server, auth_token, device_id, s)
      if (deleteStatus != 204):
         nbrFailed += 1
      else:
         nbrSucceeded += 1
      # } if deleteStatus != 204..
   # } for s in sensors..

   print('\n*********** deleteAllSensors: ' + str(nbrSucceeded) + ' succeeded, and ' + str(nbrFailed) + ' failed.')

   return deleteStatus

def getChannels(server, auth_token, device_id, sensor_name):
   """
   Sample call:
   channels, status_message = getChannels(server, auth_token, device_id, sensor_name)
   """
   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/%s/channels/?version=1&auth_token=%s" % (device_id, sensor_name, auth_token)

   headers = {"Accept":"application/xdr"}

   channels = {}

   packer = xdrlib.Packer()

   conn.request("GET", url, None, headers)

   response = conn.getresponse()
   if response.status == 200:
      print("getChannels Successful for sensor name: ", sensor_name)

      unpacker = xdrlib.Unpacker(response.read())

      # Unpack version, always first
      ver = unpacker.unpack_int()

      # 'channels' is an array of channelInfo structs.  In XDR, first you read an int, and that's the number of items in the array.  You can then loop over the number of elements in the array
      numChannels = unpacker.unpack_int()

      for j in xrange(numChannels):
         channelName = unpacker.unpack_string()

         channelLabel = unpacker.unpack_string()
         channelDescription = unpacker.unpack_string()

         # Using channel name as a key, add info to channel dict
         channels[channelName] = {"name":channelName, "label":channelLabel, "description":channelDescription, "streams":{}}

         # dataStreams for each channel is an array of streamInfo structs, Read array length as int, then loop through the items
         numStreams = unpacker.unpack_int()

         for k in xrange(numStreams):
            # streamInfo is a union, where the type indicates which stream struct to use.  Currently we only support timeseries version 1, so we'll just code for that
            streamType = unpacker.unpack_string()

            if streamType == "TS_V1":
               # TS_V1 means we have a timeseriesInfo struct
               # Total bytes allows us to jump ahead in our buffer if we're uninterested in the units.  For verbosity, we will parse them.
               total_bytes = unpacker.unpack_int()

               # Units for each data stream is an array of unit structs.  Read array length as int, then loop through the items
               numUnits = unpacker.unpack_int()

               # Add TS_V1 to streams dict
               channels[channelName]["streams"]["TS_V1"] = {"units":{}}

               for l in xrange(numUnits):
                  storedUnit = unpacker.unpack_string()
                  preferredUnit = unpacker.unpack_string()
                  unitTimestamp = unpacker.unpack_uhyper()
                  slope = unpacker.unpack_float()
                  offset = unpacker.unpack_float()

                  # Using unitTimestamp as a key, add unit info to unit dict
                  channels[channelName]["streams"]["TS_V1"]["units"][str(unitTimestamp)] = {"stored":storedUnit, "preferred":preferredUnit, "unitTimestamp":unitTimestamp, "slope":slope, "offset":offset}
               # } for l in xrange(numUnits)..
            # } if streamType == "TS_V1"..
         # } for k in xrange(numStreams)..
      # } for j in xrange(numChannels)..
   else:
      # print "getChannels Failed: ", response.status, response.read()
      response_read_dict = json.loads(response.read().decode('utf-8'))
      print("Info: getChannels Failed: " + sensor_name + ", Details: ", response_read_dict["message"])

   return channels

def getSensors(server, auth_token, device_id):
   """
   Download the Sensors and Channel information for the Device.
   Packs into a dict for easy parsing

   Sample call:
   sensors = getSensors(server, auth_token, device_id)
   """
   conn = httplib.HTTPSConnection(server)
   url = "/SensorCloud/devices/%s/sensors/?version=1&auth_token=%s" % (device_id, auth_token)
   headers = {"Accept":"application/xdr"}

   conn.request("GET", url=url, headers=headers)

   sensors = {}
   response = conn.getresponse()

   if response.status is httplib.OK:
      # print "Data Retrieved"
      unpacker = xdrlib.Unpacker(response.read())

      # Unpack version, always first
      unpacker.unpack_int()

      # Sensor info is an array of sensor structs.  In XDR, first you read an int, and that's the number of items in the array.  You can then loop over the number of elements in the array
      numSensors = unpacker.unpack_int()

      for i in xrange(numSensors):
         sensorName = unpacker.unpack_string()

         sensorType = unpacker.unpack_string()
         sensorLabel = unpacker.unpack_string()
         sensorDescription = unpacker.unpack_string()

         # Using sensorName as a key, add info to sensor dict
         sensors[sensorName] = {"name":sensorName, "type":sensorType, "label":sensorLabel, "description":sensorDescription, "channels":{}}

         # Channels for each sensor is an array of channelInfo structs.  Read array length as int, then loop through the items
         numChannels = unpacker.unpack_int()

         for j in xrange(numChannels):
            channelName = unpacker.unpack_string()
            channelLabel = unpacker.unpack_string()
            channelDescription = unpacker.unpack_string()

            # Using channel name as a key, add info to sensor's channel dict
            sensors[sensorName]["channels"][channelName] = {"name":channelName, "label":channelLabel, "description":channelDescription, "streams":{}}

            # dataStreams for each channel is an array of streamInfo structs, Read array length as int, then loop through the items
            numStreams = unpacker.unpack_int()

            for k in xrange(numStreams):
               # streamInfo is a union, where the type indicates which stream struct to use.  Currently we only support timeseries version 1, so we'll just code for that
               streamType = unpacker.unpack_string()

               if streamType == "TS_V1":
                  # TS_V1 means we have a timeseriesInfo struct
                  # Total bytes allows us to jump ahead in our buffer if we're uninterested in the units.  For verbosity, we will parse them.
                  total_bytes = unpacker.unpack_int()

                  # Units for each data stream is an array of unit structs.  Read array length as int, then loop through the items
                  numUnits = unpacker.unpack_int()

                  # Add TS_V1 to streams dict
                  sensors[sensorName]["channels"][channelName]["streams"]["TS_V1"] = {"units":{}}

                  for l in xrange(numUnits):
                     storedUnit = unpacker.unpack_string()
                     preferredUnit = unpacker.unpack_string()
                     unitTimestamp = unpacker.unpack_uhyper()
                     slope = unpacker.unpack_float()
                     offset = unpacker.unpack_float()

                     # Using unitTimestamp as a key, add unit info to unit dict
                     sensors[sensorName]["channels"][channelName]["streams"]["TS_V1"]["units"][str(unitTimestamp)] = {"stored":storedUnit,
                     "preferred":preferredUnit, "unitTimestamp":unitTimestamp, "slope":slope, "offset":offset}
                  # } for l in xrange(numUnits)..
               # } if streamType == "TS_V1"..
            # } for k in xrange(numStreams)..
         # } for j in xrange(numChannels)..
      # } for i in xrange(numSensors)..
   # } if response.status is httplib.OK..

   return sensors

# AddTimeSeriesData() function [The FAQ refer to this by its original name of 'upload2sensorcloud()']
def addTimeSeriesData(server, auth_token, device_id, sensorName, channelName, sampleRate, sampleRateType, data):
   conn = httplib.HTTPSConnection(server)

   url="/SensorCloud/devices/%s/sensors/%s/channels/%s/streams/timeseries/data/?version=1&auth_token=%s"%(device_id, sensorName, channelName, auth_token)

   # We need to pack these strings into an xdr structure
   packer = xdrlib.Packer()
   packer.pack_int(1)  #version 1

   packer.pack_enum(sampleRateType)
   packer.pack_int(sampleRate)

   # Nbr of data points
   packer.pack_int(len(data))
   for datapoint in data:
      ts = datapoint.ts
      value = datapoint.value

      packer.pack_uhyper(ts)
      packer.pack_float(value)

   uploadData = packer.get_buffer()

   headers = {"Content-type" : "application/xdr"}
   conn.request('POST', url=url, body=uploadData, headers=headers)
   response = conn.getresponse()

   # If response is 201 created then we know the channel was added
   # if response.status is httplib.CREATED:
   if (response.status == 201):
      print("Data successfully uploaded for channel name: " + channelName)
   elif (response.status == 404):
      print("Error uploading data for channel: " + channelName + ". Error: A channel name was used that doesn't exist.")
   elif (response.status == 401):
      print("Error uploading data for channel: " + channelName + ". Error: You have exceeded your upload quota.")

   return response.status

# DownloadTimeSeriesData() function
def downloadTimeSeriesData(server, auth_token, device_id, sensor_name, channel_name, startTime, endTime):
   conn = httplib.HTTPSConnection(server)

   url = "/SensorCloud/devices/%s/sensors/%s/channels/%s/streams/timeseries/data/?version=1&auth_token=%s&starttime=%s&endtime=%s" %(device_id, sensor_name, channel_name, auth_token, str(startTime), str(endTime))

   headers = {"Accept":"application/xdr"}
   conn.request("GET", url=url, headers=headers)
   response = conn.getresponse()

   data = []
   unix_timestamp = []

   if response.status is httplib.OK:
      # print "Data retrieved"
      unpacker = xdrlib.Unpacker(response.read())
      while (True):
         try:
            timestamp = unpacker.unpack_uhyper()
            value = unpacker.unpack_float()
            # data.append((timestamp, value))

            # ch = channel_data_struct()
            # ch.ts = timestamp
            # ch.value = value
            # data.append(ch)

            data.append(value)
            unix_timestamp.append(timestamp)
         except Exception as e:
            print(e)
            break
      # } while (True)..
      return np.array(data), np.array(unix_timestamp)
   else:
      print("BAD Status: %s" % response.status)
      print("Reason: %s" % response.reason)
      return data, unix_timestamp
   # } if response.status is httplib.OK..


