GPS_FORMAT_UNINITIALIZED               = 0

class GSG_GPS_format(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = GPS_FORMAT_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""

   [self.gps_tow, self.gps_week] = [0,0]
   [self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc] = [0,0,0,0,0,0]
   [self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc] = [0,0,0,0,0,0,0,0]
   [self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC] = [0,0,0,0]
   [self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC] = [0,0,0,0]
   [self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop] = [0,0,0,0,0,0,0]
   [self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec] = [0,0,0,0,0,0]
   [self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags] = [0,0,0]
   [self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate] = [0,0,0]
   [self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power] = [0,0,0]

 # gps_default_cols_dict = {"0120":"1", "0102":"2", "0112":"3", "0101":"4", "0111":"5", "0104":"6", "0121":"7", "0103":"8", "0106":"9" }

 # Master Format (all available columns from DCP, in a 'master sequence'):
 # GPS Week,GPS TOW,     Lat [x0102],Long [x0102],Height [x0102],MSL Height [x0102],Horz Acc [x0102],Vert Acc [x0102],   Vel N [x0112],Vel E [x0112],Vel D [x0112],Speed [x0112],Gnd Speed [x0112],Heading [x0112],Speed Acc [x0112],Heading Acc [x0112],   ECEF X [x0101],ECEF Y [x0101],ECEF Z [x0101],ECEF Acc [x0101],     ECEF Vel X [x0111],ECEF Vel Y [x0111],ECEF Vel Z [x0111],ECEF Vel Acc [x0111],  Geo DOP [x0104],Pos DOP [x0104],Hor DOP [x0104],Vert DOP [x0104],Time DOP [x0104],Northing DOP [x0104],Easting DOP [x0104],   UTC Year [x0121],UTC Month [x0121],UTC Day [x0121],UTC Hour [x0121],UTC Minute [x0121],UTC Second [x0121],    GPS Fix Type [x0103],GPS SVs Used [x0103],GPS Fix Flags [x0103],   Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],   HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D]
 # %4d,%12.4f,           %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                      %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                                           %14.8f,%14.8f,%14.8f,%14.8f,                                       %14.8f,%14.8f,%14.8f,%14.8f,                                                    %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                                             %4d,%d,%d,%d,%d,%d,                                                                                           %d,%d,%d,                                                          %14.8f,%14.8f,%14.8f,                                       %d,%d,%d,
 # gps_week, gps_tow,    gps_lat, gps_lon, gps_ht_abv_ellip, gps_ht_abv_MSL, gps_horiz_acc, gps_vert_acc,                gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc,                        gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC,   gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC,                geom_dop, pos_dop, horiz_dop, vert_dop, time_dop, northing_dop, easting_dop,                                                  utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec                                                             gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags                   gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate,    gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power

 def format(self, format_in):
     if (format_in == 1):
         return '{:-4d},{:-12.4f},'.format(self.gps_week, self.gps_tow)
     elif (format_in == 2):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc)
     elif (format_in == 3):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc)
     elif (format_in == 4):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC)
     elif (format_in == 5):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC)
     elif (format_in == 6):
         return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop)
     elif (format_in == 7):
         return '{:-4d},{:-d},{:-d},{:-d},{:-d},{:-d},'.format(self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec)
     elif (format_in == 8):
         return '{:-d},{:-d},'.format(self.gps_fix_type, self.gps_fix_flags)
     elif (format_in == 9):
         return '{:-d},'.format(self.gps_nbr_of_svs_used)
     elif (format_in == 10):
         return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate)
     elif (format_in == 11):
         return '{:-d},{:-d},{:-d},'.format(self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power)

     return 'GPS_format'

 def format_header(self, format_in):
     if (format_in == 1):
         return 'GPS Week,GPS TOW,'
     elif (format_in == 2):
         return 'Lat [x0102],Long [x0102],Height [x0102],MSL Height [x0102],Horz Acc [x0102],Vert Acc [x0102],'
     elif (format_in == 3):
         return 'Vel N [x0112],Vel E [x0112],Vel D [x0112],Speed [x0112],Gnd Speed [x0112],Heading [x0112],Speed Acc [x0112],Heading Acc [x0112],'
     elif (format_in == 4):
         return 'ECEF X [x0101],ECEF Y [x0101],ECEF Z [x0101],ECEF Acc [x0101],'
     elif (format_in == 5):
         return 'ECEF Vel X [x0111],ECEF Vel Y [x0111],ECEF Vel Z [x0111],ECEF Vel Acc [x0111],'
     elif (format_in == 6):
         return 'Geo DOP [x0104],Pos DOP [x0104],Hor DOP [x0104],Vert DOP [x0104],Time DOP [x0104],Northing DOP [x0104],Easting DOP [x0104],'
     elif (format_in == 7):
         return 'UTC Year [x0121],UTC Month [x0121],UTC Day [x0121],UTC Hour [x0121],UTC Minute [x0121],UTC Second [x0121],'
     elif (format_in == 8):
         return 'GPS Fix Type [x0103],GPS Fix Flags [x0103],'
     elif (format_in == 9):
         return 'GPS SVs Used [x0103],'
     elif (format_in == 10):
         return 'Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],'
     elif (format_in == 11):
         return 'HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],'

     return 'GPS_format_header'


