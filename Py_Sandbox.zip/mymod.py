def myfunc():
    """Display message."""
    return 'version 3'
