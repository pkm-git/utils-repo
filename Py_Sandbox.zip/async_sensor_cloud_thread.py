import sys
import threading       #import thread library
import StringIO
from time import time  #import time library
from time import sleep           #sleep
# from QSensorCloudUtils_GUI_SensorListWidget import *

from PyQt4 import QtCore, QtGui

#Class to asynchronously load Sensor List from Sensor Cloud
class AsyncSensorCloud(threading.Thread):
   """Thread Object for loading sensor list from sensor cloud """
   def __init__(self, lbl_status_object, timeout = 0.001):
      """Initialize the AsyncSensorCloud Object"""
      threading.Thread.__init__(self)
      # self.main_window = main_window
      # self.sensor_list_widget = None
      # self.load_sensor_list_obj = load_sensor_list_object
      self.timeout = timeout
      self._stop = False
      self.step = 0
      self.lbl_status_object = lbl_status_object

   def stop(self):
      """Stop thread loop"""
      self._stop = True

   def run(self):
      print(' *********** AsyncSensorCloud::run(): ')
      # self.load_sensor_list_obj.sensor_list_widget = MySensorListWidget(self.main_window)
      
      # self.load_sensor_list_obj.done = True

      while(self._stop == False):
         # self.command_line_obj.done = True
         self.step += 1
         print(' ********** self.step = ' + str(self.step))
         
         self.lbl_status_object.setText("Status: Doing.. Time elapsed: " + str(self.step) + " seconds")
         
         sleep(1.0)

      # } while(self._stop == False)...

