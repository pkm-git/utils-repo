NOVATEL_GPS_FORMAT_UNINITIALIZED               = 0

class Novatel_GPS_format(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = NOVATEL_GPS_FORMAT_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""

   [self.gps_week, self.gps_tow, self.message_length, self.message_type, self.imu_status, self.ins_status] = [0,0,0,0,0,0]
   # [self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation, self.datum_id_nbr, self.lat_sd, self.lon_sd, self.ht_MSL_sd, self.base_station_id, self.diff_age, self.sol_age, self.nbr_svs_tracked, self.nbr_svs_used, self.nbr_gps_gll1_svs_used, self.nbr_gps_gll1l2_svs_used] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
   [self.ins_lat, self.ins_lon, self.ins_ht_abv_ellip] = [0,0,0]
   [self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation] = [0,0,0,0]
   [self.ins_vned_N, self.ins_vned_E, self.ins_vned_D] = [0,0,0]
   [self.ekf_latency, self.diff_age, self.ins_horiz_speed, self.ins_vert_speed, self.ins_grnd_trc] = [0,0,0,0,0]
   [self.ekf_horiz_speed, self.ekf_vert_speed, self.ekf_grnd_trc] = [0,0,0]
   [self.roll, self.pitch, self.azimuth] = [0,0,0]
   [self.x_accel, self.y_accel, self.z_accel] = [0,0,0]
   [self.x_gyro, self.y_gyro, self.z_gyro] = [0,0,0]
   [self.rcvr_clock_status, self.rcvr_clock_offset, self.rcvr_clock_offset_sd, self.utc_offset, self.utc_year, self.utc_month, self.utc_day, self.utc_hour, self.utc_min, self.utc_ms, self.utc_status] = [0,0,0,0,0,0,0,0,0,0,0]
   [self.x_veh2body_angle, self.y_veh2body_angle, self.z_veh2body_angle, self.x_veh2body_angle_unc, self.y_veh2body_angle_unc, self.z_veh2body_angle_unc] = [0,0,0,0,0,0]

 # } def init(self)..

 # gps_default_cols_dict = {"321":"1", "324":"2", "323":"3", "319":"4", "325":"5"}

 # Master Format (all available columns from DCP, in a 'master sequence'):
 # GPS Week,GPS TOW,     INS Lat [321],INS Lon [321],INS Ht Abv Ellips [321],   EKF Lat [42],EKF Lon [42],EKF Ht Abv MSL [42],Undulation [42],    Vel N [324],Vel E [324],Vel D [324],   INS Horiz Speed [323],INS Vert Speed [323],INS Grnd Trc [323],  EKF Latency[99], EKF Diff Age[99],EKF Horiz Speed [99],EKF Vert Speed [99],EKF Grnd Trc [99],   Roll [319],Pitch [319],Azimuth [319],    X_Accel [325],Y_Accel [325],Z_Accel [325],X_Gyro [325],X_Gyro [325],X_Gyro [325],
 # %4d,%12.4f,           %14.8f,%14.8f,%14.8f,                                  %14.8f,%14.8f,%14.8f,%14.8f,                                      %14.8f,%14.8f,%14.8f,                  %14.8f,%14.8f,%14.8f,                                           %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                             %14.8f,%14.8f,%14.8f,                    %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,
 # gps_week, gps_tow,    ins_lat, ins_lon, ins_ht_abv_ellip,                    ekf_lat, ekf_lon, ekf_ht_abv_MSL, undulation,                     ins_vned_N, ins_vned_E, ins_vned_D,    ins_horiz_speed, ins_vert_speed, ins_grnd_trc                   ekf_latency, diff_age, ekf_horiz_speed, ekf_vert_speed, ekf_grnd_trc                            roll,pitch,azimuth,                      x_accel,y_accel,z_accel,x_gyro,y_gyro,z_gyro

 # 42: BESTPOS
 # 99: BESTVEL
 # 101: TIME
 # 241: BESTXYZ

 # 265: INSPOS
 # 321: INSPOSS

 # 266: INSSPD
 # 323: INSSPDS

 # 267: INSVEL
 # 324: INSVELS

 # 263: INSATT
 # 319: INSATTS

 # 507: INSPVA
 # 508: INSPVAS

 # 268: RAWIMU
 # 325: RAWIMUS

 # 642: VEHICLEBODYROTATION

 # Message ID sequence: "42":"1", "99":"2", "101":"3", "319":"4", "321":"5", "324":"6", "323":"7", "508":"8", "325":"9", "642":"10", "263":"11", "265":"12", "266":"13", "267":"14", "507":"15", "268":"16"
 # min_gps_default_cols_dict = {"42":"1", "99":"2", "101":"3", "319":"4", "321":"5", "324":"6", "323":"7", "508":"8", "325":"9", "642":"10", "263":"11", "265":"12", "266":"13", "267":"14", "507":"15", "268":"16"}

 # min_gps_default_cols_dict = {"321":"1", "42":"2", "324":"3", "323":"4", "99":"5", "319":"6", "508":"7", "325":"8", "101":"9", "642":"10"}

 # min_gps_default_long_cols_dict = {"263":"319", "265":"321", "266":"323", "267":"324", "507":"508", "268":"325"}

 def format(self, format_in):
     if (format_in == 0):
        return '{:-4d},{:-12.4f},{:-4d},{:-4d},{:-4d},{:-4d},'.format(self.gps_week, self.gps_tow, self.message_length, self.message_type, self.imu_status, self.ins_status)
        # return '{:-4d},{:-12.4f},{:-4d},{:-4d},'.format(self.gps_week, self.gps_tow, self.message_id, self.message_length)
     elif (format_in == 1):
        return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_lat, self.ins_lon, self.ins_ht_abv_ellip)
     elif (format_in == 2):
        # return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation, self.datum_id_nbr, self.lat_sd, self.lon_sd, self.ht_MSL_sd, self.base_station_id, self.diff_age, self.sol_age, self.nbr_svs_tracked, self.nbr_svs_used, self.nbr_gps_gll1_svs_used, self.nbr_gps_gll1l2_svs_used)
        return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation)
     elif (format_in == 3):
        return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_vned_N, self.ins_vned_E, self.ins_vned_D)
     elif (format_in == 4):
        return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_horiz_speed, self.ins_vert_speed, self.ins_grnd_trc)
     elif (format_in == 5):
        return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ekf_latency, self.diff_age, self.ekf_horiz_speed, self.ekf_vert_speed, self.ekf_grnd_trc)
     elif (format_in == 6):
        return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.roll, self.pitch, self.azimuth)
     elif (format_in == 7):
        return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.ins_pva_lat, self.ins_pva_lon, self.ins_pva_ht_abv_ellips, self.ins_pva_vned_N, self.ins_pva_vned_E, self.ins_pva_vned_D, self.ins_pva_roll, self.ins_pva_pitch, self.ins_pva_azimuth)
     elif (format_in == 8):
        return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.x_accel, self.y_accel, self.z_accel, self.x_gyro, self.y_gyro, self.z_gyro)
     elif (format_in == 9):
        return '{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},{:-2d},{:-2d},{:-2d},{:-2d},{:-4d},{:-4d},'.format(self.rcvr_clock_status, self.rcvr_clock_offset, self.rcvr_clock_offset_sd, self.utc_offset, self.utc_year, self.utc_month, self.utc_day, self.utc_hour, self.utc_min, self.utc_ms, self.utc_status)
     elif (format_in == 10):
        return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.x_veh2body_angle, self.y_veh2body_angle, self.z_veh2body_angle, self.x_veh2body_angle_unc, self.y_veh2body_angle_unc, self.z_veh2body_angle_unc)

     return 'Novatel_GPS_format'

 # } def format(self, format_in)..

 def format_header(self, format_in):
     if (format_in == 0):
        return 'GPS Week,GPS TOW,Msg Length,Msg Type,IMU Status,INS Status,'
     elif (format_in == 1):
        return 'INS Lat [321],INS Long [321],INS Height Abv Ellips [321],'
     elif (format_in == 2):
        return 'EKF Lat [42],EKF Long [42],EKF Height Abv MSL [42],Undulation[42],'
     elif (format_in == 3):
        return 'Vel N [324/267],Vel E [324/267],Vel D [324/267],'
     elif (format_in == 4):
        return 'INS Horiz Speed [323/266],INS Vert Speed [323/266],INS Grnd Trc [323/266],'
     elif (format_in == 5):
        return 'EKF Latency [99],EKF Diff Age [99],EKF Horiz Speed [99],EKF Vert Speed [99],EKF Grnd Trc [99],'
     elif (format_in == 6):
        return 'Roll [319/263],Pitch [319/263],Azimuth [319/263],'
     elif (format_in == 7):
        # return 'Roll [319/263],Pitch [319/263],Azimuth [319/263],'
        return 'INS_PVA_Lat [508/507], INS_PVA_Lon [508/507], INS_PVA_Ht_abv_ellips [508/507], INS_PVA_vned_N [508/507], INS_PVA_vned_E [508/507], INS_PVA_vned_D [508/507], INS_PVA_roll [508/507], INS_PVA_pitch [508/507], INS_PVA_azimuth [508/507],'   
     elif (format_in == 8):
        return 'X_Accel [325/268],Y_Accel [325/268],Z_Accel [325/268],X_Gyro [325/268],Y_Gyro [325/268],Z_Gyro [325/268],'
     elif (format_in == 9):
        return 'Rcvr Clock Status [101], Rcvr Clock Offset [101], Rcvr Clock Offset SD [101], UTC_Offset [101], UTC_Year [101], UTC_Month [101], UTC_Day [101], UTC_Hour [101], UTC_Min [101], UTC_TOW_ms [101], UTC_status [101],'
     elif (format_in == 10):
        return 'X_Veh2Body_Angle [642],X_Veh2Body_Angle [642],Z_Veh2Body_Angle [642],X_Veh2Body_Angle_Unc [642],X_Veh2Body_Angle_Unc [642],Z_Veh2Body_Angle_Unc [642],'

     return 'Novatel_GPS_format_header'

 # } def format_header(self, format_in)..

