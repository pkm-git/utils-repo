import csv
import sys
import numpy
import serial                  #library for accessing serial ports

from mip_csv_utils import *
from mip import *
from ublx import *

from time import time  #import time library

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from time import sleep         #sleep

def print_usage_message():
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("Usage: python csv_to_mip_and_ublox_packet.py -gp gps_port_name -gb gps_port_baud -ip imu_port_name -ib imu_port_baud -ig in_gps_file_name -ii in_imu_file_name -ir imu_data_rate -inf infinite_loop\n")
 print("imu_port_name\t\t-- the name of the IMU port (example: COM10)")
 print("imu_port_baud\t\t-- the baud rate of the IMU port (example: -ib 921600)")
 print("in_imu_file_name\t-- the name of the input IMU csv data file including the path")
 print("gps_port_name\t\t-- the name of the GPS port (example: COM6)")
 print("gps_port_baud\t\t-- the baud rate of the GPS port (example: -gb 115200)")
 print("in_gps_file_name\t-- the name of the input GPS csv data file including the path")
 print("imu_data_rate\t\t-- the rate of input IMU data [use one of: 100 Hz, 250 Hz and 500 Hz.  Example: for 250 Hz, use: -ir 250]")
 print("infinite_loop\t-- use 'y' if the file reading loop needs to repeat indefinitely, 'n' if it needs to loop only once")
 print("Note: -ir and -inf clauses are optional.  If not present, it will assume 500 Hz IMU input data rate, and -inf = 'n'.  All other clauses are required.")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""

    imu_data_rate = 500 # Hz

    in_imu_file_name = None
    in_gps_file_name = None

    imu_port_name = None
    gps_port_name = None

    imu_port_baud = 0
    gps_port_baud = 0

    infinite_loop = 'n'

    #parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-gp' and len(argv) > i+1):
         gps_port_name = argv[i+1]
       elif(argv[i] == '-gb' and len(argv) > i+1):
         gps_port_baud = int(argv[i+1])
       elif(argv[i] == '-ip' and len(argv) > i+1):
         imu_port_name = argv[i+1]
       elif(argv[i] == '-ib' and len(argv) > i+1):
         imu_port_baud = int(argv[i+1])
       elif(argv[i] == '-ir' and len(argv) > i+1):
         imu_data_rate = int(argv[i+1])
       elif(argv[i] == '-gi' and len(argv) > i+1):
         in_gps_file_name = argv[i+1]
       elif(argv[i] == '-ii' and len(argv) > i+1):
         in_imu_file_name = argv[i+1]
       elif(argv[i] == '-inf' and len(argv) > i+1):
         infinite_loop = argv[i+1]

    # if command line arguments were not properly specified tell the user and exit
    if(gps_port_name == None or gps_port_baud == 0 or imu_port_name == None or imu_port_baud == 0 or in_gps_file_name == None or in_imu_file_name == None or (imu_data_rate <> 100 and imu_data_rate <> 250 and imu_data_rate <> 500)):
      print_usage_message()
      sys.exit()

    print('********** GPS PORT : '+ gps_port_name + ', IMU PORT : '+ imu_port_name);

    imu_in_csvfile = open(in_imu_file_name,'rUb')
    imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')

    gps_in_csvfile = open(in_gps_file_name,'rUb')
    gps_csvreader = csv.reader(gps_in_csvfile, delimiter=',')

    cntGlobal = 1

    # fout_processing_time = open("Processing_time.csv", "w")

    imu_interp_loops = int(500/imu_data_rate)
    print('************* IMU interpolation loops: imu_interp_loops = ' + str(imu_interp_loops) );

    #Assign serial port object
    imu_port = serial.Serial(imu_port_name, imu_port_baud)

    #Close port in case it was left open by other process
    imu_port.close()

    #open specified port
    imu_port.open()

    #Assign serial port object
    gps_port = serial.Serial(gps_port_name, gps_port_baud)

    #Close port in case it was left open by other process
    gps_port.close()

    #open specified port
    gps_port.open()

    # Create a file to log the IMU data that was supplied as input to the HIL
    fout_imu_hil = open("IMU_HIL_Input.csv", "w")

    fout_imu_hil.write('GPS TFlags,GPS Week,GPS TOW,X Accel [x8004],Y Accel [x8004],Z Accel [x8004],X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],Pressure [x8017]\n')
    # fout_gps_hil.write('GPS TFlags,GPS Week,GPS TOW,Lat [x8103],Long [x8103],Height [x8103],MSL Height [x8103],Horz Acc [x8103],Vert Acc [x8103],Flags [x8103],ECEF X [x8104],ECEF Y [x8104],ECEF Z [x8104],ECEF Acc [x8104],Flags [x8104],Vel N [x8105],Vel E [x8105],Vel D [x8105],Speed [x8105],Gnd Speed [x8105],Heading [x8105],Speed Acc [x8105],Heading Acc [x8105],Flags [x8105],ECEF Vel X [x8106],ECEF Vel Y [x8106],ECEF Vel Z [x8106],ECEF Vel Acc [x8106],Flags [x8106],Geo DOP [x8107],Pos DOP [x8107],Hor DOP [x8107],Vert DOP [x8107],Time DOP [x8107],Northing DOP [x8107],Easting DOP [x8107],Flags [x8107],UTC Year [x8108],UTC Month [x8108],UTC Day [x8108],UTC Hour [x8108],UTC Minute [x8108],UTC Second [x8108],UTC Millesecond [x8108],Flags [x8108],Clock Bias [x810A],Clock Drift [x810A],Clock Acc [x810A],Flags [x810A],GPS Fix [x810B],GPS SVs Used [x810B],GPS Fix Flags [x810B],Flags [x810B],HW Sensor Stat [x810D],HW Ant Stat [x810D],HW Ant Pwr [x810D],Flags [x810D]\n')

    gps_determine_headers = False
    gps_headers_found = False
    gps_n_input_rows = 0
    gps_n_output_rows = 0

    gps_row_cnt = 0
    gps_data_row_cnt = 0

    debug_mode = 0

    imu_determine_headers = False
    imu_headers_found = False
    imu_n_input_rows = 0
    imu_n_output_rows = 0

    imu_row_cnt = 0
    imu_data_row_cnt = 0

    # **********************************************
    # Store GPS data into an array of objects (rows)
    # **********************************************
    gps_row_ublox_data = []
    gps_row_data = []

    gps_init_tow = 0.0

    for gps_row_items in gps_csvreader:

        gps_row_cnt = gps_row_cnt + 1

        # print(" *************************************************************************** ")
        # print(" ***** gps_row cnt: " + str(gps_row_cnt) + ', gps_row_items = ' + str(gps_row_items) + ', len(gps_row_items) = ' + str(len(gps_row_items)) );

        # determined that last row in CSV indicated data start (headers are in this row)
        if (gps_determine_headers == True):
            # column headers have been found
            gps_headers_found = True

            # headers no longer need to be determined
            gps_determine_headers = False

        elif(gps_headers_found == True):
            gps_data_row_cnt = gps_data_row_cnt + 1

            # print("************ gps_data_row_cnt = " + str(gps_data_row_cnt) + ", gps_row_items[2] = " + str(gps_row_items[2]))

            if (gps_data_row_cnt == 1):
                gps_init_tow = numpy.double(gps_row_items[2])

            ublxp = bytearray([])

            packet_data = bytearray([])

            ##################################
            # NAV-TIMEGPS message (0x01 0x20):
            ##################################
            GPS_TOW_rounded_ms = numpy.uint32(numpy.rint(numpy.double(gps_row_items[2]) * 1000.0))
            GPS_TOW_Real_Minus_Rounded_ms = numpy.double(gps_row_items[2]) * 1000.0 - numpy.uint32(numpy.rint(numpy.double(gps_row_items[2]) * 1000.0))
            GPS_TOW_Real_Minus_Rounded_nano_s = GPS_TOW_Real_Minus_Rounded_ms * 1e6

            # As of July 15, 2015, there were 26 leap seconds since 1970..
            # Valid_flags = 7 is being sent here, to indicate valid TOW, Week, and leap seconds.

            packet_data = pack('<IihbbI', GPS_TOW_rounded_ms, numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s), numpy.short(gps_row_items[1]), 26, 7, 0)

            # print "********* NAV-TIMEGPS packet_data: " + hexlify(packet_data).upper()

            ublxp_timegps = ublx_create_ublx_message(0x01, 0x20, 16, packet_data)

            #finalize packet
            ublx_finalize(ublxp_timegps)

            ublxp.extend(bytearray(ublxp_timegps))

            # print "\nNAV-TIMEGPS Packet after finalize: " + hexlify(ublxp_timegps).upper()

            ##################################
            # NAV-STATUS message (0x01 0x03):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IBBBBII', GPS_TOW_rounded_ms, 2, 13, 0, 0, 0, 0)

            # print "********* NAV-STATUS packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_status = ublx_create_ublx_message(0x01, 0x03, 16, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_status)

            ublxp.extend(bytearray(ublxp_nav_status))

            # print "\nNAV-STATUS Packet after finalize: " + hexlify(ublxp_nav_status).upper()

            ##################################
            # NAV-POSLLH message (0x01 0x02):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_items[4]) * 1e+07), numpy.int32(numpy.double(gps_row_items[3]) * 1e+07), numpy.int32(numpy.double(gps_row_items[5]) * 1e+03), numpy.int32(numpy.double(gps_row_items[6]) * 1e+03), numpy.int32(numpy.double(gps_row_items[7]) * 1e+03), numpy.int32(numpy.double(gps_row_items[8]) * 1e+03))

            # print "********* NAV-POSLLH packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_llh = ublx_create_ublx_message(0x01, 0x02, 28, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_llh)

            ublxp.extend(bytearray(ublxp_nav_llh))

            # print "\nNAV-POSLLH Packet after finalize: " + hexlify(ublxp_nav_llh).upper()

            ##################################
            # NAV-VELNED message (0x01 0x12):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiIIiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_items[15]) * 1e+02), numpy.int32(numpy.double(gps_row_items[16]) * 1e+02), numpy.int32(numpy.double(gps_row_items[17]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[18]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[19]) * 1e+02), numpy.int32(numpy.double(gps_row_items[20]) * 1e+05), numpy.uint32(numpy.double(gps_row_items[21]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[22]) * 1e+05))

            # print "********* NAV-VELNED packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_vned = ublx_create_ublx_message(0x01, 0x12, 36, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_vned)

            ublxp.extend(bytearray(ublxp_nav_vned))

            # print "\nNAV-VELNED Packet after finalize: " + hexlify(ublxp_nav_vned).upper()

            ##################################
            # NAV-TIMEUTC message (0x01 0x21):
            ##################################

            packet_data = bytearray([])

            # valid = 7 meaning UTC, Wk Nbr, and TOW all valid
            packet_data = pack('<IIiHBBBBBB', GPS_TOW_rounded_ms, 0, 0, numpy.short(gps_row_items[37]), numpy.uint8(gps_row_items[38]), numpy.uint8(gps_row_items[39]), numpy.uint8(gps_row_items[40]), numpy.uint8(gps_row_items[41]), numpy.uint8(gps_row_items[42]), 7 )

            # print "********* NAV-TIMEUTC packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_timeutc = ublx_create_ublx_message(0x01, 0x21, 20, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_timeutc)

            ublxp.extend(bytearray(ublxp_nav_timeutc))

            # print "\nNAV-TIMEUTC Packet after finalize: " + hexlify(ublxp).upper()

            ##################################
            # NAV-POSECEF message (0x01 0x01):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiI', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_items[10]) * 1e+02), numpy.int32(numpy.double(gps_row_items[11]) * 1e+02), numpy.int32(numpy.double(gps_row_items[12]) * 1e+02), numpy.int32(numpy.double(gps_row_items[13]) * 1e+02))

            # print "********* NAV-POSECEF packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_posecef = ublx_create_ublx_message(0x01, 0x01, 20, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_posecef)

            ublxp.extend(bytearray(ublxp_nav_posecef))

            # print "\nNAV-POSECEF Packet after finalize: " + hexlify(ublxp_nav_posecef).upper()

            #send GPS UBLOX packet to device
            # gps_port.write(ublxp_nav_posecef)
            # gps_port.flush()

            ##################################
            # NAV-VELECEF message (0x01 0x11):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IiiiI', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_items[24]) * 1e+02), numpy.int32(numpy.double(gps_row_items[25]) * 1e+02), numpy.int32(numpy.double(gps_row_items[26]) * 1e+02), numpy.int32(numpy.double(gps_row_items[27]) * 1e+02))

            # print "********* NAV-VELECEF packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_velecef = ublx_create_ublx_message(0x01, 0x11, 20, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_velecef)

            ublxp.extend(bytearray(ublxp_nav_velecef))

            # print "\nNAV-VELECEF Packet after finalize: " + hexlify(ublxp_nav_velecef).upper()

            ##################################
            # NAV-DOP message (0x01 0x04):
            ##################################

            packet_data = bytearray([])

            packet_data = pack('<IHHHHHHH', GPS_TOW_rounded_ms, numpy.uint32(numpy.double(gps_row_items[29]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[30]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[33]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[32]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[31]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[34]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[35]) * 1e+02) )

            # print "********* NAV-DOP packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_dop = ublx_create_ublx_message(0x01, 0x04, 18, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_dop)

            ublxp.extend(bytearray(ublxp_nav_dop))

            # print "\nNAV-DOP Packet after finalize: " + hexlify(ublxp_nav_dop).upper()

            ##################################
            # NAV-SOL message (0x01 0x06):
            ##################################

            packet_data = bytearray([])
            # Number of SV's used in solution = 5 (spoof value):
            packet_data = pack('<IihBBiiiIiiiIHBBI', GPS_TOW_rounded_ms, numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s), numpy.short(gps_row_items[1]), 2, 13, numpy.int32(numpy.double(gps_row_items[10]) * 1e+02), numpy.int32(numpy.double(gps_row_items[11]) * 1e+02), numpy.int32(numpy.double(gps_row_items[12]) * 1e+02), numpy.int32(numpy.double(gps_row_items[13]) * 1e+02), numpy.int32(numpy.double(gps_row_items[24]) * 1e+02), numpy.int32(numpy.double(gps_row_items[25]) * 1e+02), numpy.int32(numpy.double(gps_row_items[26]) * 1e+02), numpy.int32(numpy.double(gps_row_items[27]) * 1e+02), numpy.uint32(numpy.double(gps_row_items[30]) * 1e+02), 0, 5, 0)
            # print "********* NAV-SOL packet_data: " + hexlify(packet_data).upper()

            ublxp_nav_sol = ublx_create_ublx_message(0x01, 0x06, 52, packet_data)

            #finalize packet
            ublx_finalize(ublxp_nav_sol)

            ublxp.extend(bytearray(ublxp_nav_sol))

            # print "\nNAV-SOL Packet after finalize: " + hexlify(ublxp_nav_sol).upper()

            gps_n_input_rows += 1

            # print(" ****** GPS: Week = " + str(gps_row_items[1]) + " TOW = " + str(gps_row_items[2]) );

            gps_row_ublox_data.append(ublxp)
            gps_row_data.append(gps_row_items)

            # fout_gps_hil.write('%4d,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(gps_row_items[0], gps_row_items[1], gps_row_items[2], gps_row_items[3], gps_row_items[4], gps_row_items[5], gps_row_items[6], gps_row_items[7], gps_row_items[8], gps_row_items[9], gps_row_items[10], gps_row_items[11], gps_row_items[12], gps_row_items[13], gps_row_items[14], gps_row_items[15], gps_row_items[16], gps_row_items[17], gps_row_items[18], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], gps_row_items[2], ]))

        # this row is neither column headers nor data elements
        else:
            # test for DATA_START row (column headers to follow)
            if(len(gps_row_items) == 1 and gps_row_items[0] == 'DATA_START'):
               gps_determine_headers = True
               # print("GPS DATA_START found, collecting headers")

    # **********************************************
    # Store IMU data into an array of objects (rows)
    # **********************************************
    imu_row_data = []
    imu_row_mip_data = []

    for imu_row_items in imu_csvreader:

        imu_row_cnt = imu_row_cnt + 1

        # determined that last row in CSV indicated data start (headers are in this row)
        if (imu_determine_headers == True):
            # column headers have been found
            imu_headers_found = True

            # headers no longer need to be determined
            imu_determine_headers = False

        elif(imu_headers_found == True):
            imu_data_row_cnt = imu_data_row_cnt + 1

            # print(" ***** imu_data_row_cnt: " + str(imu_data_row_cnt) );

            if (imu_data_row_cnt > 1):
                # for i in range(imu_interp_loops):
                for i in range(1, imu_interp_loops+1):
                    # print(" ***** Interp loop: i: " + str(i) );

                    # Create a temporary array with interpolated IMU data values (coming at 100 Hz, instead of required 500 Hz)
                    temp_imu_row_item = [0] * (len(imu_row_items_prev)-1)

                    temp_imu_row_item[1] = imu_row_items_prev[1]
                    temp_imu_row_item[2] = numpy.double(imu_row_items_prev[2]) + (numpy.double(imu_row_items[2]) - numpy.double(imu_row_items_prev[2])) * i/imu_interp_loops

                    for j in range(3, (len(imu_row_items_prev)-1)):
                        if (j < 9 or j > 14):
                            temp_imu_row_item[j] = float(imu_row_items_prev[j]) + (float(imu_row_items[j]) - float(imu_row_items_prev[j])) * i/imu_interp_loops
                        else:
                            temp_imu_row_item[j] = float(imu_row_items_prev[j])/imu_interp_loops + (float(imu_row_items[j]) - float(imu_row_items_prev[j])) * i/(imu_interp_loops*imu_interp_loops) # Need to get Delta Theta, Delta V for 500 Hz from 100 Hz data

                    fout_imu_hil.write('%4d,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(int(imu_row_items_prev[0]), int(temp_imu_row_item[1]), temp_imu_row_item[2], temp_imu_row_item[3], temp_imu_row_item[4], temp_imu_row_item[5], temp_imu_row_item[6], temp_imu_row_item[7], temp_imu_row_item[8], temp_imu_row_item[9], temp_imu_row_item[10], temp_imu_row_item[11], temp_imu_row_item[12], temp_imu_row_item[13], temp_imu_row_item[14], temp_imu_row_item[15]))

                    mp = bytearray([])

                    #initialize a packet for a base command
                    mip_init(mp,0x80)

                    # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " temp_imu_row_item[2] = " + str(temp_imu_row_item[2]) + " temp_imu_row_item[3] = " + str(temp_imu_row_item[3]));

                    # if ((debug_mode == 1) and (GPS_init_found == True) and ((imu_data_row_cnt - GPS_init_found_index) % 500 == 0)):
                        # raw_input("IMU: Press Enter to continue...")

                    #print "****** Packet after add field: " + hexlify(mp).upper()

                    mip_add_field(mp, 0x12, pack('>dHH', numpy.double(temp_imu_row_item[2]), numpy.ushort(temp_imu_row_item[1]), numpy.ushort(temp_imu_row_item[0])))

                    # Accel (0x8004)
                    mip_add_field(mp, 0x04, pack('>fff', temp_imu_row_item[3], temp_imu_row_item[4], temp_imu_row_item[5]))

                    # Gyro (0x8005)
                    mip_add_field(mp, 0x05, pack('>fff', temp_imu_row_item[6], temp_imu_row_item[7], temp_imu_row_item[8]))

                    # Mag (0x8006)
                    # # mip_add_field(mp, 0x06, pack('>fff', temp_imu_row_item[15], temp_imu_row_item[16], temp_imu_row_item[17]))
                    # mip_add_field(mp, 0x06, pack('>fff', temp_imu_row_item[16], temp_imu_row_item[17], temp_imu_row_item[18]))
                    # # mip_add_field(mp, 0x06, pack('>fff', 0, 0, 0))

                    # Delta Theta (0x8007)
                    mip_add_field(mp, 0x07, pack('>fff', temp_imu_row_item[9], temp_imu_row_item[10], temp_imu_row_item[11]))

                    # Delta Vel (0x8008)
                    mip_add_field(mp, 0x08, pack('>fff', temp_imu_row_item[12], temp_imu_row_item[13], temp_imu_row_item[14]))

                    # Pressure (0x8017)
                    # mip_add_field(mp, 0x17, pack('>f', temp_imu_row_item[18]))
                    mip_add_field(mp, 0x17, pack('>f', temp_imu_row_item[15]))

                    # mip_add_field(mp,0x12, bytearray.fromhex('2A895F'))

                    # checksum = fletcher_check16(mp)

                    #Print the checksum bytes
                    #print "Checksum bytes: " + hexlify(checksum).upper()

                    #finalize packet
                    mip_finalize(mp)

                    #print "Packet after finalize: " + hexlify(mp).upper()

                    imu_row_mip_data.append(mp)
                    imu_row_data.append(temp_imu_row_item)
                # } for i in range(1, imu_interp_loops+1)..
            # } if (imu_data_row_cnt > 1)..

            imu_n_input_rows += 1

            imu_row_items_prev = [0] * (len(imu_row_items))
            for k in range(len(imu_row_items)):
               imu_row_items_prev[k] = imu_row_items[k]
            # }

        # this row is neither column headers nor data elements
        else:
            # test for DATA_START row (column headers to follow)
            if(len(imu_row_items) == 1 and imu_row_items[0] == 'DATA_START'):
               imu_determine_headers = True
               # print("IMU DATA_START found, collecting headers")
        # } if (imu_determine_headers == True)..

    # } for imu_row_items in imu_csvreader..

    # *************************************************
    #           Now process IMU data
    # *************************************************
    print(' **************** Init GPS TOW found, now start main IMU processing loop: imu_data_row_cnt = ' + str(imu_data_row_cnt) + ' gps_data_row_cnt = ' + str(gps_data_row_cnt) + ' len(imu_row_data) = ' + str(len(imu_row_data)) + " len(gps_row_ublox_data) = " + str(len(gps_row_ublox_data)))

    start_time = time()
    print('\n************* CSV to MIP and UBLOX: start_time = ' + str(start_time) );

    imu_row_data_prev = [0] * (len(imu_row_data))
    for k in range(len(imu_row_data)):
       imu_row_data_prev[k] = imu_row_data[k]

    imu_row_mip_data_prev = [0] * (len(imu_row_mip_data))
    for k in range(len(imu_row_mip_data)):
       imu_row_mip_data_prev[k] = imu_row_mip_data[k]

    gps_row_ublox_data_prev = [0] * (len(gps_row_ublox_data))
    for k in range(len(gps_row_ublox_data)):
       gps_row_ublox_data_prev[k] = gps_row_ublox_data[k]

    gps_row_data_prev = [0] * (len(gps_row_data))
    for k in range(len(gps_row_data)):
       gps_row_data_prev[k] = gps_row_data[k]

    while(True):
    # while(cntGlobal < 4):
       imu_data_row_cnt = 0
       GPS_Output_Due = False
       GPS_init_found = False

       print("*******************************************************" )
       print("****************** GLOBAL LOOP NBR: " + str(cntGlobal) )
       print("*******************************************************" )

       # Reset gps_n_input_rows to 0
       gps_n_input_rows = 0

       imu_tow_prev = 0.0
       imu_tow = 0.0

       for imu_row_items in imu_row_data:
           imu_data_row_cnt = imu_data_row_cnt + 1

           # if (debug_mode == 1 and imu_data_row_cnt % 500 == 1):
              # raw_input("Press Enter to continue...")

           # *******************************************************************************
           # Check if it is time to output GPS data as well (assume 500 Hz IMU and 4 Hz GPS):
           # *******************************************************************************
           GPS_Output_Due = False

           if (GPS_init_found == False):
               imu_tow_prev = imu_tow
               imu_tow = numpy.double(imu_row_items[2])
               if (imu_tow > gps_init_tow):
                   GPS_init_found = True
                   # if ((imu_tow - gps_init_tow) > (gps_init_tow - imu_tow_prev)):
                       # GPS_init_found_index = imu_data_row_cnt - 1
                   # else:
                   GPS_init_found_index = imu_data_row_cnt

           if ((GPS_init_found == True) and ((imu_data_row_cnt - GPS_init_found_index) % 125 == 0)):  # IMU/GPS ratio: 500 Hz /4 Hz = 125

               if (imu_data_row_cnt > 1):
                  GPS_Output_Due = True
                  packet_process_start_time = time()

                  # print( " ****** CROSS OVER: imu_data_row_cnt = " + str(imu_data_row_cnt) + " GPS_init_found_index = " + str(GPS_init_found_index) + " current imu_tow = " + str(imu_row_items[2]) + " len(gps_row_ublox_data) = " + str(len(gps_row_ublox_data)) )

                  if (len(gps_row_ublox_data)>0):
                     gps_n_input_rows += 1
                     # print(" ********* imu_data_row_cnt = " + str(imu_data_row_cnt) + ", GPS_init_found_index = " + str(GPS_init_found_index) )

                     gps_row_item = gps_row_data.pop(0)  # get first item
                     ublxp = gps_row_ublox_data.pop(0)  # get first item

                     # print(" ****** GPS: Week = " + str(gps_row_item[1]) + " TOW = " + str(gps_row_item[2]) );

                     #send block of GPS UBLOX packets to device
                     gps_port.write(ublxp)
                     gps_port.flush

                     if (debug_mode == 1):
                        raw_input("GPS dump: Week = " + str(gps_row_item[1]) + " TOW = " + str(gps_row_item[2]) + ", Press Enter to continue...")

           # ************************************************
           # **** Continue processing IMU data **************
           # ************************************************

           if (imu_data_row_cnt > 1):
               # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " imu_row_items[1] = " + str(imu_row_items[1]) + " imu_row_items[2] = " + str(imu_row_items[2]));
               # print(" ********** len(imu_row_items_prev) = " + str(len(imu_row_items_prev)) + " len(imu_row_items) = " + str(len(imu_row_items)) + " imu_row_items_prev[2] = " + str(imu_row_items_prev[2]) )

               x = 1

               if (len(imu_row_mip_data) > 0):
                   mp = imu_row_mip_data.pop(0)
                   # imu_row_item = imu_row_data.pop(0)  # get first item

                   if (GPS_Output_Due == False):
                       packet_process_start_time = time()
                   elif (debug_mode == 1):
                       x = 2
                       # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " imu_row_items[1] = " + str(imu_row_items[1]) + " imu_row_items[2] = " + str(imu_row_items[2]));
                       # raw_input("IMU: Press Enter to continue...")

                   if (debug_mode == 1 and imu_data_row_cnt == 1):
                       # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " imu_row_items[1] = " + str(imu_row_items[1]) + " imu_row_items[2] = " + str(imu_row_items[2]));
                       # raw_input("IMU: Press Enter to continue...")
                       x = 3
                   else:
                       # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " imu_row_items[1] = " + str(imu_row_items[1]) + " imu_row_items[2] = " + str(imu_row_items[2]));
                       x = 4

                   # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " imu_row_items[1] = " + str(imu_row_items[1]) + " imu_row_items[2] = " + str(imu_row_items[2]));

                   #send IMU MIP packet to device
                   imu_port.write(mp)
                   imu_port.flush()

                   packet_process_end_time = time()
                   dt = packet_process_end_time - packet_process_start_time

                   # print('\n************* Time for packet processing = ' + str(dt));
                   # fout_processing_time.write('%4d,%14.8f\n'%(5 * (imu_data_row_cnt-1) + (i+1), dt))
                   # fout_processing_time.write('%4d,%14.8f\n'%(imu_data_row_cnt, dt))

                   # Sleep only for the remainder of the 2 ms time step (after deducting the time taken to create and send the packet)
                   if (GPS_Output_Due == True):
                       sleep(0.001)
                   elif (dt < 0.002):
                       sleep(0.002 - dt)

       #file complete
       print(" *************************************************")
       print(" *********** Global Loop Nbr: " + str(cntGlobal))
       print(" *************************************************")

       print("IMU: " + str(imu_n_input_rows)+" input rows processed")

       #file complete
       print("GPS: " + str(gps_n_input_rows) + " input rows processed")

       cntGlobal = cntGlobal + 1

       imu_row_data = [0] * (len(imu_row_data_prev))
       for k in range(len(imu_row_data_prev)):
          imu_row_data[k] = imu_row_data_prev[k]

       imu_row_mip_data = [0] * (len(imu_row_mip_data_prev))
       for k in range(len(imu_row_mip_data_prev)):
          imu_row_mip_data[k] = imu_row_mip_data_prev[k]

       gps_row_ublox_data = [0] * (len(gps_row_ublox_data_prev))
       for k in range(len(gps_row_ublox_data_prev)):
          gps_row_ublox_data[k] = gps_row_ublox_data_prev[k]

       gps_row_data = [0] * (len(gps_row_data_prev))
       for k in range(len(gps_row_data_prev)):
          gps_row_data[k] = gps_row_data_prev[k]

       if (infinite_loop == 'n' and cntGlobal == 2):
          break

    end_time = time()
    print('\n************* CSV to MIP and UBLOX: end_time = ' + str(end_time) + ', Time elapsed = ' + str(end_time - start_time));

    imu_port.close()
    gps_port.close()

    fout_imu_hil.close()

if(__name__ == "__main__"):
  main_line(sys.argv)


