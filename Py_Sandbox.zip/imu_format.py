IMU_FORMAT_UNINITIALIZED               = 0

class IMU_format(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = IMU_FORMAT_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""

   [self.imu_tow, self.imu_week, self.flags_80_12] = [0,0,0]
   [self.scaled_accel_x, self.scaled_accel_y, self.scaled_accel_z] = [0,0,0]
   [self.scaled_gyro_x, self.scaled_gyro_y, self.scaled_gyro_z] = [0,0,0]
   [self.delta_theta_roll, self.delta_theta_pitch, self.delta_theta_yaw] = [0,0,0]
   [self.delta_vel_x, self.delta_vel_y, self.delta_vel_z] = [0,0,0]
   [self.mag_x, self.mag_y, self.mag_z] = [0,0,0]
   [self.ambient_pr] = [0]
   [self.cf_matrix_m11, self.cf_matrix_m12, self.cf_matrix_m13, self.cf_matrix_m21, self.cf_matrix_m22, self.cf_matrix_m23, self.cf_matrix_m31, self.cf_matrix_m32, self.cf_matrix_m33] = [0,0,0,0,0,0,0,0,0]
   [self.cf_quat_0, self.cf_quat_1, self.cf_quat_2, self.cf_quat_3] = [0,0,0,0]
   [self.cf_euler_angle_roll, self.cf_euler_angle_pitch, self.cf_euler_angle_yaw] = [0,0,0]
   [self.cf_stabilized_mag_vector_north_x, self.cf_stabilized_mag_vector_north_y, self.cf_stabilized_mag_vector_north_z, self.cf_stabilized_accel_vector_up_x, self.cf_stabilized_accel_vector_up_y, self.cf_stabilized_accel_vector_up_z] = [0,0,0,0,0,0]

 # Master Format (all available IMU columns from DCP, in a 'master sequence'):
 # GPS TFlags,GPS Week,GPS TOW,       X Accel [x8004],Y Accel [x8004],Z Accel [x8004],    X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],      Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],    Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],     X Mag [x8006],Y Mag [x8006],Z Mag [x8006],    Pressure [x8017],   CF_Matrix M11[x8009],CF_Matrix M12[x8009],CF_Matrix M13[x8009],CF_Matrix M21[x8009],CF_Matrix M22[x8009],CF_Matrix M23[x8009],CF_Matrix M31[x8009],CF_Matrix M32[x8009],CF_Matrix M33[x8009],    CF q0 [x800A],CF q1 [x800A],CF q2 [x800A],CF q3 [x800A],          CF Euler Roll [x800C],CF Euler Pitch [x800C],CF Euler Yaw [x800C],   CF_Stabilized_Mag_Vector_North_x [x8010],CF_Stabilized_Mag_Vector_North_y [x8010],CF_Stabilized_Mag_Vector_North_z [x8010],   CF_Stabilized_Accel_Vector_Up_x [x8011],CF_Stabilized_Accel_Vector_Up_y [x8011],CF_Stabilized_Accel_Vector_Up_z [x8011]
 # %d,%4d,%12.4f,                     %14.8f,%14.8f,%14.8f,                               %14.8f,%14.8f,%14.8f,                              %14.8f,%14.8f,%14.8f,                                                 %14.8f,%14.8f,%14.8f,                                            %14.8f,%14.8f,%14.8f,                         %14.8f,             %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                                                                                                  %14.8f,%14.8f,%14.8f,%14.8f,                                      %14.8f,%14.8f,%14.8f,                                                %14.8f,%14.8f,%14.8f,                                                                                                         %14.8f,%14.8f,%14.8f,
 # flags_80_12,imu_week, imu_tow,     scaled_accel_x, scaled_accel_y, scaled_accel_z,     scaled_gyro_x, scaled_gyro_y, scaled_gyro_z,       delta_theta_roll, delta_theta_pitch, delta_theta_yaw,                 delta_vel_x, delta_vel_y, delta_vel_z,                           mag_x, mag_y, mag_z,                          ambient_pr,         matrix_m11, matrix_m12, matrix_m13, matrix_m21, matrix_m22, matrix_m23, matrix_m31, matrix_m32, matrix_m33,                                                                                      self.cf_quat_0, self.cf_quat_1, self.cf_quat_2, self.cf_quat_3    cf_euler_angle_roll, cf_euler_angle_pitch, cf_euler_angle_yaw,       cf_stabilized_mag_vector_north_x, self.cf_stabilized_mag_vector_north_y, self.cf_stabilized_mag_vector_north_z,               cf_stabilized_accel_vector_up_x, cf_stabilized_accel_vector_up_y, cf_stabilized_accel_vector_up_z

 def format(self, format_in):
    if (format_in == 1):
       return '{:-4d},{:-4d},{:-12.4f},'.format(self.flags_80_12, self.imu_week, self.imu_tow)
    elif (format_in == 2):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.scaled_accel_x, self.scaled_accel_y, self.scaled_accel_z)
    elif (format_in == 3):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.scaled_gyro_x, self.scaled_gyro_y, self.scaled_gyro_z)
    elif (format_in == 4):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.delta_theta_roll, self.delta_theta_pitch, self.delta_theta_yaw)
    elif (format_in == 5):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.delta_vel_x, self.delta_vel_y, self.delta_vel_z)
    elif (format_in == 6):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.mag_x, self.mag_y, self.mag_z)
    elif (format_in == 7):
       return '{:-14.8f},'.format(self.ambient_pr)
    elif (format_in == 8):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.cf_matrix_m11, self.cf_matrix_m12, self.cf_matrix_m13, self.cf_matrix_m21, self.cf_matrix_m22, self.cf_matrix_m23, self.cf_matrix_m31, self.cf_matrix_m32, self.cf_matrix_m33)
    elif (format_in == 9):
       return '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.cf_quat_0, self.cf_quat_1, self.cf_quat_2, self.cf_quat_3)
    elif (format_in == 10):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.cf_euler_angle_roll, self.cf_euler_angle_pitch, self.cf_euler_angle_yaw)
    elif (format_in == 11):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.cf_stabilized_mag_vector_north_x, self.cf_stabilized_mag_vector_north_y, self.cf_stabilized_mag_vector_north_z)
    elif (format_in == 12):
       return '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.cf_stabilized_accel_vector_up_x, self.cf_stabilized_accel_vector_up_y, self.cf_stabilized_accel_vector_up_z)

    return 'IMU_format'

 def format_header(self, format_in):
    if (format_in == 1):
       return 'GPS TFlags,GPS Week,GPS TOW,'
    elif (format_in == 2):
       return 'X Accel [x8004],Y Accel [x8004],Z Accel [x8004],'
    elif (format_in == 3):
       return 'X Gyro [x8005],Y Gyro [x8005],Z Gyro [x8005],'
    elif (format_in == 4):
       return 'Delta Theta X [x8007],Delta Theta Y [x8007],Delta Theta Z [x8007],'
    elif (format_in == 5):
       return 'Delta Vel X [x8008],Delta Vel Y [x8008],Delta Vel Z [x8008],'
    elif (format_in == 6):
       return 'X Mag [x8006],Y Mag [x8006],Z Mag [x8006],'
    elif (format_in == 7):
       return 'Pressure [x8017],'
    elif (format_in == 8):
       return 'CF M11 [x8009],CF M12 [x8009],CF M13 [x8009],CF M21 [x8009],CF M22 [x8009],CF M23 [x8009],CF M31 [x8009],CF M32 [x8009],CF M33 [x8009],'
    elif (format_in == 9):
       return 'CF q0 [x800A],CF q1 [x800A],CF q2 [x800A],CF q3 [x800A],'
    elif (format_in == 10):
       return 'CF Euler Roll [x800C],CF Euler Pitch [x800C],CF Euler Yaw [x800C],'
    elif (format_in == 11):
       return 'CF_Stabilized_Mag_Vector_North_x [x8010],CF_Stabilized_Mag_Vector_North_y [x8010],CF_Stabilized_Mag_Vector_North_z [x8010],'
    elif (format_in == 12):
       return 'CF_Stabilized_Accel_Vector_Up_x [x8011],CF_Stabilized_Accel_Vector_Up_y [x8011],CF_Stabilized_Accel_Vector_Up_z [x8011],'

    return 'IMU_format_header'

 def format_channel_name(self, format_in):
    if (format_in == 1):
       return ['IMU_TFlags', 'IMU_Week', 'IMU_TOW']
    elif (format_in == 2):
       return ['X_Accel_x8004', 'Y_Accel_x8004', 'Z_Accel_x8004']
    elif (format_in == 3):
       return ['X_Gyro_x8005', 'Y_Gyro_x8005', 'Z_Gyro_x8005']
    elif (format_in == 4):
       return ['Delta_Theta_X_x8007', 'Delta_Theta_Y_x8007', 'Delta_Theta_Z_x8007']
    elif (format_in == 5):
       return ['Delta_Vel_X_x8008', 'Delta_Vel_Y_x8008', 'Delta_Vel_Z_x8008']
    elif (format_in == 6):
       return ['X_Mag_x8006', 'Y_Mag_x8006', 'Z_Mag_x8006']
    elif (format_in == 7):
       return ['Pressure_x8017']
    elif (format_in == 8):
       return ['CF_M11_x8009', 'CF_M12_x8009', 'CF_M13_x8009', 'CF_M21_x8009', 'CF_M22_x8009', 'CF_M23_x8009', 'CF_M31_x8009', 'CF_M32_x8009', 'CF_M33_x8009']
    elif (format_in == 9):
       return ['CF_q0_x800A','CF_q1_x800A','CF_q2_x800A','CF_q3_x800A']
    elif (format_in == 10):
       return ['CF_Euler_Roll_x800C','CF_Euler_Pitch_x800C','CF_Euler_Yaw_x800C']
    elif (format_in == 11):
       return ['CF_Stabilized_Mag_Vector_North_x_x8010','CF_Stabilized_Mag_Vector_North_y_x8010','CF_Stabilized_Mag_Vector_North_z_x8010']
    elif (format_in == 12):
       return ['CF_Stabilized_Accel_Vector_Up_x_x8011','CF_Stabilized_Accel_Vector_Up_y_x8011','CF_Stabilized_Accel_Vector_Up_z_x8011']

    return 'IMU_format_channel_name'


 def format_channel_value(self, format_in):
    if (format_in == 1):
       return [self.flags_80_12, self.imu_week, self.imu_tow]
    elif (format_in == 2):
       return [self.scaled_accel_x, self.scaled_accel_y, self.scaled_accel_z]
    elif (format_in == 3):
       return [self.scaled_gyro_x, self.scaled_gyro_y, self.scaled_gyro_z]
    elif (format_in == 4):
       return [self.delta_theta_roll, self.delta_theta_pitch, self.delta_theta_yaw]
    elif (format_in == 5):
       return [self.delta_vel_x, self.delta_vel_y, self.delta_vel_z]
    elif (format_in == 6):
       return [self.mag_x, self.mag_y, self.mag_z]
    elif (format_in == 7):
       return [self.ambient_pr]
    elif (format_in == 8):
       return [self.cf_matrix_m11, self.cf_matrix_m12, self.cf_matrix_m13, self.cf_matrix_m21, self.cf_matrix_m22, self.cf_matrix_m23, self.cf_matrix_m31, self.cf_matrix_m32, self.cf_matrix_m33]
    elif (format_in == 9):
       return [self.cf_quat_0, self.cf_quat_1, self.cf_quat_2, self.cf_quat_3]
    elif (format_in == 10):
       return [self.cf_euler_angle_roll, self.cf_euler_angle_pitch, self.cf_euler_angle_yaw]
    elif (format_in == 11):
       return [self.cf_stabilized_mag_vector_north_x, self.cf_stabilized_mag_vector_north_y, self.cf_stabilized_mag_vector_north_z]
    elif (format_in == 12):
       return [self.cf_stabilized_accel_vector_up_x, self.cf_stabilized_accel_vector_up_y, self.cf_stabilized_accel_vector_up_z]

    return []

