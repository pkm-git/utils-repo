# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import sys

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

from sensor_cloud_api import *

import csv
import numpy
import math
import os
import re

def print_row(time, vectornav_row_array, fout_csv_file):
   fout_csv_file.write('%10.4f'%(time))
   i = 0
   for v in vectornav_row_array:
      if (i > 0):
         if (v != ''):
            if (i == 12):
               fout_csv_file.write(',%12.6f'%(numpy.double(v[:-3])))
            else:
               fout_csv_file.write(',%12.6f'%(numpy.double(v)))
            # } if (i == 12)..
         else:
            fout_csv_file.write(',')
         # } if (v != '')..
      # } if (i > 0)..
      i += 1
   # } for v in vectornav_row_array..

   fout_csv_file.write('\n')

def vectornav_to_csv_fn(in_file_name, in_file_type = 'ASCII', data_rate_hz = 100):

   print('\n---- in vectornav_to_csv_fn -----------------')
   print( ' ********* in_file_type = ' + in_file_type)

   # if arguments sent in were not properly specified, tell the user and exit
   if (in_file_name == None):
      print('Input file name cannot be empty')
      sys.exit()
   # } if (in_file_name == None..
   
   (fin_filepath, fin_filename) = os.path.split(in_file_name)
   
   if ('.' in fin_filename):
      csv_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_Log.csv")
   else:
      csv_filename = os.path.join(fin_filepath, fin_filename + "_Log.csv")
   # } if ('.' in fin_filename)..
   
   vectornav_in_csvfile = open(in_file_name, 'r')
   if (in_file_type == 'ASCII'):
      vectornav_csvreader = csv.reader(vectornav_in_csvfile, delimiter=',')
   else: 
      vectornav_csvreader = csv.reader(vectornav_in_csvfile.read().splitlines(), delimiter='\t')
   # } if (in_file_type == 'ASCII')..
      
   # Create the output csv file
   (fin_filepath, fin_filename) = os.path.split(in_file_name)
   fout_csv_file = open(csv_filename, "w")
   
   # fout_csv_file.write('DATA_START\n')
   fout_csv_file.write('DATA_START [Other]\n')
   
   if (data_rate_hz == 0):
      data_rate_hz = 100
   # } if (data_rate_hz == 0)..
      
   delta_t = 1.0/data_rate_hz
   
   vectornav_row_cnt = 0
   vectornav_vnymr_row_cnt = 0

   time = 0.0
   time_prev = 0.0
   found_header_tsv = False
   nbr_of_headers = 0
   
   int_index_array = [43, 44, 45, 48, 49]
   long_index_array = [46, 47]
   
   vectornav_row_array_prev = []
   
   # TSV_header_array = ['Attitude.YawPitchRoll.Yaw', 'Attitude.YawPitchRoll.Pitch', 'Attitude.YawPitchRoll.Roll', 'YawPitchRoll.Yaw', 'YawPitchRoll.Pitch', 'YawPitchRoll.Roll', 'Quaternion.X', 'Quaternion.Y', 'Quaternion.Z', 'Quaternion.W', 'Dcm00', 'Dcm01', 'Dcm02', 'Dcm10', 'Dcm11', 'Dcm12', 'Dcm20', 'Dcm21', 'Dcm22', 'YawPitchRollUncertainty.X', 'YawPitchRollUncertainty.Y', 'YawPitchRollUncertainty.Z', 'Acceleration.X', 'Acceleration.Y', 'Acceleration.Z', 'Magnetic.X', 'Magnetic.Y', 'Magnetic.Z', 'AngularRate.X', 'AngularRate.Y', 'AngularRate.Z', 'UncompensatedAcceleration.X', 'UncompensatedAcceleration.Y', 'UncompensatedAcceleration.Z', 'UncompensatedMagnetic.X', 'UncompensatedMagnetic.Y', 'UncompensatedMagnetic.Z', 'UncompensatedAngularRate.X', 'UncompensatedAngularRate.Y', 'UncompensatedAngularRate.Z', 'Temperature', 'Pressure', 'ImuStatus', 'VpeStatus', 'SensorSaturation', 'TimeStartup', 'TimeSyncIn', 'SyncInCount', 'DeltaTime', 'DeltaTheta.X', 'DeltaTheta.Y', 'DeltaTheta.Z', 'DeltaVelocity.X', 'DeltaVelocity.Y', 'DeltaVelocity.Z', 'AccelerationNed.X', 'AccelerationNed.Y', 'AccelerationNed.Z', 'LinearAccelerationBody.X', 'LinearAccelerationBody.Y', 'LinearAccelerationBody.Z', 'LinearAccelerationNed.X', 'LinearAccelerationNed.Y', 'LinearAccelerationNed.Z', 'MagneticNed.X', 'MagneticNed.Y', 'MagneticNed.Z']
   TSV_header_array = ['Time','Att_YPR_Yaw','Att_YPR_Pitch','Att_YPR_Roll','YPR_Yaw','YPR_Pitch','YPR_Roll','Quat_X','Quat_Y','Quat_Z','Quat_W','DCM00','DCM01','DCM02','DCM10','DCM11','DCM12','DCM20','DCM21','DCM22','YPR_Unc_X','YPR_Unc_Y','YPR_Unc_Z','Accel_X','Accel_Y','Accel_Z','Mag_X','Mag_Y','Mag_Z','Ang_Rate_X','Ang_Rate_Y','Ang_Rate_Z','Uncomp_Accel_X','Uncomp_Accel_Y','Uncomp_Accel_Z','Uncomp_Mag_X','Uncomp_Mag_Y','Uncomp_Mag_Z','Uncomp_Ang_Rate_X','Uncomp_Ang_Rate_Y','Uncomp_Ang_Rate_Z','Temperature','Pressure','IMU_Status','VPE_Status','Sensor_Sat','Time_Startup','Time_Sync_In','Sync_In_Count','Delta_Time','Delta_Theta_X','Delta_Theta_Y','Delta_Theta_Z','DeltaV_X','DeltaV_Y','DeltaV_Z','Accel_NED_X','Accel_NED_Y','Accel_NED_Z','Lin_Accel_Body_X','Lin_Accel_Body_Y','Lin_Accel_Body_Z','Lin_Accel_NED_X','Lin_Accel_NED_Y','Lin_Accel_NED_Z','Mag_NED_X','Mag_NED_Y','Mag_NED_Z']
   ASCII_header_array = ['Time','Yaw','Pitch','Roll','MagX','MagY','MagZ','AccelX','AccelY','AccelZ','GyroX','GyroY','GyroZ']
   
   # **********************************
   # Write VectorNav data into csv file
   # **********************************
   
   for vectornav_row_array in vectornav_csvreader:

       vectornav_row_cnt = vectornav_row_cnt + 1

       # $VNYMR,-054.952,-013.845,+034.012,+00.0893,+00.0224,+00.4504,-00.874,-05.037,-08.495,-00.165593,+00.018441,+00.038927*65
       
       if (vectornav_row_array[0] == '$VNYMR'):
          vectornav_vnymr_row_cnt = vectornav_vnymr_row_cnt + 1

          time += delta_t
  
          # If both first and second row have same nbr of items, print both rows to csv file.
          # If second row has more nbr of values than first, discard first row and
          # use second row as the reference nbr of items to determine whether to discard subsequent rows.
          # If second row has less nbr of values than first, assume that the second row had a problem 
          # and has partial data.  So in that case, discard second row and
          # use the first row as the reference nbr of items to determine whether to discard subsequent rows.
  
          if (vectornav_vnymr_row_cnt == 1):
             vectornav_row_array_prev = vectornav_row_array
             time_prev = time
          else:
             if (vectornav_vnymr_row_cnt == 2):
                if (len(vectornav_row_array_prev) == len(vectornav_row_array)):
                   nbr_of_items_per_row = len(vectornav_row_array)
                elif (len(vectornav_row_array_prev) < len(vectornav_row_array)):
                   nbr_of_items_per_row = len(vectornav_row_array)
                else:
                   nbr_of_items_per_row = len(vectornav_row_array_prev)
                # } if (len(vectornav_row_array_prev) ==..
   
                cnt_hdr = 0
                for h in ASCII_header_array:
                   if (cnt_hdr == (nbr_of_items_per_row-1)):
                      fout_csv_file.write('%s'%(h)) 
                   elif (cnt_hdr < nbr_of_items_per_row):
                      fout_csv_file.write('%s,'%(h)) 
                   # } if (cnt_hdr < nbr_of_items_per_row)..
   
                   cnt_hdr += 1   
                # } for h in ASCII_header_array..

                fout_csv_file.write('\n')
             # } if (vectornav_vnymr_row_cnt == 2)..
     
             if (len(vectornav_row_array) == nbr_of_items_per_row):
                if (vectornav_vnymr_row_cnt == 2):
                   print_row(time_prev, vectornav_row_array_prev, fout_csv_file)
                # } if (vectornav_vnymr_row_cnt == 2)..  
                print_row(time, vectornav_row_array, fout_csv_file)
             # } if (len(vectornav_row_array) == nbr_of_items_per_row)..
          # } if (vectornav_vnymr_row_cnt == 1)..
  
       elif (not found_header_tsv and vectornav_row_array[0] == 'Timestamp'):
          found_header_tsv = True
          nbr_of_headers = len(vectornav_row_array)
      
          print(' ****** nbr_of_headers found = ' + str(nbr_of_headers) + ' and len(TSV_header_array) = ' + str(len(TSV_header_array)))
  
          nbr_of_headers = len(TSV_header_array)
 
          # if (len(TSV_header_array) == nbr_of_headers):
          cnt_hdr = 0
          for h in TSV_header_array:
             if (cnt_hdr == (nbr_of_headers-1)):
                fout_csv_file.write('%s'%(h)) 
             elif (cnt_hdr < nbr_of_headers):
                fout_csv_file.write('%s,'%(h)) 
             # } if (cnt_hdr < nbr_of_headers)..

             cnt_hdr += 1   
          # } for h in TSV_header_array..
          fout_csv_file.write('\n')
  
       # elif (found_header_tsv and len(vectornav_row_array) == nbr_of_headers):
       elif (found_header_tsv):
       
          time = numpy.double(vectornav_row_array[0]);
  
          fout_csv_file.write('%10.4f'%(time))
  
          i = 0
          for v in vectornav_row_array:
             if (i > 0 and i < nbr_of_headers):
                if (v != ''):
                   if (i in int_index_array):
                      fout_csv_file.write(',%12.6f'%(int(v)))
                   elif (i in long_index_array):
                      fout_csv_file.write(',%12.6f'%(long(v)))
                   else:
                      fout_csv_file.write(',%12.6f'%(numpy.double(v)))
                   # } if (i in int_index_array)..
                else:
                   fout_csv_file.write(',')
                # } if (v != '')..
             # } if (i > 0)..
             i += 1
          # } for v in vectornav_row_array..
  
          fout_csv_file.write('\n')

      # } if (vectornav_row_array[0] == '$VNYMR')..  
   # } for vectornav_row_array in vectornav_csvreader..

   print('\n------------------------------------------------------------------------------')
   print ('\n************* Total nbr of VectorNav rows processed: ' + str(vectornav_row_cnt) + '; Nbr of VNYMR rows = ' + str(vectornav_vnymr_row_cnt))
   print('\n------------------------------------------------------------------------------')

   fout_csv_file.close()
   vectornav_in_csvfile.close()

if(__name__ == "__main__"):
  main_line(sys.argv)




