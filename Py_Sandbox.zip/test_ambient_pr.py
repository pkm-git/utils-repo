import numpy

# Create altitude array (in meters above sea level)
altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

# Create ambient pressure array (in bar)
ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]

ambient_pressure = 0
llh_ht = 978
altitude_prev = 0
altitude = 0

for altitude_array_index in range(len(altitude_array)):
   altitude = numpy.int32(altitude_array[altitude_array_index])
   print(' *********** altitude_array_index = ' + str(altitude_array_index) + ' altitude = ' + str(altitude))
   if (altitude > llh_ht):
       index_alt_match = altitude_array_index-1
       altitude_prev = numpy.int32(altitude_array[index_alt_match])
       print(' ************ for llh_ht = ' + str(llh_ht) + ' found match: index_alt_match = ' + str(index_alt_match) + ' altitude: ' + str(altitude) + ' altitude_prev: ' + str(altitude_prev))
       break;

ambient_pressure_prev = ambient_pressure_array[index_alt_match]
ambient_pressure_next = ambient_pressure_array[index_alt_match+1]

x = numpy.double(llh_ht - altitude_prev)/(altitude - altitude_prev)
delta = (ambient_pressure_next - ambient_pressure_prev) * x
print( ' ********** ratio = ' + str(x) + ', delta = ' + str(delta))

ambient_pressure = ambient_pressure_prev + delta

print(' ******* ambient_pressure_prev: ' + str(ambient_pressure_prev) + ' ambient_pressure_next: ' + str(ambient_pressure_next) + ' ambient_pressure = ' + str(ambient_pressure*1000))

print(' ************* len(altitude_array) = ' + str(len(altitude_array)))

temp_imu_row_item = [0] * (len(altitude_array)-1)

print(' ************* len(temp_imu_row_item) = ' + str(len(temp_imu_row_item)))
