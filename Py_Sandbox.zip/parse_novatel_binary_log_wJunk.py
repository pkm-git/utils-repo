import sys
import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from novatel_gps_format import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

import numpy
import os

def print_usage_message():
 """Output usage instructions"""

 print("usage: python parse_novatel_binary_log.py -i input_file_name -o output_type\n")
 print("input_file_name\t\t: (Required) Name of the binary input Novatel log file including the path")
 print("output_type\t\t: (Optional) Type of output file (Use 'i' for INS, 'g' for GPS, 'e' for EKF and 'r' for RAWIMU.\t\t\t\t\t\t Default: Creates 4 output csv files, one for each group or type.")

def main_line(argv):
 """Main line program"""

 # initialize command line arguments
 in_file_name = None
 out_file_type = None

 short_header_length = 12
 long_header_length = 28

 print('\n------------------------------------------------------------------')

 # Grouping of Messages:

 # ----------
 # EKF Group:
 # ----------
 # 42: BESTPOS
 # 99: BESTVEL
 # 101: TIME
 # 241: BESTXYZ

 # --------------------------------------------
 # INS Group: [Long/Short Header Message Pairs]
 # --------------------------------------------
 # 263: INSATT
 # 319: INSATTS

 # 265: INSPOS
 # 321: INSPOSS

 # 266: INSSPD
 # 323: INSSPDS

 # 267: INSVEL
 # 324: INSVELS

 # 507: INSPVA
 # 508: INSPVAS

 # -------------
 # RAWIMU Group:
 # -------------
 # 268: RAWIMU
 # 325: RAWIMUS

 # ----------
 # GPS Group:
 # ----------
 # 101: TIME (UTC-related)

 # 642: VEHICLEBODYROTATION

 # Define "Master columns" (i.e. subset, consisting of 'minimum' or 'important' columns in DCP) in a "master sequence"
 min_gps_default_cols_dict = {321:1, 42:2, 324:3, 323:4, 99:5, 241:6, 319:7, 508:8, 325:9, 101:10, 642:11}
 min_gps_default_long2shorthdr_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

 gyro_scale_factor = 0.1/(3600.0 * 256.0)
 accel_scale_factor = 0.05/(2**15)

 if (argv != None):
   # parse command line arguements
   for i in range(len(argv)):
     if(argv[i] == '-i' and len(argv) > i+1):
        in_file_name = argv[i+1]
     elif(argv[i] == '-o' and len(argv) > i+1):
        out_file_type = argv[i+1]

 # if command line arguments were not properly specified tell the user and exit
 if (in_file_name == None):
    print_usage_message()
    sys.exit()

 out_file_type_array = []

 if (out_file_type == None):
    out_file_type_array.append('i')  # IMU (INSATT, INSPOS, INSVEL, INSPVA)
    out_file_type_array.append('e')  # EKF (BESTPOS, BESTVEL, BESTXYZ)
    out_file_type_array.append('r')  # RAWIMU
    out_file_type_array.append('g')  # GPS (TIME)
 else:
    out_file_type_array.append(out_file_type)

 print(' ******** will start loop, len(out_file_type_array) = ' + str(len(out_file_type_array)))

 # Loop thro binary input file for each output group (INS, EKF, RAWIMU and GPS):
 for out_file_type in out_file_type_array:
    print(' ******************************************************* ')
    print(' **************** out_file_type = ' + out_file_type)
    print(' ******************************************************* ')

    # Array to store the order of columns requested by the user:
    gps_output_order = []
    gps_output_order.append(0)

    no_desc_list_supplied_gps_headers_printed = False

    gps_format_obj = Novatel_GPS_format()

    fin_bin = open(in_file_name, "rb")

    message_id_array = []
    if (out_file_type == 'i'):
       out_file_name = "INS_Log.csv"
       message_id_array = [321, 323, 324, 319, 508]
    elif (out_file_type == 'g'):
       out_file_name = "GPS_Log.csv"
       message_id_array = [101]
    elif (out_file_type == 'e'):
       out_file_name = "EKF_Log.csv"
       message_id_array = [42, 99, 241]
    elif (out_file_type == 'r'):
       out_file_name = "RAWIMU_Log.csv"
       message_id_array = [325]

    (fin_filepath, fin_filename) = os.path.split(in_file_name)
    fout_gps = open(os.path.join(fin_filepath, out_file_name), "w")

    start_time = time()

    # print('\n------------------------------------------------------------------')
    print(' ************* Parse Novatel Binary Log: start_time = ' + str(start_time) );

    k_start = 0

    bytes_read = fin_bin.read();

    print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

    for k in range(0, len(bytes_read)):
       if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])) == '44' and (hexlify(bytearray(bytes_read[k+2])) == '12' or hexlify(bytearray(bytes_read[k+2])) == '13')):
          print(' ***** Found first SYNC BYTE trio at byte index: ' + str(k) + '\n')
          k_start = k;
          break;

    message_length = 0
    k = k_start

    message_cnt = 0
    packet_set_cnt = 1
    [temp_week, temp_tow_ms, temp_tow_ms_prev, crc_length] = [0,0,0,4]
    [message_id, port_address, sequence, idle_time, time_status, rcvr_status, res1, res2] = [0,0,0,0,0,0,0,0]

    [temp_soln_status, temp_pos_type, res3, res4, res5, sig_mask, temp_ext_sol_status] = [0,0,0,0,0,0,0]
    [temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age] = [0,0,0,0,0,0]
    [temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used] = [0,0,0,0,0]

    [gps_week, gps_tow] = [0,0]
    [ins_vned_N, ins_vned_E, ins_vned_D] = [0,0,0]
    [gps_lat, gps_lon, gps_ht_ellip] = [0,0,0]
    [temp_ins_lat, temp_ins_lon, temp_ins_ht_abv_ellips, temp_ins_vned_N, temp_ins_vned_E, temp_ins_vned_D, temp_roll, temp_pitch, temp_azimuth, temp_ins_status] = [0,0,0,0,0,0,0,0,0,0]
    [temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_heading] = [0,0,0,0,0]

    # Look for beginning of a valid Novatel packet (Bytes: 0xAA4412):
    while (k < len(bytes_read)):

      print('--------------------------------------------------------')

      if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])).upper() == '44'):

         if (hexlify(bytearray(bytes_read[k+2])).upper() == '12'): # Long header
            print(' ********** k = ' + str(k) + ', FOUND AA 44 12, LONG HEADER ***********, Message Length: ' + hexlify(bytearray(bytes_read[k+8:k+10])) + ', packet_set_cnt = ' + str(packet_set_cnt))
            [header_length] = unpack('<B', bytearray(bytes_read[k+3]))
            [message_length] = unpack('<H', bytearray(bytes_read[k+8:k+10]) )

            # Parse the remaining part of header:
            [message_id, gps_format_obj.message_type, port_address, gps_format_obj.message_length, sequence, idle_time, time_status, temp_week, temp_tow_ms, rcvr_status, res1, res2] = unpack('<HbBHHBBHLLHH', bytearray(bytes_read[k+4:k+header_length]) )

            # Revert the GPS TOW if it is the VEHICLEBODYROTATION message (because it's GPS TOW is invalid)
            if (message_id == 642):
               temp_tow_ms = temp_tow_ms_prev
            else:
               gps_format_obj.gps_week = temp_week

         elif (hexlify(bytearray(bytes_read[k+2])).upper() == '13'): # Short header

            print(' ********** k = ' + str(k) + ', FOUND AA 44 13, SHORT HEADER ***********, Message Length: ' + hexlify(bytearray(bytes_read[k+8:k+10])) + ', packet_set_cnt = ' + str(packet_set_cnt))

            # Check if it is a message with short header (in this case, message_length becomes equal to header_length read before):
            [message_length] = unpack('<B', bytearray(bytes_read[k+3]))
            header_length = short_header_length

            # Parse the remaining part of header:
            [message_id, gps_format_obj.gps_week, temp_tow_ms] = unpack('<HHL', bytearray(bytes_read[k+4:k+header_length]) )

         # } if (hexlify(bytearray(bytes_read[k+2])).upper() == '12')..

         gps_format_obj.gps_tow = temp_tow_ms/1000.0

         if (message_id in message_id_array):
            print(' ************* message_id: ' + str(message_id) + ' IS in message_id_array ***** ')

            # If new value of GPS TOW found, convert GPS TOW from ms to sec and store in GPS Format Object
            if (temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms and temp_tow_ms > temp_tow_ms_prev):
                print('********** packet_set_cnt: ' + str(packet_set_cnt) + ', message_id: ' + str(message_id) + ', temp_tow_ms_prev = ' + str(temp_tow_ms_prev) + ' is NOT equal to temp_tow_ms: ' + str(temp_tow_ms))

                if (no_desc_list_supplied_gps_headers_printed == False):
                   gps_output_order.sort()

                   fout_gps.write('DATA_START\n')
                   print(' *********** writing headers, len(gps_output_order) = ' + str(len(gps_output_order)))
                   for gps_output_index in range(len(gps_output_order)):
                      input_index = numpy.int32(gps_output_order[gps_output_index])
                      header = gps_format_obj.format_header(input_index)
                      print(' *********** writing headers: input_index = ' + str(input_index) + ', Header: ' + header)
                      fout_gps.write(header)

                      # fout_gps.write(gps_format_obj.format_header(input_index))

                   fout_gps.write('\n')

                   no_desc_list_supplied_gps_headers_printed = True
                # } if (no_desc_list_supplied_gps_headers_printed == False)..

                # Print values of previous GPS set, before updating 'gps_format_obj' with new set of values:
                input_index = 0
                for gps_output_index in range(len(gps_output_order)):
                   input_index = numpy.int32(gps_output_order[gps_output_index])
                   fout_gps.write(gps_format_obj.format(input_index))

                fout_gps.write('\n')

                # Track the number of 'packet sets' (i.e. set of Novatel packets at same GPS Timestamp)
                print(' ********** Incrementing packet_set_cnt, currently: ' + str(packet_set_cnt))

                packet_set_cnt = packet_set_cnt + 1

                # temp_tow_ms_prev = temp_tow_ms
            else:
                print('********** packet_set_cnt: ' + str(packet_set_cnt) + ', message_id: ' + str(message_id) + ', temp_tow_ms_prev = ' + str(temp_tow_ms_prev) + ' IS equal to temp_tow_ms: ' + str(temp_tow_ms))

            # } if (message_id != 642 and temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms)..

            if (packet_set_cnt == 1):
               if (message_id in min_gps_default_cols_dict or (message_id in min_gps_default_long2shorthdr_cols_dict)):
                  if (message_id in min_gps_default_long2shorthdr_cols_dict):
                     message_id = min_gps_default_cols_dict[min_gps_default_long2shorthdr_cols_dict[message_id]]

                  gps_output_order.append(min_gps_default_cols_dict[message_id])
                  print('********* message_id = ' + str(message_id) + ' does exist in dictionary, adding output_order: ' + str(min_gps_default_cols_dict[message_id]) )
               else:
                  print('********* message_id = ' + str(message_id) + ' does NOT exist in dictionary' )
            # } if (packet_set_cnt == 1)..

            print(' ********* message_id: ' + str(message_id) + ', gps_format_obj.gps_week: ' + str(gps_format_obj.gps_week) + ', gps_format_obj.gps_tow: ' + str(gps_format_obj.gps_tow))

            message_cnt = message_cnt + 1

            full_message_bytes = bytearray( bytes_read[k:k+message_length+header_length+crc_length] )
            message_bytes = bytearray( bytes_read[k+header_length:k+header_length+message_length] )

            # print('\n****** Message Cnt: ' + str(message_cnt) + ', Message ID: ' + str(message_id) + ', Message Length = ' + str(message_length) + ' and full_message_bytes = ' + hexlify( bytearray(full_message_bytes) ).upper())
            tmp_str = hexlify( bytearray(full_message_bytes) ).upper()
            print('\n****** Message Cnt: ' + str(message_cnt) + ', Message ID: ' + str(message_id) + ', Message Length = ' + str(message_length) + ', and full_message_bytes = ' )

            for i in range(0,len(tmp_str),2):
               print(tmp_str[i] + tmp_str[i+1]),
            print('\n')

            print(' ************* message_id: ' + str(message_id) + ' IS in message_id_array, will parse fields ***** ')

            if (message_id == 319):  # INSATTS [INS Attitude]
               [temp_gps_week, temp_tow_ms2, gps_format_obj.roll, gps_format_obj.pitch, gps_format_obj.azimuth, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

            elif (message_id == 42):   # BESTPOS [GPS/INS Blended Position]
               [temp_soln_status, temp_pos_type, gps_format_obj.ekf_lat, gps_format_obj.ekf_lon, gps_format_obj.ekf_ht_abv_MSL, gps_format_obj.undulation, temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfIfffIffBBBBBBBB', message_bytes )

            elif (message_id == 321):   # INSPOSS [INS Position]
               [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_lat, gps_format_obj.ins_lon, gps_format_obj.ins_ht_abv_ellip, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

            elif (message_id == 508):   # INSPVAS [INS Position, Velocity and Attitude]
               [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_pva_lat, gps_format_obj.ins_pva_lon, gps_format_obj.ins_pva_ht_abv_ellips, gps_format_obj.ins_pva_vned_N, gps_format_obj.ins_pva_vned_E, gps_format_obj.ins_pva_vned_D, gps_format_obj.ins_pva_roll, gps_format_obj.ins_pva_pitch, gps_format_obj.ins_pva_azimuth, temp_ins_status] = unpack('<LddddddddddI', bytearray(message_bytes) )

            elif (message_id == 101):   # TIME
               [gps_format_obj.rcvr_clock_status, gps_format_obj.rcvr_clock_offset, gps_format_obj.rcvr_clock_offset_sd, gps_format_obj.utc_offset, gps_format_obj.utc_year, gps_format_obj.utc_month, gps_format_obj.utc_day, gps_format_obj.utc_hour, gps_format_obj.utc_min, gps_format_obj.utc_ms, gps_format_obj.utc_status] = unpack('<IdddLBBBBLI', bytearray(message_bytes) )

            elif (message_id == 99):   # BESTVEL [GPS/INS Blended Velocity]
               [temp_soln_status, temp_vel_type, gps_format_obj.ekf_latency, gps_format_obj.diff_age, gps_format_obj.ekf_horiz_speed, gps_format_obj.ekf_grnd_trc, gps_format_obj.ekf_vert_speed, res5] = unpack('<IIffdddf', bytearray(message_bytes) )

            elif (message_id == 241):   # BESTXYZ [GPS/INS ECEF Position/Velocity]
               [gps_format_obj.p_sol_status, gps_format_obj.pos_type, gps_format_obj.ecef_pos_x, gps_format_obj.ecef_pos_y, gps_format_obj.ecef_pos_z, gps_format_obj.ecef_pos_x_sd, gps_format_obj.ecef_pos_y_sd, gps_format_obj.ecef_pos_z_sd, gps_format_obj.v_sol_status, gps_format_obj.vel_type, gps_format_obj.ecef_vel_x, gps_format_obj.ecef_vel_y, gps_format_obj.ecef_vel_z, gps_format_obj.ecef_vel_x_sd, gps_format_obj.ecef_vel_y_sd, gps_format_obj.ecef_vel_z_sd, temp_base_station_id, gps_format_obj.vel_time_latency, temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfffIIdddfffIfffBBBBbbbb', bytearray(message_bytes) )

            elif (message_id == 324):   # INSVELS [INS NED Velocity]
               [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_vned_N, gps_format_obj.ins_vned_E, gps_format_obj.ins_vned_D, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

            elif (message_id == 323):   # INSSPDS [INS Speed]
               [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_grnd_trc, gps_format_obj.ins_horiz_speed, gps_format_obj.ins_vert_speed, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

            elif (message_id == 325):   # RAWIMUS [IMU Raw values]
               [temp_gps_week, temp_tow_ms2, gps_format_obj.imu_status, temp_z_accel, temp_y_accel, temp_x_accel, temp_z_gyro, temp_y_gyro, temp_x_gyro] = unpack('<Ldlllllll', bytearray(message_bytes) )

               gps_format_obj.z_accel = temp_z_accel * accel_scale_factor
               gps_format_obj.y_accel = -temp_y_accel * accel_scale_factor
               gps_format_obj.x_accel = temp_x_accel * accel_scale_factor

               gps_format_obj.z_gyro = temp_z_gyro * gyro_scale_factor
               gps_format_obj.y_gyro = -temp_y_gyro * gyro_scale_factor
               gps_format_obj.x_gyro = temp_x_gyro * gyro_scale_factor
            # } if (message_id == 319)..

            temp_tow_ms_prev = temp_tow_ms

         # } if (message_id in message_id_array) ..

         # ************* TEST ONLY **********************
         # if (packet_set_cnt == 150):
            # return

         k = k + header_length + message_length + crc_length

      else:
         # print(' ****** DID NOT FIND MATCHING AA 44 *************')
         k = k + 1
      # } if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and..
    # } while (k < len(bytes_read))..

    # Print the last set of values from the 'gps_format_obj', because there won't be another occurrence of GPS Time message at this point:
    if (packet_set_cnt >= 2):
      input_index = 0
      for gps_output_index in range(len(gps_output_order)):
         input_index = numpy.int32(gps_output_order[gps_output_index])
         fout_gps.write(gps_format_obj.format(input_index))

      fout_gps.write('\n')

    print('\n------------------------------------------------------------------')

    print ('\n************* Total nbr of Novatel packets: ' + str(message_cnt) + ', Nbr of Packet Sets = ' + str(packet_set_cnt))

    print('\n------------------------------------------------------------------')

    fin_bin.close()
    fout_gps.close()

 # } for out_file_type in out_file_type_array..

if(__name__ == "__main__"):
  main_line(sys.argv)




