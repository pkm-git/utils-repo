# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import numpy as np

def print_row(data_row_cnt, data_row, fout_csv_file, start_col, end_col):
      
   i = 0
   
   # if (data_row_cnt < 5):
      # print(' **** data_row_cnt = 1, data_row[3] = ' + data_row[3] + ', data_row[4] = ' + data_row[4])
   
   # ekf_row = False
   other_category_row = False
   whole_row_empty = True
   for v in data_row:
      i += 1
      
      # if (i <= 3 or (i >= start_col and i <= end_col)):
      # if (i > 3 and i >= start_col and i <= end_col and v.strip() == ''):
      if (i >= start_col and i <= end_col):
         if (v.strip() == ''):
            other_category_row = True
            # if (data_row_cnt < 15):
               # print(' **** other_category_row is TRUE: data_row_cnt = ' + str(data_row_cnt) + ',  i = ' + str(i) + ', start_col: ' + str(start_col) + ', end_col = ' + str(end_col)) 
            break
         elif ('nan' not in v.strip().lower() and 'ind' not in v.strip().lower()):
            whole_row_empty = False
         # } if (i > 3 and..
   # } for v in data_row..
   
   # if (whole_row_empty or ekf_row):
   if (whole_row_empty or other_category_row):
      return
   
   i = 0
   
   for v in data_row:
      i += 1
      
      if (i <= 3 or (i >= start_col and i <= end_col)):
         try:
            if (v.strip() != '' and 'nan' not in v.strip().lower() and 'ind' not in v.strip().lower()):
               if (i == end_col):
                  if ('.' in v or 'e' in v):
                     fout_csv_file.write('%14.8f'%(float(v)))
                  else:
                     fout_csv_file.write('%1d'%(int(v)))        
                  # } if ('.' in v)...
                  break
               elif ('.' in v or 'e' in v):
                  fout_csv_file.write('%14.8f,'%(float(v)))
               else:
                  fout_csv_file.write('%1d,'%(int(v)))
               # } if (i == end_col)..
            else:
               fout_csv_file.write(',')
            # } if (v.strip() != '')..

         except TypeError:
            print(' ***** print_row: TypeError: at data_row_cnt = ' + str(data_row_cnt) + ', len(data_row) = ' + str(len(data_row)) + ', column: ' + str(i) + ', value: ' + str(v))
         
         except ValueError:
            print(' ***** print_row: ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))

   # } for v in data_row..
   
   fout_csv_file.write('\n')
      
def process_csv_file(csvreader, start_col, end_col):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   prev_gps_week = 0
   
   for data_row in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True
 
         # headers no longer need to be determined
         determine_headers = False
         
         i = 0
         for c in data_row:
            i += 1
      
            if (i <= 3 or (i >= start_col and i <= end_col)):
               if (i == end_col):
                  fout_csv_file.write(c)
                  break
               else:
                  fout_csv_file.write(c + ',')
               # } if (i == end_col)..
            # } if (i <= 3 or..   
         # } for c in data_row..   
         fout_csv_file.write('\n')
 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
 
         print_row(data_row_cnt, data_row, fout_csv_file, start_col, end_col)

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in csvreader..
   

in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_10_17_NAL_Research/Sand Dollar + Raw IMU - Manassas 07-25-2019/Loop 1 with Mag heading/INS/3DM-CX5-45 6271.83053 Data Log 7-25-2019 8.48.16 AM.csv'

(fin_filepath, fin_filename) = os.path.split(in_file_name)

# data_desired = 'IMU'
# data_desired = 'GNSS'
data_desired = 'EF'

start_col = 0
end_col = 0

if (data_desired == 'IMU'):
   start_col = 4
   end_col = 21
elif (data_desired == 'GNSS'):
   start_col = 22
   end_col = 57
else:
   start_col = 58
   end_col = 112
# } if (data_desired == 'IMU')..

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + '_' + data_desired + '_Only.csv'), "w")

fout_csv_file.write('DATA_START\n')

in_csvfile = open(in_file_name,'rU')
csvreader = csv.reader(in_csvfile, delimiter=',')

print(' ***** start_col = ' + str(start_col) + ', end_col = ' + str(end_col))

process_csv_file(csvreader, start_col, end_col)
   
fout_csv_file.close()
