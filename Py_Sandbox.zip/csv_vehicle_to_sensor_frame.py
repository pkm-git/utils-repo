# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import numpy as np

def print_row(data_row_cnt, data_row, fout_csv_file):
      
   i = 0
   
   for v in data_row:
      i += 1
      try:
         if (v.strip() != '' and 'nan' not in v.strip().lower() and 'ind' not in v.strip().lower()):
	    if (i == 6):
	       if ('.' in v or 'e' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))        
               # } if ('.' in v)...
       	       break
	    elif (i == 2 or i == 5):
	       if (data_row_cnt < 5):
	          print(' **** i = ' + str(i) + ', will skip')
               continue
	    elif (i == 1 or i == 4):
	       if (data_row_cnt < 5):
	          print(' **** data_row_cnt: ' + str(data_row_cnt) + ', i = ' + str(i) + ', value: ' + v + ', next col value: ' + data_row[i])
		   
               fout_csv_file.write('%14.8f,%14.8f,'%(float(data_row[i]), float(v) * -1))   # swap the x- and y- accel/gyro/mag column values, and muliply resulting Y-value by -1 (Canadian Space Agency)
	    elif ('.' in v or 'e' in v):
	       fout_csv_file.write('%14.8f,'%(float(v)))
   	    else:
	       fout_csv_file.write('%1d,'%(int(v)))
	    # } if (i == 6)..
	       
         elif ('nan' in v.strip().lower() or 'ind' in v.strip().lower()):
	    if (i == len(data_row)):
	       fout_csv_file.write(v)
	    else:
	       fout_csv_file.write(v + ',')
            # } if (i == len(data_row))..	       
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..

      except TypeError:
         print(' ***** print_row: TypeError: at data_row_cnt = ' + str(data_row_cnt) + ', len(data_row) = ' + str(len(data_row)) + ', column: ' + str(i) + ', value: ' + str(v))
      
      except ValueError:
         if (data_row_cnt < 5):
            print(' ***** print_row: ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))

   # } for v in data_row..

   fout_csv_file.write('\n')
      
      
def process_csv_file(csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   prev_gps_week = 0
   
   for data_row in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         
         i = 0
         for c in data_row:
            i += 1
            if (i == 6):
               fout_csv_file.write(c)
     	       break
   	    else:
               fout_csv_file.write(c + ',')
	    # } if (i == 6)..
         # } for c in data_row..   
         fout_csv_file.write('\n')
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
	 print_row(data_row_cnt, data_row, fout_csv_file)

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in csvreader..
   

in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Decimated_By_10_18500_25000_Rel_Time_for_iron_cal.csv'

(fin_filepath, fin_filename) = os.path.split(in_file_name)

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_sensorFrame.csv"), "w")

fout_csv_file.write('DATA_START\n')

in_csvfile = open(in_file_name,'r')
csvreader = csv.reader(in_csvfile, delimiter=',')

process_csv_file(csvreader)
   
fout_csv_file.close()




