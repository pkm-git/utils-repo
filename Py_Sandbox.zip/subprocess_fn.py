import subprocess

def subprocess_fn(command_line):
   # str1 = 'python sensor_cloud_utils.py -i "'
   # str1 += 'U:/Lord/Python_HIL_Sim_From_File/Vehicle_Logs/2016_07_12/3DM-GX4-45 6236.46589 Data Log 7-19-2016 4.53.30 PM.bin" -a pfmb';

   subprocess.call(command_line)
