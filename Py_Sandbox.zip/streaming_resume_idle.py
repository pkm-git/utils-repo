#import libraries used
from mip import *              #local file should be in local folder
from mip_parser import *       #local file should be in local folder
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 # global streaming_enabled
 print("****** mip_parser_callback: callback_type = " + str(callback_type))
 print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
   print("Valid Packet Found")

   #loop over fields in received valid packet
   for field in mip_get_next_field(packet_bytes):
     # print('field[1]: ' + str(field[1]) + ', Device response to command: (' + hex(field[2]).upper() + ') = '\
            # + mip_ack_nacks[field[3]])

     #if this field is an ack/nack output it to show the user
     if (field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):  # 0xF1
       print('field[1]: ' + str(field[1]) + ', Device response to command: (' + hex(field[2]).upper() + ') = '\
            + mip_ack_nacks[field[3]])

       # print('Device response to command '+hex(field[2]).upper()+': '\
            # +mip_ack_nacks[field[3]])
     elif (field[1] == MIP_REPLY_DESC_ENABLE_DISABLE_STREAMING_DATA_VALUE): # 0x85
       # streaming_enabled = field[3]
       mip_parser.set_streaming_enabled(field[3])
       print('field[1]: ' + str(field[1]) + ', Device: (' + hex(field[2]).upper() + ') = ' + str(field[3]))
            # + mip_enable_disable[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

# streaming_enabled = 0

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM20'
# port_baud = 115200    # USE THIS FOR RQ1
# port_baud = 460800  # DON'T USE
port_baud = 921600    # USE THIS FOR RQ1

# port_name = 'COM4'
# port_baud = 921600   # DON'T USE
# port_baud = 12000000 # USE THIS FOR GX4

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-m' and len(argv) > i+1):
  mode = argv[i+1]

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name,port_baud)

#Close port in case it was left open by other process
port.close()

#generate command bytearrays

# Enter Idle Mode
idle_mode_command = bytearray.fromhex('756501020202E1C7')

# Resume Streaming
resume_command = bytearray.fromhex('756501020206E5CB')

ping_filter_command = bytearray.fromhex('756501020201E0C6');

resume_imu_command = bytearray.fromhex('75650C050511010101041A');
idle_imu_command = bytearray.fromhex('75650C0505110101000319');

resume_gps_command = bytearray.fromhex('75650C050511010201051C');
idle_gps_command = bytearray.fromhex('75650C050511010200041B');

resume_filter_command = bytearray.fromhex('75650C050511010301061E');
idle_filter_command = bytearray.fromhex('75650C050511010300051D');

resume_imu_and_filter_command = bytearray.fromhex('75650C0A0511010101051101030124CC');

# IMU Read Current  - 0x75 0x65 0x0C 0x04 0x04 0x11 0x02 0x01 0x02 0x0F
# GPS Read Current   - 0x75 0x65 0x0C 0x04 0x04 0x11 0x02 0x02 0x03 0x10

read_current_imu_streaming_command = bytearray.fromhex('75650C0404110201020F');
read_current_gps_streaming_command = bytearray.fromhex('75650C04041102020310');
read_current_filter_streaming_command = bytearray.fromhex('75650C04041102030411');

# 75650C050511010301061E -- resume
# 75650C04041102030411   -- read

# NAV Read Current   - 0x75 0x65 0x0C 0x04 0x04 0x11 0x02 0x03 0x04 0x11

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

#open specified port
port.open()

#set up background process to update data buffers
background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

#start the response parsing thread
background_data_update.start()

if (mode == 'ping'):
    #send Ping command
    print('Sending Ping command:')
    port.write(ping_filter_command)

elif (mode == 'idle'):
    #send Enter Idle Mode command
    # print('Sending IMU Idle Mode command:')
    # port.write(idle_imu_command)

    # print('Sending GPS Idle Mode command:')
    # port.write(idle_gps_command)

    # print('Sending Filter Idle Mode command:')
    # port.write(idle_filter_command)

    print('Sending Idle Mode command:')
    port.write(idle_mode_command)

elif (mode == 'resume'):
    #send Resume Streaming command
    print('Sending IMU Resume Streaming command:')
    port.write(resume_imu_command)

    print('Sending GPS Resume Streaming command:')
    port.write(resume_gps_command)

    print('Sending Filter Resume Streaming command:')
    port.write(resume_filter_command)

    print('Sending Resume Streaming command:')
    port.write(resume_command)

elif (mode == 'testdcf'):
    print('Sending IMU and Filter Streaming command:')
    port.write(resume_imu_and_filter_command)

elif (mode == 'readi'):
    print('Sending Read Current IMU command:')
    port.write(read_current_imu_streaming_command)

elif (mode == 'readg'):
    print('Sending Read Current GPS command:')
    port.write(read_current_gps_streaming_command)

elif (mode == 'readf'):
    print('Sending Read Current Filter command:')
    port.write(read_current_filter_streaming_command)


#sleep while waiting for response
sleep(1)

if (mip_parser.get_streaming_enabled() == 1):
  label = 'Enabled'
else:
  label = 'Disabled'

# print(' ************ RESULT: filter streaming_enabled = ' + str(mip_parser.get_streaming_enabled()))
if (mode == 'read'):
   print(' ************ RESULT: filter streaming_enabled = ' + label)

#stop background response parsing thread
background_data_update.stop()

#close port
port.close()


