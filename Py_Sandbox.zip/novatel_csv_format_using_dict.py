# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

NOVATEL_FORMAT_USING_DICT_UNINITIALIZED = 0

class Novatel_Timestamp_struct:  # from message header
   def __init__(self):
      [self.gps_tow, self.gps_week, self.imu_status, self.ins_status, self.soln_status] = [0,0,0,0,0]

class Novatel_321_struct: # INSPOSS [INS Position]
   def __init__(self):
      [self.ins_lat, self.ins_lon, self.ins_ht_abv_ellip] = [0,0,0]

class Novatel_42_struct:  # BESTPOS [GPS/INS Blended Position]
   def __init__(self):
      [self.pos_type, self.ekf_lat, self.ekf_lon, self.ekf_ht_abv_MSL, self.undulation, self.lat_sd, self.lon_sd, self.ht_MSL_sd, self.sol_age, self.nbr_svs_tracked, self.nbr_svs_used] = [0,0,0,0,0,0,0,0,0,0,0]

class Novatel_324_struct: # INSVELS [INS NED Velocity]
   def __init__(self):
      [self.ins_vned_N, self.ins_vned_E, self.ins_vned_D] = [0,0,0]

class Novatel_323_struct: # INSSPDS [INS Speed]
   def __init__(self):
      [self.ins_grnd_trc, self.ins_horiz_speed, self.ins_vert_speed] = [0,0,0]

class Novatel_99_struct:  # BESTVEL [GPS/INS Blended Velocity]
   def __init__(self):
      [self.vel_type, self.ekf_horiz_speed, self.ekf_grnd_trc, self.ekf_vert_speed, self.ekf_latency, self.diff_age] = [0,0,0,0,0,0]

class Novatel_241_struct:  # BESTXYZ [GPS/INS ECEF Position/Velocity]
   def __init__(self):
      [self.p_sol_status, self.pos_type, self.ecef_pos_x, self.ecef_pos_y, self.ecef_pos_z, self.ecef_pos_x_sd, self.ecef_pos_y_sd, self.ecef_pos_z_sd, self.v_sol_status, self.vel_type, self.ecef_vel_x, self.ecef_vel_y, self.ecef_vel_z, self.ecef_vel_x_sd, self.ecef_vel_y_sd, self.ecef_vel_z_sd, self.vel_time_latency] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class Novatel_319_struct: # INSATTS [INS Attitude]
   def __init__(self):
      [self.roll, self.pitch, self.azimuth] = [0,0,0]

class Novatel_508_struct: # INSPVAS [INS Position, Velocity and Attitude]
   def __init__(self):
      # [self.ins_pva_lat, self.ins_pva_lon, self.ins_pva_ht_abv_ellips, self.ins_pva_vned_N, self.ins_pva_vned_E, self.ins_pva_vned_D, self.ins_pva_roll, self.ins_pva_pitch, self.ins_pva_azimuth, self.ins_status] = [0,0,0,0,0,0,0,0,0,0]
      [self.ins_pva_lat, self.ins_pva_lon, self.ins_pva_ht_abv_ellips, self.ins_pva_vned_N, self.ins_pva_vned_E, self.ins_pva_vned_D, self.ins_pva_roll, self.ins_pva_pitch, self.ins_pva_azimuth] = [0,0,0,0,0,0,0,0,0]

class Novatel_325_struct: # RAWIMUS [IMU Raw values]
   def __init__(self):
      # [self.imu_status, self.z_accel, self.y_accel, self.x_accel, self.z_gyro, self.y_gyro, self.x_gyro] = [0,0,0,0,0,0,0]
      [self.z_accel, self.y_accel, self.x_accel, self.z_gyro, self.y_gyro, self.x_gyro] = [0,0,0,0,0,0]

class Novatel_101_struct: # TIME
   def __init__(self):
      [self.rcvr_clock_status, self.rcvr_clock_offset, self.rcvr_clock_offset_sd, self.utc_offset, self.utc_year, self.utc_month, self.utc_day, self.utc_hour, self.utc_min, self.utc_ms, self.utc_status] = [0,0,0,0,0,0,0,0,0,0,0]

class Novatel_642_struct:
   def __init__(self):
      [self.x_veh2body_angle, self.y_veh2body_angle, self.z_veh2body_angle, self.x_veh2body_angle_unc, self.y_veh2body_angle_unc, self.z_veh2body_angle_unc] = [0,0,0,0,0,0]

novatel_valid_packet_field_desc_array = [321, 42, 324, 323, 99, 241, 319, 508, 325, 101, 642]

min_gps_default_long2shorthdr_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

class Novatel_CSV_format_using_dict(object):

 #default 'constructor'
 def __init__(self, novatel_format_dict = None):
    """Class default initialization function"""
    try:
       self.init(novatel_format_dict)
    except:
       self.state = NOVATEL_FORMAT_USING_DICT_UNINITIALIZED

 #class initializer function
 def init(self, novatel_format_dict):
   """Class initialization function"""

   [self.novatel_Timestamp_struct, self.novatel_321_struct, self.novatel_42_struct, self.novatel_324_struct, self.novatel_323_struct, self.novatel_99_struct] = [None, None, None, None, None, None]
   [self.novatel_241_struct, self.novatel_319_struct, self.novatel_508_struct, self.novatel_325_struct, self.novatel_101_struct, self.novatel_642_struct] = [None, None, None, None, None, None]

   if (novatel_format_dict != None):
      self.novatel_Timestamp_struct = novatel_format_dict['TIMESTAMP']
      for k in novatel_valid_packet_field_desc_array:
         if (k in novatel_format_dict):
            if (k == 321):
               self.novatel_321_struct = novatel_format_dict[k]
            elif (k == 42):
               self.novatel_42_struct = novatel_format_dict[k]
            elif (k == 324):
               self.novatel_324_struct = novatel_format_dict[k]
            elif (k == 323):
               self.novatel_323_struct = novatel_format_dict[k]
            elif (k == 99):
               self.novatel_99_struct = novatel_format_dict[k]
            elif (k == 241):
               self.novatel_241_struct = novatel_format_dict[k]
            elif (k == 319):
               self.novatel_319_struct = novatel_format_dict[k]
            elif (k == 508):
               self.novatel_508_struct = novatel_format_dict[k]
            elif (k == 325):
               self.novatel_325_struct = novatel_format_dict[k]
            elif (k == 101):
               self.novatel_101_struct = novatel_format_dict[k]
            elif (k == 642):
               self.novatel_642_struct = novatel_format_dict[k]
            # } if (k == "TOW")..
         # } if (k in novatel_format_dict)..
      # } for k in novatel_valid_packet_field_desc_array..
   # } if (novatel_format_dict != None)..

 def format_header(self, format_in, is_last_format = False, out_file_type = None):
    ret_str = ''
    if (format_in == 0):
       if (out_file_type != None):
          if (out_file_type.lower() == 'i'):
             ret_str = 'INS_Week,INS_TOW,INS_Status,'
          elif (out_file_type.lower() == 'e'):
             ret_str = 'EKF_Week,EKF_TOW,Soln Status,'
          elif (out_file_type.lower() == 'r'):
             ret_str = 'RAWIMU_Week,RAWIMU_TOW,IMU_Status,'
          else:
             ret_str = 'GPS_Week,GPS_TOW,'
       else:
          ret_str = 'GPS_Week,GPS_TOW,'
    elif (format_in == 1):
       ret_str = 'INS Lat [321/265],INS Lon [321/265],INS Height Abv Ellips [321/265],'
    elif (format_in == 2):
       ret_str = 'EKF Pos Type[42],EKF Lat [42],EKF Lon [42],EKF Height Abv MSL [42],EKF Undulation[42],EKF Lat Sigma [42],EKF Lon Sigma [42],EKF Ht MSL Sigma [42],EKF Sol Age [42],EKF Nbr SVs Tracked [42],EKF Nbr SVs Used [42],'
    elif (format_in == 3):
       ret_str = 'Vel N [324/267],Vel E [324/267],Vel D [324/267],'
    elif (format_in == 4):
       ret_str = 'INS Horiz Speed [323/266],INS Vert Speed [323/266],INS Grnd Trc [323/266],'
    elif (format_in == 5):
       ret_str = 'EKF Vel Type[99],EKF Horiz Speed [99],EKF Vert Speed [99],EKF Grnd Trc [99],EKF Latency [99],EKF Diff Age [99],'
    elif (format_in == 6):
       ret_str = 'Pos Soln Status [241],Pos Type [241],ECEF Pos X[241],ECEF Pos Y[241],ECEF Pos Z[241],ECEF Pos X Sigma[241],ECEF Pos Y Sigma [241],ECEF Pos Z Sigma [241],Vel Soln Status [241],Vel Type [241],ECEF Vel X[241],ECEF Vel Y[241],ECEF Vel Z[241],ECEF Vel X Sigma[241],ECEF Vel Y Sigma[241],ECEF Vel Z Sigma[241],Vel Time Latency[241],'
    elif (format_in == 7):
       ret_str = 'Roll [319/263],Pitch [319/263],Azimuth [319/263],'
    elif (format_in == 8):
       ret_str = 'INS_PVA_Lat [508/507], INS_PVA_Lon [508/507], INS_PVA_Ht_abv_ellips [508/507], INS_PVA_vned_N [508/507], INS_PVA_vned_E [508/507], INS_PVA_vned_D [508/507], INS_PVA_roll [508/507], INS_PVA_pitch [508/507], INS_PVA_azimuth [508/507],'
    elif (format_in == 9):
       ret_str = 'DeltaV_X [325/268],DeltaV_Y [325/268],DeltaV_Z [325/268],DeltaTheta_X [325/268],DeltaTheta_Y [325/268],DeltaTheta_Z [325/268],'
    elif (format_in == 10):
       ret_str = 'Rcvr Clock Status [101], Rcvr Clock Offset [101], Rcvr Clock Offset SD [101], UTC_Offset [101], UTC_Year [101], UTC_Month [101], UTC_Day [101], UTC_Hour [101], UTC_Min [101], UTC_TOW_ms [101], UTC_status [101],'
    elif (format_in == 11):
       ret_str = 'X_Veh2Body_Angle [642],Y_Veh2Body_Angle [642],Z_Veh2Body_Angle [642],X_Veh2Body_Angle_Unc [642],Y_Veh2Body_Angle_Unc [642],Z_Veh2Body_Angle_Unc [642],'
    # } if (format_in == 0)..
   
    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 # Master Format (subset of 'important' or 'min' columns from DCP, in a 'master sequence'):
 # GPS Week,GPS TOW,     INS Lat [321],INS Lon [321],INS Ht Abv Ellips [321],   EKF Lat [42],EKF Lon [42],EKF Ht Abv MSL [42],Undulation [42],    Vel N [324],Vel E [324],Vel D [324],   INS Horiz Speed [323],INS Vert Speed [323],INS Grnd Trc [323],  EKF Latency[99], EKF Diff Age[99],EKF Horiz Speed [99],EKF Vert Speed [99],EKF Grnd Trc [99],   Pos Soln Status [241],Pos Type [241],ECEF Pos X[241],ECEF Pos Y[241],ECEF Pos Z[241],ECEF Pos X Sigma[241],ECEF Pos Y Sigma [241],ECEF Pos Z Sigma [241],Vel Soln Status [241],Vel Type [241],ECEF Vel X[241],ECEF Vel Y[241],ECEF Vel Z[241],ECEF Vel X Sigma[241],ECEF Vel Y Sigma[241],ECEF Vel Z Sigma[241],Vel Time Latency[241],   Roll [319],Pitch [319],Azimuth [319],    X_Accel [325],Y_Accel [325],Z_Accel [325],X_Gyro [325],Y_Gyro [325],Z_Gyro [325]
 # %4d,%12.4f,           %14.8f,%14.8f,%14.8f,                                  %14.8f,%14.8f,%14.8f,%14.8f,                                      %14.8f,%14.8f,%14.8f,                  %14.8f,%14.8f,%14.8f,                                           %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,                                                             %4d,%4d,%14.8f,14.8f,14.8f,14.8f,14.8f,14.8f,4d,4d,14.8f,14.8f,14.8f,14.8f,14.8f,14.8f,14.8f,                                                                                                                                                                                                                                            %14.8f,%14.8f,%14.8f,                    %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f
 # gps_week, gps_tow,    ins_lat, ins_lon, ins_ht_abv_ellip,                    ekf_lat, ekf_lon, ekf_ht_abv_MSL, undulation,                     ins_vned_N, ins_vned_E, ins_vned_D,    ins_horiz_speed, ins_vert_speed, ins_grnd_trc                   ekf_latency, diff_age, ekf_horiz_speed, ekf_vert_speed, ekf_grnd_trc                            p_sol_status, self.pos_type, self.ecef_pos_x, self.ecef_pos_y, self.ecef_pos_z, self.ecef_pos_x_sd, self.ecef_pos_y_sd, self.ecef_pos_z_sd, self.v_sol_status, self.vel_type, self.ecef_vel_x, self.ecef_vel_y, self.ecef_vel_z, self.ecef_vel_x_sd, self.ecef_vel_y_sd, self.ecef_vel_z_sd, self.vel_time_latency                       roll,pitch,azimuth,                      x_accel,y_accel,z_accel,x_gyro,y_gyro,z_gyro

 # 'Master Sequence' Message ID's:
 # min_gps_default_cols_dict = {321:1, 42:2, 324:3, 323:4, 99:5, 241:6, 319:7, 508:8, 325:9, 101:10, 642:11}
 # min_gps_default_long2shorthdr_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

 def format(self, format_in, is_last_format = False, out_file_type = None):
    ret_str = ''
    if (format_in == 0):
       if (out_file_type != None):
          if (self.novatel_Timestamp_struct != None):
             if (out_file_type.lower() == 'i'):
                ret_str = '{:-4d},{:-12.4f},{:-4d},'.format(self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow, self.novatel_Timestamp_struct.ins_status)
             elif (out_file_type.lower() == 'r'):
                ret_str = '{:-4d},{:-12.4f},{:-4d},'.format(self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow, self.novatel_Timestamp_struct.imu_status)
             elif (out_file_type.lower() == 'e'):
                ret_str = '{:-4d},{:-12.4f},{:-4d},'.format(self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow, self.novatel_Timestamp_struct.soln_status)
             else:
                ret_str = '{:-4d},{:-12.4f},'.format(self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow)
             # } if (out_file_type.lower() == 'i')..
          else:
             if (out_file_type.lower() == 'i' or out_file_type.lower() == 'r' or out_file_type.lower() == 'e'):
                ret_str = ',,,'
             else:
                ret_str = ',,'
             # } if (out_file_type.lower() == 'i' or..
          # } if (self.novatel_Timestamp_struct != None)..
       else:
          if (self.novatel_Timestamp_struct != None):
             ret_str = '{:-4d},{:-12.4f},'.format(self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow)
          else:
             ret_str = ',,'
          # } if (self.novatel_Timestamp_struct != None)..
       # } if (out_file_type != None)..
    elif (format_in == 1):
       if (self.novatel_321_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.Novatel_321_struct.ins_lat, self.Novatel_321_struct.ins_lon, self.Novatel_321_struct.ins_ht_abv_ellip)
       else:
          ret_str = ',,,'
    elif (format_in == 2):
       if (self.novatel_42_struct != None):
          ret_str = '{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},{:-d},'.format(self.novatel_42_struct.pos_type, self.novatel_42_struct.ekf_lat, self.novatel_42_struct.ekf_lon, self.novatel_42_struct.ekf_ht_abv_MSL, self.novatel_42_struct.undulation, self.novatel_42_struct.lat_sd, self.novatel_42_struct.lon_sd, self.novatel_42_struct.ht_MSL_sd, self.novatel_42_struct.sol_age, self.novatel_42_struct.nbr_svs_tracked, self.novatel_42_struct.nbr_svs_used)
       else:
          ret_str = ',,,,,,,,,,,'
    elif (format_in == 3):
       if (self.novatel_324_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_324_struct.ins_vned_N, self.novatel_324_struct.ins_vned_E, self.novatel_324_struct.ins_vned_D)
       else:
          ret_str = ',,,'
    elif (format_in == 4):
       if (self.novatel_323_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_323_struct.ins_horiz_speed, self.novatel_323_struct.ins_vert_speed, self.novatel_323_struct.ins_grnd_trc)
       else:
          ret_str = ',,,'
    elif (format_in == 5):
       if (self.novatel_99_struct != None):
          ret_str = '{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_99_struct.vel_type, self.novatel_99_struct.ekf_horiz_speed, self.novatel_99_struct.ekf_vert_speed, self.novatel_99_struct.ekf_grnd_trc, self.novatel_99_struct.ekf_latency, self.novatel_99_struct.diff_age)
       else:
          ret_str = ',,,,,,'
    elif (format_in == 6):
       if (self.novatel_241_struct != None):
          ret_str = '{:-4d},{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_241_struct.p_sol_status, self.novatel_241_struct.pos_type, self.novatel_241_struct.ecef_pos_x, self.novatel_241_struct.ecef_pos_y, self.novatel_241_struct.ecef_pos_z, self.novatel_241_struct.ecef_pos_x_sd, self.novatel_241_struct.ecef_pos_y_sd, self.novatel_241_struct.ecef_pos_z_sd, self.novatel_241_struct.v_sol_status, self.novatel_241_struct.vel_type, self.novatel_241_struct.ecef_vel_x, self.novatel_241_struct.ecef_vel_y, self.novatel_241_struct.ecef_vel_z, self.novatel_241_struct.ecef_vel_x_sd, self.novatel_241_struct.ecef_vel_y_sd, self.novatel_241_struct.ecef_vel_z_sd, self.novatel_241_struct.vel_time_latency)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,'
    elif (format_in == 7):
       if (self.novatel_319_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_319_struct.roll, self.novatel_319_struct.pitch, self.novatel_319_struct.azimuth)
       else:
          ret_str = ',,,'
    elif (format_in == 8):
       if (self.novatel_508_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_508_struct.ins_pva_lat, self.novatel_508_struct.ins_pva_lon, self.novatel_508_struct.ins_pva_ht_abv_ellips, self.novatel_508_struct.ins_pva_vned_N, self.novatel_508_struct.ins_pva_vned_E, self.novatel_508_struct.ins_pva_vned_D, self.novatel_508_struct.ins_pva_roll, self.novatel_508_struct.ins_pva_pitch, self.novatel_508_struct.ins_pva_azimuth)
       else:
          ret_str = ',,,,,,,,,'
    elif (format_in == 9):
       if (self.novatel_325_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_325_struct.x_accel, self.novatel_325_struct.y_accel, self.novatel_325_struct.z_accel, self.novatel_325_struct.x_gyro, self.novatel_325_struct.y_gyro, self.novatel_325_struct.z_gyro)
       else:
          ret_str = ',,,,,,'
    elif (format_in == 10):
       if (self.novatel_101_struct != None):
          ret_str = '{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},{:-d},{:-d},{:-d},{:-d},{:-4d},{:-4d},'.format(self.novatel_101_struct.rcvr_clock_status, self.novatel_101_struct.rcvr_clock_offset, self.novatel_101_struct.rcvr_clock_offset_sd, self.novatel_101_struct.utc_offset, self.novatel_101_struct.utc_year, self.novatel_101_struct.utc_month, self.novatel_101_struct.utc_day, self.novatel_101_struct.utc_hour, self.novatel_101_struct.utc_min, self.novatel_101_struct.utc_ms, self.novatel_101_struct.utc_status)
       else:
          ret_str = ',,,,,,,,,,,'
    elif (format_in == 11):
       if (self.novatel_642_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.novatel_642_struct.x_veh2body_angle, self.novatel_642_struct.y_veh2body_angle, self.novatel_642_struct.z_veh2body_angle, self.novatel_642_struct.x_veh2body_angle_unc, self.novatel_642_struct.y_veh2body_angle_unc, self.novatel_642_struct.z_veh2body_angle_unc)
       else:
          ret_str = ',,,,,,'
    # } if (format_in == 0)..
   
    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 # } def format(self, format_in)..

 def format_channel_name(self, format_in, out_file_type = None):
    if (format_in == 0):
       if (out_file_type == None or out_file_type.lower() == 'g'):
          return ['GPS_Week','GPS_TOW']
       elif (out_file_type.lower() == 'i'):
          return ['INS_Week','INS_TOW','INS_Status']
       elif (out_file_type.lower() == 'e'):
          return ['EKF_Week','EKF_TOW', 'Soln_Status']
       elif (out_file_type.lower() == 'r'):
          return ['RAWIMU_Week','RAWIMU_TOW','IMU_Status']
    elif (format_in == 1):
       return ['INS_Lat_321_265','INS_Lon_321_265','INS_Height_Abv_Ellips_321_265']
    elif (format_in == 2):
       return ['EKF_Pos_Type_42','EKF_Lat_42','EKF_Lon_42','EKF_Ht_Abv_MSL_42','EKF_Undulation_42','EKF_Lat_Sigma_42','EKF_Lon_Sigma_42','EKF_Ht_MSL_Sigma_42','EKF_Sol_Age_42','EKF_Nbr_SVs_Tracked_42','EKF_Nbr_SVs_Used_42']
    elif (format_in == 3):
       return ['Vel_N_324_267','Vel_E_324_267','Vel_D_324_267']
    elif (format_in == 4):
       return ['INS_Horiz_Speed_323_266','INS_Vert_Speed_323_266','INS_Grnd_Trc_323_266']
    elif (format_in == 5):
       return ['EKF_Vel_Type_99','EKF_Horiz_Speed_99','EKF_Vert_Speed_99','EKF_Grnd_Trc_99','EKF_Latency_99','EKF_Diff_Age_99']
    elif (format_in == 6):
       return ['Pos_Soln_Status_241','Pos_Type_241','ECEF_Pos_X241','ECEF_Pos_Y241','ECEF_Pos_Z241','ECEF_Pos_X_Sigma241','ECEF_Pos_Y_Sigma_241','ECEF_Pos_Z_Sigma_241','Vel_Soln_Status_241','Vel_Type_241','ECEF_Vel_X241','ECEF_Vel_Y241','ECEF_Vel_Z241','ECEF_Vel_X_Sigma241','ECEF_Vel_Y_Sigma241','ECEF_Vel_Z_Sigma241','Vel_Time_Latency241']
    elif (format_in == 7):
       return ['Roll_319_263','Pitch_319_263','Azimuth_319_263']
    elif (format_in == 8):
       return ['INS_PVA_Lat_508_507','INS_PVA_Lon_508_507','INS_PVA_Ht_abv_ellips_508_507','INS_PVA_vned_N_508_507','INS_PVA_vned_E_508_507','INS_PVA_vned_D_508_507','INS_PVA_roll_508_507','INS_PVA_pitch_508_507','INS_PVA_azimuth_508_507']
    elif (format_in == 9):
       return ['DeltaV_X_325_268','DeltaV_Y_325_268','DeltaV_Z_325_268','DeltaTheta_X_325_268','DeltaTheta_Y_325_268','DeltaTheta_Z_325_268']
    elif (format_in == 10):
       return ['Rcvr_Clock_Status_101','Rcvr_Clock_Offset_101','Rcvr_Clock_Offset_SD_101','UTC_Offset_101','UTC_Year_101','UTC_Month_101','UTC_Day_101','UTC_Hour_101','UTC_Min_101','UTC_TOW_ms_101','UTC_status_101']
    elif (format_in == 11):
       return ['X_Veh2Body_Angle_642','Y_Veh2Body_Angle_642','Z_Veh2Body_Angle_642','X_Veh2Body_Angle_Unc_642','Y_Veh2Body_Angle_Unc_642','Z_Veh2Body_Angle_Unc_642']

    return []

 def format_channel_value(self, format_in, out_file_type = None):
    if (format_in == 0):
       if (out_file_type != None):
          if (self.novatel_Timestamp_struct != None):
             if (out_file_type.lower() == 'i'):
                return [self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow, self.novatel_Timestamp_struct.ins_status]
             elif (out_file_type.lower() == 'r'):
                return [self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow, self.novatel_Timestamp_struct.imu_status]
             elif (out_file_type.lower() == 'e'):
                return [self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow, self.novatel_Timestamp_struct.soln_status]
             else:
                return [self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow]
          else:
             return None
          # } if (self.novatel_Timestamp_struct != None)..
       else:
          if (self.novatel_Timestamp_struct != None):
             return [self.novatel_Timestamp_struct.gps_week, self.novatel_Timestamp_struct.gps_tow]
          else:
             return None
          # } if (self.novatel_Timestamp_struct != None)..
       # } if (out_file_type != None)..
    elif (format_in == 1):
       if (self.novatel_321_struct != None):
          return [self.novatel_321_struct.ins_lat, self.novatel_321_struct.ins_lon, self.novatel_321_struct.ins_ht_abv_ellip]
       else:
          return None
       # } if (self.novatel_321_struct != None)..
    elif (format_in == 2):
       if (self.novatel_42_struct != None):
          # return [self.novatel_42_struct.ekf_lat, self.novatel_42_struct.ekf_lon, self.novatel_42_struct.ekf_ht_abv_MSL, self.novatel_42_struct.undulation]
          return [self.novatel_42_struct.ekf_lat, self.novatel_42_struct.ekf_lon, self.novatel_42_struct.ekf_ht_abv_MSL, self.novatel_42_struct.undulation, self.novatel_42_struct.lat_sd, self.novatel_42_struct.lon_sd, self.novatel_42_struct.ht_MSL_sd, self.novatel_42_struct.sol_age, self.novatel_42_struct.nbr_svs_tracked, self.novatel_42_struct.nbr_svs_used]
       else:
          return None
       # } if (self.novatel_42_struct != None)..
    elif (format_in == 3):
       if (self.novatel_324_struct != None):
          return [self.novatel_324_struct.ins_vned_N, self.novatel_324_struct.ins_vned_E, self.novatel_324_struct.ins_vned_D]
       else:
          return None
       # } if (self.novatel_324_struct != None)..
    elif (format_in == 4):
       if (self.novatel_323_struct != None):
          return [self.novatel_323_struct.ins_horiz_speed, self.novatel_323_struct.ins_vert_speed, self.novatel_323_struct.ins_grnd_trc]
       else:
          return None
       # } if (self.novatel_323_struct != None)..
    elif (format_in == 5):
       if (self.novatel_99_struct != None):
          # return [self.vel_type, self.ekf_horiz_speed, self.ekf_vert_speed, self.ekf_grnd_trc, self.ekf_latency, self.diff_age]
          return [self.novatel_99_struct.vel_type, self.novatel_99_struct.ekf_horiz_speed, self.novatel_99_struct.ekf_vert_speed, self.novatel_99_struct.ekf_grnd_trc, self.novatel_99_struct.ekf_latency, self.novatel_99_struct.diff_age]
       else:
          return None
       # } if (self.novatel_99_struct != None)..
    elif (format_in == 6):
       if (self.novatel_241_struct != None):
          return [self.novatel_241_struct.p_sol_status, self.novatel_241_struct.pos_type, self.novatel_241_struct.ecef_pos_x, self.novatel_241_struct.ecef_pos_y, self.novatel_241_struct.ecef_pos_z, self.novatel_241_struct.ecef_pos_x_sd, self.novatel_241_struct.ecef_pos_y_sd, self.novatel_241_struct.ecef_pos_z_sd, self.novatel_241_struct.v_sol_status, self.novatel_241_struct.vel_type, self.novatel_241_struct.ecef_vel_x, self.novatel_241_struct.ecef_vel_y, self.novatel_241_struct.ecef_vel_z, self.novatel_241_struct.ecef_vel_x_sd, self.novatel_241_struct.ecef_vel_y_sd, self.novatel_241_struct.ecef_vel_z_sd, self.novatel_241_struct.vel_time_latency]
       else:
          return None
       # } if (self.novatel_241_struct != None)..
    elif (format_in == 7):
       if (self.novatel_319_struct != None):
          return [self.novatel_319_struct.roll, self.novatel_319_struct.pitch, self.novatel_319_struct.azimuth]
       else:
          return None
       # } if (self.novatel_319_struct != None)..
    elif (format_in == 8):
       if (self.novatel_508_struct != None):
          return [self.novatel_508_struct.ins_pva_lat, self.novatel_508_struct.ins_pva_lon, self.novatel_508_struct.ins_pva_ht_abv_ellips, self.novatel_508_struct.ins_pva_vned_N, self.novatel_508_struct.ins_pva_vned_E, self.novatel_508_struct.ins_pva_vned_D, self.novatel_508_struct.ins_pva_roll, self.novatel_508_struct.ins_pva_pitch, self.novatel_508_struct.ins_pva_azimuth]
       else:
          return None
       # } if (self.novatel_508_struct != None)..
    elif (format_in == 9):
       if (self.novatel_325_struct != None):
          return [self.novatel_325_struct.x_accel, self.novatel_325_struct.y_accel, self.novatel_325_struct.z_accel, self.novatel_325_struct.x_gyro, self.novatel_325_struct.y_gyro, self.novatel_325_struct.z_gyro]
       else:
          return None
       # } if (self.novatel_325_struct != None)..
    elif (format_in == 10):
       if (self.novatel_101_struct != None):
          return [self.novatel_101_struct.rcvr_clock_status, self.novatel_101_struct.rcvr_clock_offset, self.novatel_101_struct.rcvr_clock_offset_sd, self.novatel_101_struct.utc_offset, self.novatel_101_struct.utc_year, self.novatel_101_struct.utc_month, self.novatel_101_struct.utc_day, self.novatel_101_struct.utc_hour, self.novatel_101_struct.utc_min, self.novatel_101_struct.utc_ms, self.novatel_101_struct.utc_status]
       else:
          return None
       # } if (self.novatel_101_struct != None)..
    elif (format_in == 11):
       if (self.novatel_642_struct != None):
          return [self.novatel_642_struct.x_veh2body_angle, self.novatel_642_struct.y_veh2body_angle, self.novatel_642_struct.z_veh2body_angle, self.novatel_642_struct.x_veh2body_angle_unc, self.novatel_642_struct.y_veh2body_angle_unc, self.novatel_642_struct.z_veh2body_angle_unc]
       else:
          return None
       # } if (self.novatel_642_struct != None)..

    return []

