import math;

# orig_gyro_x = -3599.002689;
# orig_gyro_x = -3598.002689;
# orig_gyro_x = 449.9999064;
orig_gyro_x = -451.2004416;

tmp = int(math.floor(abs(orig_gyro_x)));
tmp_rem = tmp % 360
tmp_frac = abs(orig_gyro_x) - tmp;

if (tmp_rem == 359 or tmp_rem == 89 or tmp_rem == 90):
  gyro_x = 0.0
elif (orig_gyro_x > 0):
  gyro_x = tmp_rem + tmp_frac;
else:
  gyro_x = -(tmp_rem + tmp_frac);

print '***** orig_gyro_x = ' + str(orig_gyro_x) + ' tmp = ' + str(tmp) + ' tmp_rem = ' + str(tmp_rem) + ' tmp_frac = ' + str(tmp_frac) + ' gyro_x = ' + str(gyro_x)
