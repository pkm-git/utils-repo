# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

from PyQt4 import QtCore, QtGui
# from PyQt4.QtCore import *
# from PyQt4.QtGui import *

TYPE_STREAM_BUTTON = 1
TYPE_RECORD_BUTTON = 2
TYPE_STOP_STREAM_BUTTON = 3

class comp_port_data_struct:
   def __init__(self):
      self.ComPort = None
      self.port_name = ''
      self.port_baud = 0
      self.model_name = ''
      self.serial_nbr = ''
      self.fw_version = 0
      self.model_nbr = ''
      self.options = ''
      self.port_nbr = ''
      self.filter_status = 'Idle'
      self.recording_state = 0  # (0: Off, 1: On, and -1: Pause)
      self.waiting_to_rec = False
      self.streaming_on = False
      self.logging_thread = None
      self.bin_filename = ''
      self.previous_saved_bin_filename = ''
      self.overwrite_bin_file = False
      self.fout_bin = None
      self.is_header = False
      self.cnt_stream_click = 0
      
   def toString(self):
      return '{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}'.format(self.model_name.strip(), self.serial_nbr.strip(), str(self.fw_version), self.model_nbr.strip(), self.options.strip(), self.port_nbr.strip(), self.filter_status)

class Noise_Data_Struct:
   def __init__(self, device = 'GX5-45'):
   
      if (device == 'GX5-45'):
         self.mag_noise = '0.1' # Value for GX5-45
         self.grav_noise = '0.1'
         
         self.accel_noise_x = '0.1'
         self.accel_noise_y = '0.1'
         self.accel_noise_z = '0.1'
         
         self.accel_bias_beta_x = '0.0'
         self.accel_bias_beta_y = '0.0'
         self.accel_bias_beta_z = '0.0'
         
         self.accel_bias_noise_x = '0.00001'
         self.accel_bias_noise_y = '0.00001'
         self.accel_bias_noise_z = '0.00001'

         self.gyro_noise_x = '0.000128'
         self.gyro_noise_y = '0.000128'
         self.gyro_noise_z = '0.000128'
 
         self.gyro_bias_beta_x = '0.0'
         self.gyro_bias_beta_y = '0.0'
         self.gyro_bias_beta_z = '0.0'
         
         self.gyro_bias_noise_x = '0.00001'
         self.gyro_bias_noise_y = '0.00001'
         self.gyro_bias_noise_z = '0.00001'

         self.hard_iron_noise_x = '0.0001'
         self.hard_iron_noise_y = '0.0001'
         self.hard_iron_noise_z = '0.0001'
         
         self.soft_iron_matrix_noise1_x = '0.0001'
         self.soft_iron_matrix_noise1_y = '0.0001'
         self.soft_iron_matrix_noise1_z = '0.0001'

         self.soft_iron_matrix_noise2_x = '0.0001'
         self.soft_iron_matrix_noise2_y = '0.0001'
         self.soft_iron_matrix_noise2_z = '0.0001'

         self.soft_iron_matrix_noise3_x = '0.0001'
         self.soft_iron_matrix_noise3_y = '0.0001'
         self.soft_iron_matrix_noise3_z = '0.0001'
 
      else: # GX5-25
      
         self.mag_noise = '0.1' # Value for GX5-25
         self.grav_noise = '0.1'
         
         self.accel_noise_x = '0.1'
         self.accel_noise_y = '0.1'
         self.accel_noise_z = '0.1'
         
         self.gyro_noise_x = '0.000128'
         self.gyro_noise_y = '0.000128'
         self.gyro_noise_z = '0.000128'
         
         self.gyro_bias_beta_x = '0.0'
         self.gyro_bias_beta_y = '0.0'
         self.gyro_bias_beta_z = '0.0'
         
         self.gyro_bias_noise_x = '0.00001'
         self.gyro_bias_noise_y = '0.00001'
         self.gyro_bias_noise_z = '0.00001'

         self.hard_iron_noise_x = '0.0001'
         self.hard_iron_noise_y = '0.0001'
         self.hard_iron_noise_z = '0.0001'
         
         self.soft_iron_matrix_noise1_x = '0.0001'
         self.soft_iron_matrix_noise1_y = '0.0001'
         self.soft_iron_matrix_noise1_z = '0.0001'

         self.soft_iron_matrix_noise2_x = '0.0001'
         self.soft_iron_matrix_noise2_y = '0.0001'
         self.soft_iron_matrix_noise2_z = '0.0001'

         self.soft_iron_matrix_noise3_x = '0.0001'
         self.soft_iron_matrix_noise3_y = '0.0001'
         self.soft_iron_matrix_noise3_z = '0.0001'
      # } if (device == 'GX5-45')..

class MyLineEdit(QtGui.QLineEdit):

   def __init__(self):
      super(MyLineEdit, self).__init__()

# ---------------------------------------------------
class MyCheckBox(QtGui.QCheckBox):

   def __init__(self, lbl):
      super(MyCheckBox, self).__init__(lbl)

      self.initUI()

   def initUI(self):
      self.toggle()

# ---------------------------------------------------
class MyComboBox(QtGui.QComboBox):

   def __init__(self, type, device_name = 'GX5-45', lord_internal = False):
      super(MyComboBox, self).__init__()
      
      self.device_name = device_name
      self.type = type
      self.lord_internal = lord_internal
      self.initUI(type)

   def initUI(self, type):
      if (type == 'Device'):
         self.addItem("MIP")
         self.addItem("Novatel")
         if (self.lord_internal):
            self.addItem("SBG")
         # } if (lord_internal)..
 
      elif (type == 'NRTSIM Device'):
         self.addItem("GX5-45")
         self.addItem("GX5-25")
      
      elif (type == 'NRTSIM FW Version'):
         self.addItem("fw1165")

      elif (type == 'Unbounded Yaw'):
         self.addItem("Unbounded")
         self.addItem("360_Bounded")
         self.addItem("Orig in Deg")
         self.addItem("Orig Log")
    
      elif (type == 'Pitch/Roll Aid'):
         self.addItem("None")
         self.addItem("Gravity Vector")

         index = self.findText('Gravity Vector', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..

      elif (type == 'Gravity Adaptive'):
         self.addItem("Disabled")
         self.addItem("Auto-Adaptive")

         index = self.findText('Auto-Adaptive', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..

      elif (type == 'Mag Adaptive'):
         self.addItem("Disabled")
         self.addItem("Auto-Adaptive")

         index = self.findText('Auto-Adaptive', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..

      elif (type == 'Heading Aid'):
         self.addItem("None")
         self.addItem("Magnetometer")
         self.addItem("GNSS Velocity Vector")
         self.addItem("External Heading Msgs")
         self.addItem("Internal GNSS Vel Vector and Mag")
         self.addItem("Internal GNSS Vel Vector and Ext Heading Msgs")
         self.addItem("Internal Mag and Ext Heading Msgs")
         self.addItem("Internal GNSS Vel Vector and Mag and Ext Heading Msgs")
 
         index = self.findText('Magnetometer', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..
 
      elif (type == 'GNSS Source'):
         self.addItem("Internal GNSS")
         self.addItem("External GNSS")

         index = self.findText('Internal GNSS', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..

      elif (type == 'Altitude Aid'):
         self.addItem("None")
         self.addItem("Pressure Altimeter")

         index = self.findText('Pressure Altimeter', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..
      
      elif (type == 'Vehicle Dyn Mode'):
         self.addItem("Portable")
         self.addItem("Automotive")
         self.addItem("Airborne")
         self.addItem("Airborne (High G)")
 
         if (self.device_name == 'GX5-45'):
            index = self.findText('Automotive', QtCore.Qt.MatchFixedString)
         else:   
            index = self.findText('Portable', QtCore.Qt.MatchFixedString)
         # } if (self.device_name == 'GX5-45')..
 
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..
      
      elif (type == 'Lord Internal'):
         self.addItem("Binary")
         self.addItem("CSV")
         self.addItem("VectorNav ASCII")
         self.addItem("VectorNav TSV")

      else:
         self.addItem("Binary")
         self.addItem("CSV")

      self.move(50, 50)

# ---------------------------------------------------
class MyPushButton(QtGui.QPushButton):

   def __init__(self):
      super(MyPushButton, self).__init__()
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px;");

   def __init__(self, label):
      super(MyPushButton, self).__init__(label)
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px;");
   
   def enterEvent(self, e):
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #F3DD93; border: 1px solid #330019; padding: 3px;");
      
   def leaveEvent(self, e):
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px;");

# ---------------------------------------------------
class MyStreamRecordPushButton(MyPushButton):

   def __init__(self):
      super(MyStreamRecordPushButton, self).__init__()
      self.off_state_default_icon = None
      self.on_state_default_icon = None
      self.off_state_hover_icon = None
      self.on_state_hover_icon = None
      self.state = 0
      self.hover_state = 0
      self.enable_border = False
      self.enable_waiting_to_record = False
      self.type = 0
      print('***** MyStreamRecordPushButton init: will set fixed size *****')
      self.setFixedSize(50,50)
      
   def __init__(self, label):
      super(MyStreamRecordPushButton, self).__init__(label)

      self.off_state_icon = None
      self.on_state_icon = None
      self.off_state_hover_icon = None
      self.on_state_hover_icon = None
      self.state = 0
      self.hover_state = 0
      self.enable_border = False
      self.enable_waiting_to_record = False
      self.type = 0
      
   def set_off_state_icon(self, off_state_icon):
      self.off_state_icon = off_state_icon
      self.setIcon(off_state_icon)

   def set_on_state_icon(self, on_state_icon):
      self.on_state_icon = on_state_icon

   def set_off_state_hover_icon(self, off_state_hover_icon):
      self.off_state_hover_icon = off_state_hover_icon

   def set_on_state_hover_icon(self, on_state_hover_icon):
      self.on_state_hover_icon = on_state_hover_icon
   
   def getState(self):
      return self.state

   def setState(self, state):
      self.state = state
   
   def getType(self):
      return self.type
      
   def setType(self, type):
      self.type = type

   def enterEvent(self, e):
      if (self.enable_border):
         if (self.enable_waiting_to_record): # dull yellow (hover state)     # bright green
            self.setStyleSheet("background-color: #F3DD93; border: 2px solid #008000;border-radius:6px;padding:12px;margin:0px;");
         else:                 # dull yellow (hover state)     # red
            self.setStyleSheet("background-color: #F3DD93; border: 2px solid red;border-radius:6px;padding:12px;margin:0px;");
         # } if (enable_waiting_to_record)..
      else:               # dull yellow (hover state)                     # dark violet
         self.setStyleSheet("background-color: #F3DD93; border: 1px solid #330019;border-radius:6px;padding:6px;margin:0px;");
      # } if (not self.enable_border)..
      
      self.hover_state = 1
      self.switchIcon()
      
   def leaveEvent(self, e):
      if (self.enable_border):
         if (self.enable_waiting_to_record): # dull violet (off, default state) # bright green
            self.setStyleSheet("background-color: #CFC3F0; border: 2px solid #008000;border-radius:6px;padding:12px;margin:0px;");
         else:                 # dull orange                               # red
            self.setStyleSheet("background-color: #FFCC99; border: 2px solid red;border-radius:6px;padding:12px;margin:0px;");
         # } if (enable_waiting_to_record)..
      else:               # dull violet (off, default state)          # dark violet
         self.setStyleSheet("background-color: #CFC3F0; border: 1px solid #330019;border-radius:6px;padding:6px;margin:0px;");
      # } if (not self.enable_border)..
      
      self.hover_state = 0
      self.switchIcon()
      
   def enableBorder(self, enable):
      self.enable_border = enable
      
      if (enable):           
         if (self.enable_waiting_to_record):
            if (self.hover_state == 1): # dull yellow (hover state)       # bright green
               self.setStyleSheet("background-color: #F3DD93; border: 2px solid #008000;border-radius:6px;padding:12px;margin:0px;");
            else:                       # dull violet (off, default state)  # bright green
               self.setStyleSheet("background-color: #CFC3F0; border: 2px solid #008000;border-radius:6px;padding:12px;margin:0px;");
            # } if (self.hover_state == 1)..
         else:                                     
            if (self.hover_state == 1): # dull yellow (hover state)           # red
               self.setStyleSheet("background-color: #F3DD93; border: 2px solid red;border-radius:6px;padding:12px;margin:0px;");
            else:                       # dull orange                         # red
               self.setStyleSheet("background-color: #FFCC99; border: 2px solid red;border-radius:6px;padding:12px;margin:0px;");
            # } if (self.hover_state == 1)..   
         # } if (self.enable_waiting_to_record)..   
      else:                 # dull violet (off, default state)           # dark violet
         self.setStyleSheet("background-color: #CFC3F0; border: 1px solid #330019;border-radius:6px;padding:6px;margin:0px");
      # } if (enable)..

   def enableWaitingToRecord(self, enable_waiting_to_record):
      self.enable_waiting_to_record = enable_waiting_to_record
      
   def switchIcon(self):
      if (self.state <= 0):
         if (self.hover_state == 1):
            self.setIcon(self.off_state_hover_icon)
         else:
            self.setIcon(self.off_state_icon)
         # } if (self.hover_state == 1)..
      else:
         if (self.hover_state == 1):
            self.setIcon(self.on_state_hover_icon)
         else:
            self.setIcon(self.on_state_icon)
         # } if (self.enable_border)..   
      # } if (self.state <= 0)..

class MyListWidgetItem(QtGui.QListWidgetItem):

   def __init__(self, str, port_obj = None):
      super(MyListWidgetItem, self).__init__(str)
      self.port_obj = port_obj
      self.currentForegroundBrush = QtGui.QBrush()
      self.currentForegroundBrush.setColor(QtCore.Qt.white)
      self.origForegroundBrush = QtGui.QBrush()
      self.origForegroundBrush.setColor(QtCore.Qt.blue)
      
   def enterEvent(self, e):
      d.setBackgroundColor(QtGui.QColor("#A87831"))
      d.setForeground(self.currentForegroundBrush)
      
   def leaveEvent(self, e):
      d.setBackgroundColor(QtGui.QColor("#F2EBE3"))
      d.setForeground(self.origForegroundBrush)

class MyListModel(QtCore.QAbstractListModel): 
   def __init__(self, datain, parent=None, *args): 
      """ datain: a list where each item is a row
      """
      QtCore.QAbstractListModel.__init__(self, parent, *args) 
      self.listdata = datain

   def rowCount(self, parent=QtCore.QModelIndex()): 
      return len(self.listdata) 

   def data(self, index, role): 
      if index.isValid() and role == QtCore.Qt.DisplayRole:
          return QtCore.QVariant(self.listdata[index.row()])
      else: 
          return QtCore.QVariant()
      # } if index.isValid()..
       
class MyTabWidget(QtGui.QTabWidget):

   def __init__(self, indx):
      super(MyTabWidget, self).__init__()
      # self.init_widget = None
      self.spl_widget_indx = indx
      self.replace_mode = False
      self.new_widget = None

   def widget(self, indx):
      print('******* in MyTabWidget: widget: indx = ' + str(indx))

      if (indx == self.spl_widget_indx):
         print('******* in MyTabWidget: indx is equal to self.spl_widget_indx')
         if (self.replace_mode):
            print('******* in MyTabWidget: self.replace_mode is TRUE')
            return self.new_widget
         else:
            print('******* in MyTabWidget: self.replace_mode is FALSE')
            return super(MyTabWidget, self).widget(indx)
         # } if (self.replace_mode)..   
      else:
         print('******* in MyTabWidget: indx is NOT equal to self.spl_widget_indx')
         return super(MyTabWidget, self).widget(indx)
      # } if (indx == self.spl_widget_indx)..
      
   def replaceTabWidget(self, widget):
      self.replace_mode = True
      self.new_widget = widget

class MyTabWidget_bad(QtGui.QTabWidget):

   # def setTabsClosable (self, bool closeable):
      # super(MyTabWidget, self).setTabsClosable(closeable)
      # self.tabBar.tabButton()

   def __init__(self):
      super(MyTabWidget, self).__init__()
      self.tabCloseRequested.connect(self.closeTab)
      self.cnt = 0

   # def addTab(self, QtGui.QWidget widget, QtCore.QString label):
   def addTab(self, widget, label):
      super(MyTabWidget, self).addTab(widget, label)
      self.cnt += 1

      if (self.tabsClosable):
         print(' ************** in addTab, tabsClosable is True, self.currentIndex() = ' + str(self.currentIndex()) + ', self.count() = ' + str(self.count()) + ' self.cnt = ' + str(self.cnt))
         # indx = self.count() - 1
         indx = self.cnt - 1
         if (indx < 2):
            self.tabBar().setTabButton(indx, QtGui.QTabBar.RightSide, None)
         else:
            closeButton = QtGui.QPushButton()
            closeButton.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon.png")))
            # closeButton.clicked.connect(lambda:self.whichbtn(closeButton))
            closeButton.setFixedWidth(15)
            closeButton.setFixedHeight(15)

            # self.tabBar().setTabText(tabIndex,"CSV Data")
            self.tabBar().setTabButton(indx, QtGui.QTabBar.RightSide, closeButton)

   def closeTab(self, i):
      if (i > 1):
         self.removeTab(i)

   def removeTab(self, index):
      super(MyTabWidget, self).removeTab(index)
      self.cnt -= 1

   def insertTab(self, index, widget, label):
      super(MyTabWidget, self).insertTab(index, widget, label)
      self.cnt += 1
