from inspect import getargspec
from ring_buffer import RingBuffer
from mip import *
from time import time

#initialization values
MIP_PARSER_UNINITIALIZED               = 0
MIP_PARSER_INITIALIZED                 = 1

#function return state variables
MIP_PARSER_OK                          = 0
MIP_PARSER_ERROR                       = 1

#callback type values
MIP_PARSER_CALLBACK_VALID_PACKET       = 0
MIP_PARSER_CALLBACK_CHECKSUM_ERROR     = 1
MIP_PARSER_CALLBACK_TIMEOUT            = 2

#number required arguments for calback function
MIP_PARSER_NUM_CALLBACK_ARGS           = 3

def generic_callback(callback_owner, packet_bytes, callback_type):
   """Some Information Here"""
   if (callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
      print("Valid Packet Found")
   elif (callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
      print("Packet Timeout Callback")
   elif (callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
      print("Bad Checksum Found")
   else:
      print("Unrecognized Callback Type")
   # } if (callback_type ==..

class MipParser:
   """Class to parse MIP packets"""
   # Default 'constructor'
   def __init__(self, packet_timeout_value_ms = None, object_to_callback = 0, packet_callback = 0):
      """Class default initialization function"""
      try:
         self.init(packet_timeout_value_ms, object_to_callback, packet_callback)
      except:
         self.state = MIP_PARSER_UNINITIALIZED
      # } try..
      
   # Class initializer function
   def init(self, packet_timeout_value_ms, object_to_callback = 0, packet_callback = 0):
      """Class initialization function"""

      # Set Callback Parameters
      self.callback                    = packet_callback
      self.callback_object             = object_to_callback

      # Set member initial values
      # self.input_buffer              = RingBuffer(200*MIP_MAX_PACKET_SIZE)
      self.input_buffer                = []     
      self.mip_packet                  = bytearray()
      self.parser_start_time           = 0
      self.parser_num_bad_checksums    = 0
      self.parser_timeouts             = 0
      self.parser_in_sync              = 0
      self.parser_headers_skipped      = 0
      self.packet_timeout              = packet_timeout_value_ms/1000.0
      self.state                       = MIP_PARSER_INITIALIZED
      self.streaming_enabled           = 0
      return MIP_PARSER_OK

   def num_buffer_remaining_entries(self):
      """Function reports remaining number of bytes in the parser"""
      if (self.state != MIP_PARSER_INITIALIZED):
         return MIP_PARSER_ERROR
      # } if (self.state != MIP_PARSER_INITIALIZED)..
         
      return len(self.input_buffer)

   def num_pkm_entries(self):
      """Function reports remaining number of bytes in the parser"""
      return 8

   def get_streaming_enabled(self):
      return self.streaming_enabled

   def set_streaming_enabled(self, streaming_enabled_in):
      self.streaming_enabled = streaming_enabled_in

   # Write bytes to the packet buffer for parsing
   def write(self, data_packet):
      """Function loads bytes to the packet parser input buffer"""
      if (self.state != MIP_PARSER_INITIALIZED):
         return MIP_PARSER_ERROR
      # } if (self.state != MIP_PARSER_INITIALIZED)..
         
      for byte in data_packet:
         self.input_buffer.append(byte)
      # } for byte in data_packet..
      
      return MIP_PARSER_OK

   # Parse input buffer
   def parse_input_buffer(self):
      """Parser tries to construct packet from bytes previously written into the input buffer"""
      # Check to see parser was initialized
      if (self.state != MIP_PARSER_INITIALIZED):
         return MIP_PARSER_ERROR

      # Make sure there are bytes in the buffer
      if (len(self.input_buffer)==0):
         return MIP_PARSER_ERROR
      
      if (0):
         if (len(self.mip_packet) < MIP_HEADER_SIZE):
            # Search for the first byte if we haven't found any bytes yet
            if (len(self.mip_packet)==0):
               # If we don't find the first sync byte, throw stuff away until we find
               # it, because we don't have anything else from the packet that that stuff was
               # a part of.
               while (self.input_buffer[MIP_HEADER_SYNC1_BYTE_INDEX] != MIP_SYNC_BYTE1):
                  self.input_buffer.read();
                  # If we didn't find a start byte after searching all bytes return.
                  # This isn't a error condition necessarily, just we missed the beginning
                  # of the packet
                  if (len(self.input_buffer)==0):
                     return MIP_PARSER_OK
                  # } if (len(self.input_buffer)==0)..
                  
               # Take the byte from the input buffer and place it onto the new mip packet
               self.mip_packet.append(self.input_buffer.read());

               # Packet is considered to have started now
               self.parser_start_time = time()
            elif (len(self.mip_packet)>0):
               # Try and find the rest of the header
               if (len(self.input_buffer) >= (MIP_HEADER_SIZE - 1)):
                  self.mip_packet.extend(self.input_buffer.tolist()[0:(MIP_HEADER_SIZE - 1)])

                  # Is this header valid?
                  if (not((self.mip_packet[MIP_HEADER_SYNC2_BYTE_INDEX] == MIP_SYNC_BYTE2) and ((self.mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX] + MIP_HEADER_SIZE + MIP_CHECKSUM_SIZE) <= (MIP_MAX_PACKET_SIZE)))):
                     self.mip_packet = bytearray()
                     self.parser_in_sync = 0
                     self.parser_headers_skipped += 1
                  # } if (not((self.mip_packet[MIP_HEADER_SYNC2_BYTE_INDEX]..
                
               # Test for timeout condition or comeback later
               else:
                  if ((time()-self.parser_start_time) > self.packet_timeout):
                     self.mip_packet = bytearray()
                     self.parser_in_sync = 0
                     self.parser_timeouts += 1
                  # } if ((time()-self.parser_start_time)..
               # } if (len(self.input_buffer) >=..
            # } if (len(self.mip_packet)==0)..
         # } if (len(self.mip_packet)<MIP_HEADER_SIZE)..
         
         # else:
	 
      # If the header has been found, look at rest of the packet
      # if (len(self.mip_packet) >= MIP_HEADER_SIZE):
      
      if (len(self.input_buffer) >= (MIP_HEADER_SIZE - 1 + self.mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX] + MIP_CHECKSUM_SIZE)):
         # Get the rest of the bytes for the packet
         self.mip_packet.extend(self.input_buffer.tolist()[(MIP_HEADER_SIZE - 1):(MIP_HEADER_SIZE + self.mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX] + MIP_CHECKSUM_SIZE -1)])

         # Check the checksum on this packet
         if (mip_is_checksum_valid(self.mip_packet)):
            self.parser_in_sync = 1
            self.callback(packet_bytes = self.mip_packet, callback_type = MIP_PARSER_CALLBACK_VALID_PACKET)
            self.input_buffer.consume(len(self.mip_packet)-1)
         else:
            self.callback(packet_bytes = self.mip_packet, callback_type = MIP_PARSER_CALLBACK_CHECKSUM_ERROR)
            if (self.parser_in_sync):
               self.parser_num_bad_checksums += 1
            # } if (self.parser_in_sync)..   
            self.parser_in_sync = 0
         # } if (mip_is_checksum_valid(self.mip_packet))..
         
         self.mip_packet=bytearray()
      # Test for timeout condition
      else:
         # Test for timeout
         if ((time()-self.parser_start_time) > self.packet_timeout):
            self.callback(packet_bytes = self.mip_packet, callback_type = MIP_PARSER_CALLBACK_TIMEOUT)
            self.mip_packet = bytearray()
            self.parser_in_sync = 0
            self.parser_timeouts += 1
            self.parser_start_time = 0
         # } if ((time()-self.parser_start_time).. 
      # } if (len(self.input_buffer) >= ..
      
      # } if (len(self.mip_packet) >=..    
      
      return MIP_PARSER_OK

