# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui

from QInertialSensorUtils_GUI_CommonWidgets import *
from QInertialSensorUtils_GUI_DeviceConnectFormWidget import *
from QInertialSensorUtils_GUI_MIP_Utils import *

from time import sleep         #sleep

from stream_record_binary_log import *

BAUD_RATE = 12000000

class MyDeviceConnectTopWidget(QtGui.QMainWindow):

   def __init__(self, parent):
      super(MyDeviceConnectTopWidget, self).__init__(parent)
      self.parent_obj = parent
      
      # self.tabs = QtGui.QTabWidget()
      
      self.device_connect_form_widget = MyDeviceConnectFormWidget(self)
      # # self.device_connect_form_widget.setStyleSheet("background-color: #ACCCFA;");
      # self.device_connect_form_widget.setStyleSheet("background-color: #F2D5B0;");
      # self.device_connect_form_widget.setStyleSheet("background-color: white");
      self.device_connect_form_widget.setStyleSheet("background-color: #F2EBE3;");
      
      self.declare_spaces()
      self.__controls()
      
      central_widget = QtGui.QWidget()
      
      central_layout = QtGui.QVBoxLayout()
      central_layout.addWidget(self.device_connect_form_widget)
      central_layout.addWidget(self.h5BoxWidget)
      
      central_widget.setLayout(central_layout)
      
      self.setCentralWidget(central_widget)
      
      # self.tabs.setStyleSheet("background-color: #ACCCFA;");
      # self.tabs.blockSignals(False) #now listen the currentChanged signal
      
      if (self.parent_obj.sensor_cloud_enabled):
         self.setFixedSize(610,275)
      else:
         # self.setFixedSize(550,250)
         self.setFixedSize(600,225)
      # } if (self.parent_obj.sensor_cloud_enabled)..
   
   def closeEvent(self, event):
      print "Closing MyDeviceConnectTopWidget window"

      self.logFile.close()

      super(MyDeviceConnectTopWidget, self).closeEvent(event)
   
   def __controls(self):

      self.stream_icon = QtGui.QIcon()
      self.stream_icon.addPixmap(QtGui.QPixmap("icon_stream.png"))

      self.stream_hover_icon = QtGui.QIcon()
      self.stream_hover_icon.addPixmap(QtGui.QPixmap("icon_stream_hover.png"))
      
      self.record_icon = QtGui.QIcon()
      self.record_icon.addPixmap(QtGui.QPixmap("icon_record.png"))

      self.record_hover_icon = QtGui.QIcon()
      self.record_hover_icon.addPixmap(QtGui.QPixmap("icon_record_hover.png"))

      self.stop_icon = QtGui.QIcon()
      self.stop_icon.addPixmap(QtGui.QPixmap("icon_stop.png"))

      self.stop_hover_icon = QtGui.QIcon()
      self.stop_hover_icon.addPixmap(QtGui.QPixmap("icon_stop_hover.png"))

      self.refresh_icon = QtGui.QIcon()
      self.refresh_icon.addPixmap(QtGui.QPixmap("icon_refresh.png"))

      self.refresh_hover_icon = QtGui.QIcon()
      self.refresh_hover_icon.addPixmap(QtGui.QPixmap("icon_refresh_hover.png"))

      # self.settings_icon = QtGui.QIcon()
      # self.settings_icon.addPixmap(QtGui.QPixmap("icon_settings.png"))
      
      self.start_stop_streaming_button = MyStreamRecordPushButton(self)
      
      self.start_stop_streaming_button.set_off_state_icon(self.stream_icon)
      self.start_stop_streaming_button.set_on_state_icon(self.stop_icon)
      self.start_stop_streaming_button.set_off_state_hover_icon(self.stream_hover_icon)
      self.start_stop_streaming_button.set_on_state_hover_icon(self.stop_hover_icon)

      self.start_stop_streaming_button.setCheckable(True)
      self.start_stop_streaming_button.toggle()
      self.start_stop_streaming_button.clicked.connect(lambda:self.validate(self.start_stop_streaming_button))
      self.start_stop_streaming_button.setFixedWidth(30)
      # self.start_stop_streaming_button.setCode(self.CODE_STREAM)
      self.start_stop_streaming_button.setState(0)
      self.start_stop_streaming_button.setType(TYPE_STREAM_BUTTON)
      
      # self.settings_button = MyPushButton(self)
      # self.settings_button.setCheckable(True)
      # self.settings_button.toggle()
      # self.settings_button.clicked.connect(lambda:self.validate(self.settings_button))
      # self.settings_button.setFixedWidth(30)
      # self.settings_button.setIcon(self.settings_icon)

      self.refresh_button = MyStreamRecordPushButton(self)
      self.refresh_button.setCheckable(True)
      self.refresh_button.toggle()
      self.refresh_button.clicked.connect(self.parent_obj.refreshDeviceList)
      self.refresh_button.setFixedWidth(30)
      self.refresh_button.set_off_state_icon(self.refresh_icon)
      self.refresh_button.set_off_state_hover_icon(self.refresh_hover_icon)
      
      self.start_stop_recording_button = MyStreamRecordPushButton(self)
      self.start_stop_recording_button.set_off_state_icon(self.record_icon)
      self.start_stop_recording_button.set_on_state_icon(self.stop_icon)
      self.start_stop_recording_button.set_off_state_hover_icon(self.record_hover_icon)
      self.start_stop_recording_button.set_on_state_hover_icon(self.stop_hover_icon)

      self.start_stop_recording_button.setCheckable(True)
      self.start_stop_recording_button.toggle()
      self.start_stop_recording_button.clicked.connect(lambda:self.validate(self.start_stop_recording_button))
      self.start_stop_recording_button.setFixedWidth(30)
      # self.start_stop_recording_button.setCode(self.CODE_RECORD)
      self.start_stop_recording_button.setState(0)
      self.start_stop_recording_button.setType(TYPE_RECORD_BUTTON)
      
      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(450)
      self.lbl_status.setFixedHeight(25)
      
      self.browse_button = MyPushButton("Browse")
      self.browse_button.setCheckable(True)
      self.browse_button.toggle()
      self.browse_button.clicked.connect(self.selectFile)
      self.browse_button.setFixedWidth(75)

      self.lbl_filename = QtGui.QLabel("Binary Filename:")
      self.lbl_filename.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_filename = MyLineEdit()
      self.edt_filename.setStyleSheet("background-color: white;");
      self.edt_filename.setFixedWidth(250)

      self.h5box = QtGui.QHBoxLayout()
      self.h5box.addWidget(self.start_stop_streaming_button)
      self.h5box.addWidget(self.edt_filename)
      self.h5box.addWidget(self.browse_button)
      self.h5box.addWidget(self.start_stop_recording_button)
      # self.h5box.addWidget(self.settings_button)
      self.h5box.addWidget(self.refresh_button)
      
      self.h5BoxWidget = QtGui.QWidget()
      self.h5BoxWidget.setLayout(self.h5box)
      self.h5BoxWidget.setFixedSize(550,40)

      # self.h6box = QtGui.QHBoxLayout()
      
      # self.h6BoxWidget = QtGui.QWidget()
      # self.h6BoxWidget.setLayout(self.h6box)
      # self.h6BoxWidget.setFixedSize(550,40)
      
   def clearStatusText(self):
      self.lbl_status.setText("Status:")
   
   def selectFile(self):
   
      theInputDir = ""

      user_config = os.getcwd() + "/inertial_sensor.cfg"

      config = ConfigParser.ConfigParser()
      config.read(user_config)

      if config.has_section("dirs"):
         # if an entry exists then add the value to the form
         if config.has_option("dirs", "inputdir"):
            theInputDir = config.get("dirs", "inputdir")
         # } if config.has_option("dirs", "inputdir")..
      # } if config.has_section("dirs")..

      self.model_name = ''
      self.serial_nbr = ''
      self.fw_version = ''
      self.model_nbr = ''
      self.options = ''
      self.port_name = ''
      
      default_filename = ''
      
      selected_device = self.device_connect_form_widget.deviceList.currentItem()
      if (selected_device != None and selected_device.port_obj != None):
         default_filename = get_filename(selected_device.port_obj.model_name.strip(), selected_device.port_obj.serial_nbr.strip())
      # } if (selected_device != None and..
          
      filename = QtGui.QFileDialog.getSaveFileName(self, 'Save File', theInputDir + '/' + default_filename, '*.bin')
      
      if filename:
         self.edt_filename.setText(filename)

         (inputDirName, fin_filename) = os.path.split(str(filename))

         if not config.has_section("dirs"):
            config.add_section("dirs")
         # } if not config.has_section("dirs")..

         config.set("dirs", "inputdir", inputDirName)

         # if not os.getcwd().exists(configFile):
         with open("inertial_sensor.cfg", 'w') as f:
            config.write(f)
         # } with open("inertial_sensor.cfg"..
      # } if filename..
   
   def validate(self, b):
      print(' ********* IN VALIDATE ************ ')
      
      selected_device = self.device_connect_form_widget.deviceList.currentItem()

      if (selected_device == None):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select a device')
         return
      # } if (selected_device == None)..
      
      selected_com_port = ''
      str_array = selected_device.text().split('\t')
    
      print(' ***** len(str_array) = ' + str(len(str_array)))
      cnt = 0
      for s in str_array:
         cnt += 1
         print(' ***** s = ' + str(s))
 
         if (cnt == len(str_array)-1):
            selected_com_port = 'COM' + s
         # } if (cnt == len(str_array)-1)..
      # } for s in str_array..
      
      print(' **** selected_com_port = ' + str(selected_com_port))
      
      if (b == self.start_stop_streaming_button):
         
         if (b.getState() == 0):
            print(' ****** WILL START STREAM ******* ')
            selected_device.port_obj.streaming_on = True
    
            self.edt_filename.setReadOnly(True)
    
            b.setState(1)
    
            # Start a background thread that streams the device output
            stream_record_binary_log_fn(selected_device.port_obj)
    
            # If the user specified a log file name, the record button would be in 'Waiting to Record' mode.
            # In that case, start recording as soon as user hits the Streaming button
            if (self.start_stop_recording_button.getState() == -1):
               self.start_stop_recording_button.setState(1)
               selected_device.port_obj.recording_on = True
               self.start_stop_recording_button.switchIcon()
               # selected_device.port_obj.bin_filename = self.edt_filename.text()
               self.edt_filename.setReadOnly(True)
               selected_device.port_obj.logging_thread.setLogFile()
               selected_device.port_obj.waiting_to_rec = False
            # } if (self.start_stop_recording_button.getState() == -1)..
         else:
            print(' ****** WILL STOP STREAM  ******* ')
            selected_device.port_obj.streaming_on = False
            selected_device.port_obj.recording_on = False
    
            b.setState(0)
    
            self.start_stop_recording_button.setState(0)
            self.start_stop_recording_button.switchIcon()
    
            self.edt_filename.setReadOnly(False)
    
         # } if (b.text() == "Start Streaming")..
 
         self.device_connect_form_widget.updateStreamStatus(selected_device, b, self.start_stop_recording_button)
      elif (b == self.start_stop_recording_button):   
         if (self.edt_filename.text() == ''):
            QtGui.QMessageBox.about(self, "Msg Box", 'Must specify binary filename to start recording')
            return
         # } if (self.edt_filename.text() == '')..

         if (b.getState() == 0):
            print(' ****** WILL START RECORD ******* ')
    
            # Start recording only if streaming button is in ON position
            if (self.start_stop_streaming_button.getState()):
               b.setState(1)
               selected_device.port_obj.waiting_to_rec = False
               selected_device.port_obj.recording_on = True
               self.edt_filename.setReadOnly(True)
               selected_device.port_obj.logging_thread.setLogFile()
            else: # set recording button to 'waiting to record' state (-1)
               b.setState(-1)
               selected_device.port_obj.waiting_to_rec = True
            # } if (self.start_stop_streaming_button...
    
            selected_device.port_obj.bin_filename = self.edt_filename.text()
         else:
            print(' ****** WILL STOP RECORD ******* ')
            selected_device.port_obj.recording_on = False
    
            self.edt_filename.setReadOnly(False)
    
            b.setState(0)
         # } if (b.text() == "Start Recording")..
 
         self.device_connect_form_widget.updateStreamStatus(selected_device, b, self.start_stop_streaming_button)
      # else:
         # print('****** IT IS A SETTINGS BUTTON ******* ')
         # QtGui.QMessageBox.about(self, "Msg Box", 'Settings button')
      # } if (selected_device == None)..
      
      b.switchIcon()

      return

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(60)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(90)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(110)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.lbl_space_resizable_filler = QtGui.QLabel()
      self.lbl_space_resizable_filler.setFixedWidth(65)
      self.lbl_space_resizable_filler.setFixedHeight(25)

      self.lbl_space_resizable_filler2 = QtGui.QLabel()
      self.lbl_space_resizable_filler2.setFixedWidth(15)
      self.lbl_space_resizable_filler2.setFixedHeight(25)

      self.lbl_space_resizable_filler3 = QtGui.QLabel()
      self.lbl_space_resizable_filler3.setFixedWidth(65)
      self.lbl_space_resizable_filler3.setFixedHeight(5)

# ---------------------------------------------------

