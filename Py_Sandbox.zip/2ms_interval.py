2MS_INTERVAL_UNINITIALIZED               = 0

class 2ms_Interval(object):

 #default 'constructor'
 def __init__(self):
  """Class default initialization function"""
  try:
   self.init()
  except:
   self.state = 2MS_INTERVAL_UNINITIALIZED

 #class initializer function
 def init(self):
   """Class initialization function"""
   self.begin = 0
   self.end = 0

 def set_begin(self):
     self.begin = 1
     self.end = 0

 def set_end(self):
     self.end = 1
     self.begin = 0

 def get_begin(self):
     return self.begin

 def get_end(self):
     return self.end
