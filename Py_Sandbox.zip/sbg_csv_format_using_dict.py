# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

SBG_FORMAT_USING_DICT_UNINITIALIZED = 0

class SBG_01_struct:  # Device Status
   def __init__(self):
      [self.time_since_powerup, self.general_status, self.resvd_status1, self.com_status,\
       self.aiding_status, self.resvd_status2, self.resvd_status3, self.up_time] = [0,0,0,0,0,0,0,0]

class SBG_02_struct: # UTC and GPS Timestamp
   def __init__(self):
      [self.time_since_powerup, self.clock_status, self.utc_year, self.utc_month, self.utc_day,\
       self.utc_hour, self.utc_min, self.utc_sec, self.utc_nanosec, self.gps_tow] = [0,0,0,0,0,0,0,0,0,0]

class SBG_03_struct: # IMU Inertial Data
   def __init__(self):
      [self.time_since_powerup, self.imu_status, self.filtered_accel_x, self.filtered_accel_y, self.filtered_accel_z,\
       self.filtered_gyro_x, self.filtered_gyro_y, self.filtered_gyro_z, self.internal_temp,\
       self.delta_vel_x, self.delta_vel_y, self.delta_vel_z,\
       self.delta_theta_x, self.delta_theta_y, self.delta_theta_z] \
       = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class SBG_04_struct: # Magnetometer
   def __init__(self):
      [self.time_since_powerup, self.mag_status, self.mag_output_x, self.mag_output_y, self.mag_output_z,\
       self.accel_output_x, self.accel_output_y, self.accel_output_z] = [0,0,0,0,0,0,0,0]

class SBG_06_struct:  # Euler Angles
   def __init__(self):
      [self.time_since_powerup, self.roll, self.pitch, self.yaw,\
       self.roll_acc, self.pitch_acc, self.yaw_acc, self.global_soln_status] = [0,0,0,0,0,0,0,0]

class SBG_07_struct:  # Quaternion
   def __init__(self):
      [self.time_since_powerup, self.q0, self.q1, self.q2, self.q3,\
       self.roll_acc, self.pitch_acc, self.yaw_acc, self.global_soln_status] = [0,0,0,0,0,0,0,0,0]

class SBG_08_struct:  # Navigation Position
   def __init__(self):
      [self.time_since_powerup, self.gps_tow, self.vel_n, self.vel_e, self.vel_d, self.vel_n_acc, self.vel_e_acc, self.vel_d_acc,\
       self.lat, self.lon, self.ht_MSL, self.undulation, self.lat_acc, self.lon_acc, self.vert_pos_acc, self.global_soln_status] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class SBG_09_struct: # Heave, Surge, Sway
   def __init__(self):
      [self.time_since_powerup, self.heave_period_in_sec, self.surge_at_main_loc, self.sway_at_main_loc,\
       self.heave_at_main_loc, self.longitudinal_accel_x, self.lateral_accel_y, self.lateral_accel_z,\
       self.longitudinal_vel_x, self.lateral_vel_y, self.lateral_vel_z,\
       self.ship_motion_output_status] = [0,0,0,0,0,0,0,0,0,0,0,0]

class SBG_13_struct:  # GNSS Velocity
   def __init__(self):
      [self.time_since_powerup, self.gps_vel_status, self.gps_tow, self.vel_n, self.vel_e, self.vel_d,\
       self.vel_acc_n, self.vel_acc_e, self.vel_acc_d, self.course_over_grnd, self.course_over_grnd_acc] = [0,0,0,0,0,0,0,0,0,0,0]

class SBG_14_struct:  # GNSS Position
   def __init__(self):
      [self.time_since_powerup, self.gps_pos_fix_and_status, self.gps_tow, self.lat, self.lon, self.alt_MSL,\
       self.undulation, self.pos_acc_lat, self.pos_acc_lon, self.pos_acc_alt, self.nbr_of_svs_used, self.base_station_id, self.diff_age] = [0,0,0,0,0,0,0,0,0,0,0,0,0]

class SBG_15_struct:  # True Heading
   def __init__(self):
      [self.time_since_powerup, self.gps_true_heading_status, self.gps_tow, self.true_heading_angle,\
       self.true_heading_acc, self.pitch_angle_master_to_rover, self.pitch_acc] = [0,0,0,0,0,0,0]

class SBG_36_struct:  # Pressure and Altimeter
   def __init__(self):
      [self.time_since_powerup, self.altimeter_status, self.pressure, self.altitude] = [0,0,0,0]

# sbg_valid_message_id_array = [1, 2, 3, 4, 6, 7, 8, 9, 13, 14, 15, 36]
# sbg_valid_message_id_array = [1, 2, 3, 4, 6, 7, 8, 14, 13, 15, 9, 31, 17, 16, 18, 32, 38, 36]
sbg_valid_message_id_array = [1, 2, 3, 4, 6, 7, 8, 14, 13, 15, 9, 17, 16, 18, 32, 36]
sbg_valid_message_id_alt_dict = {32:9, 16:13, 17:14, 18:15, 38:31}
sbg_lengths_of_message_id_dict = {1:26, 2:21, 3:58, 4:30, 6:32, 7:36, 8:72, 9:46, 13:44, 14:57, 15:26, 36:14, 32:46, 16:44, 17:57, 18:26, 36:14}

class SBG_CSV_format_using_dict(object):

 #default 'constructor'
 def __init__(self, sbg_format_dict = None):
    """Class default initialization function"""
    try:
       self.init(sbg_format_dict)
    except:
       self.state = SBG_FORMAT_USING_DICT_UNINITIALIZED

 #class initializer function
 def init(self, sbg_format_dict):
   """Class initialization function"""

   [self.sbg_01_struct, self.sbg_02_struct, self.sbg_03_struct, self.sbg_04_struct, self.sbg_06_struct, self.sbg_07_struct] = [None, None, None, None, None, None]
   [self.sbg_08_struct, self.sbg_14_struct, self.sbg_13_struct, self.sbg_15_struct, self.sbg_09_struct] = [None, None, None, None, None]
   [self.sbg_17_struct, self.sbg_16_struct, self.sbg_18_struct, self.sbg_32_struct, self.sbg_36_struct] = [None, None, None, None, None]

   if (sbg_format_dict != None):
      for k in sbg_valid_message_id_array:
         if (k in sbg_format_dict):
            if (k == 1):
               self.sbg_01_struct = sbg_format_dict[k]
            elif (k == 2):
               self.sbg_02_struct = sbg_format_dict[k]
            elif (k == 3):
               self.sbg_03_struct = sbg_format_dict[k]
            elif (k == 4):
               self.sbg_04_struct = sbg_format_dict[k]
            elif (k == 6):
               self.sbg_06_struct = sbg_format_dict[k]
            elif (k == 7):
               self.sbg_07_struct = sbg_format_dict[k]
            elif (k == 8):
               self.sbg_08_struct = sbg_format_dict[k]
            
            elif (k == 14):
               self.sbg_14_struct = sbg_format_dict[k]
            elif (k == 13):
               self.sbg_13_struct = sbg_format_dict[k]
            elif (k == 15):
               self.sbg_15_struct = sbg_format_dict[k]
            elif (k == 9):
               self.sbg_09_struct = sbg_format_dict[k]

            elif (k == 17):
               self.sbg_17_struct = sbg_format_dict[k]
            elif (k == 16):
               self.sbg_16_struct = sbg_format_dict[k]
            elif (k == 18):
               self.sbg_18_struct = sbg_format_dict[k]
            elif (k == 32):
               self.sbg_32_struct = sbg_format_dict[k]
      
            elif (k == 36):
               self.sbg_36_struct = sbg_format_dict[k]
            # } if (k == 1)..
         # } if (k in sbg_format_dict)..
      # } for k in sbg_valid_message_id_array..
   # } if (sbg_format_dict != None)..

 def format_header(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       ret_str = 'Time_Since_Powerup [01],General_Status [01],'

    elif (format_in == 1):
       ret_str = 'Time_Since_Powerup [02],Clock Status [02],UTC Year [02],UTC Month [02],UTC Day [02],UTC Hr [02],UTC Min [02],UTC Sec [02],UTC Nanosec [02],GPS TOW [02],'

    elif (format_in == 2):
       ret_str = 'Time_Since_Powerup [03],IMU Status [03],Filt_Accel_x [03],Filt_Accel_y [03],Filt_Accel_z [03],Filt_Gyro_x [03],Filt_Gyro_y [03],Filt_Gyro_z [03],Int_Temperature [03],DeltaV_x [03],DeltaV_y [03],DeltaV_z [03],DeltaTheta_x [03],DeltaTheta_y [03],DeltaTheta_z [03],'

    elif (format_in == 3):
       ret_str = 'Time_Since_Powerup [04],Mag Status [04],Mag_Output_x [04],Mag_Output_y [04],Mag_Output_z [04],Accel_Output_x [04],Accel_Output_y [04],Accel_Output_z [04],'

    elif (format_in == 4):
       ret_str = 'Time_Since_Powerup [06],Roll [06],Pitch [06],Yaw [06],Roll_Acc [06],Pitch_Acc [06],Yaw_Acc [06],Global_Soln_Status [06],'

    elif (format_in == 5):
       ret_str = 'Time_Since_Powerup [07],Quat 0 [07],Quat 1 [07],Quat 2 [07],Quat 3 [07],Roll_Acc [07],Pitch_Acc [07],Yaw_Acc [07],Global_Soln_Status [07],'

    elif (format_in == 6):
       ret_str = 'Time_Since_Powerup [08],GPS TOW [08],Vel N [08],Vel E [08],Vel D [08],Vel N Acc [08],Vel E Acc [08],Vel D Acc [08],Lat [08],Lon [08],Ht_MSL [08],Undulation [08],Lat Acc [08],Lon Acc [08],Vert Pos Acc [08],Global_Soln_Status [08],'

    elif (format_in == 7):
       ret_str = 'Time_Since_Powerup [14],GPS Pos Fix And Status [14],GPS TOW [14],Lat [14],Lon [14],Alt_MSL [14],Undulation [14],Pos Acc Lat [14],Pos Acc Lon [14],Pos Acc Alt [14],Nbr of SVs Used [14],Base Station ID [14],Diff Age [14],'

    elif (format_in == 8):
       ret_str = 'Time_Since_Powerup [13],GPS Vel Status [13],GPS TOW [13],Vel N [13],Vel E [13],Vel D [13],Vel N Acc [13],Vel E Acc [13],Vel D Acc [13],Course Over Grnd [13],Course Over Grnd Acc [13],'

    elif (format_in == 9):
       ret_str = 'Time_Since_Powerup [15],True Heading Status [15],GPS TOW [15],True Heading Angle [15],True Heading Acc [15],Pitch Angle Master To Rover [15],Pitch Angle Acc [15],'
       
    elif (format_in == 10):
       ret_str = 'Time_Since_Powerup [09],Heave Period [09],Surge_At_Main_Loc [09],Sway_At_Main_Loc [09],Heave_At_Main_Loc [09],Longitudinal Accel X [09],Lateral Accel Y [09],Lateral Accel Z [09],Lon [08],Ht_MSL [08],Undulation [08],Lat Acc [08],Lon Acc [08],Ship_Motion_Output_Status [09],'
    
    elif (format_in == 11):
       ret_str = 'Time_Since_Powerup [17],GPS Pos Fix And Status [17],GPS TOW [17],Lat [17],Lon [17],Alt_MSL [17],Undulation [17],Pos Acc Lat [17],Pos Acc Lon [17],Pos Acc Alt [17],Nbr of SVs Used [17],Base Station ID [17],Diff Age [17],'

    elif (format_in == 12):
       ret_str = 'Time_Since_Powerup [16],GPS Vel Status [16],GPS TOW [16],Vel N [16],Vel E [16],Vel D [16],Vel N Acc [16],Vel E Acc [16],Vel D Acc [16],Course Over Grnd [16],Course Over Grnd Acc [16],'

    elif (format_in == 13):
       ret_str = 'Time_Since_Powerup [18],True Heading Status [18],GPS TOW [18],True Heading Angle [18],True Heading Acc [18],Pitch Angle Master To Rover [18],Pitch Angle Acc [18],'
       
    elif (format_in == 14):
       ret_str = 'Time_Since_Powerup [32],Heave Period [32],Surge_At_Main_Loc [32],Sway_At_Main_Loc [32],Heave_At_Main_Loc [32],Longitudinal Accel X [32],Lateral Accel Y [32],Lateral Accel Z [32],Lon [08],Ht_MSL [08],Undulation [08],Lat Acc [08],Lon Acc [08],Ship_Motion_Output_Status [32],'

    elif (format_in == 15):
       ret_str = 'Time_Since_Powerup [36],Altimeter Status [36],Pressure [36],Altitude [36],'

    # } if (format_in == 0)..
   
    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format(self, format_in, is_last_format = False, out_file_type = None):
    ret_str = ''
    if (format_in == 0):
       if (self.sbg_01_struct != None):
          ret_str = '{:-14.6f},{:-2d},'.format(self.sbg_01_struct.time_since_powerup, self.sbg_01_struct.general_status)
       else:
          ret_str = ',,'
       # } if (self.sbg_01_struct != None)..
    
    elif (format_in == 1):
       if (self.sbg_02_struct != None):
          ret_str = '{:-14.6f},{:-2d},{:-2d},{:-1d},{:-1d},{:-1d},{:-1d},{:-1d},{:-4d},{:-12.4f},'.format(self.sbg_02_struct.time_since_powerup, self.sbg_02_struct.clock_status,\
                                                                                                       self.sbg_02_struct.utc_year, self.sbg_02_struct.utc_month, self.sbg_02_struct.utc_day,\
                                                                                                       self.sbg_02_struct.utc_hour, self.sbg_02_struct.utc_min, self.sbg_02_struct.utc_sec,\
                                                                                                       self.sbg_02_struct.utc_nanosec, self.sbg_02_struct.gps_tow)
       else:
          ret_str = ',,,,,,,,,,'
       # } if (self.sbg_02_struct != None)..
    
    elif (format_in == 2):
       if (self.sbg_03_struct != None):
          ret_str = '{:-14.6f},{:-2d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.sbg_03_struct.time_since_powerup,\
                                                                                                       self.sbg_03_struct.imu_status, self.sbg_03_struct.filtered_accel_x, self.sbg_03_struct.filtered_accel_y,\
                                                                                                       self.sbg_03_struct.filtered_accel_z, self.sbg_03_struct.filtered_gyro_x, self.sbg_03_struct.filtered_gyro_y,\
                                                                                                       self.sbg_03_struct.filtered_gyro_z, self.sbg_03_struct.internal_temp, self.sbg_03_struct.delta_vel_x,\
                                                                                                       self.sbg_03_struct.delta_vel_y, self.sbg_03_struct.delta_vel_z, self.sbg_03_struct.delta_theta_x,\
                                                                                                       self.sbg_03_struct.delta_theta_y, self.sbg_03_struct.delta_theta_z)
       else:
          ret_str = ',,,,,,,,,,,,,,,'
       # } if (self.sbg_03_struct != None)..
    
    elif (format_in == 3):
       if (self.sbg_04_struct != None):
          ret_str = '{:-14.6f},{:-2d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.sbg_04_struct.time_since_powerup,\
                                                                                                        self.sbg_04_struct.mag_status, self.sbg_04_struct.mag_output_x, self.sbg_04_struct.mag_output_y,\
                                                                                                        self.sbg_04_struct.mag_output_z, self.sbg_04_struct.accel_output_x, self.sbg_04_struct.accel_output_y,\
                                                                                                        self.sbg_04_struct.accel_output_z)
       else:
          ret_str = ',,,,,,,,'
       # } if (self.sbg_04_struct != None)..
    
    elif (format_in == 4):
       if (self.sbg_06_struct != None):
          ret_str = '{:-14.6f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},'.format(self.sbg_06_struct.time_since_powerup,\
                                                                                                        self.sbg_06_struct.roll, self.sbg_06_struct.pitch, self.sbg_06_struct.yaw,\
                                                                                                        self.sbg_06_struct.roll_acc, self.sbg_06_struct.pitch_acc, self.sbg_06_struct.yaw_acc,\
                                                                                                        self.sbg_06_struct.global_soln_status)
       else:
          ret_str = ',,,,,,,,'
       # } if (self.sbg_06_struct != None)..  

    elif (format_in == 5):
       if (self.sbg_07_struct != None):
          ret_str = '{:-14.6f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},'.format(self.sbg_07_struct.time_since_powerup, self.sbg_07_struct.q0, self.sbg_07_struct.q1,\
                                                                                                        self.sbg_07_struct.q2, self.sbg_07_struct.q3, self.sbg_07_struct.roll_acc,\
                                                                                                        self.sbg_07_struct.pitch_acc, self.sbg_07_struct.yaw_acc, self.sbg_07_struct.global_soln_status)
       else:
          ret_str = ',,,,,,,,,'
       # } if (self.sbg_07_struct != None)..  

    elif (format_in == 6):
       if (self.sbg_08_struct != None):
          ret_str = '{:-14.6f},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-4d},'.format(self.sbg_08_struct.time_since_powerup, self.sbg_08_struct.gps_tow,\
                                                                                                        self.sbg_08_struct.vel_n, self.sbg_08_struct.vel_e, self.sbg_08_struct.vel_d,\
                                                                                                        self.sbg_08_struct.vel_n_acc, self.sbg_08_struct.vel_e_acc, self.sbg_08_struct.vel_d_acc,\
                                                                                                        self.sbg_08_struct.lat, self.sbg_08_struct.lon, self.sbg_08_struct.ht_MSL, self.sbg_08_struct.undulation,\
                                                                                                        self.sbg_08_struct.lat_acc, self.sbg_08_struct.lon_acc, self.sbg_08_struct.vert_pos_acc, self.sbg_08_struct.global_soln_status)
       else:
          ret_str = ',,,,,,,,,,,,,,,'
       # } if (self.sbg_08_struct != None)..  
       
    elif (format_in == 7):
       if (self.sbg_14_struct != None):
          ret_str = '{:-14.6f},{:-4d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},{:-2d},{:-10.3f},'.format(self.sbg_14_struct.time_since_powerup,\
                                                                                                        self.sbg_14_struct.gps_pos_fix_and_status, self.sbg_14_struct.gps_tow,\
                                                                                                        self.sbg_14_struct.lat, self.sbg_14_struct.lon, self.sbg_14_struct.alt_MSL, self.sbg_14_struct.undulation,\
                                                                                                        self.sbg_14_struct.pos_acc_lat, self.sbg_14_struct.pos_acc_lon, self.sbg_14_struct.pos_acc_alt,\
                                                                                                        self.sbg_14_struct.nbr_of_svs_used, self.sbg_14_struct.base_station_id, self.sbg_14_struct.diff_age)
       else:
          ret_str = ',,,,,,,,,,,,,'
       # } if (self.sbg_14_struct != None)..
       
    elif (format_in == 8):
       if (self.sbg_13_struct != None):
          ret_str = '{:-14.6f},{:-4d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.sbg_13_struct.time_since_powerup, self.sbg_13_struct.gps_vel_status, self.sbg_13_struct.gps_tow,\
                                                                                                        self.sbg_13_struct.vel_n, self.sbg_13_struct.vel_e, self.sbg_13_struct.vel_d,\
                                                                                                        self.sbg_13_struct.vel_acc_n, self.sbg_13_struct.vel_acc_e, self.sbg_13_struct.vel_acc_d,\
                                                                                                        self.sbg_13_struct.course_over_grnd, self.sbg_13_struct.course_over_grnd_acc)
       else:
          ret_str = ',,,,,,,,,,,'
       # } if (self.sbg_13_struct != None)..  

    elif (format_in == 9):
       if (self.sbg_15_struct != None):
          ret_str = '{:-14.6f},{:-2d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.sbg_15_struct.time_since_powerup, self.sbg_15_struct.gps_true_heading_status, self.sbg_15_struct.gps_tow,\
                                                                                                 self.sbg_15_struct.true_heading_angle, self.sbg_15_struct.true_heading_acc,\
                                                                                                 self.sbg_15_struct.pitch_angle_master_to_rover, self.sbg_15_struct.pitch_acc)
       else:
          ret_str = ',,,,,,,'
       # } if (self.sbg_15_struct != None)..  

    elif (format_in == 10):
       if (self.sbg_09_struct != None):
          ret_str = '{:-14.6f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-2d},'.format(self.sbg_09_struct.time_since_powerup, self.sbg_09_struct.heave_period_in_sec,\
                                                                                                        self.sbg_09_struct.surge_at_main_loc, self.sbg_09_struct.sway_at_main_loc, self.sbg_09_struct.heave_at_main_loc,\
                                                                                                        self.sbg_09_struct.longitudinal_accel_x, self.sbg_09_struct.lateral_accel_y, self.sbg_09_struct.lateral_accel_z,\
                                                                                                        self.sbg_09_struct.longitudinal_vel_x, self.sbg_09_struct.lateral_vel_y, self.sbg_09_struct.lateral_vel_z,\
                                                                                                        self.sbg_09_struct.ship_motion_output_status)
       else:
          ret_str = ',,,,,,,'
       # } if (self.sbg_09_struct != None)..  

    elif (format_in == 11):
       if (self.sbg_17_struct != None):
          ret_str = '{:-14.6f},{:-4d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},{:-2d},{:-10.3f},'.format(self.sbg_17_struct.time_since_powerup,\
                                                                                                        self.sbg_17_struct.gps_pos_fix_and_status, self.sbg_17_struct.gps_tow,\
                                                                                                        self.sbg_17_struct.lat, self.sbg_17_struct.lon, self.sbg_17_struct.alt_MSL, self.sbg_17_struct.undulation,\
                                                                                                        self.sbg_17_struct.pos_acc_lat, self.sbg_17_struct.pos_acc_lon, self.sbg_17_struct.pos_acc_alt,\
                                                                                                        self.sbg_17_struct.nbr_of_svs_used, self.sbg_17_struct.base_station_id, self.sbg_17_struct.diff_age)
       else:
          ret_str = ',,,,,,,,,,,,,'
       # } if (self.sbg_17_struct != None)..
       
    elif (format_in == 12):
       if (self.sbg_16_struct != None):
          ret_str = '{:-14.6f},{:-4d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.sbg_16_struct.time_since_powerup, self.sbg_16_struct.gps_vel_status, self.sbg_16_struct.gps_tow,\
                                                                                                        self.sbg_16_struct.vel_n, self.sbg_16_struct.vel_e, self.sbg_16_struct.vel_d,\
                                                                                                        self.sbg_16_struct.vel_acc_n, self.sbg_16_struct.vel_acc_e, self.sbg_16_struct.vel_acc_d,\
                                                                                                        self.sbg_16_struct.course_over_grnd, self.sbg_16_struct.course_over_grnd_acc)
       else:
          ret_str = ',,,,,,,,,,,'
       # } if (self.sbg_16_struct != None)..  
    
    elif (format_in == 13):
       if (self.sbg_18_struct != None):
          ret_str = '{:-14.6f},{:-2d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.format(self.sbg_18_struct.time_since_powerup, self.sbg_18_struct.gps_true_heading_status, self.sbg_18_struct.gps_tow,\
                                                                                                 self.sbg_18_struct.true_heading_angle, self.sbg_18_struct.true_heading_acc,\
                                                                                                 self.sbg_18_struct.pitch_angle_master_to_rover, self.sbg_18_struct.pitch_acc)
       else:
          ret_str = ',,,,,,,'
       # } if (self.sbg_18_struct != None)..  

    elif (format_in == 14):
       if (self.sbg_32_struct != None):
          ret_str = '{:-14.6f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-2d},'.format(self.sbg_32_struct.time_since_powerup, self.sbg_32_struct.heave_period_in_sec,\
                                                                                                        self.sbg_32_struct.surge_at_main_loc, self.sbg_32_struct.sway_at_main_loc, self.sbg_32_struct.heave_at_main_loc,\
                                                                                                        self.sbg_32_struct.longitudinal_accel_x, self.sbg_32_struct.lateral_accel_y, self.sbg_32_struct.lateral_accel_z,\
                                                                                                        self.sbg_32_struct.longitudinal_vel_x, self.sbg_32_struct.lateral_vel_y, self.sbg_32_struct.lateral_vel_z,\
                                                                                                        self.sbg_32_struct.ship_motion_output_status)
       else:
          ret_str = ',,,,,,,'
       # } if (self.sbg_09_struct != None)..  

    elif (format_in == 15):
       if (self.sbg_36_struct != None):
          ret_str = '{:-14.6f},{:-2d},{:-14.8f},{:-14.8f},'.format(self.sbg_36_struct.time_since_powerup, self.sbg_36_struct.altimeter_status, self.sbg_36_struct.pressure, self.sbg_36_struct.altitude)
       else:
          ret_str = ',,,,'
       # } if (self.sbg_36_struct != None)..  

    # } if (format_in == 0)..
   
    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 # } def format(self, format_in)..

