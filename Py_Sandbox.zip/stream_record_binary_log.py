# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import sys

from async_stream_record_thread import AsyncStreamRecord # Asynchronous Stream Record thread

def stream_record_binary_log_fn(port_obj):

   print(' ***** in stream_record_binary_log_fn(), port_name = ' + str(port_obj.port_name) + ', port_obj.ComPort = ' + str(port_obj.ComPort))
   
   if (port_obj.port_name == None or (str(port_obj.port_name)).strip() == ''):
      print(' ***** Must provide valid Port Name for streaming')
      sys.exit()
   elif (port_obj.port_baud == 0):
      print(' ***** Must provide non-zero baud rate for streaming')
      sys.exit()
   # } if (port_obj.port_name == None..

   if (port_obj.streaming_on):
      print('****** port_obj.streaming_on = ' + str(port_obj.streaming_on))
      
      # Set up background process to accept user input such as pressing Enter key (to exit this script)
      background_stream_record = AsyncStreamRecord(port_obj, 10000)

      # Start the user input thread
      background_stream_record.start()
      
      port_obj.logging_thread = background_stream_record

   # } if (port_obj.streaming_on)..

