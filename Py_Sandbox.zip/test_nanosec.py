import numpy

tow = 327930.7504
print(' ********** tow = ' + str(tow) + ', 1000 * tow = ' + str(tow * 1000.0) + ', tow * 1000.0 - numpy.uint32(numpy.rint(tow * 1000.0) = ' + str(tow * 1000.0 - numpy.uint32(numpy.rint(tow * 1000.0))) )

GPS_TOW_rounded_ms = numpy.uint32(numpy.rint(tow * 1000.0))

print('****** GPS_TOW_rounded_ms = ' + str(GPS_TOW_rounded_ms) )

GPS_TOW_Real_Minus_Rounded_ms = tow * 1000.0 - numpy.uint32(numpy.rint(tow * 1000.0))

print(' ****** GPS_TOW_Real_Minus_Rounded_ms = ' + str(GPS_TOW_Real_Minus_Rounded_ms))

GPS_TOW_Real_Minus_Rounded_nano_s = GPS_TOW_Real_Minus_Rounded_ms * 1e6

print(' ****** GPS_TOW_Real_Minus_Rounded_nano_s = ' + str(GPS_TOW_Real_Minus_Rounded_nano_s))

print(' ****** numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s) = ' + str(numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s)))

# print(' numpy.rint(2.56789) = ' + str(numpy.rint(2.16789)))"

orig_tow = GPS_TOW_rounded_ms/1e3 + GPS_TOW_Real_Minus_Rounded_nano_s/1e9

print(' ****** orig_tow = ' + str(orig_tow))
