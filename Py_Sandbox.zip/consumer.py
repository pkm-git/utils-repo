import threading       #import thread library
import random
from time import time  #import time library
from time import sleep           #sleep

class Consumer(threading.Thread):
    # Consumes random integers from a list

    def __init__(self, integers, condition):
        # Constructor.
        
        threading.Thread.__init__(self)
        self.integers = integers
        self.condition = condition
        
    def run(self):
        # Thread run method. Consumes integers from list
        while True:
            self.condition.acquire()
            print 'condition acquired by %s' % self.name
        
            while True:
                if self.integers:
                    integer = self.integers.pop()
                    print '%d popped from list by %s' % (integer, self.name)
                    break
                print 'condition wait by %s' % self.name
                self.condition.wait()
            print 'condition released by %s' % self.name
            self.condition.release()

