# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

from fletcher_check import fletcher_check16
from binascii import hexlify

#Sync Bytes
MIP_SYNC_BYTE1 = 0x75
MIP_SYNC_BYTE2 = 0x65

#MIP Packet Sizes
MIP_HEADER_SIZE = 4
MIP_CHECKSUM_SIZE = 2
MIP_MAX_PAYLOAD_SIZE = 255
MIP_FIELD_HEADER_SIZE = 2
MIP_MAX_FIELD_DATA_SIZE = MIP_MAX_PAYLOAD_SIZE - MIP_FIELD_HEADER_SIZE
MIP_MAX_PACKET_SIZE = (MIP_HEADER_SIZE + MIP_MAX_PAYLOAD_SIZE + MIP_CHECKSUM_SIZE)
MIP_MIN_PACKET_SIZE = 6 #This is a valid packet length, but not a practical packet

#MIP Packet Header Data Locations
MIP_HEADER_PAYLOAD_SIZE_INDEX = 3
MIP_HEADER_DESCRIPTOR_SET_INDEX = 2
MIP_HEADER_SYNC2_BYTE_INDEX = 1
MIP_HEADER_SYNC1_BYTE_INDEX = 0

MIP_PAYLOAD_START_INDEX = 4

#MIP Field Data Locations
MIP_FIELD_LENGTH_INDEX = 0
MIP_FIELD_DESCRIPTOR_INDEX = 1
MIP_FIELD_DATA_START_INDEX = 2

########################################
# GLOBAL MIP DESCRIPTORS  (global desc are 0xF0 - 0xFF) - same usage in all descriptor sets
########################################

MIP_REPLY_DESC_GLOBAL_ACK_NACK = 0xF1 # Ack/nack desc is same in all sets
MIP_REPLY_DESC_SENSOR2VEHICLE_TRANSFORM_VALUE = 0x81
MIP_REPLY_DESC_ENABLE_DISABLE_STREAMING_DATA_VALUE = 0x85
MIP_DESC_GLOBAL_DEVICE_ID = 0xF3 # Integer based unique Device ID: Model# Serial#
MIP_DESC_GLOBAL_MIPNET_DEVICE_TYPE = 0xF4 # Device type for network enumeration
MIP_DESC_GLOBAL_MIPNET_ROUTING = 0xF5 # Routing field for packets in MIP network
MIP_DESC_GLOBAL_MIPNET_PATH = 0xF6 # Path field for literal routing path to device
MIP_DESC_GLOBAL_PRODUCTION_TEST = 0xFE # Production Test desc is same in all sets
MIP_DATA_DESCRIPTOR_BOUNDARY = 0x80 # Start position for DATA descriptor sets

########################################
# GLOBAL ACK/NACK ERROR CODES
########################################

MIP_ACK_NACK_ERROR_NONE = 0x00

MIP_ACK_NACK_ERROR_UNKNOWN_COMMAND = 0x01
MIP_ACK_NACK_ERROR_CHECKSUM_INVALID = 0x02
MIP_ACK_NACK_ERROR_PARAMETER_INVALID = 0x03
MIP_ACK_NACK_ERROR_COMMAND_FAILED = 0x04
MIP_ACK_NACK_ERROR_COMMAND_TIMEOUT = 0x05
MIP_ACK_NACK_ERROR_UNKNOWN_DESCRIPTOR_SET = 0x06

mip_ack_nacks = {MIP_ACK_NACK_ERROR_NONE : 'No Error', \
                 MIP_ACK_NACK_ERROR_UNKNOWN_COMMAND : 'Unknown Command', \
                 MIP_ACK_NACK_ERROR_CHECKSUM_INVALID : 'Bad Checksum', \
                 MIP_ACK_NACK_ERROR_PARAMETER_INVALID : 'Invalid Parameter', \
                 MIP_ACK_NACK_ERROR_COMMAND_FAILED : 'Command Failed', \
                 MIP_ACK_NACK_ERROR_COMMAND_TIMEOUT : 'Command Timed-Out'}

MIP_DATA_VALUE_DISABLED = 0x00
MIP_DATA_VALUE_ENABLED = 0x01

mip_enable_disable = {MIP_DATA_VALUE_DISABLED : 'Disabled', \
                      MIP_DATA_VALUE_ENABLED : 'Enabled'}

########################################
# Function Selector Byte for Settings
########################################

MIP_FUNCTION_SELECTOR_WRITE = 0x01
MIP_FUNCTION_SELECTOR_READ = 0x02
MIP_FUNCTION_SELECTOR_STORE_EEPROM = 0x03
MIP_FUNCTION_SELECTOR_LOAD_EEPROM = 0x04
MIP_FUNCTION_SELECTOR_LOAD_DEFAULT = 0x05
MIP_FUNCTION_SELECTOR_WRITE_NO_ACK = 0x06

########################################
# Function Return Codes
########################################

MIP_OK = 0
MIP_ERROR = 1
MIP_MEMORY_ERROR = 2
MIP_FIELD_NOT_AVAILABLE = 3
MIP_INVALID_PACKET = 4
MIP_CHECKSUM_ERROR = 5
MIP_PAYLOAD_LENGTH_MISMATCH_ERROR = 6

########################################
# Miscellaneous Data widths
########################################

MIP_DESCRIPTOR_SIZE = 1
MIP_DECIMATION_SIZE = 2


def mip_is_checksum_valid(mip_packet):
    """Some Information Here"""
    if(len(mip_packet)<MIP_MIN_PACKET_SIZE or len(mip_packet)>MIP_MAX_PACKET_SIZE):
     return False

    #force into bytearray
    mip_packet = bytearray(mip_packet)

    #Calculate expected checksum
    expected_checksum = fletcher_check16(mip_packet[0:len(mip_packet)-2])

    #Compare with current checksum
    if(expected_checksum == mip_packet[-2:]):
        return True
    else:
        return False

def mip_init(packet, descriptor_set):
    """Some Information Here"""
    if(len(packet)!=0):
        return MIP_ERROR;

    if(descriptor_set > 0xFF):
        return MIP_ERROR

    #start packet with sync bytes descriptor set and initial packet payload size
    packet.append(MIP_SYNC_BYTE1);
    packet.append(MIP_SYNC_BYTE2);
    packet.append(descriptor_set);
    packet.append(0x00);

def mip_add_field(mip_packet, field_descriptor, field_data=bytearray([])):
    """Some Information Here"""
    #is the current packet a valid length
    if(len(mip_packet)<(MIP_MIN_PACKET_SIZE - MIP_CHECKSUM_SIZE)):
        return MIP_ERROR

    #assemble field, first field length and field descriptor
    field = bytearray([len(field_data)+2,field_descriptor])

    #print "******** mip add field: str(len(field_data)) = " + str(len(field_data))
    #print "******** mip add field: field_descriptor = " + str(field_descriptor)
    #print "******** mip add field: field = " + hexlify(field).upper()

    #add the field data
    field.extend(bytearray(field_data))

    #print "******** mip add field: AFTER extend, field = " + hexlify(field).upper()

    #would the addition of this field make the packet grow too large
    if(len(mip_packet)+len(bytearray(field))+MIP_CHECKSUM_SIZE>MIP_MAX_PACKET_SIZE):
        return MIP_MEMORY_ERROR

    return mip_add_formatted_field(mip_packet,field)

def mip_add_formatted_field(mip_packet,field):
    """Some Information Here"""
    #is this a valid field length
    if(len(bytearray(field))==0):
        return MIP_ERROR

    #is the current packet a valid length
    if(len(mip_packet)<(MIP_MIN_PACKET_SIZE - MIP_CHECKSUM_SIZE)):
        return MIP_ERROR

    #would the addition of this field make the packet grow too large
    if(len(mip_packet)+len(bytearray(field))+MIP_CHECKSUM_SIZE>MIP_MAX_PACKET_SIZE):
        return MIP_MEMORY_ERROR

    #add the field
    mip_packet.extend(bytearray(field))

    #update the payload size
    mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX] += len(bytearray(field))

    return MIP_OK

def mip_finalize(mip_packet):
    """Some Information Here"""
    #test for a packet of valid length
    if(((len(bytearray(mip_packet))+2) < MIP_MIN_PACKET_SIZE) or \
       ((len(bytearray(mip_packet))+2) > MIP_MAX_PACKET_SIZE)):
     return 0

    #test if payload indicated is consistent with the packet length
    if(mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX]+MIP_HEADER_SIZE > len(mip_packet)):
        return 0

    #calculate the checksum
    checksum = fletcher_check16(mip_packet)

    #add the checksum to the packet
    mip_packet.extend(checksum)

    #return the length of the packet
    return len(mip_packet)

def mip_is_initialized(mip_packet, descriptor_set):
    """Some Information Here"""
    #test for necessary length for initialized packet
    if(len(mip_packet)+2 < MIP_MIN_PACKET_SIZE):
     return MIP_ERROR

    #test for valid sync bytes and that the descriptor set matches
    if(mip_packet[MIP_HEADER_SYNC1_BYTE_INDEX] == MIP_SYNC_BYTE1 and \
       mip_packet[MIP_HEADER_SYNC2_BYTE_INDEX] == MIP_SYNC_BYTE2 and \
       mip_packet[MIP_HEADER_DESCRIPTOR_SET_INDEX] == descriptor_set):
     return MIP_OK

    return MIP_ERROR

def mip_is_mip_packet(mip_packet):
    """Some Information Here"""
    #test for a packet of valid length
    # if(((len(bytearray(mip_packet))+2) < MIP_MIN_PACKET_SIZE) or \
       # ((len(bytearray(mip_packet))+2) > MIP_MAX_PACKET_SIZE)):
     # return MIP_ERROR

    #test for valid sync bytes
    if(mip_packet[MIP_HEADER_SYNC1_BYTE_INDEX] != MIP_SYNC_BYTE1 or \
       mip_packet[MIP_HEADER_SYNC2_BYTE_INDEX] != MIP_SYNC_BYTE2):
     return MIP_INVALID_PACKET

    #test if payload indicated matches length
    if((len(mip_packet)-MIP_CHECKSUM_SIZE-MIP_HEADER_SIZE) != \
                                       mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX]):
     return MIP_PAYLOAD_LENGTH_MISMATCH_ERROR
     # return MIP_INVALID_PACKET

    #test for valid checksum
    if(not(mip_is_checksum_valid(mip_packet))):
     return MIP_CHECKSUM_ERROR
     # return MIP_INVALID_PACKET

    return MIP_OK

def mip_get_packet_descriptor_set(mip_packet):
    """Some Information Here"""
    # if(mip_is_mip_packet(mip_packet) != MIP_OK):
    #  return 0

    return mip_packet[MIP_HEADER_DESCRIPTOR_SET_INDEX]

def mip_get_payload_size(mip_packet):
    """Some Information Here"""
    # if(mip_is_mip_packet(mip_packet) != MIP_OK):
    #  return 0

    return mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX]

def mip_get_payload(mip_packet):
    """Some Information Here"""
    # if(mip_is_mip_packet(mip_packet) != MIP_OK):
    #  return 0

    return mip_packet[MIP_PAYLOAD_START_INDEX:MIP_PAYLOAD_START_INDEX+mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX]]

def mip_get_packet_size(mip_packet):
    """Some Information Here"""
    # if(mip_is_mip_packet(mip_packet) != MIP_OK):
    #  return 0

    return len(bytearray(mip_packet))

def mip_get_next_field_offset(mip_packet, field_offset):
    """Some Information Here"""
    # if(mip_is_mip_packet(mip_packet) != MIP_OK):
    #  return 0

    if(field_offset == 0):
        return MIP_HEADER_SIZE

    try:
        next_offset = field_offset+mip_packet[field_offset]
    except:
        return 0

    if((next_offset >= MIP_HEADER_SIZE+mip_packet[MIP_HEADER_PAYLOAD_SIZE_INDEX])\
       or (next_offset == field_offset)):
        return 0

    return next_offset

def mip_get_first_field_offset(mip_packet):
    """Some Information Here"""
    return mip_get_next_field_offset(mip_packet,0)

def mip_get_field_at_offset(mip_packet,offset):
    """Some Information Here"""
    # if(mip_is_mip_packet(mip_packet) != MIP_OK):
    #  return 0

    try:
        return mip_packet[offset:offset+mip_packet[offset]]
    except:
        return 0

def mip_get_next_field(mip_packet):
    """
    Generator Function to generate iterable of Mip Fields. If used as an iterable
    will iterate over fields, otherwise just returns first field on 'next' call
    """
    local_packet = bytearray(mip_packet)
    #get offset of first field
    offset = mip_get_first_field_offset(local_packet)
    while(offset != 0):
        yield mip_get_field_at_offset(local_packet, offset)
        #get offset of next field
        offset = mip_get_next_field_offset(local_packet, offset)

#assign this call to the fletcher_check16 function
mip_calculate_checksum = fletcher_check16


