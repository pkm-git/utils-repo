# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import numpy as np
from datetime import *
import sys

def print_row(data_row_cnt, data_row, fout_csv_file, date_time_stamp_init):
      
   i = 0
   
   for v in data_row:
      i += 1
      try:
         if (data_row_cnt  < 3):
	    print(' ***** in print_row: i: ' + str(i) + ', will print value: ' + v)
	    
         if (v.strip() != '' and 'nan' not in v.strip().lower() and 'ind' not in v.strip().lower()):
	    if (i == 13):
	       if ('.' in v or 'e' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))
               # } if ('.' in v)...
       	       break
            elif ('-' in v and ':' in v):
	       fout_csv_file.write('%s,'%(v))
	    elif ('.' in v or 'e' in v):
	       fout_csv_file.write('%14.8f,'%(float(v)))
   	    else:
	       fout_csv_file.write('%1d,'%(int(v)))
	    # } if (i == 13)..
	    
            # Print extra column value for computed GPS Week and GPS TOW using Hr_min of Day
            if (i == time_of_day_index+1):
	       # print(' ****** i = ' + str(i) + ', WILL PRINT EXTRA COLUMN OF GPS WEEK, TOW ')
	    
	       str_timestamp = data_row[0][:-4]
	       str_timestamp_last3 = data_row[0][-4:]
	       # '2017-01-09 18:44:42.370'
	       # date_time_stamp = datetime.strptime(str_timestamp, '%Y-%m-%d %H:%M:%S') + timedelta(seconds= float(str_timestamp_last3))
	       date_time_stamp = datetime.strptime(str_timestamp, '%Y-%m-%d %H:%M:%S')
	       print(' ***** date_time_stamp.type() = ' + str(type(date_time_stamp)))
	       # date_time_stamp = str_timestamp.to_datetime()
	       
	       # print(' ***** CALLING strptime OVER ' ) 
	       
               if (data_row_cnt == 1):
	       	  date_time_stamp_init = date_time_stamp - timedelta(seconds= float(65.0))
		  print('******* date_time_stamp_init = ' + str(date_time_stamp_init))
		  
               elif (data_row_cnt == 2):
	       	  print(' **** data_row_cnt = 2, WILL FIND DATE DIFF, date_time_stamp = ' + str(date_time_stamp) + ', date_time_stamp_init = ' + str(date_time_stamp_init))
	          date_diff = (date_time_stamp - date_time_stamp_init).total_seconds()
	          print(' ******* data_row_cnt = 2, Date: ' + (date_time_stamp) + ', date diff: ' + str(date_diff))
	       # } if (data_row_cnt == 1)..
	          
               # '%Y-%m-%d %H:%M:%S'
               # dt = datetime.strptime(str_timestamp, '%H:%M:%S')
               # print(' ****** dt: ' + str(dt))

               # dt = datetime.strptime('25/07/19', '%d/%m/%y')
               # print(' ****** dt: ' + str(dt))
	       
	       # nbr_secs_since_midnight = int(str_timestamp[0:2]) * 3600 + int(str_timestamp[3:5]) * 60 + int(str_timestamp[6:8])
	       
	       # gps_tow = float(86400 * 4 + nbr_secs_since_midnight)  # For July 25, 2019 only
               
	       date_diff = (date_time_stamp - date_time_stamp_init).total_seconds()
	       	       
    	       if (data_row_cnt < 3):
    	          print(' **** data_row_cnt: ' + str(data_row_cnt) + ', date_diff = ' + str(date_diff))
               # } if (data_row_cnt < 5)..
	       
	       fout_csv_file.write('%1d,%11.3f,'%(gps_week, date_diff))
    	    
	    # } if (i == time_of_day_index+1)..

         elif ('nan' in v.strip().lower() or 'ind' in v.strip().lower()):
	    if (i == len(data_row)):
	       fout_csv_file.write(v)
	    else:
	       fout_csv_file.write(v + ',')
            # } if (i == len(data_row))..	       
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..

      except TypeError:
         print(' ***** print_row: TypeError: at data_row_cnt = ' + str(data_row_cnt) + ', len(data_row) = ' + str(len(data_row)) + ', column: ' + str(i) + ', value: ' + str(v))
      	 sys.exit()
	 
      except ValueError:
         if (data_row_cnt < 5):
            print(' ***** print_row: ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))

   # } for v in data_row..

   fout_csv_file.write('\n')
   
   return date_time_stamp_init
      
def process_csv_file(csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0
   date_time_stamp_init = None

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   prev_gps_week = 0
   
   for data_row in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         
         i = 0
         for c in data_row:
            i += 1
	    # print(' ***** i: ' + str(i) + ', will print header: ' + c)
            if (i == 13):
               fout_csv_file.write(c)
     	       break
   	    else:
               fout_csv_file.write(c + ',')
               
     	       if (i == time_of_day_index+1):
     	          fout_csv_file.write('GPS Week,GPS TOW,')
               # } if (i == time_of_day_index+1)..
	    # } if (i == 13)..
         # } for c in data_row..   
         fout_csv_file.write('\n')
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
	 if (data_row_cnt < 3):
	    print(' ****** will call print_row using data_row_cnt = ' + str(data_row_cnt))
	 
	    date_time_stamp_init = print_row(data_row_cnt, data_row, fout_csv_file, date_time_stamp_init)

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in csvreader..
   
# '%Y-%m-%d %H:%M:%S'
# dt = datetime.strptime(str_timestamp, '%H:%M:%S')
# print(' ****** dt: ' + str(dt))

# dt = datetime.strptime('25/07/19', '%d/%m/%y')
# print(' ****** dt: ' + str(dt))

# str_date_time_stamp = '2017-01-09 18:44:42.370'
# date_time_stamp_1 = datetime.strptime(str_date_time_stamp[:-4], '%Y-%m-%d %H:%M:%S') + timedelta(seconds=float('.370'))
# print(' ****** str_date_time_stamp = ' + str(str_date_time_stamp) + ', date_time_stamp: ' + str(date_time_stamp))

# str_date_time_stamp = '2017-01-09 18:44:43.620'
# date_time_stamp_2 = datetime.strptime(str_date_time_stamp[:-4], '%Y-%m-%d %H:%M:%S') + timedelta(seconds=float('.620'))

# date_diff = (date_time_stamp_2 - date_time_stamp_1).total_seconds()

# print(' ***** DATE DIFF: ' + str(date_diff))

# sys.exit()

# in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_10_17_NAL_Research/Sand Dollar + Raw IMU - Manassas 07-25-2019/Loop 1 with Mag heading/SD/71 Harris Teeter Loop 07-25-2019_GPS.csv'
in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/2019_10_25_AXYS/54974.csv'

(fin_filepath, fin_filename) = os.path.split(in_file_name)

time_of_day_index = 0
gps_week = 1931

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_for_NRTSIM.csv"), "w")

fout_csv_file.write('DATA_START\n')

in_csvfile = open(in_file_name,'r')
csvreader = csv.reader(in_csvfile, delimiter=',')

process_csv_file(csvreader)
   
fout_csv_file.close()
