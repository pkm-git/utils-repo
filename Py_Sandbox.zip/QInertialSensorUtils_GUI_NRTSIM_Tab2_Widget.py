import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

class MyNRTSIMTab2FormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyNRTSIMTab2FormWidget, self).__init__(parent)
      self.parent_obj = parent
      self.processError = False
      self.submit_timestamp = ''
      self.submit_timestamp_no_spaces_spl_chr = ''
      
      self.gnss_source = 1     # Internal GNSS
      self.heading_aid = 1     # Magnetometer
      self.pitch_roll_aid = 1  # Gravity Vector
      self.altitude_aid = 1    # Pressure Altimeter
      
      self.grav_adaptive = 2   # Auto-adaptive
      self.mag_adaptive = 2    # Auto-adaptive
      
      if (parent.nrtsim_form_widget.device_name == 'GX5-45'):
         self.veh_dyn_mode = 2    # Automotive
      else:
         self.veh_dyn_mode = 1    # Portable
      # } if (parent.nrtsim..
      
      # self.setFixedSize(550,250)
      # self.setFixedSize(575,175)
      self.setFixedSize(575,225)

      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyNRTSIMTab2FormWidget window"

      super(MyNRTSIMTab2FormWidget, self).closeEvent(event)

   def __controls(self):
   
      self.declare_spaces()
      
      self.lbl_title = QtGui.QLabel("NRTSIM Tab 2")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(120)
      self.lbl_title.setFixedHeight(25)
      
      # ************************************
      
      self.chkbx_mag_on = MyCheckBox('Mag On')
      self.chkbx_mag_on.stateChanged.connect(self.processMagOn)
      self.chkbx_mag_on.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.lbl_GNSS_source = QtGui.QLabel("GNSS Source:")
      self.lbl_GNSS_source.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.cmbox_GNSS_source = MyComboBox('GNSS Source')
      self.cmbox_GNSS_source.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_GNSS_source.currentIndexChanged.connect(self.processGNSSSource)
      self.cmbox_GNSS_source.setEnabled(False)
      if (self.parent_obj.nrtsim_form_widget.device_name == 'GX5-45'):
         self.cmbox_GNSS_source.setEnabled(True)
      # } if (self.parent_obj...
         
      self.lbl_heading_aid = QtGui.QLabel("Heading Aid:")
      self.lbl_heading_aid.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_heading_aid.setFixedSize(75,20)
      
      self.cmbox_heading_aid = MyComboBox('Heading Aid')
      self.cmbox_heading_aid.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_heading_aid.currentIndexChanged.connect(self.processHeadingAid)
      self.cmbox_heading_aid.setFixedSize(250,20)
      
      self.lbl_pitch_roll_aid = QtGui.QLabel("Pitch/Roll Aid:")
      self.lbl_pitch_roll_aid.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.cmbox_pitch_roll_aid = MyComboBox('Pitch/Roll Aid')
      self.cmbox_pitch_roll_aid.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_pitch_roll_aid.currentIndexChanged.connect(self.processPitchRoll)

      self.lbl_grav_adaptive = QtGui.QLabel("Gravity Adaptive:")
      self.lbl_grav_adaptive.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.cmbox_grav_adaptive = MyComboBox('Gravity Adaptive')
      self.cmbox_grav_adaptive.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_grav_adaptive.currentIndexChanged.connect(self.processGravAdaptive)

      # ************************************
      self.lbl_altitude_aid = QtGui.QLabel("Altitude Aid:")
      self.lbl_altitude_aid.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.cmbox_altitude_aid = MyComboBox('Altitude Aid')
      self.cmbox_altitude_aid.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_altitude_aid.currentIndexChanged.connect(self.processAltitudeAid)

      self.lbl_vehicle_dyn_mode = QtGui.QLabel("Vehicle Dyn Mode:")
      self.lbl_vehicle_dyn_mode.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.cmbox_vehicle_dyn_mode = MyComboBox('Vehicle Dyn Mode', self.parent_obj.nrtsim_form_widget.device_name)
      self.cmbox_vehicle_dyn_mode.setStyleSheet("background-color: #E0E0E0;");
      # self.cmbox_vehicle_dyn_mode.setCurrentIndex(1) # Automotive
      self.cmbox_vehicle_dyn_mode.currentIndexChanged.connect(self.processVehDynMode)

      self.lbl_mag_adaptive = QtGui.QLabel("Mag Adaptive:")
      self.lbl_mag_adaptive.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.cmbox_mag_adaptive = MyComboBox('Mag Adaptive')
      self.cmbox_mag_adaptive.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_mag_adaptive.currentIndexChanged.connect(self.processMagAdaptive)
   
   def setDropDowns(self):
      print(' ***** in setDropDowns: self.parent_obj.nrtsim_form_widget.device_name = ' + self.parent_obj.nrtsim_form_widget.device_name)
      
      if (self.parent_obj.nrtsim_form_widget.device_name == 'GX5-45'):
         self.cmbox_GNSS_source.setEnabled(True)
         self.cmbox_altitude_aid.setEnabled(True)
         self.cmbox_vehicle_dyn_mode.setEnabled(True)
         dyn_mode = 'Automotive'
      else:      
         self.cmbox_GNSS_source.setEnabled(False)
         self.cmbox_altitude_aid.setEnabled(False)
         self.cmbox_vehicle_dyn_mode.setEnabled(False)
         dyn_mode = 'Portable'
      # } if (self.parent_obj...
      
      index = self.cmbox_vehicle_dyn_mode.findText(dyn_mode, QtCore.Qt.MatchFixedString)
      
      if index >= 0:
         self.cmbox_vehicle_dyn_mode.setCurrentIndex(index)
      # } if index >= 0..
      
   def clearStatusText(self):
      self.lbl_status.setText("Status:")

   def processPitchRoll(self, state):
      if (state == 0): # None
         self.pitch_roll_aid = 0
      elif (state == 1): # Gravity
         self.pitch_roll_aid = 1
      # } if (state == 0)..
   
   def processGravAdaptive(self, state):
      if (state == 0): # Disabled
         self.grav_adaptive = 0
      elif (state == 1): # Auto-adaptive
         self.grav_adaptive = 2
      # } if (state == 0)..

   def processAltitudeAid(self, state):
      if (state == 0): # None
         self.altitude_aid = 0
      elif (state == 1): # Pressure Altimeter
         self.altitude_aid = 1
      # } if (state == 0)..

   def processVehDynMode(self, state):
      if (state == 0): # Portable
         self.veh_dyn_mode = 1
      elif (state == 1): # Automotive
         self.veh_dyn_mode = 2
      elif (state == 2): # Airborne
         self.veh_dyn_mode = 3
      elif (state == 3): # Airborne (HiG)
         self.veh_dyn_mode = 4
      # } if (state == 0)..

   def processMagAdaptive(self, state):
      if (state == 0): # Disabled
         self.mag_adaptive = 0
      elif (state == 1): # Auto-adaptive
         self.mag_adaptive = 2
      # } if (state == 0)..

   def processMagOn(self, state):
      
      self.cmbox_heading_aid.clear()
      
      if state == QtCore.Qt.Checked:
         self.cmbox_heading_aid.addItem("None")
         self.cmbox_heading_aid.addItem("Magnetometer")
         self.cmbox_heading_aid.addItem("GNSS Velocity Vector")
         self.cmbox_heading_aid.addItem("External Heading Msgs")
         self.cmbox_heading_aid.addItem("Internal GNSS Vel Vector and Mag")
         self.cmbox_heading_aid.addItem("Internal GNSS Vel Vector and Ext Heading Msgs")
         self.cmbox_heading_aid.addItem("Internal Mag and Ext Heading Msgs")
         self.cmbox_heading_aid.addItem("Internal GNSS Vel Vector and Mag and Ext Heading Msgs")
 
         index = self.cmbox_heading_aid.findText('Magnetometer', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.cmbox_heading_aid.setCurrentIndex(index)
         # } if index >= 0..
 
         self.cmbox_mag_adaptive.setEnabled(True)
      else:
         self.cmbox_heading_aid.addItem("None")
         self.cmbox_heading_aid.addItem("GNSS Velocity Vector")
         self.cmbox_heading_aid.addItem("External Heading Msgs")
         self.cmbox_heading_aid.addItem("Internal GNSS Vel Vector and Ext Heading Msgs")
 
         index = self.cmbox_heading_aid.findText('None', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.cmbox_heading_aid.setCurrentIndex(index)
         # } if index >= 0..
 
         self.cmbox_mag_adaptive.setEnabled(False)
 
      # } if state == QtCore.Qt.Checked..

   def processHeadingAid(self, state):
      if (self.parent_obj.nrtsim_form_widget.device_name == 'GX5-45'):
         self.gx5_45_mode = True
      else:
         self.gx5_45_mode = False
      # } if (self.parent_obj...
         
      if (state == 0): # None
         self.heading_aid = 0
      elif (state == 1):
         if (self.gx5_45_mode):
            self.heading_aid = 1  # Internal Mag
         else:
            self.heading_aid = 2  # GNSS Vel Vector
         # } if (self.gx5_45_mode)..
      elif (state == 2): 
         if (self.gx5_45_mode):
            self.heading_aid = 2 # Internal GNSS Vel Vector
         else:
            self.heading_aid = 3 # External Heading Msgs 
         # } if (self.gx5_45_mode)..   
      elif (state == 3): 
         if (self.gx5_45_mode):
            self.heading_aid = 3  # External Heading Msgs
         else:
            self.heading_aid = 5  # Internal GNSS Vel Vector and Ext Heading Msgs
         # } if (self.gx5_45_mode)..   
      elif (state == 4): # Internal GNSS Vel Vector and Mag
         self.heading_aid = 4
      elif (state == 5): # Internal GNSS Vel Vector and Ext Heading Msgs
         self.heading_aid = 5
      elif (state == 6): # Internal Mag and Ext Heading Msgs
         self.heading_aid = 6
      elif (state == 7): # Internal GNSS Vel Vector and Mag and Ext Heading Msgs
         self.heading_aid = 7
      # } if (state == 0)..
   
   def processGNSSSource(self, state):
      if (state == 0): # Internal GNSS
         self.gnss_source = 1
      elif (state == 1): 
         self.gnss_source = 2
      # } if (state == 0)..
      
   def __layout(self):

      self.vNRTSIMFirstColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_GNSS_source)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_pitch_roll_aid)
      self.vNRTSIMFirstColumnBox.addWidget(self.lbl_grav_adaptive)
      
      self.vNRTSIMFirstColumnWidget = QtGui.QWidget()
      self.vNRTSIMFirstColumnWidget.setLayout(self.vNRTSIMFirstColumnBox)
      # self.vNRTSIMFirstColumnWidget.setFixedSize(100,70)
      self.vNRTSIMFirstColumnWidget.setFixedSize(100,110)
      
      self.vNRTSIMSecondColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMSecondColumnBox.addWidget(self.cmbox_GNSS_source)
      self.vNRTSIMSecondColumnBox.addWidget(self.cmbox_pitch_roll_aid)
      self.vNRTSIMSecondColumnBox.addWidget(self.cmbox_grav_adaptive)
      
      self.vNRTSIMSecondColumnWidget = QtGui.QWidget()
      self.vNRTSIMSecondColumnWidget.setLayout(self.vNRTSIMSecondColumnBox)
      # self.vNRTSIMSecondColumnWidget.setFixedSize(160,70)
      self.vNRTSIMSecondColumnWidget.setFixedSize(160,110)
      
      self.vNRTSIMThirdColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMThirdColumnBox.addWidget(self.lbl_altitude_aid)
      self.vNRTSIMThirdColumnBox.addWidget(self.lbl_vehicle_dyn_mode)
      self.vNRTSIMThirdColumnBox.addWidget(self.lbl_mag_adaptive)

      self.vNRTSIMThirdColumnWidget = QtGui.QWidget()
      self.vNRTSIMThirdColumnWidget.setLayout(self.vNRTSIMThirdColumnBox)
      # self.vNRTSIMThirdColumnWidget.setFixedSize(120,70)
      self.vNRTSIMThirdColumnWidget.setFixedSize(120,110)

      self.vNRTSIMFourthColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFourthColumnBox.addWidget(self.cmbox_altitude_aid)
      self.vNRTSIMFourthColumnBox.addWidget(self.cmbox_vehicle_dyn_mode)
      self.vNRTSIMFourthColumnBox.addWidget(self.cmbox_mag_adaptive)

      self.vNRTSIMFourthColumnWidget = QtGui.QWidget()
      self.vNRTSIMFourthColumnWidget.setLayout(self.vNRTSIMFourthColumnBox)
      # self.vNRTSIMFourthColumnWidget.setFixedSize(160,70)
      self.vNRTSIMFourthColumnWidget.setFixedSize(160,110)

      self.vNRTSIMHeadingAidRowLayout = QtGui.QHBoxLayout()
      self.vNRTSIMHeadingAidRowLayout.addWidget(self.chkbx_mag_on)
      self.vNRTSIMHeadingAidRowLayout.addWidget(self.lbl_heading_aid)
      self.vNRTSIMHeadingAidRowLayout.addWidget(self.cmbox_heading_aid)
      self.vNRTSIMHeadingAidRowLayout.addWidget(self.lbl_space_custom)
      
      self.vNRTSIMBottomRowLayout = QtGui.QHBoxLayout()
      self.vNRTSIMBottomRowLayout.addWidget(self.lbl_space_medium)

      self.vNRTSIMBottomRowWidget = QtGui.QWidget()
      self.vNRTSIMBottomRowWidget.setLayout(self.vNRTSIMBottomRowLayout)
      self.vNRTSIMBottomRowWidget.setFixedSize(575,40)

      self.hNRTSIMOptionsBox = QtGui.QHBoxLayout()
      self.hNRTSIMOptionsBox.addWidget(self.vNRTSIMFirstColumnWidget)
      self.hNRTSIMOptionsBox.addWidget(self.vNRTSIMSecondColumnWidget)
      self.hNRTSIMOptionsBox.addWidget(self.vNRTSIMThirdColumnWidget)
      self.hNRTSIMOptionsBox.addWidget(self.vNRTSIMFourthColumnWidget)
      
      self.hNRTSIMOptionsBox.addWidget(self.lbl_space_small_b)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.vNRTSIMHeadingAidRowLayout)
      self.vbox.addLayout(self.hNRTSIMOptionsBox)
      self.vbox.addWidget(self.vNRTSIMBottomRowWidget)

      self.setLayout(self.vbox)

   def declare_spaces(self):
   
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_small_b = QtGui.QLabel()
      self.lbl_space_small_b.setFixedSize(20,25)

      self.lbl_space_medium_s = QtGui.QLabel()
      self.lbl_space_medium_s.setFixedSize(50,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)
      
      self.lbl_space_custom = QtGui.QLabel()
      self.lbl_space_custom.setFixedSize(150,25)

