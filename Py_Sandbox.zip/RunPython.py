import PyClass
import numpy as np

V1=PyClass.VehicleClass('Red')
V2=PyClass.VehicleClass('Yellow',5)

V1.accelerate(np.array([1,2]))
V2.accelerate(np.array([3,4]))

V3=V1+V2
V3.accelerate(np.array([5,1.3]))
print (V3)





multout=V3.Velocity * V1.Velocity
print('multout={0}'.format(multout))

