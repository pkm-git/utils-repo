import httplib
import xdrlib
import time
# AUTH_SERVER = "sensorcloud.microstrain.com"
AUTH_SERVER = "dev.sensorcloud.microstrain.com"
HERTZ = 1
SECONDS = 0

def authenticate_key(device_id, key):
   """
   authenticate with sensorcloud and get the server and auth_key for all subsequent api requests
   """
   conn = httplib.HTTPSConnection(AUTH_SERVER)

   headers = {"Accept": "application/xdr"}
   url = "/SensorCloud/devices/%s/authenticate/?version=1&key=%s"%(device_id, key)

   print "authenticating..."
   conn.request('GET', url=url, headers=headers)
   response =conn.getresponse()
   print response.status, response.reason

   #if response is 200 ok then we can parse the response to get the auth token and server
   if response.status is httplib.OK:
      print "Credential are correct"

      #read the body of the response
      data = response.read()

      #response will be in xdr format. Create an XDR unpacker and extract the token and server as strings
      unpacker = xdrlib.Unpacker(data)
      auth_token = unpacker.unpack_string()
      server = unpacker.unpack_string()

      print "unpacked xdr.  server:%s  token:%s"%(server, auth_token)

      return server, auth_token

def addSensor(server, auth_token, device_id, sensor_name, sensor_type="", sensor_label="", sensor_desc=""):
   """
   Add a sensor to the device. type, label, and description are optional.
   """

   conn = httplib.HTTPSConnection(server)

   url="/SensorCloud/devices/%s/sensors/%s/?version=1&auth_token=%s"%(device_id, sensor_name, auth_token)

   headers = {"Content-type" : "application/xdr"}

   #addSensor allows you to set the sensor type label and description.  All fileds are strings.
   #we need to pack these strings into an xdr structure
   packer = xdrlib.Packer()
   packer.pack_int(1)  #version 1
   packer.pack_string(sensor_type)
   packer.pack_string(sensor_label)
   packer.pack_string(sensor_desc)
   data = packer.get_buffer()

   print "adding sensor..."
   conn.request('PUT', url=url, body=data, headers=headers)
   response =conn.getresponse()
   print response.status , response.reason

   #if response is 201 created then we know the sensor was added
   if response.status is httplib.CREATED:
      print "Sensor added"
   else:
      print "Error adding sensor. Error:", response.read()

def addChannel(server, auth_token, device_id, sensor_name, channel_name, channel_label="", channel_desc=""):
   """
   Add a channel to the sensor.  label and description are optional.
   """

   conn = httplib.HTTPSConnection(server)

   url="/SensorCloud/devices/%s/sensors/%s/channels/%s/?version=1&auth_token=%s"%(device_id, sensor_name, channel_name, auth_token)

   headers = {"Content-type" : "application/xdr"}

   #addChannel allows you to set the channel label and description.  All fileds are strings.
   #we need to pack these strings into an xdr structure
   packer = xdrlib.Packer()
   packer.pack_int(1)  #version 1
   packer.pack_string(channel_label)
   packer.pack_string(channel_desc)
   data = packer.get_buffer()

   print "adding sensor..."
   conn.request('PUT', url=url, body=data, headers=headers)
   response =conn.getresponse()
   print response.status , response.reason

   #if response is 201 created then we know the channel was added
   if response.status is httplib.CREATED:
      print "Channel successfuly added"
   else:
      print "Error adding channel.  Error:", response.read()

# device_id = "OAPI000RCUZT6EEQ"
device_id = "OAPI00QKJTDKCM0R"

# key = "d2c7c19799bde67b9bf32335e42fd6d7fad2538037f1f6426ef416b5ee752d14"
key = "ae5049445b0025feede8459115c63640ffee2c9eab72624fb9834b9b6f1a263b"

server, token = authenticate_key(device_id, key)
addSensor(server, token, device_id, "ExampleSensor")
addChannel(server, token, device_id, "ExampleSensor", "ch1")

from datetime import datetime
time1 = datetime(2016,6,17,15,0,0)
ts1 = time.mktime(time1.utctimetuple()) * 1000000000
ts2 = ts1 + (1000000000)
ts3 = ts2 + 1000000000
data = [(int(ts1), 55.5), (int(ts2), 15), (int(ts3), 25.5)]

def uploadToSensorCloud(server, auth_token, device_id, sensorName, channelName, sampleRate, sampleRateType, data):
   conn = httplib.HTTPSConnection(server)

   url="/SensorCloud/devices/%s/sensors/%s/channels/%s/streams/timeseries/data/?version=1&auth_token=%s"%(device_id, sensorName, channelName, auth_token)

   #we need to pack these strings into an xdr structure
   packer = xdrlib.Packer()
   packer.pack_int(1)  #version 1

   #set samplerate to 10 Hz
   packer.pack_enum(sampleRateType)
   packer.pack_int(sampleRate)
   #num points
   packer.pack_int(len(data))
   for datapoint in data:
      ts = datapoint[0]
      value = datapoint[1]
      packer.pack_uhyper(ts)
      packer.pack_float(value)
   uploadData = packer.get_buffer()
   print "adding data..."
   headers = {"Content-type" : "application/xdr"}
   conn.request('POST', url=url, body=uploadData, headers=headers)
   response =conn.getresponse()
   print response.status , response.reason

   #if response is 201 created then we know the channel was added
   if response.status is httplib.CREATED:
      print "data successfuly added"
   else:
      print "Error adding data.  Error:", response.read()

uploadToSensorCloud(server, token, device_id, "ExampleSensor", "lucky", 1, HERTZ, data)