import threading       #import thread library
from time import time  #import time library

#Class to asynchronously update data from serial port
class AsyncMIPDataUpdater(threading.Thread):

 """Thread Object for doing Threaded Data Updating"""
 def __init__(self, serial_port, mip_parser, timeout = 0.001):
  """Initialize the AsyncDataUpdater Object"""
  threading.Thread.__init__(self)
  self.parser = mip_parser
  self.serial_port = serial_port
  self.serial_buffer = []
  self.timeout = timeout
  self._stop = False

 def stop(self):
  """Stop thread loop"""
  self._stop = True

 def load_serial_buffer(self):
  """Load data bytes waiting on the serial buffer"""
  start_time = time()
  # print(' ****** load_serial_buffer: start time = ' + str(start_time))

  j = 1
  #Read response if any
  while self.serial_port.inWaiting():
   byte_reply = bytearray(self.serial_port.read(self.serial_port.inWaiting()))
   self.serial_buffer.extend(bytearray(byte_reply));
   # print('****** load_serial_buffer: j = ' + str(j) + ', Packet: ' + hexlify(bytearray(byte_reply)).upper())
   j = j + 1

 def run(self):
  """Enter infinite Update loop"""
  i = 1
  while(self._stop == False):
   # print('****** in asyn run ****, i = ' + str(i))

   #Read reply
   self.load_serial_buffer()
   #write the response bytes to the parser
   self.parser.write(bytearray(self.serial_buffer))
   #print contents of buffer
#   print(self.serial_buffer)
   #clear the buffer
   self.serial_buffer = [];
   #parse the response
   self.parser.parse_input_buffer()
   i = i + 1

