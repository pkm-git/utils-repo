import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

from sensor_cloud_utils import *
from sensor_cloud_api import *
from csv_to_sensor_cloud import *

class MyNRTSIMFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyNRTSIMFormWidget, self).__init__(parent)
      self.parent_obj = parent
      self.processError = False
      self.submit_timestamp = ''
      self.submit_timestamp_no_spaces_spl_chr = ''
      
      self.device_name = 'GX5-45'
      self.fw_version = '1128'
      
      self.setFixedSize(550,250)
      # self.setFixedSize(650,375)

      self.__controls()
      self.__layout()
      
      if (0):
         layout = QtGui.QHBoxLayout()  # layout for the central widget
         widget = QtGui.QWidget(self)  # central widget
         widget.setLayout(layout)
         
         # ********* Number Group **************
         number_group = QtGui.QButtonGroup(widget) # Number group
         
         r0 = QtGui.QRadioButton("0")
         number_group.addButton(r0)
         
         r1 = QtGui.QRadioButton("1")
         number_group.addButton(r1)
         
         layout.addWidget(r0)
         layout.addWidget(r1)

         # ********* Letter Group **************
         # letter_group = QtGui.QButtonGroup(widget) # Letter group
         
         # ra = QtGui.QRadioButton("a")
         # letter_group.addButton(ra)
         
         # rb = QtGui.QRadioButton("b")
         # letter_group.addButton(rb)
         
         # layout.addWidget(ra)
         # layout.addWidget(rb)

         # assign the widget to the main window
         # self.setCentralWidget(widget)
         # self.show()
    
   def closeEvent(self, event):
      print "Closing MyNRTSIMFormWidget window"

      # self.logFile.close()

      super(MyNRTSIMFormWidget, self).closeEvent(event)

   def __controls(self):

      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(60)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(90)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(110)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.lbl_space_resizable_filler = QtGui.QLabel()
      self.lbl_space_resizable_filler.setFixedWidth(65)
      self.lbl_space_resizable_filler.setFixedHeight(25)

      self.lbl_space_resizable_filler2 = QtGui.QLabel()
      self.lbl_space_resizable_filler2.setFixedWidth(15)
      self.lbl_space_resizable_filler2.setFixedHeight(25)

      self.lbl_space_resizable_filler3 = QtGui.QLabel()
      self.lbl_space_resizable_filler3.setFixedWidth(65)
      self.lbl_space_resizable_filler3.setFixedHeight(5)

      self.lbl_title = QtGui.QLabel("NRTSIM")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(80)
      self.lbl_title.setFixedHeight(25)

      self.lbl_imu_filename = QtGui.QLabel("Input IMU CSV Filename:")
      self.lbl_imu_filename.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_imu_filename = MyLineEdit()
      self.edt_imu_filename.setStyleSheet("background-color: white;");
      self.edt_imu_filename.setFixedWidth(250)

      self.lbl_gps_filename = QtGui.QLabel("Input GPS CSV Filename:")
      self.lbl_gps_filename.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_gps_filename = MyLineEdit()
      self.edt_gps_filename.setStyleSheet("background-color: white;");
      self.edt_gps_filename.setFixedWidth(250)

      self.lbl_device_type = QtGui.QLabel("Device:")
      self.lbl_device_type.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.cmbox_device_type = MyComboBox('NRTSIM Device')
      self.cmbox_device_type.setFixedWidth(70)
      self.cmbox_device_type.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_device_type.currentIndexChanged.connect(self.onDeviceChange)

      self.radiob_developer = QtGui.QRadioButton("Developer")
      self.radiob_developer.setChecked(True)
      # self.radiob_developer.setEnabled(False)
      # self.radiob_developer.toggled.connect(lambda:self.enable_fw_version(self.radiob_developer))
      self.radiob_developer.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.radiob_customer = QtGui.QRadioButton("Customer")
      # self.radiob_customer.setEnabled(False)
      # self.radiob_customer.toggled.connect(lambda:self.enable_fw_version(self.radiob_customer))
      self.radiob_customer.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      # Create a button group for radio buttons
      self.developer_button_group = QtGui.QButtonGroup()

      # Add each radio button to the button group & give it an ID of i
      self.developer_button_group.addButton(self.radiob_developer, 1)
      self.developer_button_group.addButton(self.radiob_customer, 2)
      
      # Connect each radio button to a method to run when it's clicked
      # self.connect(self.radiob_developer, SIGNAL("clicked()"), lambda:self.enable_fw_version(self.radiob_developer))
      # self.connect(self.radiob_customer, SIGNAL("clicked()"), lambda:self.enable_fw_version(self.radiob_customer))
      
      self.radiob_developer.clicked.connect(lambda:self.enable_fw_version(self.radiob_developer))
      self.radiob_customer.clicked.connect(lambda:self.enable_fw_version(self.radiob_customer))
      
      self.lbl_fw_version = QtGui.QLabel("FW Version:")
      self.lbl_fw_version.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.cmbox_fw_version = MyComboBox('NRTSIM FW Version')
      self.cmbox_fw_version.setFixedWidth(70)
      self.cmbox_fw_version.setEnabled(False)
      self.cmbox_fw_version.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_fw_version.currentIndexChanged.connect(self.onFWVersionChange)

      self.chkbx_estimate_accel_bias = MyCheckBox('Estimate Accel Bias')
      self.chkbx_estimate_accel_bias.setChecked(False)
      self.chkbx_estimate_accel_bias.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.chkbx_estimate_gyro_bias = MyCheckBox('Estimate Gyro Bias')
      self.chkbx_estimate_gyro_bias.setChecked(False)
      self.chkbx_estimate_gyro_bias.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.chkbx_estimate_accel_SF = MyCheckBox('Estimate Accel SF')
      self.chkbx_estimate_accel_SF.setChecked(False)
      self.chkbx_estimate_accel_SF.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.chkbx_estimate_gyro_SF = MyCheckBox('Estimate Gyro SF')
      self.chkbx_estimate_gyro_SF.setChecked(False)
      self.chkbx_estimate_gyro_SF.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      # self.chkbx_estimate_gnss_ant_offset = MyCheckBox('Estimate GNSS Antenna Offset')
      # self.chkbx_estimate_gnss_ant_offset.setChecked(False)
      # self.chkbx_estimate_gnss_ant_offset.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.chkbx_enable_mag_hard_auto_cal = MyCheckBox('Enable Mag Hard Iron Auto Cal')
      self.chkbx_enable_mag_hard_auto_cal.setChecked(False)
      self.chkbx_enable_mag_hard_auto_cal.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.chkbx_enable_mag_soft_auto_cal = MyCheckBox('Enable Mag Soft Iron Auto Cal')
      self.chkbx_enable_mag_soft_auto_cal.setChecked(False)
      self.chkbx_enable_mag_soft_auto_cal.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      # self.chkbx_enable_EF_Vel_ZUPT = MyCheckBox('Enable EF Velocity ZUPT')
      # self.chkbx_enable_EF_Vel_ZUPT.setChecked(False)
      # self.chkbx_enable_EF_Vel_ZUPT.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      # self.chkbx_enable_angular_rate_ZUPT = MyCheckBox('Enable Angular Rate ZUPT')
      # self.chkbx_enable_angular_rate_ZUPT.setChecked(False)
      # self.chkbx_enable_angular_rate_ZUPT.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.browse_button_imu = MyPushButton("Browse")
      self.browse_button_imu.setCheckable(True)
      self.browse_button_imu.toggle()
      self.browse_button_imu.clicked.connect(lambda:self.selectFile('imu'))
      self.browse_button_imu.setFixedWidth(75)

      self.browse_button_gps = MyPushButton("Browse")
      self.browse_button_gps.setCheckable(True)
      self.browse_button_gps.toggle()
      self.browse_button_gps.clicked.connect(lambda:self.selectFile('gps'))
      self.browse_button_gps.setFixedWidth(75)

      self.next_tab_button = MyPushButton("Next tab")
      self.next_tab_button.setCheckable(True)
      self.next_tab_button.toggle()
      self.next_tab_button.clicked.connect(self.validate)
      self.next_tab_button.setFixedWidth(100)

      # Open log file in append mode
      self.logFile = open('InertialSensorUtils_NRTSIM.log','a')

      # QProcess object for external app
      self.process = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process.readyRead.connect(self.dataReady)

      self.process.readyReadStandardOutput.connect(self.readyReadStandardOutput)
      self.process.readyReadStandardError.connect(self.readyReadStandardError)

      # Just to prevent accidentally running multiple times
      # Disable the button when process starts, and enable it when it finishes
      self.process.started.connect(self.showStarted)
      self.process.finished.connect(self.showDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

   def dataReady(self):
      self.process.setReadChannel(QtCore.QProcess.StandardOutput);

      self.logFile.write('\n')
      while (self.process.canReadLine()):
         current_line = str(self.process.readLine())
         # self.logOutput.appendText(current_line)
         self.logFile.write(current_line)
      # } while (self.process.canReadLine())..

      self.logFile.flush()

   def readyReadStandardOutput(self):
      stdOutputStr = str(self.process.readAllStandardOutput())

      self.logFile.write('\n' + stdOutputStr)
      self.logFile.flush()

   def readyReadStandardError(self):
      self.processError = True

      self.logFile.write('\n')
      errorLog = str(self.process.readAllStandardError())

      self.logFile.write(errorLog)
      self.logFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith('Status: DONE')):
         self.timer.stop()
         return
      # } if (self.lbl_status.text()..

      self.step = self.step + 1

      self.lbl_status.setText("Status: Doing.. Time elapsed: " + str(self.step) + " seconds")

   def doAction(self):
      if self.timer.isActive():
         self.timer.stop()
      else:
         self.step = 0
         self.timer.start(1000, self)
      # } if self.timer.isActive()..

   def showStarted(self):
      self.lbl_status.setText('Status: Doing.. please wait')
      self.logFile.write('\nStatus: Started the process... please wait')
      self.doAction()

   def showDone(self):
      print(' ******** in showDone *********** ')

      if (self.processError):
         logMsg = 'ERROR.. Please check NRTSIM log file.'
      else:
         # Look in config file to see if there were any errors logged for timestamp of last comamnd sent to QProcess
         errorMsg = None

         user_config = "inertial_sensor_errors_" + self.submit_timestamp_no_spaces_spl_chr + ".cfg"

         config = ConfigParser.ConfigParser()

         if (os.path.exists(user_config)):
            config.read(user_config)

            if config.has_section("errors"):
               if config.has_option("errors", "message"):
                  errorMsg = config.get("errors", "message")
               # } if config.has_option("errors"..
            # } if config.has_section("errors")..

            # Remove the temporary cfg file for that timestamp
            os.remove(user_config)
         # } if os.path.exists(user_config)..

         if (errorMsg != None):
            logMsg = 'ERROR: ' + errorMsg
         else:
            logMsg = 'DONE.. Time taken: ' + str(self.step) + ' seconds'
         # } if (errorMsg != None)..
      # } if (self.processError)..

      self.lbl_status.setText('Status: ' + logMsg)
      self.logFile.write('\nStatus: ' + logMsg)
      
      # Reset processError flag for next call
      self.processError = False
      self.step = 0
      self.timer.stop()
      self.logFile.flush()

   def clearStatusText(self):
      self.lbl_status.setText("Status:")
      # self.logOutput.clear()

   def onDeviceChange(self, state):
      if (state == 0):  # GX5-45
	 self.device_name = 'GX5-45'
      elif (state == 1): # GX5-25
	 self.device_name = 'GX5-25'
      # } if (state == 0)..

   def onFWVersionChange(self, state):
      if (state == 0):  # fw1128
      	 self.fw_version = '1128'
      elif (state == 1): # fw1129
	 self.fw_version = '1129'
      # } if (state == 0)..

   def processPitchRoll(self, state):
      if (state == 0): # None
	 self.pitch_roll_aid = 0
      elif (state == 1): # Gravity
	 self.pitch_roll_aid = 1
      # } if (state == 0)..

   def processAltitudeAid(self, state):
      if (state == 0): # None
	 self.altitude_aid = 0
      elif (state == 1): # Pressure Altimeter
	 self.altitude_aid = 1
      # } if (state == 0)..

   def processHeadingAid(self, state):
      if (state == 0): # None
	 self.heading_aid = 0
      elif (state == 1): # Internal Mag
	 self.heading_aid = 1
      elif (state == 2): # Internal GNSS Vel Vector
	 self.heading_aid = 2
      elif (state == 3): # External Heading Msgs
	 self.heading_aid = 3
      elif (state == 4): # Internal GNSS Vel Vector and Mag
	 self.heading_aid = 4
      elif (state == 5): # Internal GNSS Vel Vector and Ext Heading Msgs
	 self.heading_aid = 5
      elif (state == 6): # Internal Mag and Ext Heading Msgs
	 self.heading_aid = 6
      elif (state == 7): # Internal GNSS Vel Vector and Mag and Ext Heading Msgs
	 self.heading_aid = 7
      # } if (state == 0)..
   
   def processGNSSSource():
      if (state == 0): # Internal GNSS
	 self.gnss_source = 1
      elif (state == 1):	 
	 self.gnss_source = 2
      # } if (state == 0)..
      
   def setHeading(self, b):
      if (b == self.radiob_manual_init and b.isChecked()):
         self.radiob_auto_init.setChecked(False)
	 
         self.edt_heading.setStyleSheet("background-color: white;");
         self.edt_heading.setText('0.0')
         self.edt_heading.setReadOnly(False)

         self.edt_pitch.setStyleSheet("background-color: white;");
         self.edt_pitch.setText('0.0')
         self.edt_pitch.setReadOnly(False)

         self.edt_roll.setStyleSheet("background-color: white;");
         self.edt_roll.setText('0.0')
         self.edt_roll.setReadOnly(False)
	 
      elif (b == self.radiob_auto_init and b.isChecked()):
         self.radiob_manual_init.setChecked(False)
	 
         self.edt_heading.setStyleSheet("background-color: #E0E0E0;");
         self.edt_heading.setText('')
         self.edt_heading.setReadOnly(True)
	 
         self.edt_pitch.setStyleSheet("background-color: #E0E0E0;");
         self.edt_pitch.setText('')
         self.edt_pitch.setReadOnly(True)

         self.edt_roll.setStyleSheet("background-color: #E0E0E0;");
         self.edt_roll.setText('')
         self.edt_roll.setReadOnly(True)

      # } if (b == self.radiob_auto_init..
   
   def enable_fw_version(self, b):
      if (b == self.radiob_developer and b.isChecked()):
	 self.cmbox_fw_version.setEnabled(False)
	 
      elif (b == self.radiob_customer and b.isChecked()):
	 self.cmbox_fw_version.setEnabled(True)

   def __layout(self):

      self.h0box = QtGui.QHBoxLayout()
      self.h0box.addWidget(self.lbl_space_small)
      self.h0box.addWidget(self.lbl_title)
      self.h0box.addWidget(self.lbl_space_xlarge)

      self.hDeveloperBox = QtGui.QHBoxLayout()
      self.hDeveloperBox.addWidget(self.radiob_developer)
      self.hDeveloperBox.addWidget(self.radiob_customer)

      self.h12box = QtGui.QHBoxLayout()
      self.h12box.addLayout(self.hDeveloperBox)
      self.h12box.addWidget(self.lbl_space_small)
      self.h12box.addWidget(self.lbl_device_type)
      self.h12box.addWidget(self.cmbox_device_type)
      self.h12box.addWidget(self.lbl_space_small)
      
      self.h12box.addWidget(self.lbl_fw_version)
      self.h12box.addWidget(self.cmbox_fw_version)

      self.h12Lbox = QtGui.QHBoxLayout()
      self.h12Lbox.addLayout(self.h12box)

      self.h22box = QtGui.QHBoxLayout()
      self.h22box.addWidget(self.lbl_imu_filename)
      self.h22box.addWidget(self.edt_imu_filename)
      self.h22box.addWidget(self.browse_button_imu)
      self.h22box.addWidget(self.lbl_space_resizable_filler2)

      self.h23box = QtGui.QHBoxLayout()
      self.h23box.addWidget(self.lbl_gps_filename)
      self.h23box.addWidget(self.edt_gps_filename)
      self.h23box.addWidget(self.browse_button_gps)
      self.h23box.addWidget(self.lbl_space_resizable_filler2)
      
      self.vNRTSIMFirstColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_accel_bias)
      self.vNRTSIMFirstColumnBox.addWidget(self.chkbx_estimate_gyro_bias)
      
      self.vNRTSIMSecondColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMSecondColumnBox.addWidget(self.chkbx_enable_mag_hard_auto_cal)
      self.vNRTSIMSecondColumnBox.addWidget(self.chkbx_enable_mag_soft_auto_cal)
      
      self.vNRTSIMThirdColumnBox = QtGui.QVBoxLayout()
      self.vNRTSIMThirdColumnBox.addWidget(self.chkbx_estimate_accel_SF)
      self.vNRTSIMThirdColumnBox.addWidget(self.chkbx_estimate_gyro_SF)
      
      self.hNRTSIMOptionsBox = QtGui.QHBoxLayout()
      self.hNRTSIMOptionsBox.addWidget(self.lbl_space_small)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMFirstColumnBox)
      self.hNRTSIMOptionsBox.addWidget(self.lbl_space_small)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMSecondColumnBox)
      self.hNRTSIMOptionsBox.addWidget(self.lbl_space_small)
      self.hNRTSIMOptionsBox.addLayout(self.vNRTSIMThirdColumnBox)

      self.v12box = QtGui.QVBoxLayout()
      self.v12box.addLayout(self.h12Lbox)
      self.v12box.addLayout(self.h22box)
      self.v12box.addLayout(self.h23box)
      self.v12box.setAlignment(QtCore.Qt.AlignLeft)

      self.h1box = QtGui.QHBoxLayout()
      # self.h1box.addLayout(self.v11box)
      self.h1box.addLayout(self.v12box)

      self.h5box = QtGui.QHBoxLayout()
      self.h5box.addWidget(self.next_tab_button)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.h0box)
      self.vbox.addLayout(self.h1box)
      self.vbox.addLayout(self.hNRTSIMOptionsBox)
      self.vbox.addLayout(self.h5box)

      self.setLayout(self.vbox)

      # *******************************************
      
      # self.hInitBox = QtGui.QHBoxLayout()  # layout for the central widget
      # widget = QtGui.QWidget(self)  # central widget
      # widget.setLayout(layout)
      
      # ********* Number Group **************
      # number_group = QtGui.QButtonGroup(widget) # Number group
      # number_group = QtGui.QButtonGroup() # Number group
      
      # r0 = QtGui.QRadioButton("0")
      # number_group.addButton(r0)
      # number_group.addButton(self.radiob_auto_init)
      
      # r1 = QtGui.QRadioButton("1")
      # number_group.addButton(r1)
      # number_group.addButton(self.radiob_manual_init)
     
      # self.hInitBox.addWidget(self.radiob_auto_init)
      # self.hInitBox.addWidget(self.radiob_manual_init)

      # layout.addWidget(r0)
      # layout.addWidget(r1)

      # ******************************************* 

      # container.setStyleSheet("background-color: #CCE5FF;");
      
      # self.hInitBox.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319; border: 1px solid #330019;")
      # self.setStyleSheet("background-color: #CCE5FF;");

   def selectFile(self, which_one):
      theInputDir = ""

      user_config = os.getcwd() + "/inertial_sensor.cfg"

      config = ConfigParser.ConfigParser()
      config.read(user_config)
      
      if (which_one == 'imu'):
      	 keyToUse = 'imu_dir'
	 keyInputDir = 'imuinputdir'
      else:
	 keyToUse = 'gps_dir'
	 keyInputDir = 'gpsinputdir'
      # } if (which_one == 'imu')..
      
      if config.has_section(keyToUse):
         # if an entry exists then add the value to the form
         if config.has_option(keyToUse, keyInputDir):
            theInputDir = config.get(keyToUse, keyInputDir)
         # } if config.has_option(keyToUse, keyInputDir)..
      # } if config.has_section(keyToUse)..

      filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', theInputDir, '*.*')

      if filename:
         (inputDirName, fin_filename) = os.path.split(str(filename))
	 
	 if (which_one == 'imu'):
            self.edt_imu_filename.setText(filename)
	 elif (which_one == 'gps'):
	    self.edt_gps_filename.setText(filename)
	 # } if (which_one == 'imu')..
	    
         if not config.has_section(keyToUse):
            config.add_section(keyToUse)
         # } if not config.has_section(keyToUse)..

         config.set(keyToUse, keyInputDir, inputDirName)
          
         # if not os.getcwd().exists(configFile):
         with open("inertial_sensor.cfg", 'w') as f:
            config.write(f)
         # } with open("inertial_sensor.cfg"..
      # } if filename..

   def validate(self):
      error_msg = ''
      
      # ********* TEST ONLY ***********
      self.edt_imu_filename.setText('U:/Lord/Python_Sandbox/Vehicle_Logs/2017_06_06_Fritz/3DM-GX5-45 6251.60131 Data Log 6-6-2017 8.50.43 AM_IMU_Log_nrtsim.csv')
      self.edt_gps_filename.setText('U:/Lord/Python_Sandbox/Vehicle_Logs/2017_06_06_Fritz/3DM-GX5-45 6251.60131 Data Log 6-6-2017 8.50.43 AM_GPS_Log_nrtsim.csv')
      
      if (self.edt_imu_filename.text() == ''):
         error_msg += 'IMU File name cannot be empty\n'
      elif (self.edt_gps_filename.text() == ''):
         error_msg += 'GPS File name cannot be empty\n'
      # } if (self.edt_imu_filename.text() == '')..

      command_line = ''

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
         return
      else:
	 if (0):
   	    self.autoinit = 0
            if (self.radiob_auto_init.isChecked()):
               self.autoinit = 1
            # } if (self.radiob_auto_init...
         # } if (0)..
	 
	 self.estaccelbias = 0
	 if (self.chkbx_estimate_accel_bias.checkState() == QtCore.Qt.Checked):
	    self.estaccelbias = 1 
	 # } if (self.chkbx_estimate_accel_bias..

	 self.estgyrobias = 0
	 if (self.chkbx_estimate_gyro_bias.checkState() == QtCore.Qt.Checked):
	    self.estgyrobias = 1 
	 # } if (self.chkbx_estimate_gyro_bias..

	 self.estaccelSF = 0
	 if (self.chkbx_estimate_accel_SF.checkState() == QtCore.Qt.Checked):
	    self.estaccelSF = 1 
	 # } if (self.chkbx_estimate_accel_SF..

	 self.estgyroSF = 0
	 if (self.chkbx_estimate_gyro_SF.checkState() == QtCore.Qt.Checked):
	    self.estgyroSF = 1 
	 # } if (self.chkbx_estimate_gyro_SF..

	 self.automagcalhard = 0
	 if (self.chkbx_enable_mag_hard_auto_cal.checkState() == QtCore.Qt.Checked):
	    self.automagcalhard = 1 
	 # } if (self.chkbx_enable_mag_hard_auto_cal..
	 
	 self.automagcalsoft = 0
	 if (self.chkbx_enable_mag_soft_auto_cal.checkState() == QtCore.Qt.Checked):
	    self.automagcalsoft = 1 
	 # } if (self.chkbx_enable_mag_soft_auto_cal..
	 
	 # ****************************
         # TBD: Open new tab for second set of input options...
	 # ****************************
	 
	 self.parent_obj.switchToNRTSIMNextTab()

      # } if (error_msg != '')..

      return

# ---------------------------------------------------

