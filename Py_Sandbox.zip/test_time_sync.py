import visa
import numpy
from gpstime import *

from time import sleep           #sleep
from time import time  #import time library

rm = visa.ResourceManager()

# inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

# print(' ********* inst.query: ' + str(inst.query("*IDN?")))
# print(' ********* query SOUR:SCEN:SENS:DAT? ')

print("****** SOUR:SCEN:CONT?")
print(str(inst.query("SOUR:SCEN:CONT?")))

str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

print(' ********* RESPONSE: ' + str_scen_running)

cnt = 0

if (str_scen_running[0:5] == 'START'):
   while(cnt < 15):
       str_runtime = "%s" %(str(inst.query("SOUR:SCEN:RUN?")))
       print('******* str_runtime : ' + str_runtime)
       runtime = numpy.double(str_runtime)

       cnt = cnt + 1

       inst.query("*OPC?")

