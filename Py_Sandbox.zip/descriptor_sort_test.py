gps_default_cols_dict = {"8109":"1", "8108":"2", "8103":"3", "8105":"4", "8104":"5", "8106":"6", "8107":"7", "810A":"8", "810D":"9", "810B":"10" }

if (0):
    gps_output_order = []

    gps_output_order.append("8103")
    gps_output_order.append("8109")
    gps_output_order.append("8105")

    print(' ********* BEFORE SORT: ' )

    for g in gps_output_order:
      print(' *** g = ' + g)

    gps_output_order.sort()

    print(' ********* AFTER SORT: ' )

    for g in gps_output_order:
      print(' *** g = ' + g)

gps_output_order = []

# gps_output_order.append(gps_default_cols_dict["8103"])
# gps_output_order.append(gps_default_cols_dict["8109"])
# gps_output_order.append(gps_default_cols_dict["8105"])

gps_output_order.append(gps_default_cols_dict["8105"])
gps_output_order.append(gps_default_cols_dict["8106"])
gps_output_order.append(gps_default_cols_dict["8103"])
gps_output_order.append(gps_default_cols_dict["8104"])
gps_output_order.append(gps_default_cols_dict["8109"])

print(' ********* USING DICT: BEFORE SORT: ' )

if (0):
   for g in gps_output_order:
     print(' *** g = ' + g)

   gps_output_order.sort()

   print(' ********* AFTER SORT: ' )

   for g in gps_output_order:
     print(' *** g = ' + g)

gps_output_order_minus_d = []

gps_output_order_minus_d.append("4")
# gps_output_order_minus_d.append("6")
# gps_output_order_minus_d.append("3")
# gps_output_order_minus_d.append("5")
gps_output_order_minus_d.append("1")

gps_output_order_in_log = []

gps_output_order_in_log.append("3")
gps_output_order_in_log.append("1")
gps_output_order_in_log.append("4")

print(' ********* IN LOG FILE:' )

for g in gps_output_order_in_log:
  print(' *** g = ' + g)

# print(' ********* USING MIP MON SELECTIONS: BEFORE SORT: ' )
print(' ********* USING MINUS D: BEFORE SORT: ' )

gps_output_order_final = []

for g in gps_output_order_minus_d:
  print(' *** g = ' + g)
  if (g in gps_output_order_in_log):
     gps_output_order_final.append(g)

print(' ********* FINAL: BEFORE SORT: ' )

for g in gps_output_order_final:
  print(' *** g = ' + g)

gps_output_order_final.sort()

print(' ********* FINAL: AFTER SORT: ' )

for g in gps_output_order_final:
  print(' *** g = ' + g)

# gps_default_cols_dict = {"8109":"1", "8108":"2", "8103":"3", "8105":"4", "8104":"5", "8106":"6", "8107":"7", "810A":"8", "810D":"9", "810B":"10" }

print (' ************ gps_default_cols_dict[8105] = ' + gps_default_cols_dict["8105"])

my_dict = {"errorcode": "404-001", "message": "A Sensor name was used that doesn't exist (Sensor: GX4-45-2)."}

print (' ************ my_dict[errorcode] = ' + my_dict["errorcode"])

