from PyQt4.QtCore import *
from PyQt4.QtGui import *

class AppForm(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        self.create_main_frame()

    def fill_item(item, value):
      item.setExpanded(True)
      if type(value) is dict:
        for key, val in sorted(value.iteritems()):
          child = QTreeWidgetItem()
          child.setText(0, unicode(key))
          item.addChild(child)
          fill_item(child, val)
      elif type(value) is list:
        for val in value:
          child = QTreeWidgetItem()
          item.addChild(child)
          if type(val) is dict:
            child.setText(0, '[dict]')
            fill_item(child, val)
          elif type(val) is list:
            child.setText(0, '[list]')
            fill_item(child, val)
          else:
            child.setText(0, unicode(val))
          child.setExpanded(True)
      else:
        child = QTreeWidgetItem()
        child.setText(0, unicode(value))
        item.addChild(child)

    def fill_widget(widget, value):
      widget.clear()
      fill_item(widget.invisibleRootItem(), value)

    def create_main_frame(self):
        page = QWidget()

        self.button = QPushButton('joy', page)
        self.edit1 = QLineEdit()
        self.edit2 = QLineEdit()

        vbox1 = QVBoxLayout()
        vbox1.addWidget(self.edit1)
        vbox1.addWidget(self.edit2)
        vbox1.addWidget(self.button)
        page.setLayout(vbox1)
        self.setCentralWidget(page)

        self.connect(self.button, SIGNAL("clicked()"), self.clicked)

    def clicked(self):
        QMessageBox.about(self, "My message box", "Text1 = %s, Text2 = %s" % (
            self.edit1.text(), self.edit2.text()))



if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = AppForm()
    form.show()
    app.exec_()
