P = py.sys.path;

if (count(P,'U:/Lord/Python_HIL_Sim_From_File') == 0)
    insert(P, int32(0), 'U:/Lord/Python_HIL_Sim_From_File');
end

if (count(P,'U:/Lord/Python_HIL_Sim_From_File') == 0)
    insert(P, int32(0), 'U:/Lord/Python_HIL_Sim_From_File');
end
