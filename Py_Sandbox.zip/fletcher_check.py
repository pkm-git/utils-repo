# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

def fletcher_check16(packet_bytes):
 """Some Information Here"""
 if(len(packet_bytes)==0):
  return bytearray([])

 #force into bytearray
 packet_bytes = bytearray(packet_bytes)

 sum1 = 0
 sum2 = 0

 for byte in packet_bytes:
  sum1 += byte
  sum2 += sum1

 sum1 = sum1%0x100
 sum2 = sum2%0x100

 return bytearray([sum1,sum2])

def fletcher_check8(packet_bytes):
 """Some Information Here"""
 if(len(packet_bytes)==0):
  return bytearray([])

 #force into bytearray
 packet_bytes = bytearray(packet_bytes)

 sum1 = 0
 sum2 = 0

 for byte in packet_bytes:
  sum1 += byte
  sum2 += sum1

 sum1 = sum1%0x100
 sum2 = sum2%0x100

 return bytearray([sum1,sum2])

