import os, sys
import ConfigParser
from datetime import datetime
from PyQt4 import QtCore, QtGui
from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

from sensor_cloud_utils import *
from sensor_cloud_api import *
from csv_to_sensor_cloud import *
from mip_binary_to_csv_or_sensor_cloud import *
from novatel_binary_to_csv_or_sensor_cloud import *

class MyLogFileFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyLogFileFormWidget, self).__init__(parent)
      self.parent_obj = parent
      self.processError = False

      self.setFixedSize(550,250)

      self.__controls()
      self.__layout()

   def closeEvent(self, event):
      print "Closing MyLogFileFormWidget window"

      self.outputFile.close()

      super(MyLogFileFormWidget, self).closeEvent(event)

   def __controls(self):

      self.lbl_title = QtGui.QLabel("Inertial Sensor Utils")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000; border: 1px solid #330019;");
      self.lbl_title.setFixedWidth(200)
      self.lbl_title.setFixedHeight(25)

      self.lbl_filename = QtGui.QLabel("Binary Filename:")
      self.lbl_filename.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_filename = MyLineEdit()
      self.edt_filename.setStyleSheet("background-color: white;");
      # self.edt_filename.setFixedWidth(300)

      self.lbl_desired_actions = QtGui.QLabel("Desired Action(s):")
      self.lbl_desired_actions.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_sensor_name = MyLineEdit()
      self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
      self.edt_sensor_name.setFixedWidth(200)
      self.edt_sensor_name.setReadOnly(True)

      self.lbl_descriptor_filter_or_csv_object = QtGui.QLabel("Descriptor Filter:")
      self.lbl_descriptor_filter_or_csv_object.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_descriptor_filter_or_csv_object_help = QtGui.QLabel("[Optional: Ex: 8012800C810981038105]")
      self.lbl_descriptor_filter_or_csv_object_help.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_descriptor_filter_or_csv_object = MyLineEdit()
      self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;");
      self.edt_descriptor_filter_or_csv_object.setFixedWidth(150)

      self.lbl_device_id = QtGui.QLabel("Device ID:")
      self.lbl_device_id.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_device_id = MyLineEdit()
      self.edt_device_id.setStyleSheet("background-color: #E0E0E0;");
      if (self.parent_obj.sensor_cloud_enabled == True):
         self.edt_device_id.setText(self.parent_obj.device_id)
      self.edt_device_id.setFixedWidth(200)
      self.edt_device_id.setReadOnly(True)

      self.lbl_key = QtGui.QLabel("Key:")
      self.lbl_key.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_key = MyLineEdit()
      self.edt_key.setStyleSheet("background-color: #E0E0E0;");
      if (self.parent_obj.sensor_cloud_enabled == True and self.parent_obj.key != None):
         self.edt_key.setText(self.parent_obj.key)
      self.edt_key.setReadOnly(True)
      self.edt_key.setFixedWidth(400)

      self.lbl_input_specs = QtGui.QLabel("Input Spec:")
      self.lbl_input_specs.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_file_type = QtGui.QLabel("File Type:")
      self.lbl_file_type.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.cmbox_file_type = MyComboBox('File')
      self.cmbox_file_type.setFixedWidth(70)
      self.cmbox_file_type.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_file_type.currentIndexChanged.connect(self.switchParseCSVToLoad)

      self.lbl_device_type_used = QtGui.QLabel("Device Type Used:")
      self.lbl_device_type_used.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.cmbox_device_type_used = MyComboBox('Device')
      self.cmbox_device_type_used.setFixedWidth(70)
      self.cmbox_device_type_used.setStyleSheet("background-color: #E0E0E0;");

      self.chkbx_parse_to_csv = MyCheckBox('Parse to CSV')
      self.chkbx_parse_to_csv.setChecked(False)
      self.chkbx_parse_to_csv.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.chkbx_load_csv = MyCheckBox('Load CSV')
      self.chkbx_load_csv.setChecked(False)
      self.chkbx_load_csv.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_load_csv.hide()

      self.chkbx_upload_to_sensor_cloud = MyCheckBox('Upload to Sensor Cloud')
      self.chkbx_upload_to_sensor_cloud.setChecked(False)
      self.chkbx_upload_to_sensor_cloud.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_upload_to_sensor_cloud.stateChanged.connect(self.enableSensorCloudFields)

      self.browse_button = QtGui.QPushButton("Browse")
      self.browse_button.setCheckable(True)
      self.browse_button.toggle()
      self.browse_button.clicked.connect(self.selectFile)
      self.browse_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #E1C4B8; border: 1px solid #330019; padding: 5px;");
      self.browse_button.setFixedWidth(100)

      self.submit_button = QtGui.QPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(self.validate)
      self.submit_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");
      self.submit_button.setFixedWidth(100)

      self.home_button = QtGui.QPushButton("Home/Logout")
      self.home_button.setCheckable(True)
      self.home_button.toggle()
      self.home_button.clicked.connect(self.parent().switchToModuleSelect)
      self.home_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");
      self.home_button.setFixedWidth(100)

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(450)
      self.lbl_status.setFixedHeight(25)

      self.clear_status_text_button = QtGui.QPushButton("Clear Status Text")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");
      self.clear_status_text_button.setFixedWidth(120)

      # self.logOutput = QtGui.QPlainTextEdit()
      # self.logOutput = QtGui.QTextEdit()
      # self.logOutput.setReadOnly(True)
      # self.logOutput.setStyleSheet("font-weight: bold; font-size: 12px; background-color: #F2CFC0");

      # Open log file in append mode
      self.outputFile = open('InertialSensorUtils_UploadSensor.log','a')

      # QProcess object for external app
      self.process = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process.readyRead.connect(self.dataReady)

      self.process.readyReadStandardOutput.connect(self.readyReadStandardOutput)
      self.process.readyReadStandardError.connect(self.readyReadStandardError)

      # Just to prevent accidentally running multiple times
      # Disable the button when process starts, and enable it when it finishes
      self.process.started.connect(self.showStarted)
      self.process.finished.connect(self.showDone)

      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(60)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(90)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(110)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

   def dataReady(self):
      self.process.setReadChannel(QtCore.QProcess.StandardOutput);

      self.outputFile.write('\n')
      while (self.process.canReadLine()):
         current_line = str(self.process.readLine())
         # self.logOutput.appendText(current_line)
         self.outputFile.write(current_line)

      self.outputFile.flush()

   def readyReadStandardOutput(self):
      # cursor = self.logOutput.textCursor()
      # cursor.movePosition(cursor.End)
      stdOutputStr = str(self.process.readAllStandardOutput())
      # cursor.insertText(stdOutputStr)
      # self.logOutput.ensureCursorVisible()

      self.outputFile.write('\n' + stdOutputStr)
      self.outputFile.flush()

      # self.outputFile.write('\n')
      # current_line = str(self.process.readAllStandardOutput())
      # self.logOutput.appendText(current_line)
      # self.outputFile.write(current_line)
      # self.outputFile.flush()

   def readyReadStandardError(self):
      self.processError = True

      self.outputFile.write('\n')
      print(' ************* in readyReadStandardError, will get error log msg')
      errorLog = str(self.process.readAllStandardError())

      print(' ************* in readyReadStandardError, errorLog = ' + errorLog)

      # self.logOutput.appendText(errorLog)
      self.outputFile.write(errorLog)
      self.outputFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith('Status: DONE')):
         self.timer.stop()
         return

      self.step = self.step + 1

      self.lbl_status.setText("Status: Doing.. Time elapsed: " + str(self.step) + " seconds")

   def doAction(self):
      if self.timer.isActive():
         self.timer.stop()
      else:
         self.step = 0
         self.timer.start(1000, self)

   def showStarted(self):
      self.lbl_status.setText('Status: Doing.. please wait')
      self.outputFile.write('\nStatus: Started the process... please wait')
      self.doAction()

   def showDone(self):
      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked and not self.processError):
         self.parent_obj.loaded_sensor_list = False

      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked or \
         self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):
         if (self.processError):
            logMsg = 'ERROR.. Please check Upload Sensor log file.'
         else:
            logMsg = 'DONE.. Time taken: ' + str(self.step) + ' seconds'

         self.lbl_status.setText('Status: ' + logMsg)
         self.outputFile.write('\nStatus: ' + logMsg)

      # Reset processError flag for next call
      self.processError = False
      self.step = 0
      self.timer.stop()
      self.outputFile.flush()

      # If both Upload to Sensor Cloud and Load CSV check-boxes are checked, it means
      # we have completed the Upload to Sensor Cloud task now, and need to load CSV and
      # display the tree structure in the new tab called 'CSV Data'.  Wait for a couple of
      # seconds so that the status field displays status of the Upload to Sensor Cloud task
      # and then switch to the CSV data tab
      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked and \
          self.chkbx_load_csv.checkState() == QtCore.Qt.Checked):
          sleep(2)
          self.parent_obj.switchToCSVDataTab()

   def clearStatusText(self):
      self.lbl_status.setText("Status:")
      # self.logOutput.clear()

   def enableSensorCloudFields(self, state):
      if state == QtCore.Qt.Checked:
         self.edt_sensor_name.setStyleSheet("background-color: white;");
         self.edt_sensor_name.setReadOnly(False)
      else:
         self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
         self.edt_sensor_name.setReadOnly(True)
         self.edt_sensor_name.setText('')

   def switchParseCSVToLoad(self, state):
      if (state == 0):
         self.chkbx_parse_to_csv.show()
         self.chkbx_load_csv.hide()
         self.lbl_filename.setText('Binary Filename:')

         self.lbl_descriptor_filter_or_csv_object.setText('Descriptor Filter:')
         self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional: Ex: 8012800C810981038105]')

      elif (state == 1):
         self.chkbx_parse_to_csv.hide()
         self.chkbx_load_csv.show()
         self.lbl_filename.setText('CSV Filename:')

         self.lbl_descriptor_filter_or_csv_object.setText('CSV Object Name:')
         self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional: Defaults to CSV File name]')

   def __layout(self):

      self.h0box = QtGui.QHBoxLayout()
      self.h0box.addWidget(self.lbl_space_large)
      self.h0box.addWidget(self.lbl_title)
      self.h0box.addWidget(self.lbl_space_large)
      self.h0box.addWidget(self.home_button)
      self.h0box.addWidget(self.lbl_space_small)

      # Create self.v11box:
      self.v11box = QtGui.QVBoxLayout()
      self.v11box.addWidget(self.lbl_input_specs)
      self.v11box.addWidget(self.lbl_filename)
      self.v11box.addWidget(self.lbl_descriptor_filter_or_csv_object)
      self.v11box.addWidget(self.lbl_desired_actions)

      if (self.parent_obj.sensor_cloud_enabled == True):
         self.v11box.addWidget(self.lbl_sensor_name)
         self.v11box.addWidget(self.lbl_device_id)
         if (self.parent_obj.key != None):
            self.v11box.addWidget(self.lbl_key)

      # Create self.v12box:
      self.h12box = QtGui.QHBoxLayout()
      self.h12box.addWidget(self.lbl_space_xsmall)
      self.h12box.addWidget(self.lbl_file_type)
      self.h12box.addWidget(self.cmbox_file_type)
      self.h12box.addWidget(self.lbl_space_small)
      self.h12box.addWidget(self.lbl_device_type_used)
      self.h12box.addWidget(self.cmbox_device_type_used)
      self.h12box.addWidget(self.lbl_space_medium)

      self.h12Lbox = QtGui.QHBoxLayout()
      self.h12Lbox.addLayout(self.h12box)
      self.h12Lbox.addWidget(self.lbl_space_small)

      self.h22box = QtGui.QHBoxLayout()
      self.h22box.addWidget(self.edt_filename)
      self.h22box.addWidget(self.browse_button)
      self.h22box.addWidget(self.lbl_space_small)

      self.h32box = QtGui.QHBoxLayout()
      self.h32box.addWidget(self.edt_descriptor_filter_or_csv_object)
      self.h32box.addWidget(self.lbl_descriptor_filter_or_csv_object_help)

      self.h42box = QtGui.QHBoxLayout()
      self.h42box.addWidget(self.lbl_space_xsmall)
      self.h42box.addWidget(self.chkbx_parse_to_csv)
      self.h42box.addWidget(self.chkbx_load_csv)
      if (self.parent_obj.sensor_cloud_enabled == True):
         self.h42box.addWidget(self.chkbx_upload_to_sensor_cloud)
         self.h42box.addWidget(self.lbl_space_small)
      else:
         self.h42box.addWidget(self.lbl_space_small)

      self.h42Lbox = QtGui.QHBoxLayout()
      self.h42Lbox.addLayout(self.h42box)
      self.h42Lbox.addWidget(self.lbl_space_medium)

      self.v12box = QtGui.QVBoxLayout()
      self.v12box.addLayout(self.h12Lbox)
      self.v12box.addLayout(self.h22box)
      self.v12box.addLayout(self.h32box)
      self.v12box.addLayout(self.h42Lbox)

      if (self.parent_obj.sensor_cloud_enabled == True):
         self.v12box.addWidget(self.edt_sensor_name)
         self.v12box.addWidget(self.edt_device_id)
         if (self.parent_obj.key != None):
            self.v12box.addWidget(self.edt_key)

      self.h1box = QtGui.QHBoxLayout()
      self.h1box.addLayout(self.v11box)
      self.h1box.addLayout(self.v12box)

      self.h5box = QtGui.QHBoxLayout()
      self.h5box.addWidget(self.lbl_space_medium)
      self.h5box.addWidget(self.clear_status_text_button)
      self.h5box.addWidget(self.submit_button)
      self.h5box.addWidget(self.lbl_space_small)

      self.h6box = QtGui.QHBoxLayout()
      self.h6box.addWidget(self.lbl_space_small)
      self.h6box.addWidget(self.lbl_status)
      self.h6box.addWidget(self.lbl_space_small)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.h0box)
      self.vbox.addLayout(self.h1box)
      self.vbox.addLayout(self.h5box)
      self.vbox.addLayout(self.h6box)
      # self.vbox.addWidget(self.logOutput)

      # self.vbox.setSizeConstraint(QtGui.QLayout.SetFixedSize);

      self.setLayout(self.vbox)

   # QLayoutItem *child;
   # while ((child = layout->takeAt(0)) != 0) {
     # ...
     # delete child;

   def clearLayout(self, layout):
      if layout is not None:
         while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
               widget.deleteLater()
            else:
               self.clearLayout(item.layout())
            # } if widget is not None..
         # } while layout.count()..
      # } if layout is not None..

   # def sizeHint(self):
      # return QtCore.QSize(600, 300);

   def selectFile(self):
      theInputDir = ""

      user_config = os.getcwd() + "/inertial_sensor.cfg"

      config = ConfigParser.ConfigParser()
      config.read(user_config)

      if config.has_section("dirs"):
         # if an entry exists then add the value to the form
         if config.has_option("dirs", "inputdir"):
            theInputDir = config.get("dirs", "inputdir")

      filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', theInputDir, '*.*')

      if filename:
         self.edt_filename.setText(filename)

         (inputDirName, fin_filename) = os.path.split(str(filename))

         config = ConfigParser.ConfigParser()

         if not config.has_section("dirs"):
            config.add_section("dirs")

         config.set("dirs", "inputdir", inputDirName)

         # if not os.getcwd().exists(configFile):
         with open("inertial_sensor.cfg", 'w') as f:
            config.write(f)

   def validate(self):
      error_msg = ''

      if (self.edt_filename.text() == ''):
         error_msg += 'File name cannot be empty\n'

      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
         if (self.edt_sensor_name.text() == ''):
            error_msg += 'Sensor name cannot be empty\n'

      sensor_label = None

      parse_to_csv_action = ''
      load_csv_only = False
      command_line = ''

      if (self.cmbox_file_type.currentText() == 'Binary'):

         if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):
            parse_to_csv_action += 'p'

         if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
            parse_to_csv_action += 'u'

         parse_to_csv_action += 'f'

         if (self.cmbox_device_type_used.currentText() == 'MIP'):
            parse_to_csv_action += 'mb'
         else:
            parse_to_csv_action += 'nb'

         # print(' ******* parse_to_csv_action = ' + parse_to_csv_action)
         desired_desc = self.edt_descriptor_filter_or_csv_object.text()

         if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

            command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
            command_line += '" -sv "' + self.parent_obj.server
            command_line += '" -t "' + self.parent_obj.token
            command_line += '" -s "' + str(self.edt_sensor_name.text())
            command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action + ' -i "'
            command_line += str(self.edt_filename.text())
            if (desired_desc != ''):
               command_line += '" -dd "' + desired_desc
            command_line += '"'
         elif (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):

            command_line = 'python sensor_cloud_utils.pyc -i "'
            command_line += str(self.edt_filename.text())
            command_line += '" -a ' + parse_to_csv_action
            if (desired_desc != ''):
               command_line += ' -dd "' + desired_desc + '"'
         elif (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

            command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
            command_line += '" -sv "' + self.parent_obj.server
            command_line += '" -t "' + self.parent_obj.token
            command_line += '" -s "' + str(self.edt_sensor_name.text())
            command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename.text()) + '"'
            if (desired_desc != ''):
               command_line += ' -dd "' + desired_desc + '"'
         else:
            error_msg += 'Must check at least one check-box: Parse to CSV or Sensor Cloud'
         # } if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked)..

      elif (self.cmbox_file_type.currentText() == 'CSV'):

         if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
            parse_to_csv_action += 'u'

         parse_to_csv_action += 'f'

         if (self.cmbox_device_type_used.currentText() == 'MIP'):
            parse_to_csv_action += 'mcsv'
         else:
            parse_to_csv_action += 'ncsv'

         if (self.chkbx_load_csv.checkState() == QtCore.Qt.Checked and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
            command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
            command_line += '" -sv "' + self.parent_obj.server
            command_line += '" -t "' + self.parent_obj.token
            command_line += '" -s "' + str(self.edt_sensor_name.text())
            command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename.text()) + '"'

         elif (self.chkbx_load_csv.checkState() == QtCore.Qt.Checked):

            load_csv_only = True

         elif (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

            command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
            command_line += '" -sv "' + self.parent_obj.server
            command_line += '" -t "' + self.parent_obj.token
            command_line += '" -s "' + str(self.edt_sensor_name.text())
            command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename.text()) + '"'

         else:
            error_msg += 'Must check at least one check-box: Load CSV or Sensor Cloud'
         # } if (self.chkbx_load_csv.checkState() == QtCore.Qt.Checked)..

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
      # elif (command_line != ''):
      else:
         # subprocess.call(command_line)

         self.outputFile.write('\n\n--------------------------------------------------------------------------\n')
         self.outputFile.write(' ******** Starting File processing command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
         # self.outputFile.write(' ******** Starting File processing command log at local date/time: ' + str(datetime.now()) + ' ' + str(local_time.tzname) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')

         msg_txt = ''
         binary_input = False

         # If action string ends with 'b', it means input file is binary
         if (parse_to_csv_action[-1] == 'b'):
            msg_txt = 'BINARY INPUT: '
            binary_input = True
         else:
            msg_txt = 'CSV INPUT: '

         # If action string begins with 'p', it means user wants to parse binary
         # If second character of action string is 'u', it means user want to upload to sensor cloud
         if (load_csv_only):
            msg_txt += 'ONLY LOAD CSV CHECKED'
         elif (parse_to_csv_action[:2] == 'pu'):
            msg_txt += 'BOTH CHECKED'
         elif (parse_to_csv_action[:1] == 'u'):
            msg_txt += 'UPLOAD TO SENSOR CLOUD CHECKED'
         elif (parse_to_csv_action[:1] == 'p' and parse_to_csv_action[1] != 'u'):
            msg_txt += 'ONLY PARSE TO CSV CHECKED'

         print('\n ***** ' + msg_txt + ': ' + command_line)
         self.outputFile.write('\n ***** ' + msg_txt + ': ' + command_line)

         if (load_csv_only):
            self.outputFile.flush()
            self.parent_obj.switchToCSVDataTab()
         else:
            # run the process
            self.process.start(command_line)

      return

# ---------------------------------------------------

