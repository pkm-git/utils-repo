import sys
import shlex, subprocess

from subprocess_fn import *
from PyQt4 import QtCore, QtGui

class MainWindow(QtGui.QMainWindow):

   def __init__(self, parent=None):
      super(MainWindow, self).__init__(parent)
      self.form_widget = MyFormWidget(self)
      self.setGeometry(400, 300, 500, 150)
      self.setWindowTitle("Sensor Cloud Utils")
      # self.setWindowIcon(QtGui.QIcon('submit_button.gif'))
      self.setStyleSheet("background-color: #BCE4C6;");

      _widget = QtGui.QWidget()
      _layout = QtGui.QVBoxLayout(_widget)
      _layout.addWidget(self.form_widget)
      self.setCentralWidget(_widget)

# ---------------------------------------------------
class MyFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyFormWidget, self).__init__(parent)
      self.__controls()
      self.__layout()

   def __controls(self):
   
      labelText = "Sensor Cloud Utils"
      
      self.lbl_title = QtGui.QLabel(labelText)
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");
      
      self.lbl_filename = QtGui.QLabel("Binary file name:")
      self.lbl_filename.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.edt_filename = MyLineEdit()
      self.edt_filename.setStyleSheet("background-color: white;");

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.edt_sensor_name = MyLineEdit()
      self.edt_sensor_name.setStyleSheet("background-color: white;");

      self.lbl_device_id = QtGui.QLabel("Device ID:")
      self.lbl_device_id.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.edt_device_id = MyLineEdit()
      self.edt_device_id.setStyleSheet("background-color: white;");

      self.lbl_key = QtGui.QLabel("Key:")
      self.lbl_key.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.edt_key = MyLineEdit()
      self.edt_key.setStyleSheet("background-color: white;");

      # self.cmbox = MyComboBox()

      self.chkbx_parse_to_csv = MyCheckBox('Parse to CSV')
      self.chkbx_parse_to_csv.setChecked(False)
      self.chkbx_parse_to_csv.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.chkbx_upload_to_sensor_cloud = MyCheckBox('Upload to Sensor Cloud')
      self.chkbx_upload_to_sensor_cloud.setChecked(False)
      self.chkbx_upload_to_sensor_cloud.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      
      self.browse_button = QtGui.QPushButton("Browse")
      self.browse_button.setCheckable(True)
      self.browse_button.toggle()
      self.browse_button.clicked.connect(self.selectFile)
      # self.browse_button.setStyleSheet("background-color: #F3B267;");
      #self.browse_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #660000; background-color: #F3B267;");
      self.browse_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #E1C4B8; border: 1px solid #330019; padding: 5px;");

      self.submit_button = QtGui.QPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(self.parseBinaryFile)
      # self.submit_button.setGeometry(340, 300, 250, 100)
      # self.submit_button.setStyleSheet("background-color: #CFC3F0;");
      # self.submit_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #660000; background-color: #CFC3F0;");
      self.submit_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.lbl_left_space = QtGui.QLabel()
      self.lbl_right_space = QtGui.QLabel()

   def __layout(self):
      # -------
      # HBox's:
      # -------
      self.h12box = QtGui.QHBoxLayout()
      self.h12box.addWidget(self.edt_filename)
      self.h12box.addWidget(self.browse_button)
      
      self.h6box = QtGui.QHBoxLayout()
      self.h6box.addWidget(self.lbl_left_space)
      self.h6box.addWidget(self.submit_button)
      self.h6box.addWidget(self.lbl_right_space)

      # -------
      # VBox's:
      # -------
      self.h0box = QtGui.QHBoxLayout()
      self.h0box.addWidget(self.lbl_left_space)
      self.h0box.addWidget(self.lbl_title)
      self.h0box.addWidget(self.lbl_right_space)
      
      self.v1box = QtGui.QVBoxLayout()
      self.v1box.addLayout(self.h0box)
      
      self.v21box = QtGui.QVBoxLayout()
      self.v21box.addWidget(self.lbl_filename)
      self.v21box.addWidget(self.chkbx_parse_to_csv)
      self.v21box.addWidget(self.lbl_sensor_name)
      self.v21box.addWidget(self.lbl_device_id)
      self.v21box.addWidget(self.lbl_key)

      self.v22box = QtGui.QVBoxLayout()
      self.v22box.addLayout(self.h12box)
      self.v22box.addWidget(self.chkbx_upload_to_sensor_cloud)
      self.v22box.addWidget(self.edt_sensor_name)
      self.v22box.addWidget(self.edt_device_id)
      self.v22box.addWidget(self.edt_key)
      
      self.h2vbox = QtGui.QHBoxLayout()
      self.h2vbox.addLayout(self.v21box)
      self.h2vbox.addLayout(self.v22box)
      
      self.v2box = QtGui.QVBoxLayout()
      self.v2box.addLayout(self.h2vbox)
      
      self.v3box = QtGui.QVBoxLayout()
      self.v3box.addLayout(self.h6box)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.v1box)
      self.vbox.addLayout(self.v2box)
      self.vbox.addLayout(self.v3box)

      self.setLayout(self.vbox)

   def selectFile(self):
      self.edt_filename.setText(QtGui.QFileDialog.getOpenFileName())

   def parseBinaryFile(self):

      if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
         # command_line = 'python sensor_cloud_utils.py -d "' + str(self.edt_device_id.text()) + '" -s "' + str(self.edt_sensor_name.text()) + '" -k "' + str(self.edt_key.text()) + '" -r 100 -rt "HERTZ" -a pufmb -i "' + str(self.edt_filename.text()) + '"'
         command_line = 'python sensor_cloud_utils.py -d "' + str(self.edt_device_id.text())
         command_line += '" -s "' + str(self.edt_sensor_name.text())
         command_line += '" -k "' + str(self.edt_key.text())
         command_line += '" -r 100 -rt "HERTZ" -a pufmb -i "'
         command_line += str(self.edt_filename.text()) + '"'
         print(' ******* BOTH CHECKED: command_line = ' + command_line)

      elif (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):
         command_line = 'python sensor_cloud_utils.py -i "'
         command_line += str(self.edt_filename.text())
         command_line += '" -a pfmb'
         print(' ******* ONLY PARSE TO CSV CHECKED: command_line = ' + command_line)

      elif (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
         command_line = 'python sensor_cloud_utils.py -d "' + str(self.edt_device_id.text()) + '" -s "' + str(self.edt_sensor_name.text()) + '" -k "' + str(self.edt_key.text()) + '" -r 100 -rt "HERTZ" -a ufmb -i "' + str(self.edt_filename.text()) + '"'
         print(' ******* UPLOAD TO SENSOR CLOUD CHECKED : command_line = ' + command_line)
      # } if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked)..

      else:
         # QMessageBox.about(self, "Msg Box", "Text1 = %s, Text2 = %s" % (self.edit1.text(), self.edit2.text()))
         QtGui.QMessageBox.about(self, "Msg Box", "Must check at least one check-box: Parse to CSV or Sensor Cloud")
         return

      subprocess.call(command_line)

      return

# ---------------------------------------------------
class MyLineEdit(QtGui.QLineEdit):

    def __init__(self):
       super(MyLineEdit, self).__init__()

       self.initUI()

    def initUI(self):

       self.move(60, 60)
       self.textChanged[str].connect(self.onChanged)
       self.show()

    def onChanged(self, text):
       self.adjustSize()

# ---------------------------------------------------
class MyCheckBox(QtGui.QCheckBox):

    def __init__(self, lbl):
       super(MyCheckBox, self).__init__(lbl)

       self.initUI()

    def initUI(self):

       self.move(20, 20)
       self.toggle()
       # self.stateChanged.connect(self.changeTitle)

       self.show()

    # def changeTitle(self, state):

       # if state == QtCore.Qt.Checked:
          # self.setText('Parse to CSV Checked')
       # else:
          # self.setText('Parse to CSV Unchecked')

# ---------------------------------------------------
class MyComboBox(QtGui.QComboBox):

    def __init__(self):
       super(MyComboBox, self).__init__()

       self.initUI()

    def initUI(self):

       self.addItem("Ubuntu")
       self.addItem("Mandriva")
       self.addItem("Fedora")
       self.addItem("Red Hat")
       self.addItem("Gentoo")

       self.move(50, 50)

       self.activated[str].connect(self.onActivated)

       self.show()

    def onActivated(self, text):
       self.adjustSize()

# ---------------------------------------------------

def main():
    app = QtGui.QApplication(sys.argv)

    win = MainWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    # sys.exit(main())
    main()
