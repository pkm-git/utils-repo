import sys

from time import time  #import time library
from time import sleep         #sleep
from time import clock  #import time library

def main_line(argv):
    """Main line program"""

    # start_time = time()
    start_time = clock()
   
    if (0):
       deltaT = 0.0004
       for i in range(50):
           sleep(deltaT)
           sleep(0.002 - deltaT)
           # sleep(0.0019)

    for i in range(200):
        sleep(0.002)

    # end_time = time()
    end_time = clock()
   
    print('\n************* Timing test: Time elapsed = ' + str(end_time - start_time));

if(__name__ == "__main__"):
  main_line(sys.argv)

