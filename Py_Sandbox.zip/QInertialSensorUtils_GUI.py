# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import re
import os
import operator
import sys
import shlex, subprocess

from time import sleep         #sleep

from PyQt4 import QtCore, QtGui
# from PyQt4.QtCore import *
# from PyQt4.QtGui import *

# from QInertialSensorUtils_GUI_LogFileFormWidget import *
from QInertialSensorUtils_GUI_LogFileFormWidget_LordInternal import *
from QInertialSensorUtils_GUI_NRTSIM_TopLevelWidget import *
from QInertialSensorUtils_GUI_DeviceConnect_TopWidget import *
from QInertialSensorUtils_GUI_BatchProcessWidget import *
from QInertialSensorUtils_GUI_ModuleSelectWidget import *
from QInertialSensorUtils_GUI_SensorListWidget import *
from QInertialSensorUtils_GUI_CommonWidgets import *

# from sensor_cloud_utils import *
from sensor_cloud_utils_LordInternal import *
from csv_to_sensor_cloud import *
from mip_binary_to_csv_or_sensor_cloud import *
from novatel_binary_to_csv_or_sensor_cloud import *

class InertialSensorUtilsControllerWindow(QtGui.QMainWindow):

   def __init__(self, parent=None):
      super(InertialSensorUtilsControllerWindow, self).__init__(parent)

      # Trying to force including spawned Python process file, 'sensor_cloud_utils.py' into the .exe
      print('Starting Inertial Sensor Utils GUI...')

      self.form_widget = None
      self.user_login_form_widget = MySensorUtilsModuleSelectWidget(self)
      self.user_login_form_widget.vbox.setSizeConstraint(QtGui.QLayout.SetFixedSize);

      self.csv_tree_widget = None
      self.sensor_list_widget = None
      self.batch_process_form_widget = None
      self.device_list_top_level_widget = None

      self.device_id = None
      self.key = None

      self.server = None
      self.token = None

      self.username = None
      self.password = None

      self.tabs = None

      self.sensor_cloud_enabled = False
      self.loaded_sensor_list = False
      self.loading_sensor_list = False
      self.loaded_batch_sensor_list = False
      self.loading_batch_sensor_list = False
      self.loading_device_list = False
      self.loaded_device_list = False
      
      # self.device_list_enabled = False
      self.device_list_enabled = True

      # self.lord_internal_user = False
      self.lord_internal_user = True

      # Don't get the sensor list from cloud every time the application loads because
      # the user may not want to use that feature and getting the list from cloud takes some time.
      # So, update Sensor List from SensorCloud only on demand, i.e. when
      # (A) user clicks on Upload to SensorCloud checkbox, or
      # (B) clicks the View Sensor tab, or
      # (C) clicks on the Batch Process tab
      # The flag is called 'sensor_list_needs_update', which defaults to True, so that we are waiting for the user to do one of the above and
      # when he/she does that, we trigger an update of sensor list from cloud and store the new list in a class attribute called 'sensorList'.
      # Once we get the list from cloud, we set this flag to False, and use the sensorList attribute if the user does any of the above 3 actions
      # (instead of getting a sensor list from cloud in each of the 3 cases).
      # Keep doing so until the user makes changes to the sensors [i.e. adds/deletes one/more sensor(s)], when this flag is again set to True
      self.sensor_list_needs_update = True

      # Sensor List always has at least one element, namely the empty field where the user can type in a new sensor name
      self.sensorList = []
      self.sensorList.append('')

      self.sensor_list_dict = {}

      self.plot_tab_push_button_dict = {}

      central_widget = QtGui.QStackedWidget()
      central_widget.addWidget(self.user_login_form_widget)
      self.setCentralWidget(central_widget)

      self.setWindowTitle("Inertial Sensor Utils / Parse Binary File")
      self.setStyleSheet("background-color: #BCE4C6;");
      # self.setStyleSheet("background-color: #CDE1D2;");
      # self.setStyleSheet("background-color: #C5E1CD;");
      # self.setStyleSheet("background-color: #CCE5FF;");

      self.csv_load_cnt = 0

      self.show()

   def onChangeTab(self, i):
      if (self.device_list_enabled):
         if (self.lord_internal_user):
            device_list_tab_index = 2
         else:   
            device_list_tab_index = 1
         # } if (self.lord_internal_user)..
  
         if (not self.loading_device_list and not self.loaded_device_list and i == device_list_tab_index):
            # reply = QtGui.QMessageBox.question(self, "Msg Box", 'Device List takes a few seconds to load first time... Continue?', \
                                                  # QtGui.QMessageBox.Yes, QtGui.QMessageBox.No)
            
            # if (reply == QtGui.QMessageBox.Yes):
               self.loading_device_list = True
    
               self.device_list_top_level_widget = MyDeviceConnectTopWidget(self)
               self.loaded_device_list = True
       
               self.tabs.removeTab(device_list_tab_index)
               self.tabs.insertTab(device_list_tab_index, self.device_list_top_level_widget, "Device List")
       
               self.tabs.setCurrentIndex(device_list_tab_index)
               self.loading_device_list = False
            # } if (reply == QtGui.QMessageBox.Yes)..   
         # } if (not self.loading_device_list..
      # } if (self.device_list_enabled)..

      if (self.sensor_cloud_enabled):
         # print(' ****** in onChangeTab, i = ' + str(i) + ' self.tabs.indexOf(self.sensor_list_widget) = ' + str(self.tabs.indexOf(self.sensor_list_widget)) + ', self.tabs.indexOf(self.batch_process_form_widget) = ' + str(self.tabs.indexOf(self.batch_process_form_widget)))

         sensor_list_tab_index = 2
         batch_process_tab_index = 3

         if (self.lord_internal_user):
            if (self.device_list_enabled):
               sensor_list_tab_index = 3
               batch_process_tab_index = 4
            else:
               sensor_list_tab_index = 2
               batch_process_tab_index = 3
            # } if (self.device_list_enabled)..
         elif (self.device_list_enabled):
            sensor_list_tab_index = 2
            batch_process_tab_index = 3
         # } if (self.lord_internal_user)..
 
         # if (not self.loading_batch_sensor_list and not self.loaded_sensor_list and i == 1):
         if (not self.loading_sensor_list and not self.loaded_sensor_list and i == sensor_list_tab_index):
            self.loading_sensor_list = True

            self.sensor_list_widget = MySensorListWidget(self)
            self.loaded_sensor_list = True

            self.tabs.removeTab(sensor_list_tab_index)
            # self.tabs.insertTab(sensor_list_tab_index, self.sensor_list_widget, "View Sensors")
            self.tabs.insertTab(sensor_list_tab_index, self.sensor_list_widget, "Sensors on Cloud")

            self.tabs.setCurrentIndex(sensor_list_tab_index)
            self.loading_sensor_list = False

         # elif (not self.loading_sensor_list and not self.loaded_batch_sensor_list and i == 2):
         if (not self.loading_batch_sensor_list and not self.loaded_batch_sensor_list and i == batch_process_tab_index):
            self.loading_batch_sensor_list = True

            self.batch_process_form_widget = MyBatchProcessFormWidget(self)
            self.loaded_batch_sensor_list = True

            self.tabs.removeTab(batch_process_tab_index)
            self.tabs.insertTab(batch_process_tab_index, self.batch_process_form_widget, "Batch Process")

            self.tabs.setCurrentIndex(batch_process_tab_index)
            self.loading_batch_sensor_list = False
         # } if (not self.loading_batch_sensor_list and..
      
   def updateSensorList(self):
      # if (self.sensor_list_needs_update):
         sensors = {}
         sensors = getSensors(self.server, self.token, self.device_id)

         self.sensor_list_dict = sensors
         self.sensor_list_needs_update = False

         self.sensorList = []
         self.sensorList.append('')

         sensors.keys().sort()

         if (sensors != None and len(sensors) > 0):
            self.sensorList.extend(sensors.keys())
         # } if (sensors != None and len(sensors) > 0)..
      # } if (self.sensor_list_needs_update)..

   def switchToCSVDataTab(self):
      self.csv_load_cnt += 1
      
      print(' ***** in swithToCSVDataTab, self.csv_load_cnt = ' + str(self.csv_load_cnt))
      
      in_file_name = self.form_widget.edt_filename.text()

      csv_object_name = self.form_widget.edt_descriptor_filter_or_csv_object.text()
      if (csv_object_name == ''):
         csv_object_name = None
      
      gps_week = 0
      
      if (self.form_widget.cmbox_device_type_used.currentText() == 'SBG'):
         gps_week = int(self.form_widget.edt_gps_week.text())
      # } if (self.form_widget.cmbox_device_type_used..
      
      # For first CSV file being loaded, create new MySensorListWidget
      # For subsequent CSV file loads, append to the existing MySensorListWidget
      if (self.csv_load_cnt == 1):
         self.csv_tree_widget = MySensorListWidget(self, str(in_file_name), csv_object_name, gps_week)
         self.tabs.addTab(self.csv_tree_widget, "CSV Data")
      else:
         self.csv_tree_widget.append_tree_obj_from_file(str(in_file_name), csv_object_name, gps_week)
      # } if (self.csv_load_cnt == 1)..

      self.tabs.setCurrentIndex(self.tabs.indexOf(self.csv_tree_widget))

   # Logout
   def switchToModuleSelect(self):
      self.device_id = None
      self.key = None

      self.server = None
      self.token = None

      self.username = None
      self.password = None
      
      self.close_process(True)
      
      self.csv_load_cnt = 0
      self.loaded_sensor_list = False
      self.loading_sensor_list = False
      self.sensor_list_dict = {}
      self.sensor_list_needs_update = True
      self.sensor_list_widget = None
      
      self.loaded_batch_sensor_list = False
      self.loading_batch_sensor_list = False

      self.batch_process_form_widget = None
      self.device_list_top_level_widget = None
      
      self.loading_device_list = False
      self.loaded_device_list = False

      self.sensor_list_dict = None
      self.sensor_list_needs_update = False

      self.sensorList = []
      
      self.tabs = None

      self.sensor_cloud_enabled = False
      self.plot_tab_push_button_dict = {}

      self.user_login_form_widget = MySensorUtilsModuleSelectWidget(self)
      self.user_login_form_widget.vbox.setSizeConstraint(QtGui.QLayout.SetFixedSize);

      central_widget = QtGui.QStackedWidget()
      central_widget.addWidget(self.user_login_form_widget)
      self.setCentralWidget(central_widget)

      self.show()

   def closeEvent(self, event):
      print "Closing Inertial Sensor Utils GUI main window"

      self.close_process()
      
      super(InertialSensorUtilsControllerWindow, self).closeEvent(event)

   def close_process(self, fromLogout = False):

      print(' ***** in MAIN window close_process: fromLogout = ' + str(fromLogout))
      
      if (self.device_list_top_level_widget != None):
         self.device_list_top_level_widget.close_process()
      # } if (self.device_list_top_level_widget != None)..
      
   def switchToLogFileUtils(self):

      self.tabs = QtGui.QTabWidget()

      self.tabs.blockSignals(True) #just for not showing the initial message
      self.tabs.currentChanged.connect(self.onChangeTab)
      self.tabs.setObjectName("TabWidget")
      
      if (self.lord_internal_user):
         self.form_widget = MyLogFileFormWidget_LordInternal(self)
      else:
         self.form_widget = MyLogFileFormWidget(self)
      # } if (self.lord_internal_user)..
       
      self.form_widget.vbox.setSizeConstraint(QtGui.QLayout.SetFixedSize);

      self.loaded_sensor_list = False

      self.tabs.addTab(self.form_widget, "Main")
      
      if (self.lord_internal_user):
         self.nrtsim_top_level_widget = MyNRTSIMTopLevelWidget(self)
         self.tabs.addTab(self.nrtsim_top_level_widget, "NRTSIM")
      # } if (self.lord_internal_user)..

      if (self.device_list_enabled):
         dummy_widget = QtGui.QWidget()
         self.tabs.addTab(dummy_widget, "Device List")
      # } if (self.device_list_enabled)..

      if (self.sensor_cloud_enabled):
         dummy_widget = QtGui.QWidget()
         # self.tabs.addTab(dummy_widget, "View Sensors")
         self.tabs.addTab(dummy_widget, "Sensors on Cloud")

         dummy_widget = QtGui.QWidget()
         self.tabs.addTab(dummy_widget, "Batch Process")
      # } if (self.sensor_cloud_enabled)..

      central_widget = QtGui.QStackedWidget()
      central_widget.addWidget(self.tabs)
      self.setCentralWidget(central_widget)

      self.tabs.blockSignals(False) #now listen the currentChanged signal

   def refreshDeviceList(self):
      if (self.device_list_enabled):
         device_list_index = self.tabs.indexOf(self.device_list_top_level_widget)
 
         self.device_list_top_level_widget.close_process()
 
         self.tabs.removeTab(device_list_index)
      
         self.device_list_top_level_widget = MyDeviceConnectTopWidget(self)
       
         self.tabs.insertTab(device_list_index, self.device_list_top_level_widget, "Device List")

         self.tabs.setCurrentIndex(device_list_index)
      # } if (self.device_list_enabled)..

   def closeButton(self, b, csvDataTabIndex = 0):
      if (b == None):
         if (csvDataTabIndex > 0):
            # After removing a tab, adjust the tab index [key or value] in dictionaries for downstream plot tabs
            for bTmp in self.plot_tab_push_button_dict.keys():
               tmpTabIndex = self.plot_tab_push_button_dict[bTmp]

               if (tmpTabIndex > csvDataTabIndex):
                  self.plot_tab_push_button_dict[bTmp] = tmpTabIndex - 1
               # } if (tmpTabIndex > csvDataTabIndex)..
            # } for (bTmp in self.plot_tab_push_button_dict.keys())..

            self.tabs.removeTab(csvDataTabIndex)
         # } if (csvDataTabIndex > 0)..
      elif (b in self.plot_tab_push_button_dict):
         indexToRemove = self.plot_tab_push_button_dict[b]
         self.tabs.removeTab(indexToRemove)

         # After removing a tab, adjust the tab index [key or value] in dictionaries for downstream plot tabs
         for bTmp in self.plot_tab_push_button_dict.keys():
            tmpTabIndex = self.plot_tab_push_button_dict[bTmp]

            if (tmpTabIndex > indexToRemove):
               self.plot_tab_push_button_dict[bTmp] = tmpTabIndex - 1
            # } if (tmpTabIndex > indexToRemove)..
         # } for (bTmp in self.plot_tab_push_button_dict.keys())..

         self.plot_tab_push_button_dict.pop(b, None)
      # } if (b in self.plot_tab_push_button_dict)..
# ---------------------------------------------------
def main():
   app = QtGui.QApplication(sys.argv)
   win = InertialSensorUtilsControllerWindow()
   sys.exit(app.exec_())

if __name__ == '__main__':
    main()

