# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import numpy as np

def print_row(data_row_cnt, data_row, fout_csv_file):
      
   i = 0
   
   for v in data_row:
      i += 1
      try:
         # if (data_row_cnt  < 5):
	    # print(' ***** in print_row: i: ' + str(i) + ', will print value: ' + v)
	    
         if (v.strip() != '' and 'nan' not in v.strip().lower() and 'ind' not in v.strip().lower()):
	    if (i == 25):
	       if ('.' in v or 'e' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))        
               # } if ('.' in v)...
       	       break
	    elif ('.' in v or 'e' in v):
	       fout_csv_file.write('%14.8f,'%(float(v)))
   	    else:
	       fout_csv_file.write('%1d,'%(int(v)))
	    # } if (i == 25)..
	       
            # Print extra column value for computed GPS Week and GPS TOW using GPS Epoch Time
            if (i == gps_epoch_time_index+1):
	       # if (data_row_cnt < 5):
	          # print(' **** will compute gps_week from data_row[1] = ' + data_row[1])
     	       gps_week = long(float(data_row[1]))/604800
	       
	       # if (data_row_cnt < 5):
	          # print(' **** computed gps_week')
     	       gps_tow = float(data_row[1]) - gps_week * 604800
	       
	       # if (data_row_cnt < 5):
	          # print(' **** computed gps_tow')
	       
    	       # if (data_row_cnt < 5):
    	          # print(' **** data_row_cnt: ' + str(data_row_cnt) + ', gps_week = ' + str(gps_week) + ', gps_tow = ' + str(gps_tow))
               # } if (data_row_cnt < 5)..
	       
	       # if (data_row_cnt < 5):
	          # print(' **** will write gps_week, tow to file')
    	       
	       fout_csv_file.write('%1d,%14.8f,'%(gps_week, gps_tow))
	       
	       # if (data_row_cnt < 5):
	          # print(' **** wrote gps_week, tow to file')
    	    # } if (i == gps_epoch_time_index+1)..

         elif ('nan' in v.strip().lower() or 'ind' in v.strip().lower()):
	    if (i == len(data_row)):
	       fout_csv_file.write(v)
	    else:
	       fout_csv_file.write(v + ',')
            # } if (i == len(data_row))..	       
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..

      except TypeError:
         print(' ***** print_row: TypeError: at data_row_cnt = ' + str(data_row_cnt) + ', len(data_row) = ' + str(len(data_row)) + ', column: ' + str(i) + ', value: ' + str(v))
      
      except ValueError:
         if (data_row_cnt < 5):
            print(' ***** print_row: ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))

   # } for v in data_row..

   fout_csv_file.write('\n')
      
      
def process_csv_file(csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   prev_gps_week = 0
   
   for data_row in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         
         i = 0
         for c in data_row:
            i += 1
	    # print(' ***** i: ' + str(i) + ', will print header: ' + c)
            if (i == 25):
               fout_csv_file.write(c)
     	       break
   	    else:
               fout_csv_file.write(c + ',')
               
     	       if (i == gps_epoch_time_index+1):
     	          fout_csv_file.write('GPS Week,GPS TOW,')
               # } if (i == gps_epoch_time_index+1)..
	    # } if (i == 25)..   
         # } for c in data_row..   
         fout_csv_file.write('\n')
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
	 # if (data_row_cnt < 5):
	    # print(' ****** will call print_row using data_row_cnt = ' + str(data_row_cnt))
	 
	 print_row(data_row_cnt, data_row, fout_csv_file)

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in csvreader..
   

in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/Trajectory63.csv'

(fin_filepath, fin_filename) = os.path.split(in_file_name)

gps_epoch_time_index = 1

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_process_for_NRTSIM.csv"), "w")

fout_csv_file.write('DATA_START\n')

in_csvfile = open(in_file_name,'r')
csvreader = csv.reader(in_csvfile, delimiter=',')

process_csv_file(csvreader)
   
fout_csv_file.close()




