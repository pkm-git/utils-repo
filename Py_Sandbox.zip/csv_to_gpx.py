# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os
import csv
import gpxpy
import gpxpy.gpx

import calendar
import dateutil.parser

from datetime import datetime

import numpy as np

# NBR_OF_LEAP_SECONDS = 17 # (as of July 2016)
NBR_OF_LEAP_SECONDS_2016 = 17 # (as of July 2016)
NBR_OF_LEAP_SECONDS = 18 # (as of Jan 2017)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800

def getDateTimeFromISO8601String(s):
   d = dateutil.parser.parse(s)
   return d

def csv_to_gpx_fn(in_file_name, gps_week_col_nbr=2, gps_tow_col_nbr=3, lat_col_nbr = 4, lon_col_nbr = 5, ht_col_nbr = 6):

   if (in_file_name == None):
      print('Input file name cannot be empty')
      sys.exit()

   in_csvfile = open(in_file_name,'rUb')
   csvreader = csv.reader(in_csvfile, delimiter=',')

   (fin_filepath, fin_filename) = os.path.split(in_file_name)

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0

   gpx = gpxpy.gpx.GPX()

   # Create first track in our GPX:
   gpx_track = gpxpy.gpx.GPXTrack()
   gpx.tracks.append(gpx_track)

   # Create first segment in our GPX track:
   gpx_segment = gpxpy.gpx.GPXTrackSegment()
   gpx_track.segments.append(gpx_segment)
   
   leap_sec_to_use = NBR_OF_LEAP_SECONDS
   
   for row_item in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers == True):
         n_data_columns =  len(row_item)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

      elif(headers_found == True):
         data_row_cnt = data_row_cnt + 1

         if (len(row_item) > 0):

            gps_lat = row_item[lat_col_nbr-1]
            gps_lon = row_item[lon_col_nbr-1]
            gps_ht = row_item[ht_col_nbr-1]

            # coord_array.append((np.double(gps_lon), np.double(gps_lat), float(gps_ht)))

            gps_week = np.int32(row_item[gps_week_col_nbr-1])
            gps_tow = np.double(row_item[gps_tow_col_nbr-1])

            if (gps_week < 1930):
               leap_sec_to_use = NBR_OF_LEAP_SECONDS_2016
            # } if (gps_week < 1930)..

            gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
            utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - leap_sec_to_use + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

            datetime_from_unix = datetime.utcfromtimestamp(utc_sec_from_utc_epoch)

            gpx_segment.points.append(gpxpy.gpx.GPXTrackPoint(np.double(gps_lat), np.double(gps_lon), elevation=float(gps_ht), time=getDateTimeFromISO8601String(datetime_from_unix.isoformat())))

         # } if (len(row_item) > 0)..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(row_item) > 0 and row_item[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers == True)..
   # } for row_item in csvreader..

   fout_gpx = open(os.path.join(fin_filepath, fin_filename[:-4] + ".gpx"), "w")
   fout_gpx.write(gpx.to_xml())
   fout_gpx.close()
