#import libraries used
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_rt_usb_parse_thread import AsyncRTDataParser #Asynchronous RealTime (RT)
                                                        #data parsing thread

MIP_SYNC_BYTE1 = 0x75
MIP_SYNC_BYTE2 = 0x65

#Callback function for mip packet parser
def rt_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
  print("*********** Valid Packet Found")

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM4'
port_baud = 115200

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-p' and len(argv) > i+1):
  port_name = argv[i+1]
 elif(argv[i] == '-b' and len(argv) > i+1):
  port_baud = int(argv[i+1])

print('**********  PORT : '+ port_name);

# packet = bytearray([])
# packet.append(MIP_SYNC_BYTE1);
# packet.append(MIP_SYNC_BYTE2);
# packet.append(0x47);

# print "********* NAV-POSLLH packet_data: " + hexlify(packet_data).upper()

# print('********************** Packet: ' + hexlify(packet).upper())
# print('********************** Bytes read: ' + packet[0:3])

#Assign serial port object
port1 = serial.Serial(port_name, port_baud)

#Close port in case it was left open by other process
# port1.close()

#Set up rt packet response parser
# rt_parser = RTParser(10000, 0, rt_parser_callback)

#open specified port
# port1.open()

while port1.inWaiting():
 byte_reply = bytearray(port1.read(port1.inWaiting()))
 # byte_reply = bytearray(port1.read(6))
 # byte_reply = bytearray(port1.readline())
 # print ('************** in gx4_rt_debug, while loop: j = ' + str(j))
 print('************** in gx4_rt_debug, while loop')
 print('********************** Packet read: ' + hexlify(bytearray(byte_reply)).upper())

#set up background process to parse byte array coming from USB port
# background_data_update = AsyncRTDataParser(port1, rt_parser, 10000)
# background_data_update = AsyncRTDataParser(port1, 10000)

#start the response parsing thread
# background_data_update.start()

#sleep while waiting for response
# sleep(1)

#stop background response parsing thread
# background_data_update.stop()

#close port
port1.close()

