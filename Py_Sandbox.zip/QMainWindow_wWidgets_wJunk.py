import sys
from PyQt4 import QtCore, QtGui

class MainWindow(QtGui.QMainWindow):

    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.form_widget = MyFormWidget(self)
        _widget = QtGui.QWidget()
        _layout = QtGui.QVBoxLayout(_widget)
        _layout.addWidget(self.form_widget)
        self.setCentralWidget(_widget)

# ---------------------------------------------------
class MyFormWidget(QtGui.QWidget):

    def __init__(self, parent):
        super(MyFormWidget, self).__init__(parent)
        self.__controls()
        self.__layout()

    def __controls(self):
        self.label = QtGui.QLabel("Binary file name:")

        # self.txted = QtGui.QLineEdit()
        self.txted = MyLineEdit()

        self.lbled = QtGui.QLabel("Sensor Name:")

        # self.cmbox = QtGui.QComboBox()
        self.cmbox = MyComboBox()

    def __layout(self):
        self.vbox = QtGui.QVBoxLayout()
        self.hbox = QtGui.QHBoxLayout()
        self.h2Box = QtGui.QHBoxLayout()

        self.hbox.addWidget(self.label)
        self.hbox.addWidget(self.txted)

        self.h2Box.addWidget(self.lbled)
        self.h2Box.addWidget(self.cmbox)

        self.vbox.addLayout(self.hbox)
        self.vbox.addLayout(self.h2Box)
        self.setLayout(self.vbox)

# ---------------------------------------------------
# class MyLineEdit(QtGui.QWidget):
class MyLineEdit(QtGui.QLineEdit):

    def __init__(self):
        super(MyLineEdit, self).__init__()

        self.initUI()

    def initUI(self):

        # self.lbl = QtGui.QLabel(self)
        # qle = QtGui.QLineEdit(self)

        # qle.move(60, 100)
        self.move(60, 60)
      
        # self.lbl.move(60, 40)

        # qle.textChanged[str].connect(self.onChanged)
        self.textChanged[str].connect(self.onChanged)

        # self.setGeometry(100, 100, 280, 170)
        # self.setWindowTitle('QtGui.QLineEdit')
        self.show()

    def onChanged(self, text):
        # self.move(10, 10)
        self.adjustSize()
      
        # self.lbl.setText(text)
        # self.lbl.adjustSize()

# ---------------------------------------------------
# class MyComboBox(QtGui.QWidget):
class MyComboBox(QtGui.QComboBox):

    def __init__(self):
        super(MyComboBox, self).__init__()

        self.initUI()

    def initUI(self):

        # self.lbl = QtGui.QLabel("Ubuntu", self)

        # combo = QtGui.QComboBox(self)
        # combo.addItem("Ubuntu")
        # combo.addItem("Mandriva")
        # combo.addItem("Fedora")
        # combo.addItem("Red Hat")
        # combo.addItem("Gentoo")

        # combo.move(50, 50)

        self.addItem("Ubuntu")
        self.addItem("Mandriva")
        self.addItem("Fedora")
        self.addItem("Red Hat")
        self.addItem("Gentoo")
      
        self.move(50, 50)
      
        # self.lbl.move(50, 150)

        # combo.activated[str].connect(self.onActivated)
        self.activated[str].connect(self.onActivated)

        # self.setGeometry(300, 300, 300, 200)
        # self.setWindowTitle('QtGui.QComboBox')
        self.show()

    def onActivated(self, text):
        # self.move(50, 50)
        self.adjustSize()
      
        # self.lbl.setText(text)
        # self.lbl.adjustSize()

# ---------------------------------------------------

def main():
    app = QtGui.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    app.exec_()

if __name__ == '__main__':
    sys.exit(main())
