import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from QInertialSensorUtils_GUI_NRTSIM_FormWidget import *
from QInertialSensorUtils_GUI_NRTSIM_Tab2_Widget import *
from QInertialSensorUtils_GUI_NRTSIM_Tab3_Widget import *
from QInertialSensorUtils_GUI_NRTSIM_Tab4_Widget import *
from QInertialSensorUtils_GUI_NRTSIM_Tab5_Widget import *
from QInertialSensorUtils_GUI_NRTSIM_Tab6_Widget import *

from time import sleep         #sleep

# NRTSIM_DIR = '"U:/Lord/SourceCode_GX5_All/ISD2/COMMON/Kalman_Filter/Desktop C Sim/kalman_filter/Debug/'

class MyNRTSIMTopLevelWidget(QtGui.QMainWindow):

   def __init__(self, parent):
      super(MyNRTSIMTopLevelWidget, self).__init__(parent)
      self.parent_obj = parent
      self.processError = False
      self.submit_timestamp = ''
      self.submit_timestamp_no_spaces_spl_chr = ''

      # self.device_name = 'GX5-45'
      self.fw_version = '1165'
      
      self.tabs = QtGui.QTabWidget()
      
      self.noise_data = Noise_Data_Struct('GX5-45')
      
      self.nrtsim_form_widget = MyNRTSIMFormWidget(self)
      self.tabs.addTab(self.nrtsim_form_widget, "Input, EF Init")

      self.NRTSIM_Tab2 = MyNRTSIMTab2FormWidget(self)
      self.tabs.addTab(self.NRTSIM_Tab2, "EF Aiding/Auto-Adaptive")

      self.NRTSIM_Tab3 = MyNRTSIMTab3FormWidget(self)
      self.tabs.addTab(self.NRTSIM_Tab3, "EF Tracking")

      self.NRTSIM_Tab4 = MyNRTSIMTab4FormWidget(self)
      self.tabs.addTab(self.NRTSIM_Tab4, "Meas. Noise (R)")

      self.NRTSIM_Tab5 = MyNRTSIMTab5FormWidget(self)
      self.tabs.addTab(self.NRTSIM_Tab5, "Process Noise (Q)")

      self.NRTSIM_Tab6 = MyNRTSIMTab6FormWidget(self)
      self.tabs.addTab(self.NRTSIM_Tab6, "Mag Process Noise (Q)")
      
      self.tabs.setCurrentIndex(self.tabs.indexOf(self.nrtsim_form_widget))

      # central_widget = QtGui.QStackedWidget()
      # central_widget.addWidget(self.tabs)
      # self.setCentralWidget(central_widget)
      
      self.declare_spaces()

      self.submit_button = MyPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(self.validate)
      self.submit_button.setFixedWidth(100)

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(450)
      self.lbl_status.setFixedHeight(25)

      self.clear_status_text_button = MyPushButton("Clear Status Text")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setFixedWidth(140)
      
      self.h5box = QtGui.QHBoxLayout()
      self.h5box.addWidget(self.lbl_space_small)
      self.h5box.addWidget(self.clear_status_text_button)
      self.h5box.addWidget(self.submit_button)
      self.h5box.addWidget(self.lbl_space_small)

      self.h6box = QtGui.QHBoxLayout()
      self.h6box.addWidget(self.lbl_space_small)
      self.h6box.addWidget(self.lbl_status)
      self.h6box.addWidget(self.lbl_space_small)

      central_widget = QtGui.QWidget()
      
      central_layout = QtGui.QVBoxLayout()
      central_layout.addWidget(self.tabs)
      central_layout.addLayout(self.h5box)
      central_layout.addLayout(self.h6box)
      
      central_widget.setLayout(central_layout)
      
      self.setCentralWidget(central_widget)
      
      # self.tabs.setStyleSheet("background-color: #A2C3F3;");
      self.tabs.setStyleSheet("background-color: #ACCCFA;");
      # self.tabs.setStyleSheet("background-color: #F6D89C;");
      # self.tabs.setStyleSheet("background-color: #DECDF9;");
      
      self.tabs.blockSignals(False) #now listen the currentChanged signal

      # self.setFixedSize(575,300)
      # self.setFixedSize(575,275)
      # self.setFixedSize(610,275)
      self.setFixedSize(630,275)

      self.__controls()
      
   def closeEvent(self, event):
      print "Closing MyNRTSIMTopLevelWidget window"

      self.logFile.close()

      super(MyNRTSIMTopLevelWidget, self).closeEvent(event)
   
   def declare_spaces(self):
   
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)
      
   def __controls(self):

      self.lbl_title = QtGui.QLabel("NRTSIM")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(80)
      self.lbl_title.setFixedHeight(25)

      # Open log file in append mode
      self.logFile = open('InertialSensorUtils_NRTSIM.log','a')

      # QProcess object for external app
      self.process = QtCore.QProcess(self)

      self.process.readyReadStandardOutput.connect(self.readyReadStandardOutput)
      self.process.readyReadStandardError.connect(self.readyReadStandardError)

      # Just to prevent accidentally running multiple times
      # Disable the button when process starts, and enable it when it finishes
      self.process.started.connect(self.showStarted)
      self.process.finished.connect(self.showDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

   def dataReady(self):
      self.process.setReadChannel(QtCore.QProcess.StandardOutput);

      self.logFile.write('\n')
      while (self.process.canReadLine()):
         current_line = str(self.process.readLine())
         # self.logOutput.appendText(current_line)
         self.logFile.write(current_line)
      # } while (self.process.canReadLine())..

      self.logFile.flush()

   def readyReadStandardOutput(self):
      stdOutputStr = str(self.process.readAllStandardOutput())

      self.logFile.write('\n' + stdOutputStr)
      self.logFile.flush()

   def readyReadStandardError(self):
      self.processError = True

      self.logFile.write('\n')
      errorLog = str(self.process.readAllStandardError())

      self.logFile.write(errorLog)
      self.logFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith('Status: DONE')):
         self.timer.stop()
         return
      # } if (self.lbl_status.text()..

      self.step = self.step + 1

      self.lbl_status.setText("Status: Doing.. Time elapsed: " + str(self.step) + " seconds")

   def doAction(self):
      if self.timer.isActive():
         self.timer.stop()
      else:
         self.step = 0
         self.timer.start(1000, self)
      # } if self.timer.isActive()..

   def showStarted(self):
      self.lbl_status.setText('Status: Doing.. please wait')
      self.logFile.write('\nStatus: Started the process... please wait')
      self.doAction()

   def showDone(self):
      print(' ******** in showDone *********** ')

      if (self.processError):
         logMsg = 'ERROR.. Please check NRTSIM log file.'
      else:
         # Look in config file to see if there were any errors logged for timestamp of last comamnd sent to QProcess
         errorMsg = None

         user_config = "inertial_sensor_errors_" + self.submit_timestamp_no_spaces_spl_chr + ".cfg"

         config = ConfigParser.ConfigParser()

         if (os.path.exists(user_config)):
            config.read(user_config)

            if config.has_section("errors"):
               if config.has_option("errors", "message"):
                  errorMsg = config.get("errors", "message")
               # } if config.has_option("errors"..
            # } if config.has_section("errors")..

            # Remove the temporary cfg file for that timestamp
            os.remove(user_config)
         # } if os.path.exists(user_config)..

         if (errorMsg != None):
            logMsg = 'ERROR: ' + errorMsg
         else:
            logMsg = 'DONE.. Time taken: ' + str(self.step) + ' seconds'
         # } if (errorMsg != None)..
      # } if (self.processError)..

      self.lbl_status.setText('Status: ' + logMsg)
      self.logFile.write('\nStatus: ' + logMsg)
      
      # Reset processError flag for next call
      self.processError = False
      self.step = 0
      self.timer.stop()
      self.logFile.flush()

   def clearStatusText(self):
      self.lbl_status.setText("Status:")
      # self.logOutput.clear()

   def validate(self):
      error_msg = ''
      
      command_line = ''
      
      self.dev_root_dir = str(self.nrtsim_form_widget.edt_developer_root_folder.text()).strip().replace('\\', '/')
      self.imu_filename = self.nrtsim_form_widget.edt_imu_filename.text()
      self.gps_filename = self.nrtsim_form_widget.edt_gps_filename.text()
      self.fw_version = str(self.nrtsim_form_widget.cmbox_fw_version.currentText())
      self.veh_dyn_mode = self.NRTSIM_Tab2.veh_dyn_mode
      
      print(' ******** Top level: self.fw_version = ' + self.fw_version)
      print(' ******** Top level: self.veh_dyn_mode = ' + str(self.veh_dyn_mode))
      print(' ******** Top Level: self.imu_filename = ' + self.imu_filename)
      print(' ******** Top Level: self.gps_filename = ' + self.gps_filename)
      
      # ************ TEST ONLY ************
      # self.dev_root_dir = 'U:/Lord/SourceCode_GX5_All'
      # self.imu_filename = 'U:/Lord/Python_Sandbox/Vehicle_Logs/2017_06_06_Fritz/3DM-GX5-45 6251.60131 Data Log 6-6-2017 8.50.43 AM_IMU_Log_nrtsim_wHdr.csv'
      # self.gps_filename = 'U:/Lord/Python_Sandbox/Vehicle_Logs/2017_06_06_Fritz/3DM-GX5-45 6251.60131 Data Log 6-6-2017 8.50.43 AM_GPS_Log_nrtsim_wHdr.csv'
      
      # print(' ************** self.imu_filename = ' + self.imu_filename)
      print(' ************** self.dev_root_dir = ' + self.dev_root_dir)
      
      if (self.nrtsim_form_widget.radiob_custom_build.isChecked() and self.dev_root_dir == ''):
         error_msg += 'Developer Root Dir cannot be empty for Custom Build\n'
      elif (self.imu_filename == ''):
         error_msg += 'IMU File name cannot be empty\n'
      # elif (self.nrtsim_form_widget.device_name == 'GX5-45' and self.gps_filename == ''):
         # error_msg += 'GPS File name cannot be empty\n'
      # } if (self.imu_filename == '')..

      radio_dev_or_customer = self.nrtsim_form_widget.developer_button_group.checkedButton()
      self.developer_or_customer = self.nrtsim_form_widget.developer_button_group.id(radio_dev_or_customer)
      
      print(' *********** in NRTSIM Top Level widget, self.developer_or_customer = ' + str(self.developer_or_customer))

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
         return
      else:
         # ********* TAB 1 ************** 
         self.autoinit = 0
         if (self.nrtsim_form_widget.radiob_auto_init.isChecked()):
            self.autoinit = 1
         # } if (self.nrtsim_form_widget.radiob_auto_init...
   
         self.initHeading = 0
         self.initRoll = 0
         self.initPitch = 0
         self.manual_init_time_offset = 0.0
 
         if (self.nrtsim_form_widget.radiob_manual_init.isChecked()):
            self.initHeading = float(self.nrtsim_form_widget.edt_heading.text())
            self.initRoll = float(self.nrtsim_form_widget.edt_roll.text())
            self.initPitch = float(self.nrtsim_form_widget.edt_pitch.text())
            self.manual_init_time_offset = float(self.nrtsim_form_widget.edt_manual_init_time_offset.text())
         # } if (self.nrtsim_form_widget.radiob_manual_init...
 
         self.imu_data_rate_actual = int(self.nrtsim_form_widget.edt_imu_data_rate.text())

         # ********* TAB 2 ************** 
         self.mag_on = 0
         if (self.NRTSIM_Tab2.chkbx_mag_on.checkState() == QtCore.Qt.Checked):
            self.mag_on = 1 
         # } if (self.NRTSIM_Tab2.chkbx_mag_on..

         # ********* TAB 3 ************** 
         self.estaccelbias = 0
         if (self.NRTSIM_Tab3.chkbx_estimate_accel_bias.checkState() == QtCore.Qt.Checked):
            self.estaccelbias = 1 
         # } if (self.NRTSIM_Tab3.chkbx_estimate_accel_bias..

         self.estgyrobias = 0
         if (self.NRTSIM_Tab3.chkbx_estimate_gyro_bias.checkState() == QtCore.Qt.Checked):
            self.estgyrobias = 1 
         # } if (self.NRTSIM_Tab3.chkbx_estimate_gyro_bias..

         self.estaccelSF = 0
         if (self.NRTSIM_Tab3.chkbx_estimate_accel_SF.checkState() == QtCore.Qt.Checked):
            self.estaccelSF = 1 
         # } if (self.NRTSIM_Tab3.chkbx_estimate_accel_SF..

         self.estgyroSF = 0
         if (self.NRTSIM_Tab3.chkbx_estimate_gyro_SF.checkState() == QtCore.Qt.Checked):
            self.estgyroSF = 1 
         # } if (self.NRTSIM_Tab3.chkbx_estimate_gyro_SF..

         self.estGNSSAntOffset = 0
         if (self.NRTSIM_Tab3.chkbx_estimate_gnss_ant_offset.checkState() == QtCore.Qt.Checked):
            self.estGNSSAntOffset = 1 
         # } if (self.NRTSIM_Tab3.chkbx_estimate_gnss_ant_offset..

         self.automagcalhard = 0
         if (self.NRTSIM_Tab3.chkbx_enable_mag_hard_auto_cal.checkState() == QtCore.Qt.Checked):
            self.automagcalhard = 1 
         # } if (self.NRTSIM_Tab3.chkbx_enable_mag_hard_auto_cal..
         
         self.automagcalsoft = 0
         if (self.NRTSIM_Tab3.chkbx_enable_mag_soft_auto_cal.checkState() == QtCore.Qt.Checked):
            self.automagcalsoft = 1 
         # } if (self.NRTSIM_Tab3.chkbx_enable_mag_soft_auto_cal..

         self.enableVelZUPT = 0
         self.velZUPTThreshold = 0.0
         if (self.NRTSIM_Tab3.chkbx_enable_EF_Vel_ZUPT.checkState() == QtCore.Qt.Checked):
            self.enableVelZUPT = 1
            self.velZUPTThreshold = float(self.NRTSIM_Tab3.edt_threshold_vel.text())
         # } if (self.NRTSIM_Tab3.chkbx_enable_EF_Vel_ZUPT..

         self.enableAngRateZUPT = 0
         self.angRateZUPTThreshold = 0.0
         if (self.NRTSIM_Tab3.chkbx_enable_angular_rate_ZUPT.checkState() == QtCore.Qt.Checked):
            self.enableAngRateZUPT = 1 
            self.angRateZUPTThreshold = float(self.NRTSIM_Tab3.edt_threshold_ang_rate.text())
         # } if (self.NRTSIM_Tab3.chkbx_enable_angular_rate_ZUPT..

         # ********* TAB 4 ************** 
         self.mag_noise_x = 0.0
         if (self.NRTSIM_Tab4.edt_mag_noise_x.text() != ''):
            self.mag_noise_x = float(self.NRTSIM_Tab4.edt_mag_noise_x.text())

         self.mag_noise_y = 0.0
         if (self.NRTSIM_Tab4.edt_mag_noise_y.text() != ''):
            self.mag_noise_y = float(self.NRTSIM_Tab4.edt_mag_noise_y.text())

         self.mag_noise_z = 0.0
         if (self.NRTSIM_Tab4.edt_mag_noise_z.text() != ''):
            self.mag_noise_z = float(self.NRTSIM_Tab4.edt_mag_noise_z.text())

         self.grav_noise_x = 0.0
         if (self.NRTSIM_Tab4.edt_grav_noise_x.text() != ''):
            self.grav_noise_x = float(self.NRTSIM_Tab4.edt_grav_noise_x.text())

         self.grav_noise_y = 0.0
         if (self.NRTSIM_Tab4.edt_grav_noise_y.text() != ''):
            self.grav_noise_y = float(self.NRTSIM_Tab4.edt_grav_noise_y.text())

         self.grav_noise_z = 0.0
         if (self.NRTSIM_Tab4.edt_grav_noise_z.text() != ''):
            self.grav_noise_z = float(self.NRTSIM_Tab4.edt_grav_noise_z.text())
         
         self.pr_alt_noise = 0.0
         if (self.NRTSIM_Tab4.edt_pr_alt_noise.text() != ''):
            self.pr_alt_noise = float(self.NRTSIM_Tab4.edt_pr_alt_noise.text())

         # ********* TAB 5 ************** 
         self.accel_noise_x = 0.0
         if (self.NRTSIM_Tab5.edt_accel_noise_x.text() != ''):
            self.accel_noise_x = float(self.NRTSIM_Tab5.edt_accel_noise_x.text())

         self.accel_noise_y = 0.0
         if (self.NRTSIM_Tab5.edt_accel_noise_y.text() != ''):
            self.accel_noise_y = float(self.NRTSIM_Tab5.edt_accel_noise_y.text())

         self.accel_noise_z = 0.0
         if (self.NRTSIM_Tab5.edt_accel_noise_z.text() != ''):
            self.accel_noise_z = float(self.NRTSIM_Tab5.edt_accel_noise_z.text())

         self.accel_bias_beta_x = 0.0
         if (self.NRTSIM_Tab5.edt_accel_bias_beta_x.text() != ''):
            self.accel_bias_beta_x = float(self.NRTSIM_Tab5.edt_accel_bias_beta_x.text())

         self.accel_bias_beta_y = 0.0
         if (self.NRTSIM_Tab5.edt_accel_bias_beta_y.text() != ''):
            self.accel_bias_beta_y = float(self.NRTSIM_Tab5.edt_accel_bias_beta_y.text())

         self.accel_bias_beta_z = 0.0
         if (self.NRTSIM_Tab5.edt_accel_bias_beta_z.text() != ''):
            self.accel_bias_beta_z = float(self.NRTSIM_Tab5.edt_accel_bias_beta_z.text())

         self.accel_bias_noise_x = 0.0
         if (self.NRTSIM_Tab5.edt_accel_bias_noise_x.text() != ''):
            self.accel_bias_noise_x = float(self.NRTSIM_Tab5.edt_accel_bias_noise_x.text())

         self.accel_bias_noise_y = 0.0
         if (self.NRTSIM_Tab5.edt_accel_bias_noise_y.text() != ''):
            self.accel_bias_noise_y = float(self.NRTSIM_Tab5.edt_accel_bias_noise_y.text())

         self.accel_bias_noise_z = 0.0
         if (self.NRTSIM_Tab5.edt_accel_bias_noise_z.text() != ''):
            self.accel_bias_noise_z = float(self.NRTSIM_Tab5.edt_accel_bias_noise_z.text())

         self.gyro_noise_x = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_noise_x.text() != ''):
            self.gyro_noise_x = float(self.NRTSIM_Tab5.edt_gyro_noise_x.text())

         self.gyro_noise_y = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_noise_y.text() != ''):
            self.gyro_noise_y = float(self.NRTSIM_Tab5.edt_gyro_noise_y.text())

         self.gyro_noise_z = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_noise_z.text() != ''):
            self.gyro_noise_z = float(self.NRTSIM_Tab5.edt_gyro_noise_z.text())

         self.gyro_bias_beta_x = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_bias_beta_x.text() != ''):
            self.gyro_bias_beta_x = float(self.NRTSIM_Tab5.edt_gyro_bias_beta_x.text())

         self.gyro_bias_beta_y = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_bias_beta_y.text() != ''):
            self.gyro_bias_beta_y = float(self.NRTSIM_Tab5.edt_gyro_bias_beta_y.text())

         self.gyro_bias_beta_z = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_bias_beta_z.text() != ''):
            self.gyro_bias_beta_z = float(self.NRTSIM_Tab5.edt_gyro_bias_beta_z.text())

         self.gyro_bias_noise_x = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_bias_noise_x.text() != ''):
            self.gyro_bias_noise_x = float(self.NRTSIM_Tab5.edt_gyro_bias_noise_x.text())

         self.gyro_bias_noise_y = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_bias_noise_y.text() != ''):
            self.gyro_bias_noise_y = float(self.NRTSIM_Tab5.edt_gyro_bias_noise_y.text())

         self.gyro_bias_noise_z = 0.0
         if (self.NRTSIM_Tab5.edt_gyro_bias_noise_z.text() != ''):
            self.gyro_bias_noise_z = float(self.NRTSIM_Tab5.edt_gyro_bias_noise_z.text())

         self.hard_iron_noise_x = 0.0
         if (self.NRTSIM_Tab6.edt_hard_iron_noise_x.text() != ''):
            self.hard_iron_noise_x = float(self.NRTSIM_Tab6.edt_hard_iron_noise_x.text())

         self.hard_iron_noise_y = 0.0
         if (self.NRTSIM_Tab6.edt_hard_iron_noise_y.text() != ''):
            self.hard_iron_noise_y = float(self.NRTSIM_Tab6.edt_hard_iron_noise_y.text())

         self.hard_iron_noise_z = 0.0
         if (self.NRTSIM_Tab6.edt_hard_iron_noise_z.text() != ''):
            self.hard_iron_noise_z = float(self.NRTSIM_Tab6.edt_hard_iron_noise_z.text())
         
         self.soft_iron_matrix_noise1_x = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise1_x.text() != ''):
            self.soft_iron_matrix_noise1_x = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise1_x.text())

         self.soft_iron_matrix_noise1_y = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise1_y.text() != ''):
            self.soft_iron_matrix_noise1_y = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise1_y.text())

         self.soft_iron_matrix_noise1_z = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise1_z.text() != ''):
            self.soft_iron_matrix_noise1_z = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise1_z.text())

         self.soft_iron_matrix_noise2_x = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise2_x.text() != ''):
            self.soft_iron_matrix_noise2_x = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise2_x.text())

         self.soft_iron_matrix_noise2_y = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise2_y.text() != ''):
            self.soft_iron_matrix_noise2_y = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise2_y.text())

         self.soft_iron_matrix_noise2_z = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise2_z.text() != ''):
            self.soft_iron_matrix_noise2_z = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise2_z.text())

         self.soft_iron_matrix_noise3_x = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise3_x.text() != ''):
            self.soft_iron_matrix_noise3_x = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise3_x.text())

         self.soft_iron_matrix_noise3_y = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise3_y.text() != ''):
            self.soft_iron_matrix_noise3_y = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise3_y.text())

         self.soft_iron_matrix_noise3_z = 0.0
         if (self.NRTSIM_Tab6.edt_soft_iron_matrix_noise3_z.text() != ''):
            self.soft_iron_matrix_noise3_z = float(self.NRTSIM_Tab6.edt_soft_iron_matrix_noise3_z.text())
         
         # REF: command_line = "U:/Lord/SourceCode_GX5_All/ISD2/COMMON/Kalman_Filter/Desktop C Sim/kalman_filter/Debug/kalman_filter.exe" imufile="U:/Lord/Python_Sandbox/Vehicle_Logs/2017_06_06_Fritz/3DM-GX5-45 6251.60131 Data Log 6-6-2017 8.50.43 AM_IMU_Log_nrtsim_wHdr.csv" gpsfile="U:/Lord/Python_Sandbox/Vehicle_Logs/2017_06_06_Fritz/3DM-GX5-45 6251.60131 Data Log 6-6-2017 8.50.43 AM_GPS_Log_nrtsim_wHdr.csv" estaccelbias=1 estgyrobias=1 automagcalsoft=1 automagcalhard=1 autoinit=1 gnsssource=1 headingaid=1 pitchrollaid=1 altitudeaid=1 accelwn_x=0.1 accelwn_y=0.1 accelwn_z=0.1 accelmarkovbeta_x=0.0 accelmarkovbeta_y=0.0 accelmarkovbeta_z=0.0 accelmarkovbetasigma_x=0.00001 accelmarkovbetasigma_y=0.00001 accelmarkovbetasigma_z=0.00001 gyrown_x=0.001 gyrown_y=0.001 gyrown_z=0.001 gyromarkovbeta_x=0.0 gyromarkovbeta_y=0.0 gyromarkovbeta_z=0.0 gyromarkovbetasigma_x=0.00001 gyromarkovbetasigma_y=0.00001 gyromarkovbetasigma_z=0.00001 magwn_x=0.1 magwn_y=0.1 magwn_z=0.1 gravwn_x=0.1 gravwn_y=0.1 gravwn_z=0.1 presswn=1.0 hardironwn_x=0.001 hardironwn_y=0.001 hardironwn_z=0.001 softironwn=0.001
         # command_line = NRTSIM_DIR + 'kalman_filter.exe" imufile="' + str(self.imu_filename) + '" gpsfile="' + str(self.gps_filename) + '" estaccelbias=' + str(self.estaccelbias) + ' estgyrobias=' + str(self.estgyrobias) + ' estaccelSF=' + str(self.estaccelSF) + ' estgyroSF=' + str(self.estgyroSF) + ' estGNSSAntOffset=' + str(self.estGNSSAntOffset) + ' automagcalsoft=' + str(self.automagcalsoft) + ' automagcalhard=' + str(self.automagcalhard) + ' autoinit=' + str(self.autoinit) + ' initHeading=' + str(self.initHeading) + ' initRoll=' + str(self.initRoll) + ' initPitch=' + str(self.initPitch) + ' enableVelZUPT=' + str(self.enableVelZUPT) + ' velZUPTThreshold=' + str(self.velZUPTThreshold) + ' enableAngRateZUPT=' + str(self.enableAngRateZUPT) + ' angRateZUPTThreshold=' + str(self.angRateZUPTThreshold) + ' gnsssource=' + str(self.NRTSIM_Tab2.gnss_source) + ' headingaid=' + str(self.NRTSIM_Tab2.heading_aid) + ' pitchrollaid=' + str(self.NRTSIM_Tab2.pitch_roll_aid) + ' altitudeaid=' + str(self.NRTSIM_Tab2.altitude_aid) + ' accelwn_x=0.1 accelwn_y=0.1 accelwn_z=0.1 accelmarkovbeta_x=0.0 accelmarkovbeta_y=0.0 accelmarkovbeta_z=0.0 accelmarkovbetasigma_x=0.00001 accelmarkovbetasigma_y=0.00001 accelmarkovbetasigma_z=0.00001 gyrown_x=0.001 gyrown_y=0.001 gyrown_z=0.001 gyromarkovbeta_x=0.0 gyromarkovbeta_y=0.0 gyromarkovbeta_z=0.0 gyromarkovbetasigma_x=0.00001 gyromarkovbetasigma_y=0.00001 gyromarkovbetasigma_z=0.00001 magwn_x=0.1 magwn_y=0.1 magwn_z=0.1 gravwn_x=0.1 gravwn_y=0.1 gravwn_z=0.1 presswn=1.0 hardironwn_x=0.001 hardironwn_y=0.001 hardironwn_z=0.001 softironwn=0.001'
         # command_line = NRTSIM_DIR + 'kalman_filter.exe" imufile="' + str(self.imu_filename) + '" gpsfile="' + str(self.gps_filename) + '" estaccelbias=' + str(self.estaccelbias) + ' estgyrobias=' + str(self.estgyrobias) + ' estaccelSF=' + str(self.estaccelSF) + ' estgyroSF=' + str(self.estgyroSF) + ' estGNSSAntOffset=' + str(self.estGNSSAntOffset) + ' automagcalsoft=' + str(self.automagcalsoft) + ' automagcalhard=' + str(self.automagcalhard) + ' autoinit=' + str(self.autoinit) + ' initHeading=' + str(self.initHeading) + ' initRoll=' + str(self.initRoll) + ' initPitch=' + str(self.initPitch) + ' enableVelZUPT=' + str(self.enableVelZUPT) + ' velZUPTThreshold=' + str(self.velZUPTThreshold) + ' enableAngRateZUPT=' + str(self.enableAngRateZUPT) + ' angRateZUPTThreshold=' + str(self.angRateZUPTThreshold) + ' gnsssource=' + str(self.NRTSIM_Tab2.gnss_source) + ' headingaid=' + str(self.NRTSIM_Tab2.heading_aid) + ' pitchrollaid=' + str(self.NRTSIM_Tab2.pitch_roll_aid) + ' altitudeaid=' + str(self.NRTSIM_Tab2.altitude_aid) + ' accelwn_x=' + str(self.accel_noise_x) + ' accelwn_y=' + str(self.accel_noise_y) + ' accelwn_z=' + str(self.accel_noise_z) + ' accelmarkovbeta_x=' + str(self.accel_bias_beta_x) + ' accelmarkovbeta_y=' + str(self.accel_bias_beta_y) + ' accelmarkovbeta_z=' + str(self.accel_bias_beta_z) + ' accelmarkovbetasigma_x=' + str(self.accel_bias_noise_x) + ' accelmarkovbetasigma_y=' + str(self.accel_bias_noise_y) + ' accelmarkovbetasigma_z=' + str(self.accel_bias_noise_z) + ' gyrown_x=' + str(self.gyro_noise_x) + ' gyrown_y=' + str(self.gyro_noise_y) + ' gyrown_z=' + str(self.gyro_noise_z) + ' gyromarkovbeta_x=' + str(self.gyro_bias_beta_x) + ' gyromarkovbeta_y=' + str(self.gyro_bias_beta_y) + ' gyromarkovbeta_z=' + str(self.gyro_bias_beta_z) + ' gyromarkovbetasigma_x=' + str(self.gyro_bias_noise_x) + ' gyromarkovbetasigma_y=' + str(self.gyro_bias_noise_y) + ' gyromarkovbetasigma_z=' + str(self.gyro_bias_noise_z) + ' magwn_x=' + str(self.mag_noise_x) + ' magwn_y=' + str(self.mag_noise_y) + ' magwn_z=' + str(self.mag_noise_z) + ' gravwn_x=' + str(self.grav_noise_x) + ' gravwn_y=' + str(self.grav_noise_y) + ' gravwn_z=' + str(self.grav_noise_z) + ' presswn=' + str(self.pr_alt_noise) + ' hardironwn_x=0.001 hardironwn_y=0.001 hardironwn_z=0.001 softironwn=0.001'
         
         build_prepend = ''
         if (self.dev_root_dir != ''):
            build_prepend = self.dev_root_dir + '/ISD2/COMMON/Kalman_Filter/Desktop C Sim/kalman_filter/Debug'
         else:
            build_prepend = 'nrtsim_builds/' + self.nrtsim_form_widget.device_name + '/' + self.fw_version
         # } if (self.dev_root_dir != '')..
    
         # command_line = '"' + build_prepend + '/ISD2/COMMON/Kalman_Filter/Desktop C Sim/kalman_filter/Debug/kalman_filter.exe" imufile="' + str(self.imu_filename) + '" gpsfile="' + str(self.gps_filename) + '" estaccelbias=' + str(self.estaccelbias) + ' estgyrobias=' + str(self.estgyrobias) + ' estaccelSF=' + str(self.estaccelSF) + ' estgyroSF=' + str(self.estgyroSF) + ' estGNSSAntOffset=' + str(self.estGNSSAntOffset) + ' automagcalsoft=' + str(self.automagcalsoft) + ' automagcalhard=' + str(self.automagcalhard) + ' autoinit=' + str(self.autoinit) + ' initHeading=' + str(self.initHeading) + ' initRoll=' + str(self.initRoll) + ' initPitch=' + str(self.initPitch) + ' enableVelZUPT=' + str(self.enableVelZUPT) + ' velZUPTThreshold=' + str(self.velZUPTThreshold) + ' enableAngRateZUPT=' + str(self.enableAngRateZUPT) + ' angRateZUPTThreshold=' + str(self.angRateZUPTThreshold) + ' gnsssource=' + str(self.NRTSIM_Tab2.gnss_source) + ' headingaid=' + str(self.NRTSIM_Tab2.heading_aid) + ' pitchrollaid=' + str(self.NRTSIM_Tab2.pitch_roll_aid) + ' altitudeaid=' + str(self.NRTSIM_Tab2.altitude_aid) + ' accelwn_x=' + str(self.accel_noise_x) + ' accelwn_y=' + str(self.accel_noise_y) + ' accelwn_z=' + str(self.accel_noise_z) + ' accelmarkovbeta_x=' + str(self.accel_bias_beta_x) + ' accelmarkovbeta_y=' + str(self.accel_bias_beta_y) + ' accelmarkovbeta_z=' + str(self.accel_bias_beta_z) + ' accelmarkovbetasigma_x=' + str(self.accel_bias_noise_x) + ' accelmarkovbetasigma_y=' + str(self.accel_bias_noise_y) + ' accelmarkovbetasigma_z=' + str(self.accel_bias_noise_z) + ' gyrown_x=' + str(self.gyro_noise_x) + ' gyrown_y=' + str(self.gyro_noise_y) + ' gyrown_z=' + str(self.gyro_noise_z) + ' gyromarkovbeta_x=' + str(self.gyro_bias_beta_x) + ' gyromarkovbeta_y=' + str(self.gyro_bias_beta_y) + ' gyromarkovbeta_z=' + str(self.gyro_bias_beta_z) + ' gyromarkovbetasigma_x=' + str(self.gyro_bias_noise_x) + ' gyromarkovbetasigma_y=' + str(self.gyro_bias_noise_y) + ' gyromarkovbetasigma_z=' + str(self.gyro_bias_noise_z) + ' magwn_x=' + str(self.mag_noise_x) + ' magwn_y=' + str(self.mag_noise_y) + ' magwn_z=' + str(self.mag_noise_z) + ' gravwn_x=' + str(self.grav_noise_x) + ' gravwn_y=' + str(self.grav_noise_y) + ' gravwn_z=' + str(self.grav_noise_z) + ' presswn=' + str(self.pr_alt_noise) + ' hardironwn_x=' + str(self.hard_iron_noise_x) + ' hardironwn_y=' + str(self.hard_iron_noise_y) + ' hardironwn_z=' + str(self.hard_iron_noise_z) + ' softironwn1_x=' + str(self.soft_iron_matrix_noise1_x) + ' softironwn1_y=' + str(self.soft_iron_matrix_noise1_y) + ' softironwn1_z=' + str(self.soft_iron_matrix_noise1_z)  + ' softironwn2_x=' + str(self.soft_iron_matrix_noise2_x) + ' softironwn2_y=' + str(self.soft_iron_matrix_noise2_y) + ' softironwn2_z=' + str(self.soft_iron_matrix_noise2_z) + ' softironwn3_x=' + str(self.soft_iron_matrix_noise3_x) + ' softironwn3_y=' + str(self.soft_iron_matrix_noise3_y) + ' softironwn3_z=' + str(self.soft_iron_matrix_noise3_z) 
         command_line = '"' + build_prepend + '/kalman_filter.exe" imufile="' + str(self.imu_filename) + '" gpsfile="' + str(self.gps_filename) + '" imu_data_rate_actual=' + str(self.imu_data_rate_actual) + ' estaccelbias=' + str(self.estaccelbias) + ' estgyrobias=' + str(self.estgyrobias) + ' estaccelSF=' + str(self.estaccelSF) + ' estgyroSF=' + str(self.estgyroSF) + ' estGNSSAntOffset=' + str(self.estGNSSAntOffset) + ' automagcalsoft=' + str(self.automagcalsoft) + ' automagcalhard=' + str(self.automagcalhard) + ' autoinit=' + str(self.autoinit) + ' initHeading=' + str(self.initHeading) + ' initRoll=' + str(self.initRoll) + ' initPitch=' + str(self.initPitch) + ' manualInitTimeOffset=' + str(self.manual_init_time_offset) + ' enableVelZUPT=' + str(self.enableVelZUPT) + ' velZUPTThreshold=' + str(self.velZUPTThreshold) + ' enableAngRateZUPT=' + str(self.enableAngRateZUPT) + ' angRateZUPTThreshold=' + str(self.angRateZUPTThreshold) + ' gnsssource=' + str(self.NRTSIM_Tab2.gnss_source) + ' mag_on=' + str(self.mag_on) + ' headingaid=' + str(self.NRTSIM_Tab2.heading_aid) + ' pitchrollaid=' + str(self.NRTSIM_Tab2.pitch_roll_aid) + ' gravadaptive=' + str(self.NRTSIM_Tab2.grav_adaptive) + ' altitudeaid=' + str(self.NRTSIM_Tab2.altitude_aid) + ' vehdynmode=' + str(self.NRTSIM_Tab2.veh_dyn_mode) + ' magadaptive=' + str(self.NRTSIM_Tab2.mag_adaptive) + ' accelwn_x=' + str(self.accel_noise_x) + ' accelwn_y=' + str(self.accel_noise_y) + ' accelwn_z=' + str(self.accel_noise_z) + ' accelmarkovbeta_x=' + str(self.accel_bias_beta_x) + ' accelmarkovbeta_y=' + str(self.accel_bias_beta_y) + ' accelmarkovbeta_z=' + str(self.accel_bias_beta_z) + ' accelmarkovbetasigma_x=' + str(self.accel_bias_noise_x) + ' accelmarkovbetasigma_y=' + str(self.accel_bias_noise_y) + ' accelmarkovbetasigma_z=' + str(self.accel_bias_noise_z) + ' gyrown_x=' + str(self.gyro_noise_x) + ' gyrown_y=' + str(self.gyro_noise_y) + ' gyrown_z=' + str(self.gyro_noise_z) + ' gyromarkovbeta_x=' + str(self.gyro_bias_beta_x) + ' gyromarkovbeta_y=' + str(self.gyro_bias_beta_y) + ' gyromarkovbeta_z=' + str(self.gyro_bias_beta_z) + ' gyromarkovbetasigma_x=' + str(self.gyro_bias_noise_x) + ' gyromarkovbetasigma_y=' + str(self.gyro_bias_noise_y) + ' gyromarkovbetasigma_z=' + str(self.gyro_bias_noise_z) + ' magwn_x=' + str(self.mag_noise_x) + ' magwn_y=' + str(self.mag_noise_y) + ' magwn_z=' + str(self.mag_noise_z) + ' gravwn_x=' + str(self.grav_noise_x) + ' gravwn_y=' + str(self.grav_noise_y) + ' gravwn_z=' + str(self.grav_noise_z) + ' presswn=' + str(self.pr_alt_noise) + ' hardironwn_x=' + str(self.hard_iron_noise_x) + ' hardironwn_y=' + str(self.hard_iron_noise_y) + ' hardironwn_z=' + str(self.hard_iron_noise_z) + ' softironwn1_x=' + str(self.soft_iron_matrix_noise1_x) + ' softironwn1_y=' + str(self.soft_iron_matrix_noise1_y) + ' softironwn1_z=' + str(self.soft_iron_matrix_noise1_z)  + ' softironwn2_x=' + str(self.soft_iron_matrix_noise2_x) + ' softironwn2_y=' + str(self.soft_iron_matrix_noise2_y) + ' softironwn2_z=' + str(self.soft_iron_matrix_noise2_z) + ' softironwn3_x=' + str(self.soft_iron_matrix_noise3_x) + ' softironwn3_y=' + str(self.soft_iron_matrix_noise3_y) + ' softironwn3_z=' + str(self.soft_iron_matrix_noise3_z) 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
         self.logFile.write('\n\n--------------------------------------------------------------------------\n')                                                                                                                                                                                                                                                                                                                                                                                                 
         self.logFile.write(' ******** Starting NRTSIM command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
        
         print('\n ***** TOP LEVEL: ' + command_line)
         self.logFile.write('\n **** EKF COMMAND USED : ' + command_line)
         # self.logFile.flush()

         # run the process
         self.process.start(command_line)

      # } if (error_msg != '')..

      return

# ---------------------------------------------------

