from mip import *
from binascii import hexlify

# Disable Magnetometer
disable_mag_command = bytearray.fromhex('75656107070D01000000025920')

# Disable Magnetometer and Pressure Sensor
disable_mag_and_pr_command = bytearray.fromhex('75656107070D01000000035A21')

# Disable Heater
disable_heater_command = bytearray.fromhex('75656107070D01000000085F26')

mp = bytearray([])

#initialize a packet for a base command
mip_init(mp,0x61)

print "Packet after init: " + hexlify(mp).upper()

#add the command ping to the packet
mip_add_field(mp,0x0D, bytearray.fromhex('0100000003'))

print "Packet after add field: " + hexlify(mp).upper()

checksum = fletcher_check16(mp)

#Print the checksum bytes
print "Checksum bytes: " + hexlify(checksum).upper()

#finalize packet
mip_finalize(mp)

print "Packet after finalize: " + hexlify(mp).upper()

#test packet validity
if(mip_is_mip_packet(mp)==MIP_OK):
 print "\nValid Packet Found"

print "Full packet: " + hexlify(mp).upper()

expected_checksum = fletcher_check16(mp[0:len(mp)-2])

# Compare with current checksum
if(expected_checksum == mp[-2:]):
   print "Checksum matched expected value: " + hexlify(expected_checksum).upper()
else:
   print "Checksum DID NOT match expected value: Found: " + hexlify(mp[0:len(mp)-2]).upper() + " Expected: " + hexlify(expected_checksum).upper()



