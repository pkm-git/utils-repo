import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

class MyNRTSIMFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyNRTSIMFormWidget, self).__init__(parent)
      self.parent_obj = parent
      self.processError = False
      self.submit_timestamp = ''
      self.submit_timestamp_no_spaces_spl_chr = ''
      
      self.device_name = 'GX5-45'
      self.fw_version = '1156'
      
      # self.setFixedSize(550,250)
      # self.setFixedSize(550,175)
      self.setFixedSize(600,175)
      # self.setFixedSize(645,225)
      
      # self.setStyleSheet("background-color: #CCE5FF;");
      
      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyNRTSIMFormWidget window"

      super(MyNRTSIMFormWidget, self).closeEvent(event)

   def __controls(self):
   
      self.declare_spaces()
      
      self.lbl_title = QtGui.QLabel("NRTSIM")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(80)
      self.lbl_title.setFixedHeight(25)

      self.lbl_imu_filename = QtGui.QLabel("Input IMU CSV Filename:")
      self.lbl_imu_filename.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_imu_filename = MyLineEdit()
      self.edt_imu_filename.setStyleSheet("background-color: white;");
      # self.edt_imu_filename.setFixedWidth(275)
      self.edt_imu_filename.setFixedWidth(260)
      
      self.lbl_imu_data_rate = QtGui.QLabel("Hz")
      self.lbl_imu_data_rate.setFixedWidth(20)
      self.lbl_imu_data_rate.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");
      
      self.edt_imu_data_rate = MyLineEdit()
      self.edt_imu_data_rate.setStyleSheet("background-color: white;");
      self.edt_imu_data_rate.setFixedWidth(30)
      # self.edt_imu_data_rate.setText('500')
      self.edt_imu_data_rate.setText('200')
      
      self.lbl_gps_filename = QtGui.QLabel("Input GPS CSV Filename:")
      self.lbl_gps_filename.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_gps_filename = MyLineEdit()
      self.edt_gps_filename.setStyleSheet("background-color: white;");
      # self.edt_gps_filename.setFixedWidth(275)
      self.edt_gps_filename.setFixedWidth(260)

      self.lbl_device_type = QtGui.QLabel("Device:")
      self.lbl_device_type.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.cmbox_device_name = MyComboBox('NRTSIM Device')
      self.cmbox_device_name.setFixedWidth(70)
      self.cmbox_device_name.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_device_name.currentIndexChanged.connect(self.onDeviceChange)

      self.radiob_developer = QtGui.QRadioButton("Developer")
      self.radiob_developer.setChecked(True)
      self.radiob_developer.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      # self.radiob_customer = QtGui.QRadioButton("Customer")
      self.radiob_customer = QtGui.QRadioButton("Support")
      self.radiob_customer.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      # Create a button group for radio buttons
      self.developer_button_group = QtGui.QButtonGroup()

      # Add each radio button to the button group & give it an ID of i
      self.developer_button_group.addButton(self.radiob_developer, 1)
      self.developer_button_group.addButton(self.radiob_customer, 2)
      
      self.radiob_developer.clicked.connect(lambda:self.change_fw_custom_block(self.radiob_developer))
      self.radiob_customer.clicked.connect(lambda:self.change_fw_custom_block(self.radiob_customer))
      
      self.lbl_fw_version = QtGui.QLabel("FW Version:")
      self.lbl_fw_version.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      self.lbl_fw_version.hide()
      
      self.radiob_fw_version = QtGui.QRadioButton("FW Version")
      self.radiob_fw_version.setChecked(True)
      self.radiob_fw_version.clicked.connect(lambda:self.enable_dev_root_folder(self.radiob_fw_version))
      
      self.radiob_custom_build = QtGui.QRadioButton("Custom Build")
      self.radiob_custom_build.clicked.connect(lambda:self.enable_dev_root_folder(self.radiob_custom_build))
      
      self.cmbox_fw_version = MyComboBox('NRTSIM FW Version')
      self.cmbox_fw_version.setFixedWidth(70)
      self.cmbox_fw_version.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_fw_version.currentIndexChanged.connect(self.onFWVersionChange)
      
      self.lbl_developer_root_folder = QtGui.QLabel("Root Directory for Build:")
      self.lbl_developer_root_folder.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_developer_root_folder = MyLineEdit()
      self.edt_developer_root_folder.setStyleSheet("background-color: white;");
      # self.edt_developer_root_folder.setFixedWidth(275)
      self.edt_developer_root_folder.setFixedWidth(260)
      self.edt_developer_root_folder.setReadOnly(True)
      self.edt_developer_root_folder.setStyleSheet("background-color: #E0E0E0;");

      # self.radiob_auto_init = QtGui.QRadioButton("Auto Init")
      self.radiob_auto_init = QtGui.QRadioButton("Auto")
      self.radiob_auto_init.setChecked(True)
      self.radiob_auto_init.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");
      
      self.radiob_manual_init = QtGui.QRadioButton("Manual Init")
      self.radiob_manual_init.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");
      
      self.radiob_auto_init.clicked.connect(lambda:self.setHeading(self.radiob_auto_init))
      self.radiob_manual_init.clicked.connect(lambda:self.setHeading(self.radiob_manual_init))

      self.lbl_heading = QtGui.QLabel("Heading/Pitch/Roll:")
      # self.lbl_heading.setFixedWidth(120)
      self.lbl_heading.setFixedWidth(110)
      self.lbl_heading.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");

      self.edt_heading = MyLineEdit()
      self.edt_heading.setStyleSheet("background-color: #E0E0E0;");
      self.edt_heading.setFixedWidth(30)
      self.edt_heading.setReadOnly(True)

      self.lbl_deg = QtGui.QLabel("deg")
      self.lbl_deg.setFixedWidth(30)
      self.lbl_deg.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");
      
      self.lbl_pitch_roll_slash = QtGui.QLabel("/")
      self.lbl_pitch_roll_slash.setFixedWidth(5)
      self.lbl_pitch_roll_slash.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_pitch = MyLineEdit()
      self.edt_pitch.setStyleSheet("background-color: #E0E0E0;");
      self.edt_pitch.setFixedWidth(30)
      self.edt_pitch.setReadOnly(True)

      self.edt_roll = MyLineEdit()
      self.edt_roll.setStyleSheet("background-color: #E0E0E0;");
      self.edt_roll.setFixedWidth(30)
      self.edt_roll.setReadOnly(True)

      self.lbl_time_offset = QtGui.QLabel("Time Offset:")
      self.lbl_time_offset.setFixedWidth(70)
      self.lbl_time_offset.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");

      self.lbl_time_offset_sec = QtGui.QLabel("sec")
      self.lbl_time_offset_sec.setFixedWidth(30)
      self.lbl_time_offset_sec.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319;");

      self.edt_manual_init_time_offset = MyLineEdit()
      self.edt_manual_init_time_offset.setStyleSheet("background-color: #E0E0E0;");
      self.edt_manual_init_time_offset.setFixedWidth(30)
      self.edt_manual_init_time_offset.setReadOnly(True)

      self.browse_button_imu = MyPushButton("Browse")
      self.browse_button_imu.setCheckable(True)
      self.browse_button_imu.toggle()
      self.browse_button_imu.clicked.connect(lambda:self.selectFile('imu'))
      self.browse_button_imu.setFixedWidth(75)

      self.browse_button_gps = MyPushButton("Browse")
      self.browse_button_gps.setCheckable(True)
      self.browse_button_gps.toggle()
      self.browse_button_gps.clicked.connect(lambda:self.selectFile('gps'))
      self.browse_button_gps.setFixedWidth(75)

      self.browse_button_root_dir = MyPushButton("Browse")
      self.browse_button_root_dir.setCheckable(True)
      self.browse_button_root_dir.toggle()
      self.browse_button_root_dir.clicked.connect(self.selectDir)
      self.browse_button_root_dir.setFixedWidth(75)

      self.hDeviceFWCustomBox = QtGui.QHBoxLayout()
      
   def onDeviceChange(self, state):
      self.cmbox_fw_version.clear()
      self.edt_gps_filename.setText('');
      
      if (state == 0):  # GX5-45
         self.device_name = 'GX5-45'
         self.cmbox_fw_version.addItem("fw1165")
         # self.edt_imu_data_rate.setText('500')
         self.edt_imu_data_rate.setText('200')

         self.edt_gps_filename.setReadOnly(False);
         self.edt_gps_filename.setStyleSheet("background-color: white;");

      elif (state == 1): # GX5-25
         self.device_name = 'GX5-25'
         self.cmbox_fw_version.addItem("fw1166")
         # self.edt_imu_data_rate.setText('1000')
         self.edt_imu_data_rate.setText('200')
 
         self.edt_gps_filename.setReadOnly(True);
         self.edt_gps_filename.setStyleSheet("background-color: #E0E0E0;");

         self.parent_obj.NRTSIM_Tab4.edt_pr_alt_noise.setReadOnly(True)
      # } if (state == 0)..

      self.parent_obj.noise_data = Noise_Data_Struct(self.device_name)
      
      self.parent_obj.NRTSIM_Tab2.setDropDowns()
      self.parent_obj.NRTSIM_Tab3.setCheckboxes()
      self.parent_obj.NRTSIM_Tab4.setNoiseValues()
      self.parent_obj.NRTSIM_Tab5.setNoiseValues()
      self.parent_obj.NRTSIM_Tab6.setNoiseValues()
      
   def onFWVersionChange(self, state):
      if (state == 0):  # fw1165
         if (self.device_name == 'GX5-45'):
            self.fw_version = '1165'
         elif (self.device_name == 'GX5-25'):
            self.fw_version = '1166'
         # } if (self.device_name == 'GX5-45')..   
      # elif (state == 1): # fw1165
         # self.fw_version = '1165'
      # } if (state == 0)..

   def setHeading(self, b):
      if (b == self.radiob_manual_init and b.isChecked()):
         self.radiob_auto_init.setChecked(False)
 
         self.edt_heading.setStyleSheet("background-color: white;");
         self.edt_heading.setText('0.0')
         self.edt_heading.setReadOnly(False)

         self.edt_pitch.setStyleSheet("background-color: white;");
         self.edt_pitch.setText('0.0')
         self.edt_pitch.setReadOnly(False)

         self.edt_roll.setStyleSheet("background-color: white;");
         self.edt_roll.setText('0.0')
         self.edt_roll.setReadOnly(False)

         self.edt_manual_init_time_offset.setStyleSheet("background-color: white;");
         self.edt_manual_init_time_offset.setText('0.0')
         self.edt_manual_init_time_offset.setReadOnly(False)
         
      elif (b == self.radiob_auto_init and b.isChecked()):
         self.radiob_manual_init.setChecked(False)
 
         self.edt_heading.setStyleSheet("background-color: #E0E0E0;");
         self.edt_heading.setText('')
         self.edt_heading.setReadOnly(True)
 
         self.edt_pitch.setStyleSheet("background-color: #E0E0E0;");
         self.edt_pitch.setText('')
         self.edt_pitch.setReadOnly(True)

         self.edt_roll.setStyleSheet("background-color: #E0E0E0;");
         self.edt_roll.setText('')
         self.edt_roll.setReadOnly(True)

         self.edt_manual_init_time_offset.setStyleSheet("background-color: #E0E0E0;");
         self.edt_manual_init_time_offset.setText('')
         self.edt_manual_init_time_offset.setReadOnly(True)

      # } if (b == self.radiob_auto_init..
   
   def change_fw_custom_block(self, b):
      if (b == self.radiob_developer and b.isChecked()):
         self.lbl_fw_version.hide()
         self.radiob_fw_version.show()
         self.radiob_custom_build.show()
         self.lbl_space_resizable_fillerFWBox.setFixedWidth(2)
         self.hDeviceFWCustomWidget.setFixedSize(270,35)
         # self.lbl_space_resizable_filler3.hide()
 
      elif (b == self.radiob_customer and b.isChecked()):
         self.lbl_fw_version.show()
         self.radiob_fw_version.hide()
         self.radiob_custom_build.hide()
         self.lbl_space_resizable_fillerFWBox.setFixedWidth(125)
         self.hDeviceFWCustomWidget.setFixedSize(150,35)
         # self.lbl_space_resizable_filler3.show()
 
   def enable_dev_root_folder(self, b):
      if (b == self.radiob_fw_version and b.isChecked()):
         self.cmbox_fw_version.setEnabled(True)
         self.edt_developer_root_folder.setReadOnly(True)
         self.edt_developer_root_folder.setStyleSheet("background-color: #E0E0E0;");
         self.edt_developer_root_folder.setText('')
 
      elif (b == self.radiob_custom_build and b.isChecked()):
         self.cmbox_fw_version.setEnabled(False)
         self.edt_developer_root_folder.setReadOnly(False)
         self.edt_developer_root_folder.setStyleSheet("background-color: white;");

   def selectDir(self):
   
      root_dir = QtGui.QFileDialog.getExistingDirectory(None, 'Select a root folder for build:', 'C:\\', QtGui.QFileDialog.ShowDirsOnly)
      # If the user hits cancel, then root_dir is empty.
      
      self.edt_developer_root_folder.setText(root_dir)
      
   def selectFile(self, which_one):
      theInputDir = ""

      user_config = os.getcwd() + "/inertial_sensor.cfg"

      config = ConfigParser.ConfigParser()
      config.read(user_config)
      
      if config.has_section("dirs"):
         # if an entry exists then add the value to the form
         if config.has_option("dirs", "inputdir"):
            theInputDir = config.get("dirs", "inputdir")
         # } if config.has_option("dirs", "inputdir")..
      # } if config.has_section("dirs")..

      filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', theInputDir, '*.*')

      if filename:
         (inputDirName, fin_filename) = os.path.split(str(filename))
 
         if (which_one == 'imu'):
            self.edt_imu_filename.setText(filename)
         elif (which_one == 'gps'):
            self.edt_gps_filename.setText(filename)
         # } if (which_one == 'imu')..
     
         if not config.has_section("dirs"):
            config.add_section("dirs")
         # } if not config.has_section("dirs")..

         config.set("dirs", "inputdir", inputDirName)
          
         # if not os.getcwd().exists(configFile):
         with open("inertial_sensor.cfg", 'w') as f:
            config.write(f)
         # } with open("inertial_sensor.cfg"..
      # } if filename..
 
   def __layout(self):

      self.hDeveloperBox = QtGui.QHBoxLayout()
      self.hDeveloperBox.addWidget(self.radiob_developer)
      self.hDeveloperBox.addWidget(self.radiob_customer)

      self.hDeveloperWidget = QtGui.QWidget()
      self.hDeveloperWidget.setLayout(self.hDeveloperBox)
      self.hDeveloperWidget.setStyleSheet("background-color: #E8D9FC;");
      self.hDeveloperWidget.setFixedSize(175,30)
      
      self.hDeviceFWCustomBox = QtGui.QHBoxLayout()
      # self.hDeviceFWCustomBox.addWidget(self.lbl_fw_version)
      self.hDeviceFWCustomBox.addWidget(self.radiob_fw_version)
      self.hDeviceFWCustomBox.addWidget(self.cmbox_fw_version)
      self.hDeviceFWCustomBox.addWidget(self.radiob_custom_build)

      self.hDeviceFWCustomWidget = QtGui.QWidget()
      self.hDeviceFWCustomWidget.setLayout(self.hDeviceFWCustomBox)
      self.hDeviceFWCustomWidget.setStyleSheet("background-color: #F0E9AB;");
      self.hDeviceFWCustomWidget.setFixedSize(270,35)

      self.hDeviceFWBox = QtGui.QHBoxLayout()
      self.hDeviceFWBox.addWidget(self.lbl_device_type)
      self.hDeviceFWBox.addWidget(self.cmbox_device_name)
      self.hDeviceFWBox.addWidget(self.hDeveloperWidget)
      self.hDeviceFWBox.addWidget(self.hDeviceFWCustomWidget)
      self.hDeviceFWBox.addWidget(self.lbl_space_resizable_fillerFWBox)
      
      self.hDevRootDirBox = QtGui.QHBoxLayout()
      self.hDevRootDirBox.addWidget(self.lbl_developer_root_folder)
      self.hDevRootDirBox.addWidget(self.edt_developer_root_folder)
      self.hDevRootDirBox.addWidget(self.browse_button_root_dir)
      self.hDevRootDirBox.addWidget(self.lbl_space_resizable_filler2)
      
      self.hIMUFileBox = QtGui.QHBoxLayout()
      self.hIMUFileBox.addWidget(self.lbl_imu_filename)
      self.hIMUFileBox.addWidget(self.edt_imu_data_rate)
      self.hIMUFileBox.addWidget(self.lbl_imu_data_rate)
      self.hIMUFileBox.addWidget(self.edt_imu_filename)
      self.hIMUFileBox.addWidget(self.browse_button_imu)
      self.hIMUFileBox.addWidget(self.lbl_space_resizable_filler2)

      self.hGPSFileBox = QtGui.QHBoxLayout()
      self.hGPSFileBox.addWidget(self.lbl_gps_filename)
      self.hGPSFileBox.addWidget(self.edt_gps_filename)
      self.hGPSFileBox.addWidget(self.browse_button_gps)
      self.hGPSFileBox.addWidget(self.lbl_space_resizable_filler2)

      self.hAutoManualInitButtonBox = QtGui.QHBoxLayout()
      self.hAutoManualInitButtonBox.addWidget(self.radiob_auto_init)
      self.hAutoManualInitButtonBox.addWidget(self.radiob_manual_init)

      self.hAutoManualInitButtonWidget = QtGui.QWidget()
      self.hAutoManualInitButtonWidget.setLayout(self.hAutoManualInitButtonBox)
      # self.hAutoManualInitButtonWidget.setStyleSheet("background-color: #F0E9AB;");
      self.hAutoManualInitButtonWidget.setFixedSize(160,30)
      
      self.hHeadingPitchRollDegBox = QtGui.QHBoxLayout()
      self.hHeadingPitchRollDegBox.addWidget(self.edt_heading)
      self.hHeadingPitchRollDegBox.addWidget(self.edt_pitch)
      self.hHeadingPitchRollDegBox.addWidget(self.edt_roll)
      self.hHeadingPitchRollDegBox.addWidget(self.lbl_deg)

      self.hHeadingPitchRollDegWidget = QtGui.QWidget()
      self.hHeadingPitchRollDegWidget.setLayout(self.hHeadingPitchRollDegBox)
      self.hHeadingPitchRollDegWidget.setFixedSize(145,35)
      
      self.hTimeOffsetSecBox = QtGui.QHBoxLayout()
      self.hTimeOffsetSecBox.addWidget(self.edt_manual_init_time_offset)
      self.hTimeOffsetSecBox.addWidget(self.lbl_time_offset_sec)

      self.hTimeOffsetSecWidget = QtGui.QWidget()
      self.hTimeOffsetSecWidget.setLayout(self.hTimeOffsetSecBox)
      self.hTimeOffsetSecWidget.setFixedSize(75,35)
      
      self.hAutoManualInitBox = QtGui.QHBoxLayout()
      # self.hAutoManualInitBox.addWidget(self.radiob_auto_init)
      # self.hAutoManualInitBox.addWidget(self.radiob_manual_init)
      self.hAutoManualInitBox.addWidget(self.hAutoManualInitButtonWidget)
      self.hAutoManualInitBox.addWidget(self.lbl_space_xsmall)
      self.hAutoManualInitBox.addWidget(self.lbl_heading)
      # self.hAutoManualInitBox.addWidget(self.edt_heading)
      # self.hAutoManualInitBox.addWidget(self.edt_pitch)
      # self.hAutoManualInitBox.addWidget(self.edt_roll)
      # self.hAutoManualInitBox.addWidget(self.lbl_deg)
      self.hAutoManualInitBox.addWidget(self.hHeadingPitchRollDegWidget)
      self.hAutoManualInitBox.addWidget(self.lbl_time_offset)
      self.hAutoManualInitBox.addWidget(self.hTimeOffsetSecWidget)
      # self.hAutoManualInitBox.addWidget(self.edt_manual_init_time_offset)
      # self.hAutoManualInitBox.addWidget(self.lbl_time_offset_sec)
      
      # self.hAutoManualInitBox.addWidget(self.lbl_space_xsmall)
      # self.hAutoManualInitBox.addWidget(self.lbl_space_xlarge)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.hDeviceFWBox)
      self.vbox.addLayout(self.hDevRootDirBox)
      self.vbox.addLayout(self.hIMUFileBox)
      self.vbox.addLayout(self.hGPSFileBox)
      self.vbox.addLayout(self.hAutoManualInitBox)
      self.vbox.setAlignment(QtCore.Qt.AlignLeft)

      self.setLayout(self.vbox)

   def declare_spaces(self):
   
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)
      
      self.lbl_space_resizable_filler = QtGui.QLabel()
      self.lbl_space_resizable_filler.setFixedSize(65,25)
      
      self.lbl_space_resizable_filler2 = QtGui.QLabel()
      self.lbl_space_resizable_filler2.setFixedSize(15,25)

      self.lbl_space_resizable_fillerFWBox = QtGui.QLabel()
      self.lbl_space_resizable_fillerFWBox.setFixedSize(2,25)
      
      self.lbl_space_resizable_filler3 = QtGui.QLabel()
      self.lbl_space_resizable_filler3.setFixedSize(75,5)


