import sys
import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder

from novatel_gps_format import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

import numpy
import os

def print_usage_message():
 """Output usage instructions"""

 print("usage: python parse_novatel_binary_log.py -i input_file_name\n")
 print("input_file_name\t\t-- the name of the input file including the path")

def main_line(argv):
 """Main line program"""

 # initialize command line arguments
 in_file_name = None

 short_header_length = 12
 long_header_length = 28

 print('\n------------------------------------------------------------------')

 # 42: BESTPOS
 # 99: BESTVEL
 # 101: TIME
 # 241: BESTXYZ

 # 263: INSATT
 # 319: INSATTS

 # 265: INSPOS
 # 321: INSPOSS

 # 266: INSSPD
 # 323: INSSPDS

 # 267: INSVEL
 # 324: INSVELS

 # 507: INSPVA
 # 508: INSPVAS

 # 268: RAWIMU
 # 325: RAWIMUS

 # 642: VEHICLEBODYROTATION

 # Define "Master columns" (i.e. all available columns in DCP) in a "master sequence"
 gps_default_cols_dict = {"319":"1", "321":"2", "324":"3", "323":"4", "325":"5", "508":"6"}
 # min_gps_default_cols_dict = {42:1, 99:2, 101:3, 319:4, 321:5, 324:6, 323:7, 508:8, 325:9, 642:10, 263:11, 265:12, 266:13, 267:14, 507:15, 268:16}
 # min_gps_default_cols_dict = {"321":"1", "42":"2", "324":"3", "323":"4", "99":"5", "319":"6", "508":"7", "325":"8", "101":"9", "642":"10"}

 min_gps_default_cols_dict = {321:1, 42:2, 324:3, 323:4, 99:5, 319:6, 508:7, 325:8, 101:9, 642:10}
 min_gps_default_long_cols_dict = {263:319, 265:321, 266:323, 267:324, 507:508, 268:325}

 gyro_scale_factor = 0.1/(3600.0 * 256.0)
 accel_scale_factor = 0.05/(2**15)

 # Now, get the order of columns requested by the user:
 gps_output_order = []
 gps_output_order.append(0)

 if (argv != None):
   # parse command line arguements
   for i in range(len(argv)):
     # assign specified filenames
     if(argv[i] == '-i' and len(argv) > i+1):
        in_file_name = argv[i+1]

 # if command line arguments were not properly specified tell the user and exit
 if(in_file_name == None):
   print_usage_message()
   sys.exit()

 no_desc_list_supplied_gps_headers_printed = False

 gps_format_obj = Novatel_GPS_format()

 fin_bin = open(in_file_name, "rb")

 (fin_filepath, fin_filename) = os.path.split(in_file_name)
 fout_gps = open(os.path.join(fin_filepath, "GPS_Log.csv"), "w")

 start_time = time()

 # print('\n------------------------------------------------------------------')
 print(' ************* Parse Novatel Binary Log: start_time = ' + str(start_time) );

 k_start = 0

 bytes_read = fin_bin.read();

 print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

 for k in range(0, len(bytes_read)):
    if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])) == '44' and (hexlify(bytearray(bytes_read[k+2])) == '12' or hexlify(bytearray(bytes_read[k+2])) == '13')):
       print(' ***** Found first SYNC BYTE trio at byte index: ' + str(k) + '\n')
       k_start = k;
       break;

 message_length = 0
 k = k_start

 message_cnt = 0
 packet_set_cnt = 1
 [temp_week, temp_tow_ms, temp_tow_ms_prev, crc_length] = [0,0,0,0]

 [message_id, port_address, sequence, idle_time, time_status, rcvr_status, res1, res2] = [0,0,0,0,0,0,0,0]

 [temp_soln_status, temp_pos_type, res3, res4, res5, sig_mask, temp_ext_sol_status] = [0,0,0,0,0,0,0]

 [temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age] = [0,0,0,0,0,0]
 [temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used] = [0,0,0,0,0]
 # using integer for base station id (for now) [TBD: Use string of length 4]

 [gps_week, gps_tow] = [0,0]

 [ins_vned_N, ins_vned_E, ins_vned_D] = [0,0,0]

 [gps_lat, gps_lon, gps_ht_ellip] = [0,0,0]

 [temp_ins_lat, temp_ins_lon, temp_ins_ht_abv_ellips, temp_ins_vned_N, temp_ins_vned_E, temp_ins_vned_D, temp_roll, temp_pitch, temp_azimuth, temp_ins_status] = [0,0,0,0,0,0,0,0,0,0]

 # [temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_horiz_acc, temp_vert_acc, temp_heading, temp_hAcc] = [0,0,0,0,0,0,0,0]
 [temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_heading] = [0,0,0,0,0]

 # Look for beginning of a valid Novatel packet (Bytes: 0xAA4412):
 while (k < len(bytes_read)):

   if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and hexlify(bytearray(bytes_read[k+1])).upper() == '44'):

      print('--------------------------------------------------------')

      if (hexlify(bytearray(bytes_read[k+2])).upper() == '12'): # Long header
         print(' ********** k = ' + str(k) + ', FOUND AA 44 12, LONG HEADER ***********, Message Length: ' + hexlify(bytearray(bytes_read[k+8:k+10])) + ', packet_set_cnt = ' + str(packet_set_cnt))

         # Need to determine if the message has a long or short header.
         # Start with assuming it's a long header, so read header length byte
         # and see if it is equal to long_header_length (28):

         # header_length = numpy.uint8(int(hexlify(bytearray(bytes_read[k+3])), 16))
         [header_length] = unpack('<B', bytearray(bytes_read[k+3]))
         print('***** header_length: ' + str(header_length))

         [message_length] = unpack('<H', bytearray(bytes_read[k+8:k+10]) )
         print('***** message_length: ' + str(message_length))

         print(' ******** k = ' + str(k) + ', message_cnt: ' + str(message_cnt) + ' hexlify(bytearray(bytes_read[k+3])) = ' + hexlify(bytearray(bytes_read[k+3])).upper() )

         print(' ******* FOUND AA 44 12 ON NEXT MSG, message_cnt: ' + str(message_cnt) + ' and message_length: ' + str(message_length) + ' ********* ')

         print(' ********* LONG HDR: Setting temp_tow_ms_prev to: temp_tow_ms = ' + str(temp_tow_ms))
         temp_tow_ms_prev = temp_tow_ms

         # Parse the remaining part of header:
         # [message_id, gps_format_obj.message_type, port_address, gps_format_obj.message_length, sequence, idle_time, time_status, gps_format_obj.gps_week, temp_tow_ms, rcvr_status, res1, res2] = unpack('<HbBHHBBHLLHH', bytearray(bytes_read[k+4:k+header_length]) )
         [message_id, gps_format_obj.message_type, port_address, gps_format_obj.message_length, sequence, idle_time, time_status, temp_week, temp_tow_ms, rcvr_status, res1, res2] = unpack('<HbBHHBBHLLHH', bytearray(bytes_read[k+4:k+header_length]) )

         # Revert the GPS TOW if it is the VEHICLEBODYROTATION message (because it's GPS TOW is invalid)
         if (message_id == 642):
            temp_tow_ms = temp_tow_ms_prev
         else:
            gps_format_obj.gps_week = temp_week

         # else:
            # TBD: Check if it is a message with short header but message_length = 28 (long_header_length)

         # } if (k+long_header_length+message_length..

      elif (hexlify(bytearray(bytes_read[k+2])).upper() == '13'): # Short header

         print(' ********** k = ' + str(k) + ', FOUND AA 44 13, SHORT HEADER ***********, Message Length: ' + hexlify(bytearray(bytes_read[k+8:k+10])) + ', packet_set_cnt = ' + str(packet_set_cnt))

         # Check if it is a message with short header (in this case, message_length becomes equal to header_length read before):
         [message_length] = unpack('<B', bytearray(bytes_read[k+3]))
         header_length = short_header_length

         print(' ********* SHORT HDR: Setting temp_tow_ms_prev to: temp_tow_ms = ' + str(temp_tow_ms))

         temp_tow_ms_prev = temp_tow_ms

         # Parse the remaining part of header:
         # [message_id, gps_format_obj.gps_week, gps_format_obj.gps_tow] = unpack('<HHL', bytearray(bytes_read[k+4:k+12]) )
         [message_id, gps_format_obj.gps_week, temp_tow_ms] = unpack('<HHL', bytearray(bytes_read[k+4:k+header_length]) )

      # } if (hexlify(bytearray(bytes_read[k+2])).upper() == '12')..

      print(' ********* BEFORE SET: temp_tow_ms = ' + str(temp_tow_ms))
      gps_format_obj.gps_tow = temp_tow_ms/1000.0
      print(' ********* AFTER SET: temp_tow_ms = ' + str(temp_tow_ms))

      # If new value of GPS TOW found, convert GPS TOW from ms to sec and store in GPS Format Object
      # elif (message_id != 642 and (temp_tow_ms_prev == 0 or (temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms))):
      if (message_id != 642 and temp_tow_ms_prev != 0 and temp_tow_ms_prev != temp_tow_ms):
          print('********** packet_set_cnt: ' + str(packet_set_cnt) + ', temp_tow_ms_prev = ' + str(temp_tow_ms_prev) + ' is NOT equal to temp_tow_ms: ' + str(temp_tow_ms))

          if (no_desc_list_supplied_gps_headers_printed == False):
             gps_output_order.sort()

             fout_gps.write('DATA_START\n')
             print(' *********** writing headers, len(gps_output_order) = ' + str(len(gps_output_order)))
             for gps_output_index in range(len(gps_output_order)):
                input_index = numpy.int32(gps_output_order[gps_output_index])
                header = gps_format_obj.format_header(input_index)
                print(' *********** writing headers: input_index = ' + str(input_index) + ', Header: ' + header)
                fout_gps.write(header)

                # fout_gps.write(gps_format_obj.format_header(input_index))

             fout_gps.write('\n')

             no_desc_list_supplied_gps_headers_printed = True
          # } if (no_desc_list_supplied_gps_headers_printed == False)..

          # Print values of previous GPS set, before updating 'gps_format_obj' with new set of values:
          input_index = 0
          for gps_output_index in range(len(gps_output_order)):
             input_index = numpy.int32(gps_output_order[gps_output_index])
             fout_gps.write(gps_format_obj.format(input_index))

          fout_gps.write('\n')

          # Track the number of 'packet sets' (i.e. set of Novatel packets at same GPS Timestamp)
          # if (temp_tow_ms_prev != 0):
          packet_set_cnt = packet_set_cnt + 1

          # temp_tow_ms_prev = temp_tow_ms

      if (packet_set_cnt == 1):
         # gps_output_order.append(gps_default_cols_dict[message_id])
         if (message_id != 642):
            if (message_id in min_gps_default_cols_dict or (message_id in min_gps_default_long_cols_dict)):
               if (message_id in min_gps_default_long_cols_dict):
                  message_id = min_gps_default_cols_dict[min_gps_default_long_cols_dict[message_id]]

               gps_output_order.append(min_gps_default_cols_dict[message_id])
               print('********* message_id = ' + str(message_id) + ' does exist in dictionary, adding output_order: ' + str(min_gps_default_cols_dict[message_id]) )

            else:
               print('********* message_id = ' + str(message_id) + ' does NOT exist in dictionary' )
      # } if (packet_set_cnt == 1)..

      print(' ********* message_id: ' + str(message_id) + ', gps_format_obj.gps_week: ' + str(gps_format_obj.gps_week) + ', gps_format_obj.gps_tow: ' + str(gps_format_obj.gps_tow))

      message_cnt = message_cnt + 1

      # full_message_bytes = bytearray( bytes_read[k:k+message_length+14] )
      # message_bytes = bytearray( bytes_read[k+12:k+12+message_length] )

      # full_message_bytes = bytearray( bytes_read[k:k+message_length+header_length+crc_length] )
      full_message_bytes = bytearray( bytes_read[k:k+message_length+header_length+crc_length] )
      message_bytes = bytearray( bytes_read[k+header_length:k+header_length+message_length] )

      # print('\n****** Message Cnt: ' + str(message_cnt) + ', Message ID: ' + str(message_id) + ', Message Length = ' + str(message_length) + ' and full_message_bytes = ' + hexlify( bytearray(full_message_bytes) ).upper())
      tmp_str = hexlify( bytearray(full_message_bytes) ).upper()
      print('\n****** Message Cnt: ' + str(message_cnt) + ', Message ID: ' + str(message_id) + ', Message Length = ' + str(message_length) + ', len(tmp_str): ' + str(len(tmp_str)) + ' and full_message_bytes = ' )

      for i in range(0,len(tmp_str),2):
         print(tmp_str[i] + tmp_str[i+1]),
      print('\n')

      if (message_id == 319):  # INSATTS [INS Attitude]
         [temp_gps_week, temp_tow_ms2, gps_format_obj.roll, gps_format_obj.pitch, gps_format_obj.azimuth, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

         print(' ******** parsed Novatel ATT packet: ************\n')
         print(' **** temp_gps_week: ' + str(temp_gps_week))
         print(' **** temp_tow_ms2: ' + str(temp_tow_ms2))
         print(' **** gps_format_obj.roll: ' + str(gps_format_obj.roll))
         print(' **** gps_format_obj.pitch: ' + str(gps_format_obj.pitch))
         print(' **** gps_format_obj.azimuth: ' + str(gps_format_obj.azimuth))
         print(' **** gps_format_obj.ins_status: ' + str(gps_format_obj.ins_status))

      elif (message_id == 42):   # BESTPOS [GPS/INS Blended Position]
         tmp_str = hexlify(bytearray(message_bytes)).upper()
         # print('************* BESTPOS: len(bytearray(message_bytes)) = ' + str(len(bytearray(message_bytes))) + ', bytearray(message_bytes):' + hexlify(bytearray(message_bytes)).upper())
         print('************* BESTPOS: len(bytearray(message_bytes)) = ' + str(len(bytearray(message_bytes))) + ', bytearray(message_bytes):')
         for i in range(0,len(tmp_str),2):
            print(tmp_str[i] + tmp_str[i+1]),
         print('\n')

         [temp_soln_status, temp_pos_type, gps_format_obj.ekf_lat, gps_format_obj.ekf_lon, gps_format_obj.ekf_ht_above_MSL, gps_format_obj.undulation, temp_datum_id_nbr, temp_lat_sd, temp_lon_sd, temp_ht_MSL_sd, temp_base_station_id, temp_diff_age, temp_sol_age, temp_nbr_svs_tracked, temp_nbr_svs_used, temp_nbr_gps_gll1_svs_used, temp_nbr_gps_gll1l2_svs_used, res3, temp_ext_sol_status, res4, sig_mask] = unpack('<IIdddfIfffIffBBBBBBBB', message_bytes )

      elif (message_id == 321):   # INSPOSS [INS Position]
         [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_lat, gps_format_obj.ins_lon, gps_format_obj.ins_ht_above_ellips, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

      elif (message_id == 508):   # INSPVAS [INS Position, Velocity and Attitude]
         [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_pva_lat, gps_format_obj.ins_pva_lon, gps_format_obj.ins_pva_ht_abv_ellips, gps_format_obj.ins_pva_vned_N, gps_format_obj.ins_pva_vned_E, gps_format_obj.ins_pva_vned_D, gps_format_obj.ins_pva_roll, gps_format_obj.ins_pva_pitch, gps_format_obj.ins_pva_azimuth, temp_ins_status] = unpack('<LddddddddddI', bytearray(message_bytes) )

      elif (message_id == 101):   # TIME
         [gps_format_obj.rcvr_clock_status, gps_format_obj.rcvr_clock_offset, gps_format_obj.rcvr_clock_offset_sd, gps_format_obj.utc_offset, gps_format_obj.utc_year, gps_format_obj.utc_month, gps_format_obj.utc_day, gps_format_obj.utc_hour, gps_format_obj.utc_min, gps_format_obj.utc_ms, gps_format_obj.utc_status] = unpack('<IdddLBBBBLI', bytearray(message_bytes) )
         # gps_format_obj.gps_tow = temp_tow_ms/1000.0

      elif (message_id == 99):   # BESTVEL [GPS/INS Blended Velocity]
         [temp_soln_status, temp_vel_type, gps_format_obj.ekf_latency, gps_format_obj.diff_age, gps_format_obj.ekf_horiz_speed, gps_format_obj.ekf_grnd_trc, gps_format_obj.ekf_vert_speed, res5] = unpack('<IIffdddf', bytearray(message_bytes) )

      elif (message_id == 324):   # INSVELS [INS NED Velocity]
         [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_vned_N, gps_format_obj.ins_vned_E, gps_format_obj.ins_vned_D, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

      elif (message_id == 323):   # INSSPDS [INS Speed]
         [temp_gps_week, temp_tow_ms2, gps_format_obj.ins_grnd_trc, gps_format_obj.ins_horiz_speed, gps_format_obj.ins_vert_speed, gps_format_obj.ins_status] = unpack('<LddddI', bytearray(message_bytes) )

      elif (message_id == 325):   # RAWIMUS [IMU Raw values]
         [temp_gps_week, temp_tow_ms2, gps_format_obj.imu_status, temp_z_accel, temp_y_accel, temp_x_accel, temp_z_gyro, temp_y_gyro, temp_x_gyro] = unpack('<Ldlllllll', bytearray(message_bytes) )

         gps_format_obj.z_accel = temp_z_accel * accel_scale_factor
         gps_format_obj.y_accel = -temp_y_accel * accel_scale_factor
         gps_format_obj.x_accel = temp_x_accel * accel_scale_factor

         gps_format_obj.z_gyro = temp_z_gyro * gyro_scale_factor
         gps_format_obj.y_gyro = -temp_y_gyro * gyro_scale_factor
         gps_format_obj.x_gyro = temp_x_gyro * gyro_scale_factor

      elif (message_id == 642):   # VEHICLEBODYROTATION [IMU Vehicle Body Rotation]
         [gps_format_obj.x_veh2body_angle, gps_format_obj.y_veh2body_angle, gps_format_obj.z_veh2body_angle, gps_format_obj.x_veh2body_angle_unc, gps_format_obj.y_veh2body_angle_unc, gps_format_obj.z_veh2body_angle_unc] = unpack('<dddddd', bytearray(message_bytes) )

      # } if (message_id == 319)..

      # If new value of GPS TOW found, convert GPS TOW from ms to sec and store in GPS Format Object
      if (0):
         if (message_id != 642 and temp_tow_ms_prev != temp_tow_ms):
             gps_format_obj.gps_tow = temp_tow_ms/1000.0
             temp_tow_ms_prev = temp_tow_ms
             packet_set_cnt = packet_set_cnt + 1
             # print(' ********** k = ' + str(k) + ', GPS TOW changed from ' + str(temp_tow_ms_prev/1000.0) + ' to: ' + str(temp_tow_ms/1000.0) + ', so packet_set_cnt = ' + str(packet_set_cnt))

         # Print the headers collected in the first packet set:
         if (packet_set_cnt == 2 and no_desc_list_supplied_gps_headers_printed == False):
            gps_output_order.sort()

            fout_gps.write('DATA_START\n')
            print(' *********** writing headers, len(gps_output_order) = ' + str(len(gps_output_order)))
            for gps_output_index in range(len(gps_output_order)):
               input_index = numpy.int32(gps_output_order[gps_output_index])
               fout_gps.write(gps_format_obj.format_header(input_index))

            fout_gps.write('\n')
            no_desc_list_supplied_gps_headers_printed = True
         # }

         # Print the data rows from previous packet set
         if (packet_set_cnt >= 2):
            # Print values of last GPS set, before updating 'gps_format_obj' with new set of values:
            input_index = 0
            for gps_output_index in range(len(gps_output_order)):
               input_index = numpy.int32(gps_output_order[gps_output_index])
               fout_gps.write(gps_format_obj.format(input_index))

            fout_gps.write('\n')
         # }

      # ************* TEST ONLY **********************
      if (packet_set_cnt == 150):
         return

      k = k + header_length + message_length + crc_length

   else:
      # print(' ****** DID NOT FIND MATCHING AA 44 12 *************')
      k = k + 1
   # } if (hexlify(bytearray(bytes_read[k])).upper() == 'AA' and..

 # Print the last set of values from the 'gps_format_obj', because there won't be another occurrence of GPS Time message at this point:
 if (packet_set_cnt >= 2):
   input_index = 0
   for gps_output_index in range(len(gps_output_order)):
      input_index = numpy.int32(gps_output_order[gps_output_index])
      fout_gps.write(gps_format_obj.format(input_index))

   fout_gps.write('\n')

 print('\n------------------------------------------------------------------')

 print ('\n************* Total nbr of Novatel packets: ' + str(message_cnt) + ', Nbr of Packet Sets = ' + str(packet_set_cnt))

 print('\n------------------------------------------------------------------')

 fin_bin.close()
 fout_gps.close()

if(__name__ == "__main__"):
  main_line(sys.argv)




