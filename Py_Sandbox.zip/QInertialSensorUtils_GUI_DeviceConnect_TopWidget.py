# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui

from QInertialSensorUtils_GUI_CommonWidgets import *
from QInertialSensorUtils_GUI_DeviceConnectFormWidget import *
from QInertialSensorUtils_GUI_MIP_Utils import *

from async_stream_record_thread import AsyncStreamRecord # Asynchronous Stream Record thread

from time import sleep         #sleep

from stream_record_binary_log import *

BAUD_RATE = 12000000
# BAUD_RATE = 921600

class MyDeviceConnectTopWidget(QtGui.QMainWindow):

   def __init__(self, parent):
      super(MyDeviceConnectTopWidget, self).__init__(parent)
      self.parent_obj = parent
      
      # self.tabs = QtGui.QTabWidget()

      # The folder where the binary log file will be saved (by default)
      self.last_dir = ''
      
      user_config = os.getcwd() + "/inertial_sensor.cfg"

      self.config = ConfigParser.ConfigParser()
      
      self.config.read(user_config)

      if self.config.has_section("dirs"):
         # if an entry exists then add the value to the form
         if self.config.has_option("dirs", "inputdir"):
            self.last_dir = self.config.get("dirs", "inputdir")
         # } if self.config.has_option("dirs", "inputdir")..
      # } if self.config.has_section("dirs")..
      
      # self.setStyleSheet("background-color: #DFBAEF;");
      
      self.device_connect_form_widget = MyDeviceConnectFormWidget(self)
      self.device_connect_form_widget.setStyleSheet("background-color: #F2EBE3;");
      
      self.device_connect_form_widget.setMinimumHeight(100)
      # self.device_connect_form_widget.setMinimumHeight(80)
      self.device_connect_form_widget.setFixedWidth(625)

      self.declare_spaces()
      self.__controls()
      
      central_widget = QtGui.QWidget()
      
      central_layout = QtGui.QVBoxLayout()
      central_layout.addWidget(self.vBoxWidget)
      
      central_widget.setLayout(central_layout)
      
      self.setCentralWidget(central_widget)
      
      # self.tabs.setStyleSheet("background-color: #ACCCFA;");
      # self.tabs.blockSignals(False) #now listen the currentChanged signal
      
      if (self.parent_obj.sensor_cloud_enabled):
         self.setFixedSize(610,275)
      else:
         self.setFixedSize(610,275)
         # self.setFixedSize(610,300)
      # } if (self.parent_obj.sensor_cloud_enabled)..
   
   def closeEvent(self, event):
      print "Closing MyDeviceConnectTopWidget window"
      
      self.close_process()
      
      super(MyDeviceConnectTopWidget, self).closeEvent(event)

   def close_process(self):
      print(' **** in MyDeviceConnectTopWidget: close_process()')
      
      if (self.device_connect_form_widget != None and self.device_connect_form_widget.deviceList != None):
         for cnt in range(1, self.device_connect_form_widget.deviceList.count()):
            item = self.device_connect_form_widget.deviceList.item(cnt)
    
            print(' ***** cnt = ' + str(cnt) + ', port_name: ' + item.port_obj.port_name)
    
            if (item.port_obj.ComPort != None and item.port_obj.ComPort.is_open):
               print(' ******* CLOSING Port: ' + item.port_obj.port_name)
               item.port_obj.ComPort.close()
            # } if (item.port_obj.ComPort.is_open)..
            
            if (item.port_obj.fout_bin != None):
               item.port_obj.fout_bin.close()
            # } if (item.port_obj.fout_bin != None)..
            
            if (item.port_obj.logging_thread != None and item.port_obj.logging_thread.isAlive()):
               item.port_obj.logging_thread.stop()
            # } if (item.port_obj.logging_thread != None)..
            
         # } for cnt in range(1,..
      # } if (self.device_connect_form_widget != None..
      
      self.device_connect_form_widget.clearDeviceAarray()   
      
   def __controls(self):

      self.stream_icon = QtGui.QIcon()
      self.stream_icon.addPixmap(QtGui.QPixmap("icon_stream.png"))

      self.stream_hover_icon = QtGui.QIcon()
      self.stream_hover_icon.addPixmap(QtGui.QPixmap("icon_stream_hover.png"))

      self.stream_enable_border_icon = QtGui.QIcon()
      self.stream_enable_border_icon.addPixmap(QtGui.QPixmap("icon_stream_enable_border.png"))
      
      self.record_icon = QtGui.QIcon()
      self.record_icon.addPixmap(QtGui.QPixmap("icon_record.png"))

      self.record_hover_icon = QtGui.QIcon()
      self.record_hover_icon.addPixmap(QtGui.QPixmap("icon_record_hover.png"))
      
      self.record_enable_border_icon = QtGui.QIcon()
      self.record_enable_border_icon.addPixmap(QtGui.QPixmap("icon_record_enable_border.png"))
      
      self.stop_icon = QtGui.QIcon()
      self.stop_icon.addPixmap(QtGui.QPixmap("icon_stop.png"))

      self.stop_enable_border_icon = QtGui.QIcon()
      self.stop_enable_border_icon.addPixmap(QtGui.QPixmap("icon_stop_enable_border.png"))

      self.stop_hover_icon = QtGui.QIcon()
      self.stop_hover_icon.addPixmap(QtGui.QPixmap("icon_stop_hover.png"))

      self.refresh_icon = QtGui.QIcon()
      self.refresh_icon.addPixmap(QtGui.QPixmap("icon_refresh.png"))

      self.refresh_hover_icon = QtGui.QIcon()
      self.refresh_hover_icon.addPixmap(QtGui.QPixmap("icon_refresh_hover.png"))

      self.send_cmd_icon = QtGui.QIcon()
      self.send_cmd_icon.addPixmap(QtGui.QPixmap("icon_send_command.png"))

      self.send_cmd_hover_icon = QtGui.QIcon()
      self.send_cmd_hover_icon.addPixmap(QtGui.QPixmap("icon_send_command_hover.png"))
      
      self.start_streaming_button = MyStreamRecordPushButton(self)
      self.start_streaming_button.setCheckable(True)
      self.start_streaming_button.toggle()
      self.start_streaming_button.clicked.connect(lambda:self.validate(self.start_streaming_button))
      self.start_streaming_button.setFixedWidth(30)
      self.start_streaming_button.setType(TYPE_STREAM_BUTTON)
      self.start_streaming_button.set_off_state_icon(self.stream_icon)
      self.start_streaming_button.set_off_state_hover_icon(self.stream_hover_icon)
      self.start_streaming_button.set_on_state_icon(self.stream_enable_border_icon)
      self.start_streaming_button.set_on_state_hover_icon(self.stream_hover_icon)
      
      self.stop_streaming_button = MyStreamRecordPushButton(self)
      self.stop_streaming_button.set_off_state_icon(self.stop_icon)
      self.stop_streaming_button.set_off_state_hover_icon(self.stop_hover_icon)
      self.stop_streaming_button.setCheckable(True)
      self.stop_streaming_button.toggle()
      self.stop_streaming_button.clicked.connect(lambda:self.validate(self.stop_streaming_button))
      self.stop_streaming_button.setFixedWidth(30)
      self.stop_streaming_button.setType(TYPE_STOP_STREAM_BUTTON)

      self.refresh_button = MyStreamRecordPushButton(self)
      self.refresh_button.setCheckable(True)
      self.refresh_button.toggle()
      self.refresh_button.clicked.connect(self.parent_obj.refreshDeviceList)
      self.refresh_button.setFixedWidth(30)
      self.refresh_button.set_off_state_icon(self.refresh_icon)
      self.refresh_button.set_off_state_hover_icon(self.refresh_hover_icon)
      
      self.start_stop_recording_button = MyStreamRecordPushButton(self)
      self.start_stop_recording_button.set_off_state_icon(self.record_icon)
      self.start_stop_recording_button.set_off_state_hover_icon(self.record_hover_icon)
      self.start_stop_recording_button.set_on_state_icon(self.stop_enable_border_icon)
      self.start_stop_recording_button.set_on_state_hover_icon(self.stop_hover_icon)
      
      self.start_stop_recording_button.setCheckable(True)
      self.start_stop_recording_button.toggle()
      self.start_stop_recording_button.clicked.connect(lambda:self.validate(self.start_stop_recording_button))
      self.start_stop_recording_button.setFixedWidth(30)
      self.start_stop_recording_button.setType(TYPE_RECORD_BUTTON)

      self.clear_button = MyPushButton("Clear Text Fields")
      self.clear_button.setCheckable(True)
      self.clear_button.toggle()
      self.clear_button.clicked.connect(self.clearTextFields)
      self.clear_button.setFixedWidth(110)

      self.flush_device_button = MyPushButton("Flush Device")
      self.flush_device_button.setCheckable(True)
      self.flush_device_button.toggle()
      self.flush_device_button.clicked.connect(self.flushDeviceBytes)
      self.flush_device_button.setFixedWidth(90)

      self.send_button = MyPushButton("Send")
      self.send_button.setCheckable(True)
      self.send_button.toggle()
      self.send_button.clicked.connect(self.sendCommand)
      self.send_button.setFixedWidth(50)
      
      self.browse_button = MyPushButton("Browse")
      self.browse_button.setCheckable(True)
      self.browse_button.toggle()
      self.browse_button.clicked.connect(self.selectFile)
      self.browse_button.setFixedWidth(75)

      self.edt_filename = MyLineEdit()
      self.edt_filename.setStyleSheet("background-color: white;");
      self.edt_filename.setFixedWidth(250)

      self.lbl_cmd = QtGui.QLabel("Command")
      self.lbl_cmd.setFixedWidth(60)
      self.lbl_cmd.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.lbl_chk_sum = QtGui.QLabel("Checksum")
      self.lbl_chk_sum.setFixedWidth(60)
      self.lbl_chk_sum.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_cmd = MyLineEdit()
      self.edt_cmd.setStyleSheet("background-color: white;");
      self.edt_cmd.setFixedWidth(230)

      self.lbl_checksum = QtGui.QLabel("Checksum:")
      self.lbl_checksum.setFixedWidth(60)
      self.lbl_checksum.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");

      self.edt_cmd_checksum_byte1 = MyLineEdit()
      self.edt_cmd_checksum_byte1.setStyleSheet("background-color: white;");
      self.edt_cmd_checksum_byte1.setReadOnly(True)
      self.edt_cmd_checksum_byte1.setFixedWidth(20)
      
      self.edt_cmd_checksum_byte2 = MyLineEdit()
      self.edt_cmd_checksum_byte2.setStyleSheet("background-color: white;");
      self.edt_cmd_checksum_byte2.setReadOnly(True)
      self.edt_cmd_checksum_byte2.setFixedWidth(20)
      
      self.lbl_response = QtGui.QLabel("Response")
      self.lbl_response.setFixedWidth(60)
      self.lbl_response.setStyleSheet("font-weight: bold; font-size: 11px; color: #003319");
      
      self.edt_response = MyLineEdit()
      self.edt_response.setStyleSheet("background-color: white;");
      self.edt_response.setFixedWidth(230)

      self.hStreamRecordRefreshbox = QtGui.QHBoxLayout()
      self.hStreamRecordRefreshbox.addWidget(self.start_streaming_button)
      self.hStreamRecordRefreshbox.addWidget(self.stop_streaming_button)
      self.hStreamRecordRefreshbox.addWidget(self.edt_filename)
      self.hStreamRecordRefreshbox.addWidget(self.browse_button)
      self.hStreamRecordRefreshbox.addWidget(self.start_stop_recording_button)
      self.hStreamRecordRefreshbox.addWidget(self.refresh_button)
      
      self.hStreamRecordRefreshWidget = QtGui.QWidget()
      self.hStreamRecordRefreshWidget.setLayout(self.hStreamRecordRefreshbox)
      self.hStreamRecordRefreshWidget.setStyleSheet("background-color: #DECD9F;");
      self.hStreamRecordRefreshWidget.setFixedSize(580,40)

      self.lbl_space_cmd_chk_sum_sep = QtGui.QLabel()
      self.lbl_space_cmd_chk_sum_sep.setFixedWidth(185)
      
      self.hCmdChkSumLabelbox = QtGui.QHBoxLayout()
      self.hCmdChkSumLabelbox.addWidget(self.lbl_cmd)
      self.hCmdChkSumLabelbox.addWidget(self.lbl_space_cmd_chk_sum_sep)
      self.hCmdChkSumLabelbox.addWidget(self.lbl_chk_sum)

      self.hCmdChkSumbox = QtGui.QHBoxLayout()
      self.hCmdChkSumbox.addWidget(self.edt_cmd)
      self.hCmdChkSumbox.addWidget(self.edt_cmd_checksum_byte1)
      self.hCmdChkSumbox.addWidget(self.edt_cmd_checksum_byte2)
      
      self.vCmdChkSumbox = QtGui.QVBoxLayout()
      self.vCmdChkSumbox.addLayout(self.hCmdChkSumLabelbox)
      self.vCmdChkSumbox.addLayout(self.hCmdChkSumbox)
      
      self.vCmdChkSumWidget = QtGui.QWidget()
      self.vCmdChkSumWidget.setLayout(self.vCmdChkSumbox)
      self.vCmdChkSumWidget.setStyleSheet("background-color: #E8D9FC;");
      self.vCmdChkSumWidget.setFixedSize(300,55)
      
      self.vResponsebox = QtGui.QVBoxLayout()
      self.vResponsebox.addWidget(self.lbl_response)
      self.vResponsebox.addWidget(self.edt_response)
      self.vResponsebox.setAlignment(QtCore.Qt.AlignTop)
      
      self.vResponseWidget = QtGui.QWidget()
      self.vResponseWidget.setLayout(self.vResponsebox)
      self.vResponseWidget.setStyleSheet("background-color: #ACCCFA;");
      self.vResponseWidget.setFixedSize(250,55)

      self.lbl_space_cmd_resp_sep = QtGui.QLabel()
      self.lbl_space_cmd_resp_sep.setFixedWidth(5)
      self.lbl_space_cmd_resp_sep.setFixedHeight(55)

      self.hCmdResponseBox = QtGui.QHBoxLayout()
      self.hCmdResponseBox.addWidget(self.vCmdChkSumWidget)
      self.hCmdResponseBox.addWidget(self.lbl_space_cmd_resp_sep)
      self.hCmdResponseBox.addWidget(self.vResponseWidget)
      self.hCmdResponseBox.setAlignment(QtCore.Qt.AlignTop)
      
      self.hCmdResponseWidget = QtGui.QWidget()
      self.hCmdResponseWidget.setLayout(self.hCmdResponseBox)
      self.hCmdResponseWidget.setStyleSheet("background-color: #8FBD62;");
      self.hCmdResponseWidget.setFixedSize(580,75)
      
      self.hClearSendbox = QtGui.QHBoxLayout()
      self.hClearSendbox.addWidget(self.lbl_space_xlarge)
      self.hClearSendbox.addWidget(self.clear_button)
      self.hClearSendbox.addWidget(self.flush_device_button)
      self.hClearSendbox.addWidget(self.send_button)
      self.hClearSendbox.addWidget(self.lbl_space_xlarge)
      
      self.hClearSendWidget = QtGui.QWidget()
      self.hClearSendWidget.setLayout(self.hClearSendbox)
      self.hClearSendWidget.setStyleSheet("background-color: #F2CFC0;");
      self.hClearSendWidget.setFixedSize(580,40)
      
      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addWidget(self.device_connect_form_widget)
      self.vbox.addWidget(self.hStreamRecordRefreshWidget)
      self.vbox.addWidget(self.hCmdResponseWidget)
      self.vbox.addWidget(self.hClearSendWidget)
      
      self.vBoxWidget = QtGui.QWidget()
      self.vBoxWidget.setLayout(self.vbox)

   def clearTextFields(self):
      self.edt_cmd.setText('')
      self.edt_cmd_checksum_byte1.setText('')
      self.edt_cmd_checksum_byte2.setText('')
      self.edt_response.setText('')

   def refreshDeviceList(self):
      self.close_process()
      self.device_connect_form_widget.loadDeviceList()
 
   def flushDeviceBytes(self):
      selected_device = self.device_connect_form_widget.deviceList.currentItem()

      if (selected_device == None or selected_device.port_obj == None or selected_device.port_obj.is_header):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select device first')
         return
      else:
         try:
            if (selected_device.port_obj.ComPort.is_open):
               selected_device.port_obj.ComPort.close()
            # } if (selected_device.port_obj.ComPort.is_open)..
       
            # if (not selected_device.port_obj.ComPort.is_open):
            selected_device.port_obj.ComPort.open()
            # } if (not selected_device...
         except SerialException:
            print('Port already open')
 
         sleep(0.03)
    
         data_left = selected_device.port_obj.ComPort.in_waiting    # Get the number of characters ready to be read
         print(' ****** BEFORE reset_input_buffer(), data_left = ' + str(data_left))
 
         selected_device.port_obj.ComPort.reset_input_buffer()
         selected_device.port_obj.ComPort.reset_output_buffer()
 
      # } if (selected_device == None..
      
   def sendCommand(self):
      
      selected_device = self.device_connect_form_widget.deviceList.currentItem()
      
      if (selected_device == None or selected_device.port_obj == None or selected_device.port_obj.is_header):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select device first')
         return
      elif (self.edt_cmd.text() == ''):
         QtGui.QMessageBox.about(self, "Msg Box", 'Device command cannot be empty')
         return
      else:
         print('************* in sendCommand: self.edt_cmd.text() = ' + str(self.edt_cmd.text()))
         print(' ********** self.edt_cmd.text().toLatin1() = ' + str(self.edt_cmd.text().toLatin1()))
         cmd_text = self.edt_cmd.text().toLatin1().replace(" ", "")
         print(' ********** cmd_text = ' + str(cmd_text))
 
         # mip_packet = bytearray.fromhex(self.edt_cmd.text().toLatin1())
         mip_packet = bytearray.fromhex(cmd_text)
         
         # Calculate the checksum
         checksum = fletcher_check16(mip_packet)
 
         # Add the checksum to the packet
         mip_packet.extend(checksum)
         
         tmp_str = hexlify( bytearray(checksum) ).upper()

         self.edt_cmd_checksum_byte1.setText(tmp_str[0] + tmp_str[1])
         self.edt_cmd_checksum_byte2.setText(tmp_str[2] + tmp_str[3])
 
         try:
            if (not selected_device.port_obj.ComPort.is_open):
               selected_device.port_obj.ComPort.open()
               # print(' **** in sendCmd, AFTER open(), is_open is: ' + str(selected_device.port_obj.ComPort.is_open))
            # } if (not selected_device...
         except SerialException:
            print('Port already open')

         # Send the command to device
         selected_device.port_obj.ComPort.write(mip_packet)
 
         # Read the response coming back
         # sleep(0.03)
         sleep(0.2)
         
         data_left = int(selected_device.port_obj.ComPort.in_waiting)    # Get the number of characters ready to be read
             
         print('****** data_left = ' + str(data_left))
         
         str_response_bytes = ''
 
         if (data_left > 0):
            bytes_read = selected_device.port_obj.ComPort.read(data_left)
            if (bytes_read != None):
               tmp_str = hexlify( bytearray(bytes_read) ).upper()
               
               for i1 in range(0,len(tmp_str),2):
                  str_response_bytes += tmp_str[i1] + tmp_str[i1+1]
            # } if (bytes_read != None)..
         # } if (data_left > 0)..
 
         print(' ****** str_response_bytes: ' + str_response_bytes)
 
         self.edt_response.setText(str_response_bytes)
 
         sleep(0.05)
         selected_device.port_obj.ComPort.close()
         sleep(0.05)
      # } if (selected_device == None or..
      
   def selectFile(self):
   
      default_filename = ''
      
      selected_device = self.device_connect_form_widget.deviceList.currentItem()
      
      if (selected_device == None or selected_device.port_obj == None or selected_device.port_obj.is_header):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select device first')
         return
      else:
         default_filename = get_filename(selected_device.port_obj.model_name.strip(), selected_device.port_obj.serial_nbr.strip())
      # } if (selected_device != None or..
      
      filename = QtGui.QFileDialog.getSaveFileName(self, 'Save File', self.last_dir + '/' + default_filename, '*.bin')
      
      if filename:
         self.edt_filename.setText(filename)

         (inputDirName, fin_filename) = os.path.split(str(filename))

         if not self.config.has_section("dirs"):
            self.config.add_section("dirs")
         # } if not self.config.has_section("dirs")..

         self.config.set("dirs", "inputdir", inputDirName)
 
         self.last_dir = inputDirName
 
         # if not os.getcwd().exists(configFile):
         with open("inertial_sensor.cfg", 'w') as f:
            self.config.write(f)
         # } with open("inertial_sensor.cfg"..
      # } if filename..
      
   def validate(self, b):
      print(' ********* IN VALIDATE ************ ')
      
      selected_device = self.device_connect_form_widget.deviceList.currentItem()
      
      if (selected_device == None or selected_device.port_obj == None or selected_device.port_obj.is_header):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select a device')
         return
      # } if (selected_device == None..
      
      selected_com_port = ''
      str_array = selected_device.text().split('\t')
    
      print(' ***** len(str_array) = ' + str(len(str_array)))
      cnt = 0
      for s in str_array:
         cnt += 1
         print(' ***** s = ' + str(s))
 
         if (cnt == len(str_array)-1):
            selected_com_port = 'COM' + s
         # } if (cnt == len(str_array)-1)..
      # } for s in str_array..
      
      print(' **** selected_com_port = ' + str(selected_com_port))
      
      print(' ****** self.start_stop_recording_button.getState() = ' + str(self.start_stop_recording_button.getState()))

      if (b == self.start_streaming_button):
         
         if (b.getState() == 0):
            print(' ****** WILL START STREAM ******* ')
            selected_device.port_obj.streaming_on = True
    
            self.edt_filename.setReadOnly(True)
    
            b.setState(1)
            b.enableBorder(True)
    
            # Start a background thread that streams the device output
            stream_record_binary_log_fn(selected_device.port_obj)
    
            # If the user clicked on the record button before, it would be in 'Waiting to Record' state (-1).
            # In that case, start recording (change button state to 1) as soon as user hits the Streaming button
            if (self.start_stop_recording_button.getState() == -1):
               self.start_stop_recording_button.setState(1)
               self.start_stop_recording_button.enableWaitingToRecord(False)
               self.start_stop_recording_button.enableBorder(True)
               self.start_stop_recording_button.switchIcon()
               self.edt_filename.setReadOnly(True)
               selected_device.port_obj.waiting_to_rec = False
               selected_device.port_obj.recording_state = 1
               selected_device.port_obj.cnt_stream_click = selected_device.port_obj.cnt_stream_click + 1

               if (selected_device.port_obj.bin_filename != None and \
                   str(selected_device.port_obj.bin_filename).strip() != ''):
                  print('***** Start Streaming with Waiting to Record: WILL CALL setLogFile() **** ')
                  selected_device.port_obj.logging_thread.setLogFile(selected_device.port_obj.overwrite_bin_file, selected_device.port_obj.cnt_stream_click)
               # } if (not selected_device.port_obj.overwrite_bin_file)..
            # } if (self.start_stop_recording_button.getState() == -1)..
    
            self.updateStreamStatus(selected_device, b, self.start_stop_recording_button)
         else:
            print(' ****** DUMMY STOP STREAM: DO NOTHING  ******* ')
         # } if (b.getState() == 0)..
 
      elif (b == self.stop_streaming_button):
      
         print(' ****** WILL STOP STREAM  ******* ')
         selected_device.port_obj.streaming_on = False
 
         self.start_streaming_button.setState(0)
         self.start_streaming_button.enableBorder(False)
         self.start_streaming_button.switchIcon()
        
         # If Recording is currently on, change button state to 'Waiting to Record' (-1).
         # When user clicks Start Streaming in future, the recording will resume on same file.
         if (self.start_stop_recording_button.getState() == 1):
            self.start_stop_recording_button.setState(-1)
            self.start_stop_recording_button.enableWaitingToRecord(True)
            self.start_stop_recording_button.enableBorder(True)
            self.start_stop_recording_button.switchIcon()
            selected_device.port_obj.waiting_to_rec = True
            selected_device.port_obj.recording_state = -1
         # } if (self.start_stop_recording_button.getState() == 1)..
 
         self.edt_filename.setReadOnly(False)
 
         self.updateStreamStatus(selected_device, b, self.start_stop_recording_button)
 
      elif (b == self.start_stop_recording_button):
         if (self.edt_filename.text() == ''):
            QtGui.QMessageBox.about(self, "Msg Box", 'Must specify binary filename to start recording')
            return
         # } if (self.edt_filename.text() == '')..

         if (b.getState() == 0):
            print(' ****** WILL START RECORD ******* ')

            selected_device.port_obj.overwrite_bin_file = False
            self.edt_filename.setReadOnly(True)
    
            # Check if the user is trying to record on same file as previously recorded
            if (self.edt_filename.text() == selected_device.port_obj.previous_saved_bin_filename):
               reply = QtGui.QMessageBox.question(self, "Msg Box", 'This will overwrite the previously recorded log file.  Overwrite?', \
                                                  QtGui.QMessageBox.Yes, QtGui.QMessageBox.No)
               if (reply == QtGui.QMessageBox.Yes):
                  selected_device.port_obj.overwrite_bin_file = True
                  selected_device.port_obj.bin_filename = self.edt_filename.text()
                  selected_device.port_obj.cnt_stream_click = 0
               else:
                  selected_device.port_obj.overwrite_bin_file = False
                  bin_filename = get_filename(selected_device.port_obj.model_name.strip(), selected_device.port_obj.serial_nbr.strip(), self.last_dir)
                  selected_device.port_obj.bin_filename = bin_filename
                  self.edt_filename.setText(bin_filename)
               # } if (reply == QtGui.QMessageBox.Yes)..
            else:
               selected_device.port_obj.overwrite_bin_file = False
               selected_device.port_obj.bin_filename = self.edt_filename.text()
            # } if (self.edt_filename.text() ==..  
            
            # Start recording only if streaming button is in ON position
            if (self.start_streaming_button.getState()):
               b.setState(1)
               b.enableWaitingToRecord(False)
               b.enableBorder(True)
               selected_device.port_obj.waiting_to_rec = False
               selected_device.port_obj.recording_state = 1
       
               # Open file to store binary output from device:
               if (selected_device.port_obj.bin_filename != None and \
                   str(selected_device.port_obj.bin_filename).strip() != ''):
                  print('********* Record button with Streaming ON: WILL CALL setLogFile() ******** ')    
                  selected_device.port_obj.logging_thread.setLogFile(selected_device.port_obj.overwrite_bin_file, 0)
               # } if (selected_device.port_obj.bin_filename != None..

            else: # set recording button to 'waiting to record' state (-1)
               b.setState(-1)
               b.enableWaitingToRecord(True)
               b.enableBorder(True)
               selected_device.port_obj.waiting_to_rec = True
               selected_device.port_obj.recording_state = -1
            # } if (self.start_streaming_button...
   
            print(' ***** selected_device.port_obj.overwrite_bin_file = ' + str(selected_device.port_obj.overwrite_bin_file))
            print(' ***** selected_device.port_obj.bin_filename = ' + str(selected_device.port_obj.bin_filename))
    
            if (selected_device.port_obj.logging_thread != None):
               print(' ****** selected_device.port_obj.logging_thread is NOT None')
            else:  
               print(' ****** selected_device.port_obj.logging_thread IS None')
         else:
            print(' ****** WILL STOP RECORD ******* ')
    
            reply = QtGui.QMessageBox.question(self, "Msg Box", 'This will close the recording log file.  Are you sure?', \
                                               QtGui.QMessageBox.Yes, QtGui.QMessageBox.No)
            
            if (reply == QtGui.QMessageBox.Yes):
               b.setState(0)
               b.enableWaitingToRecord(False)
               b.enableBorder(False)
               selected_device.port_obj.recording_state = 0
               selected_device.port_obj.waiting_to_rec = False
               selected_device.port_obj.previous_saved_bin_filename = self.edt_filename.text()
               self.edt_filename.setReadOnly(False)
            # } if (reply == QtGui.QMessageBox.Yes)..
         # } if (b.getState() == 0)..
 
         self.updateStreamStatus(selected_device, b, self.start_streaming_button)

      # else:
         # print('****** IT IS A SETTINGS BUTTON ******* ')
         # QtGui.QMessageBox.about(self, "Msg Box", 'Settings button')
      # } if (selected_device == None)..
      
      b.switchIcon()

      return

   def updateStreamStatus(self, item, b, b_secondary = None):

      print(' **************************************************************************** ')
      print(' *** in updateStreamStatus: INITIAL status = ' + item.port_obj.filter_status) 
      print(' **************************************************************************** ')
      
      str_filter_status = ''
      
      # print('**** Button type = ' + str(b.getType()) + ', state = ' + str(b.getState()) + ', str_filter_status_prev = ' + str_filter_status_prev)
      
      if (b.getState() == 0):
         if (b.getType() == TYPE_STREAM_BUTTON):
            # str_filter_status = 'Not Connected'
            # str_filter_status = 'Idle'
            str_filter_status = item.port_obj.filter_status
         elif (b.getType() == TYPE_STOP_STREAM_BUTTON):
            if (b_secondary.getState() == -1):
               str_filter_status = 'Waiting to Record'
            else:
               str_filter_status = 'Not Connected'
               # str_filter_status = 'Idle'
            # } if (b_secondary.getState() == -1)..   
         elif (b_secondary != None and b_secondary.getState()):
            str_filter_status = 'Streaming Data'
         else:
            # str_filter_status = 'Idle'
            str_filter_status = 'Not Connected'
         # } if (b.getType() == TYPE_STREAM_BUTTON)..
      else:
         if (b.getType() == TYPE_STREAM_BUTTON):
            if (b_secondary.getState()):
               str_filter_status = 'Recording Data'
            else:
               str_filter_status = 'Streaming Data'
            # } if (item.port_obj.filter_status ==..   
         elif (b.getType() == TYPE_RECORD_BUTTON):
            if (b.getState() == -1):
               str_filter_status = 'Waiting to Record'
            else:
               str_filter_status = 'Recording Data'
            # } if (b.getState() == -1)..   
         # } if (b.getType() == TYPE_STREAM_BUTTON)..
      # } if (b.getState() == 0)..
      
      item.port_obj.filter_status = str_filter_status
      item.setText(item.port_obj.toString())
      
      print(' ******************************************************************************* ')
      print(' ***** in updateStreamStatus: FINAL status = ' + item.port_obj.filter_status)
      print(' ******************************************************************************* ')

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)

