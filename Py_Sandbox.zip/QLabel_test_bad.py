import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

# def window():
class Form(QDialog):
   def __init__(self, parent=None):
      super(Form, self).__init__(parent)

      app = QApplication(sys.argv)
      win = QWidget()

      l1 = QLabel()
      l2 = QLabel()
      l3 = QLabel()
      l4 = QLabel()

      l1.setText("Hello World")
      # l4.setText("TutorialsPoint")
      l2.setText("welcome to Python GUI Programming")

      l1.setAlignment(Qt.AlignCenter)
      l3.setAlignment(Qt.AlignCenter)
      l4.setAlignment(Qt.AlignRight)
      l3.setPixmap(QPixmap("python.jpg"))

      layout = QVBoxLayout()
      layout.addWidget(l1)
      layout.addStretch()
      layout.addWidget(l2)
      layout.addStretch()
      layout.addWidget(l3)
      layout.addStretch()
      layout.addWidget(l4)

      l1.setOpenExternalLinks(True)
      # l4.linkActivated.connect(clicked)
      # l2.linkHovered.connect(hovered)
      l1.setTextInteractionFlags(Qt.TextSelectableByMouse)
      win.setLayout(layout)

      # layout = QVBoxLayout()

      win.b1 = QPushButton("Button1")
      win.b1.setCheckable(True)
      win.b1.toggle()
      win.b1.clicked.connect(lambda:self.whichbtn(win.b1))
      # win.b1.clicked.connect(self.btnstate)
      layout.addWidget(win.b1)

      win.b2 = QPushButton("Button2")
      win.b2.setIcon(QIcon(QPixmap("python.gif")))
      win.b2.clicked.connect(lambda:self.whichbtn(win.b2))
      layout.addWidget(win.b2)
      win.setLayout(layout)

      win.b3 = QPushButton("Disabled")
      win.b3.setEnabled(False)
      layout.addWidget(win.b3)

      win.b4 = QPushButton("&Default")
      win.b4.setDefault(True)
      win.b4.clicked.connect(lambda:self.whichbtn(win.b4))
      layout.addWidget(win.b4)

      win.setWindowTitle("QLabel Demo")
      win.show()
      sys.exit(app.exec_())

   def btnstate(self):
      # if self.b1.isChecked():
      if win.b1.isChecked():
         print "button pressed"
      else:
         print "button released"

   def whichbtn(self,b):
      print "clicked button is "+b.text()

   def hovered():
      print "hovering"

   def clicked():
      print "clicked"

def main():
   app = QApplication(sys.argv)
   ex = Form()
   ex.show()
   sys.exit(app.exec_())

if __name__ == '__main__':
   main()
   # window()
