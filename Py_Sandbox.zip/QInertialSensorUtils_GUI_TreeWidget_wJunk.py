import os
import re
import csv
import calendar

from datetime import datetime

from PyQt4 import QtCore, QtGui
from QInertialSensorUtils_GUI_CommonWidgets import *
from sensor_cloud_api import *

class MyTreeWidget(QtGui.QTreeWidget):
    def __init__(self, parent, init_file_name = None):
       super(MyTreeWidget, self).__init__()

       self.parent_obj = parent

       self.sensor_name = ''
       self.desired_action = 'gs'
       self.sensor_label = None
       self.init_file_name = None
       self.append_file_name = None
       self.csv_col_name_dict = None
       self.csv_data_dict = {}
       self.csv_mode = False

       self.n_data_columns = 0

       if (init_file_name != None):
          self.init_file_name = init_file_name
          self.csv_mode = True

       self.setItemHidden(self.headerItem(), True)
       self.initUI()
       self.itemClicked.connect(self.handleTreeWidgetClicked)

    def initUI(self):
       if (self.init_file_name != None):
          self.csv_col_name_dict = {}
          col_name_array, csv_data = self.get_table_data(False)

          (fin_filepath, fin_filename) = os.path.split(self.init_file_name)

          self.csv_col_name_dict[fin_filename] = col_name_array
          self.csv_data_dict[fin_filename] = csv_data

          self.fill_widget(self.csv_col_name_dict)
       else:
          self.sensors_dict = {}
          sensors = {}

          sensors = getSensors(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id)

          print(' ************ found ' + str(len(sensors)) + ' sensors')

          if (sensors != None and len(sensors) > 0):
             i = 0
             for s in sensors.values():
                sensor_name = str(s["name"])
                channel_name_array = []

                channels = s["channels"]
                channel_array = channels.values()
                if (channel_array != None):
                   channel_array.sort()

                   for c in channel_array:
                      channel_name = str(c["name"])
                      channel_name_array.append(channel_name)
                # } if (channel_array != None)..

                self.sensors_dict[sensor_name] = channel_name_array

                i = i + 1
             # } for s in sensors..
          # } if (sensors != None and len(sensors) > 0)..

          self.fill_widget(self.sensors_dict)

       # } if (self.init_file_name != None)..

       self.createCheckboxesForTree()

    def append_tree_obj_from_file(self, append_file_name):
       self.append_file_name = append_file_name
       self.csv_mode = True
       col_name_array, csv_data = self.get_table_data(True)
       (fin_filepath, fin_filename) = os.path.split(self.append_file_name)
       self.csv_col_name_dict[fin_filename] = col_name_array
       self.csv_data_dict[fin_filename] = csv_data

       self.fill_widget(self.csv_col_name_dict)
       root = self.invisibleRootItem()

       self.createCheckboxesForTree()

    def createCheckboxesForTree(self):
       root = self.invisibleRootItem()
       self.child_count = root.childCount()
       if (self.child_count > 0):
          for i in range(self.child_count):
              item = root.child(i)
              item.setCheckState(0, QtCore.Qt.Unchecked)
              self.childs_child_count = item.childCount()
              for j in range(self.childs_child_count):
                 items_child = item.child(j)
                 col_name = str(items_child.text(0))
                 # if (disableOnly == False):
                 items_child.setCheckState(0, QtCore.Qt.Unchecked)
                 # elif (items_child.checkState(0) == QtCore.Qt.Checked):
                    # items_child.setFlags(QtCore.Qt.ItemIsEditable)
                    # items_child.setCheckable(False)
                 # if ('tow' in str(col_name).lower()):
                    # items_child.setCheckState(0, QtCore.Qt.Checked)
                    # items_child.setFlags(QtCore.Qt.ItemIsEditable)
                    # # items_child.setCheckable(False)
                 # else:
                    # items_child.setCheckState(0, QtCore.Qt.Unchecked)
              # } for j in range(self.childs_child_count)..
          # } for i in range(self.child_count)..
       # } if (self.child_count > 0)..

    def get_table_data(self, appendMode):
       col_name_array = []
       csv_data = {}
       if (appendMode == False):
          file_name_to_use = self.init_file_name
       else:
          file_name_to_use = self.append_file_name

       if (file_name_to_use != None):
          in_csvfile = open(file_name_to_use,'rUb')
          csvreader = csv.reader(in_csvfile, delimiter=',')

          determine_headers = False
          headers_found = False
          data_row_cnt = 0
          channel_names = []
          # self.tabledata = {}

          for row_item in csvreader:

             # determined that last row in CSV indicated data start (headers are in this row)
             if (determine_headers == True):
                self.n_data_columns = len(row_item)
                print(' ******* len(row_item) = ' + str(len(row_item)) + ', self.n_data_columns = ' + str(self.n_data_columns))

                # self.tabledata[data_row_cnt] = []

                # Create a list of channel names from the headers
                for i in range(self.n_data_columns-1):
                   # self.tabledata[data_row_cnt].append(row_item[i])
                   col_name_array.append(row_item[i])
                   csv_data[row_item[i]] = []

                # column headers have been found
                headers_found = True

                # headers no longer need to be determined
                determine_headers = False

             elif(headers_found == True):
                if (len(row_item) > 0):
                   data_row_cnt = data_row_cnt + 1

                   # Now iterate the values for all columns
                   # self.tabledata[data_row_cnt] = []

                   for i in range(self.n_data_columns-1):
                      # self.tabledata[data_row_cnt].append(float(row_item[i]))
                      csv_data[col_name_array[i]].append(float(row_item[i]))
                   # } for i in range(self.n_data_columns-1)..
                # } if (len(row_item) > 0)..

             # this row is neither column headers nor data elements
             else:
                # test for DATA_START row (column headers to follow)
                if (len(row_item) == 1 and row_item[0] == 'DATA_START'):
                   determine_headers = True
             # } if (determine_headers == True)..
          # } for row_item in csvreader..
       # } if (self.init_file_name != None)..

       return col_name_array, csv_data

    def handleTreeWidgetClicked(self, item, column):
       self.blockSignals(True)
       item_parent = item.parent()
       if (item != None):
          if (item.checkState(column) == QtCore.Qt.Checked):
             msg_txt = "Checked: column: " + str(column)
             if (item_parent != None):
               msg_txt += item_parent.text(column)
             msg_txt += " " + item.text(column)
             # QtGui.QMessageBox.about(self, "Msg Box Checked", msg_txt)

             self.childs_child_count = item.childCount()
             for i in range(self.childs_child_count):
                items_child = item.child(i)
                items_child.setCheckState(0, QtCore.Qt.Checked)

          elif item.checkState(column) == QtCore.Qt.Unchecked:
             msg_txt = "UnChecked: column: " + str(column)
             if (item_parent != None):
               msg_txt += item_parent.text(column)
             msg_txt += " " + item.text(column)
             # QtGui.QMessageBox.about(self, "Msg Box Unchecked", msg_txt)

             self.childs_child_count = item.childCount()
             for i in range(self.childs_child_count):
                items_child = item.child(i)
                items_child.setCheckState(0, QtCore.Qt.Unchecked)
       # } if (item != None)..
       self.blockSignals(False)

    def fill_item(self, item, value):
       # item.setExpanded(True)
       item.setExpanded(False)
       if (type(value) is dict):
          for key, val in sorted(value.iteritems()):
             child = QtGui.QTreeWidgetItem()
             child.setText(0, unicode(key))
             item.addChild(child)
             self.fill_item(child, val)
       # } for key, val in sorted(value.iteritems())..
       elif type(value) is list:
          for val in value:
             child = QtGui.QTreeWidgetItem()
             item.addChild(child)
             if type(val) is dict:
                child.setText(0, '[dict]')
                self.fill_item(child, val)
             elif type(val) is list:
                child.setText(0, '[list]')
                self.fill_item(child, val)
             else:
                child.setText(0, unicode(val))

             # child.setExpanded(True)
             child.setExpanded(False)
          # } for val in value..
       else:
          child = QtGui.QTreeWidgetItem()
          child.setText(0, unicode(value))
          item.addChild(child)
       # } if (type(value) is dict)..

    def fill_widget(self, value):
       self.clear()
       self.fill_item(self.invisibleRootItem(), value)

