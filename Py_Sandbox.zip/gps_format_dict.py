class GPS_8109_struct:
   def __init__(self):
      [self.gps_tow, self.gps_week, self.flags_81_09] = [0,0,0]

class GPS_8103_struct:
   def __init__(self):
      [self.gps_tow, self.gps_lat, self.gps_lon, self.gps_ht_abv_ellip, self.gps_ht_abv_MSL, self.gps_horiz_acc, self.gps_vert_acc, self.flags_81_03] = [0,0,0,0,0,0,0]

class GPS_8105_struct:
   def __init__(self):
      [self.gps_tow, self.gps_vned_N, self.gps_vned_E, self.gps_vned_D, self.gps_speed, self.gps_grnd_speed, self.gps_heading, self.gps_speed_acc, self.gps_heading_acc, self.flags_81_05] = [0,0,0,0,0,0,0,0,0]

class GPS_8104_struct:
   def __init__(self):
      [self.gps_tow, self.gps_pos_ecef_x, self.gps_pos_ecef_y, self.gps_pos_ecef_z, self.gps_pos_ecef_UC, self.flags_81_04] = [0,0,0,0,0]

class GPS_8106_struct:
   def __init__(self):
      [self.gps_tow, self.gps_vel_ecef_x, self.gps_vel_ecef_y, self.gps_vel_ecef_z, self.gps_vel_ecef_UC, self.flags_81_06] = [0,0,0,0,0]

class GPS_810B_struct:
   def __init__(self):
      [self.gps_tow, self.gps_fix_type, self.gps_nbr_of_svs_used, self.gps_fix_flags, self.flags_81_0b] = [0,0,0,0]

class GPS_810A_struct:
   def __init__(self):
      [self.gps_tow, self.gps_clock_bias, self.gps_clock_drift, self.gps_clock_acc_estimate, self.flags_81_0a] = [0,0,0,0]

class GPS_810D_struct:
   def __init__(self):
      [self.gps_tow, self.gps_hw_status_sensor_state, self.gps_hw_status_antenna_state, self.gps_hw_status_antenna_power, self.flags_81_0d] = [0,0,0,0]

class GPS_8107_struct:
   def __init__(self):
      [self.gps_tow, self.geom_dop, self.pos_dop, self.horiz_dop, self.vert_dop, self.time_dop, self.northing_dop, self.easting_dop, self.flags_81_07] = [0,0,0,0,0,0,0,0]
      
class GPS_8108_struct:
   def __init__(self):
      [self.gps_tow, self.utc_yr, self.utc_mo, self.utc_day, self.utc_hr, self.utc_min, self.utc_sec, self.utc_msec, self.flags_81_08] = [0,0,0,0,0,0,0,0]



