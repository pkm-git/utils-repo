# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os, sys
import ConfigParser

from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

from csv_to_kml import *
from csv_to_gpx import *
from mip_csv_to_novatel_imu_binary import *
# from csv_remove import * # TEST ONLY

PYTHON_DIR = 'python_2_7_6/'
# PYTHON_DIR = ''

class MyLogFileFormWidget_LordInternal(QtGui.QWidget):

   def __init__(self, parent):
      super(MyLogFileFormWidget_LordInternal, self).__init__(parent)
      self.parent_obj = parent
      self.processError = False
      self.submit_timestamp = ''
      self.submit_timestamp_no_spaces_spl_chr = ''

      self.setFixedSize(550,250)
      # self.setFixedSize(550,300)

      self.__controls()
      self.__layout()

   def closeEvent(self, event):
      print "***** Closing MyLogFileFormWidget_LordInternal window"

      self.logFile.close()

      super(MyLogFileFormWidget_LordInternal, self).closeEvent(event)

   def __controls(self):
      self.declare_spaces()
   
      self.lbl_title = QtGui.QLabel("Inertial Sensor Utils")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(150)
      self.lbl_title.setFixedHeight(25)

      self.lbl_filename = QtGui.QLabel("Binary Filename:")
      self.lbl_filename.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_filename = MyLineEdit()
      self.edt_filename.setStyleSheet("background-color: white;");
      self.edt_filename.setFixedWidth(300)

      self.lbl_desired_actions = QtGui.QLabel("Desired Action(s):")
      self.lbl_desired_actions.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.cmbox_editable_sensor_list = QtGui.QComboBox()
      self.cmbox_editable_sensor_list.setFixedWidth(120)
      self.cmbox_editable_sensor_list.setFixedHeight(20)
      self.cmbox_editable_sensor_list.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_editable_sensor_list.setEditable(True)
      self.cmbox_editable_sensor_list.lineEdit().setMaxLength(120)

      self.lbl_descriptor_filter_or_csv_object = QtGui.QLabel("Descriptor Filter:")
      self.lbl_descriptor_filter_or_csv_object.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_descriptor_filter_or_csv_object_help = QtGui.QLabel("[Optional: Ex: 8012800C810981038105]")
      self.lbl_descriptor_filter_or_csv_object_help.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_descriptor_filter_or_csv_object = MyLineEdit()
      self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;");
      self.edt_descriptor_filter_or_csv_object.setFixedWidth(150)

      self.lbl_gps_week = QtGui.QLabel("GPS Week:")
      self.lbl_gps_week.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.lbl_gps_week.hide()

      self.edt_gps_week = MyLineEdit()
      self.edt_gps_week.setStyleSheet("background-color: white;");
      self.edt_gps_week.setFixedWidth(35)
      self.edt_gps_week.hide()
      
      self.lbl_device_id = QtGui.QLabel("Device ID:")
      self.lbl_device_id.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_device_id = MyLineEdit()
      self.edt_device_id.setStyleSheet("background-color: #E0E0E0;");
      if (self.parent_obj.sensor_cloud_enabled):
         self.edt_device_id.setText(self.parent_obj.device_id)
      self.edt_device_id.setFixedWidth(200)
      self.edt_device_id.setReadOnly(True)

      self.lbl_key = QtGui.QLabel("Key:")
      self.lbl_key.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_key = MyLineEdit()
      self.edt_key.setStyleSheet("background-color: #E0E0E0;");
      if (self.parent_obj.sensor_cloud_enabled and self.parent_obj.key != None):
         self.edt_key.setText(self.parent_obj.key)
      self.edt_key.setReadOnly(True)
      self.edt_key.setFixedWidth(400)

      self.lbl_input_specs = QtGui.QLabel("Input Spec:")
      self.lbl_input_specs.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.lbl_file_type = QtGui.QLabel("File Type:")
      self.lbl_file_type.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      # self.cmbox_file_type = MyComboBox('File')
      self.cmbox_file_type = MyComboBox('Lord Internal')
      self.cmbox_file_type.setFixedWidth(90)
      self.cmbox_file_type.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_file_type.currentIndexChanged.connect(self.switchParseCSVToLoad)

      # self.lbl_device_type_used = QtGui.QLabel("Protocol Used:")
      self.lbl_device_type_used = QtGui.QLabel("Protocol:")
      self.lbl_device_type_used.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.cmbox_device_type_used = MyComboBox('Device', 'GX5-45', True)
      self.cmbox_device_type_used.setFixedWidth(70)
      self.cmbox_device_type_used.setStyleSheet("background-color: #E0E0E0;");
      self.cmbox_device_type_used.currentIndexChanged.connect(self.onDeviceTypeChange)

      self.chkbx_parse_to_csv = MyCheckBox('Parse to CSV')
      self.chkbx_parse_to_csv.setChecked(False)
      self.chkbx_parse_to_csv.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.chkbx_load_csv = MyCheckBox('Load CSV')
      self.chkbx_load_csv.setChecked(False)
      self.chkbx_load_csv.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_load_csv.hide()

      self.chkbx_create_kml_gpx = MyCheckBox('Create KML/GPX')
      self.chkbx_create_kml_gpx.setChecked(False)
      self.chkbx_create_kml_gpx.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_create_kml_gpx.stateChanged.connect(self.enableGPSLLHColFields)
      self.chkbx_create_kml_gpx.hide()

      self.chkbx_create_imr = MyCheckBox('IMR')
      self.chkbx_create_imr.setChecked(False)
      self.chkbx_create_imr.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_create_imr.hide()

      self.chkbx_upload_to_sensor_cloud = MyCheckBox('Upload to SensorCloud')
      self.chkbx_upload_to_sensor_cloud.setChecked(False)
      self.chkbx_upload_to_sensor_cloud.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.chkbx_upload_to_sensor_cloud.stateChanged.connect(self.enableSensorCloudFields)

      self.lbl_gps_llh_cols = QtGui.QLabel("LLH Cols:")
      self.lbl_gps_llh_cols.setFixedWidth(55)
      self.lbl_gps_llh_cols.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");
      self.lbl_gps_llh_cols.hide()

      self.edt_gps_lat_col = MyLineEdit()
      self.edt_gps_lat_col.setStyleSheet("background-color: #E0E0E0;");
      self.edt_gps_lat_col.setFixedWidth(15)
      self.edt_gps_lat_col.setReadOnly(True)
      self.edt_gps_lat_col.hide()

      self.edt_gps_lon_col = MyLineEdit()
      self.edt_gps_lon_col.setStyleSheet("background-color: #E0E0E0;");
      self.edt_gps_lon_col.setFixedWidth(15)
      self.edt_gps_lon_col.setReadOnly(True)
      self.edt_gps_lon_col.hide()

      self.edt_gps_ht_col = MyLineEdit()
      self.edt_gps_ht_col.setStyleSheet("background-color: #E0E0E0;");
      self.edt_gps_ht_col.setFixedWidth(15)
      self.edt_gps_ht_col.setReadOnly(True)
      self.edt_gps_ht_col.hide()

      self.browse_button = MyPushButton("Browse")
      self.browse_button.setCheckable(True)
      self.browse_button.toggle()
      self.browse_button.clicked.connect(self.selectFile)
      self.browse_button.setFixedWidth(75)

      self.submit_button = MyPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(self.validate)
      self.submit_button.setFixedWidth(100)

      self.home_button = MyPushButton("Logout")
      self.home_button.setCheckable(True)
      self.home_button.toggle()
      self.home_button.clicked.connect(self.parent_obj.switchToModuleSelect)
      self.home_button.setFixedWidth(100)

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      # self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #FDDEAE; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(450)
      self.lbl_status.setFixedHeight(25)

      self.clear_status_text_button = MyPushButton("Clear Status Text")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setFixedWidth(140)

      # Open log file in append mode
      self.logFile = open('InertialSensorUtils_LogFileProcessing.log','a')

      # QProcess object for external app
      self.process = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process.readyRead.connect(self.dataReady)

      self.process.readyReadStandardOutput.connect(self.readyReadStandardOutput)
      self.process.readyReadStandardError.connect(self.readyReadStandardError)

      # Just to prevent accidentally running multiple times
      # Disable the button when process starts, and enable it when it finishes
      self.process.started.connect(self.showStarted)
      self.process.finished.connect(self.showDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

   def dataReady(self):
      self.process.setReadChannel(QtCore.QProcess.StandardOutput);

      self.logFile.write('\n')
      while (self.process.canReadLine()):
         current_line = str(self.process.readLine())
         # self.logOutput.appendText(current_line)
         self.logFile.write(current_line)
      # } while (self.process.canReadLine())..

      self.logFile.flush()

   def readyReadStandardOutput(self):
      # cursor = self.logOutput.textCursor()
      # cursor.movePosition(cursor.End)
      stdOutputStr = str(self.process.readAllStandardOutput())
      # cursor.insertText(stdOutputStr)
      # self.logOutput.ensureCursorVisible()

      self.logFile.write('\n' + stdOutputStr)
      self.logFile.flush()

      # self.logFile.write('\n')
      # current_line = str(self.process.readAllStandardOutput())
      # self.logOutput.appendText(current_line)
      # self.logFile.write(current_line)
      # self.logFile.flush()

   def readyReadStandardError(self):
      self.processError = True

      self.logFile.write('\n')
      errorLog = str(self.process.readAllStandardError())

      print(' ************* in readyReadStandardError, errorLog = ' + errorLog)

      # self.logOutput.appendText(errorLog)
      self.logFile.write(errorLog)
      self.logFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith('Status: DONE')):
         self.timer.stop()
         return
      # } if (self.lbl_status.text()..

      self.step = self.step + 1

      self.lbl_status.setText("Status: Doing.. Time elapsed: " + str(self.step) + " seconds")

   def doAction(self):
      if self.timer.isActive():
         self.timer.stop()
      else:
         self.step = 0
         self.timer.start(1000, self)
      # } if self.timer.isActive()..

   def showStarted(self):
      self.lbl_status.setText('Status: Doing.. please wait')
      self.logFile.write('\nStatus: Started the process... please wait')
      self.doAction()

   def showDone(self):
      print(' ******** in showDone *********** ')

      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked and not self.processError):
         self.parent_obj.loaded_sensor_list = False
         self.parent_obj.loaded_batch_sensor_list = False

         # Set the update sensor list flag on parent to True, so that if user does any of the 3 actions:
         # (A) user clicks on Upload to SensorCloud checkbox, or
         # (B) clicks the View Sensor tab, or
         # (C) clicks on the Batch Process tab,
         # it would get the sensor list from cloud
         self.parent_obj.sensor_list_needs_update = True
         self.parent_obj.updateSensorList()

      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked or \
          self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked or \
          self.chkbx_create_kml_gpx.checkState() == QtCore.Qt.Checked):

         if (self.processError):
            logMsg = 'ERROR.. Please check Log file processing log file.'
         else:
            # Look in config file to see if there were an errors logged for timestamp of last comamnd sent to QProcess
            errorMsg = None

            user_config = "inertial_sensor_errors_" + self.submit_timestamp_no_spaces_spl_chr + ".cfg"

            config = ConfigParser.ConfigParser()

            if (os.path.exists(user_config)):
               config.read(user_config)

               if config.has_section("errors"):
                  if config.has_option("errors", "message"):
                     errorMsg = config.get("errors", "message")
                  # } if config.has_option("errors"..
               # } if config.has_section("errors")..

               # Remove the temporary cfg file for that timestamp
               os.remove(user_config)
            # } if os.path.exists(user_config)..

            if (errorMsg != None):
               logMsg = 'ERROR: ' + errorMsg
            else:
               logMsg = 'DONE.. Time taken: ' + str(self.step) + ' seconds'
            # } if (errorMsg != None)..
         # } if (self.processError)..

         self.lbl_status.setText('Status: ' + logMsg)
         self.logFile.write('\nStatus: ' + logMsg)

      # Reset processError flag for next call
      self.processError = False
      self.step = 0
      self.timer.stop()
      # self.logFile.flush()

      if (self.chkbx_create_kml_gpx.checkState() == QtCore.Qt.Checked):
         csv_to_kml_fn(str(self.edt_filename.text()), int(self.edt_gps_lat_col.text()), int(self.edt_gps_lon_col.text()), int(self.edt_gps_ht_col.text()))
         if (self.cmbox_device_type_used.currentText() == 'MIP'):
            csv_to_gpx_fn(str(self.edt_filename.text()),2,3,int(self.edt_gps_lat_col.text()), int(self.edt_gps_lon_col.text()), int(self.edt_gps_ht_col.text()))
         else:
            csv_to_gpx_fn(str(self.edt_filename.text()),1,2,int(self.edt_gps_lat_col.text()), int(self.edt_gps_lon_col.text()), int(self.edt_gps_ht_col.text()))
         # } if (self.cmbox_device_type_used..

         self.lbl_status.setText('Status: DONE')
      # } if (self.chkbx_create_kml_gpx..

      if (self.chkbx_create_imr.checkState() == QtCore.Qt.Checked):
         if (self.cmbox_device_type_used.currentText() == 'MIP'):
            mip_csv_to_novatel_imu_binary_fn(str(self.edt_filename.text()),2,3)
         else:
            mip_csv_to_novatel_imu_binary_fn(str(self.edt_filename.text()),1,2)
         # } if (self.cmbox_device_type_used.currentText()..
      # } if (self.chkbx_create_imr.checkState()..

      # If both Upload to SensorCloud and Load CSV check-boxes are checked, it means
      # we have completed the Upload to SensorCloud task now, and need to load CSV and
      # display the tree structure in the new tab called 'CSV Data'.  Wait for a couple of
      # seconds so that the status field displays status of the Upload to SensorCloud task
      # and then switch to the CSV data tab
      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked and \
          self.chkbx_load_csv.checkState() == QtCore.Qt.Checked):
          sleep(2)
          self.parent_obj.switchToCSVDataTab()
      # } if (self.chkbx_upload_to_sensor_cloud..

   def clearStatusText(self):
      self.lbl_status.setText("Status:")
      # self.logOutput.clear()

   def enableSensorCloudFields(self, state):
      if state == QtCore.Qt.Checked:
         self.cmbox_editable_sensor_list.setStyleSheet("background-color: white;");
         self.cmbox_editable_sensor_list.setEditable(True)

         self.parent_obj.updateSensorList()

         self.cmbox_editable_sensor_list.addItems(self.parent_obj.sensorList)
      else:
         self.cmbox_editable_sensor_list.clear()
         self.cmbox_editable_sensor_list.setEditable(False)
         self.cmbox_editable_sensor_list.setStyleSheet("background-color: #E0E0E0;");
      # } if state == QtCore.Qt.Checked..

   def enableGPSLLHColFields(self, state):
      if state == QtCore.Qt.Checked:
         self.edt_gps_lat_col.setStyleSheet("background-color: white;");
         self.edt_gps_lat_col.setText('4')
         self.edt_gps_lat_col.setReadOnly(False)

         self.edt_gps_lon_col.setStyleSheet("background-color: white;");
         self.edt_gps_lon_col.setText('5')
         self.edt_gps_lon_col.setReadOnly(False)

         self.edt_gps_ht_col.setStyleSheet("background-color: white;");
         self.edt_gps_ht_col.setText('6')
         self.edt_gps_ht_col.setReadOnly(False)
      else:
         self.edt_gps_lat_col.setStyleSheet("background-color: #E0E0E0;");
         self.edt_gps_lat_col.setText('')
         self.edt_gps_lat_col.setReadOnly(True)

         self.edt_gps_lon_col.setStyleSheet("background-color: #E0E0E0;");
         self.edt_gps_lon_col.setText('')
         self.edt_gps_lon_col.setReadOnly(True)

         self.edt_gps_ht_col.setStyleSheet("background-color: #E0E0E0;");
         self.edt_gps_ht_col.setText('')
         self.edt_gps_ht_col.setReadOnly(True)
      # } if state == QtCore.Qt.Checked..

   def switchParseCSVToLoad(self, state):
      self.edt_descriptor_filter_or_csv_object.setText('')
      self.edt_gps_week.setText('')
      
      if (state == 0):   # Binary
         self.chkbx_parse_to_csv.show()
         self.chkbx_load_csv.hide()
         self.chkbx_create_kml_gpx.hide()
         self.chkbx_create_imr.hide()
         self.lbl_space_resizable_filler3.hide()
 
         self.cmbox_device_type_used.setEnabled(True) 

         self.edt_descriptor_filter_or_csv_object.setFixedWidth(150)
 
         self.lbl_descriptor_filter_or_csv_object.show()
         self.edt_descriptor_filter_or_csv_object.show()
         self.lbl_descriptor_filter_or_csv_object_help.show()
         self.lbl_space_xsmall_vis_toggle.show()
 
         self.lbl_filename.setText('Binary Filename:')

         self.lbl_descriptor_filter_or_csv_object.setText('Descriptor Filter:')
         self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional: Ex: 8012800C810981038105]')

         if (self.cmbox_device_type_used.currentText() == 'Novatel'):
            self.edt_descriptor_filter_or_csv_object.setReadOnly(True)
            self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: #E0E0E0;");
         else:
            self.edt_descriptor_filter_or_csv_object.setReadOnly(False)
            self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;")
         # } if (self.cmbox_device_type_used.currentText() ==..

         self.lbl_gps_llh_cols.hide()
         self.edt_gps_lat_col.hide()
         self.edt_gps_lon_col.hide()
         self.edt_gps_ht_col.hide()
         
         self.lbl_gps_week.hide()
         self.edt_gps_week.hide()
 
         self.lbl_space_resizable_filler.setFixedWidth(65)
         self.lbl_space_resizable_filler2.setFixedWidth(15)

      elif (state == 1):  # CSV
         self.chkbx_parse_to_csv.hide()
         self.chkbx_load_csv.show()
         self.chkbx_create_kml_gpx.show()
         self.chkbx_create_imr.show()
 
         self.edt_descriptor_filter_or_csv_object.setFixedWidth(150)
 
         self.lbl_descriptor_filter_or_csv_object.show()
         self.edt_descriptor_filter_or_csv_object.show()
         self.lbl_descriptor_filter_or_csv_object_help.show()
         self.lbl_space_xsmall_vis_toggle.show()
 
         # self.cmbox_device_type_used.setEnabled(False)
         self.cmbox_device_type_used.setEnabled(True)
         
         self.lbl_descriptor_filter_or_csv_object.setText('CSV Object Name:')
         self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional: Defaults to CSV File name]')

         self.edt_descriptor_filter_or_csv_object.setReadOnly(False)
         self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;")

         self.lbl_gps_llh_cols.show()
         self.edt_gps_lat_col.show()
         self.edt_gps_lon_col.show()
         self.edt_gps_ht_col.show()
 
         self.lbl_filename.setText('CSV Filename:')

         if (self.parent_obj.sensor_cloud_enabled):
            self.lbl_space_resizable_filler.setFixedWidth(170)
            self.lbl_space_resizable_filler2.setFixedWidth(115)
         else:
            # self.lbl_space_resizable_filler.setFixedWidth(115)
	    # self.lbl_space_resizable_filler.setFixedWidth(125)
	    self.lbl_space_resizable_filler.setFixedWidth(133)
            self.lbl_space_resizable_filler2.setFixedWidth(70)
         # } if (self.parent_obj.sensor_cloud_enabled)..
 
         if (self.cmbox_device_type_used.currentText() == 'SBG'):
            self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional]')
            self.lbl_gps_week.show()
            self.edt_gps_week.show()
            # self.lbl_space_resizable_filler2.setFixedWidth(125)
            # self.lbl_space_resizable_filler2.setFixedWidth(70)
            self.lbl_space_resizable_filler3.show()
         # } if (self.cmbox_device_type_used..
      elif (state == 2):    # VectorNav ASCII
         self.chkbx_parse_to_csv.show()
         self.chkbx_load_csv.hide()
         self.chkbx_create_kml_gpx.hide()
         self.chkbx_create_imr.hide()
         self.lbl_space_resizable_filler3.hide()
 
         self.lbl_descriptor_filter_or_csv_object.show()
         self.edt_descriptor_filter_or_csv_object.show()
         self.lbl_descriptor_filter_or_csv_object_help.show()
         self.lbl_space_xsmall_vis_toggle.show()
 
         self.lbl_descriptor_filter_or_csv_object.setText('Data Rate:')
         self.lbl_descriptor_filter_or_csv_object_help.setText('Hz')
 
         self.cmbox_device_type_used.setEnabled(False)
 
         self.edt_descriptor_filter_or_csv_object.setReadOnly(False)
         self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;")
 
         self.edt_descriptor_filter_or_csv_object.setFixedWidth(30)
         self.edt_descriptor_filter_or_csv_object.setText('100')
 
         self.lbl_filename.setText('VectorNav Log:')

         self.lbl_gps_llh_cols.hide()
         self.edt_gps_lat_col.hide()
         self.edt_gps_lon_col.hide()
         self.edt_gps_ht_col.hide()
 
         self.lbl_gps_week.hide()
         self.edt_gps_week.hide()
 
         self.lbl_space_resizable_filler.setFixedWidth(65)
	 # self.lbl_space_resizable_filler.setFixedWidth(125)
         self.lbl_space_resizable_filler2.setFixedWidth(15)
         # self.lbl_space_resizable_filler2.setFixedWidth(70)

      elif (state == 3):    # VectorNav TSV
         self.chkbx_parse_to_csv.show()
         self.chkbx_load_csv.hide()
         self.chkbx_create_kml_gpx.hide()
         self.chkbx_create_imr.hide()
         self.lbl_descriptor_filter_or_csv_object.hide()
         self.edt_descriptor_filter_or_csv_object.hide()
         self.lbl_descriptor_filter_or_csv_object_help.hide()
         self.lbl_space_xsmall_vis_toggle.hide()
 
         self.cmbox_device_type_used.setEnabled(False)
 
         self.lbl_filename.setText('VectorNav Log:')

         self.lbl_gps_llh_cols.hide()
         self.edt_gps_lat_col.hide()
         self.edt_gps_lon_col.hide()
         self.edt_gps_ht_col.hide()
 
         self.lbl_gps_week.hide()
         self.edt_gps_week.hide()
 
         self.lbl_space_resizable_filler.setFixedWidth(65)
	 # self.lbl_space_resizable_filler.setFixedWidth(125)
         self.lbl_space_resizable_filler2.setFixedWidth(15)
         # self.lbl_space_resizable_filler2.setFixedWidth(70)

      # } if (state == 0)..

   def onDeviceTypeChange(self, state):
      # self.edt_descriptor_filter_or_csv_object.setText('')
      self.lbl_space_resizable_filler3.hide()
      
      if (self.cmbox_file_type.currentText() == 'CSV'):
         self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional: Defaults to CSV File name]')
      # } if (self.cmbox_file_type.currentText() == 'CSV')..
         
      if (state == 0):  # MIP
         self.edt_descriptor_filter_or_csv_object.setReadOnly(False)
         self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;");
 
      else:  # Novatel or SBG
         if (self.cmbox_file_type.currentText() == 'Binary'):
            self.edt_descriptor_filter_or_csv_object.setReadOnly(True)
            self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: #E0E0E0;");
         else:
            self.edt_descriptor_filter_or_csv_object.setReadOnly(False)
            self.edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;");
    
         # } if (self.cmbox_file_type.currentText()..
      # } if (state == 0)..

      if (state == 2):  # SBG
         self.chkbx_upload_to_sensor_cloud.setEnabled(False)
 
         if (self.cmbox_file_type.currentText() == 'CSV'):
            self.chkbx_create_imr.setEnabled(False)
            self.chkbx_create_kml_gpx.setEnabled(False)
 
            self.lbl_gps_week.show()
            self.edt_gps_week.show()
            self.lbl_descriptor_filter_or_csv_object_help.setText('[Optional]')
            self.lbl_space_resizable_filler3.show()
         # } if (self.cmbox_file_type.currentText() == 'CSV')..   
      elif (state == 1):  # Novatel
         self.chkbx_create_imr.setEnabled(False)
         self.chkbx_create_kml_gpx.setEnabled(False)
         self.lbl_gps_week.hide()
         self.edt_gps_week.hide()
      else:
         self.chkbx_create_imr.setEnabled(True)
         self.chkbx_create_kml_gpx.setEnabled(True)
         self.chkbx_upload_to_sensor_cloud.setEnabled(True)
         self.lbl_gps_week.hide()
         self.edt_gps_week.hide()
      # } if (state == 2)..

   def openHelpWindow(self):
      addr = QtCore.QString("file:///" + os.getcwd() + "/Inertial Sensor Utils 2.0 (8500-0079) B_LordInternal.pdf")

      tempArray = QtCore.QByteArray(addr.toUtf8())
      addrW    = tempArray.data()

      qd = QtGui.QDesktopServices()
      qurl = QtCore.QUrl(addrW)
      qd.openUrl(qurl);

   def __layout(self):

      help_button = MyPushButton("?")
      help_button.setCheckable(True)
      help_button.toggle()
      help_button.clicked.connect(self.openHelpWindow)
      help_button.setFixedWidth(20)
      help_button.setFixedHeight(20)

      self.h0box = QtGui.QHBoxLayout()
      self.h0box.addWidget(self.lbl_space_small)
      self.h0box.addWidget(self.lbl_title)
      self.h0box.addWidget(self.lbl_space_large)
      self.h0box.addWidget(self.home_button)
      # self.h0box.addWidget(self.lbl_space_small)
      self.h0box.addWidget(self.lbl_space_large)
      self.h0box.addWidget(help_button)

      # Create self.v11box:
      self.v11box = QtGui.QVBoxLayout()
      self.v11box.addWidget(self.lbl_input_specs)
      self.v11box.addWidget(self.lbl_filename)
      self.v11box.addWidget(self.lbl_descriptor_filter_or_csv_object)
      self.v11box.addWidget(self.lbl_desired_actions)

      if (self.parent_obj.sensor_cloud_enabled):
         self.v11box.addWidget(self.lbl_sensor_name)
         self.v11box.addWidget(self.lbl_device_id)
         if (self.parent_obj.key != None):
            self.v11box.addWidget(self.lbl_key)
         # } if (self.parent_obj.key != None)..
      # } if (self.parent_obj.sensor_cloud_enabled)..

      self.hFileTypeProtocolBox = QtGui.QHBoxLayout()
      self.hFileTypeProtocolBox.addWidget(self.lbl_space_xsmall)
      self.hFileTypeProtocolBox.addWidget(self.lbl_file_type)
      self.hFileTypeProtocolBox.addWidget(self.cmbox_file_type)
      self.hFileTypeProtocolBox.addWidget(self.lbl_space_small)
      self.hFileTypeProtocolBox.addWidget(self.lbl_device_type_used)
      self.hFileTypeProtocolBox.addWidget(self.cmbox_device_type_used)
      
      self.hFileTypeProtocolBox.addWidget(self.lbl_space_resizable_filler)

      self.hFileTypeProtocolLBox = QtGui.QHBoxLayout()
      self.hFileTypeProtocolLBox.addLayout(self.hFileTypeProtocolBox)
 
      self.hFilenameBrowseBox = QtGui.QHBoxLayout()
      self.hFilenameBrowseBox.addWidget(self.lbl_space_xxsmall)
      self.hFilenameBrowseBox.addWidget(self.edt_filename)
      self.hFilenameBrowseBox.addWidget(self.browse_button)
      self.hFilenameBrowseBox.addWidget(self.lbl_space_resizable_filler2)

      self.h32box = QtGui.QHBoxLayout()
      # self.h32box.addWidget(self.lbl_space_xsmall)
      self.h32box.addWidget(self.lbl_space_xsmall_vis_toggle)
      self.h32box.addWidget(self.edt_descriptor_filter_or_csv_object)
      self.h32box.addWidget(self.lbl_descriptor_filter_or_csv_object_help)
      
      # self.h32box.addWidget(self.lbl_space_resizable_filler3)
      
      self.h32box.addWidget(self.lbl_gps_week)
      self.h32box.addWidget(self.edt_gps_week)
      
      self.h32box.addWidget(self.lbl_space_resizable_filler3)
      
      self.h42box = QtGui.QHBoxLayout()
      self.h42box.addWidget(self.lbl_space_xsmall)
      self.h42box.addWidget(self.chkbx_parse_to_csv)
      self.h42box.addWidget(self.chkbx_load_csv)

      if (self.parent_obj.sensor_cloud_enabled):
         self.h42box.addWidget(self.chkbx_upload_to_sensor_cloud)

      self.h42box.addWidget(self.chkbx_create_kml_gpx)

      if (self.parent_obj.sensor_cloud_enabled):
         self.h42box.addWidget(self.lbl_space_xsmall)
         self.h42box.addWidget(self.chkbx_create_imr)
      else:
         self.h42box.addWidget(self.lbl_gps_llh_cols)
         # self.h42box.addWidget(self.edt_gps_week_col)
         # self.h42box.addWidget(self.edt_gps_tow_col)
         self.h42box.addWidget(self.edt_gps_lat_col)
         self.h42box.addWidget(self.edt_gps_lon_col)
         self.h42box.addWidget(self.edt_gps_ht_col)

         self.h42box.addWidget(self.lbl_space_xsmall)
         self.h42box.addWidget(self.chkbx_create_imr)
      # } if (self.parent_obj.sensor_cloud_enabled)..

      self.h42Lbox = QtGui.QHBoxLayout()
      self.h42Lbox.addLayout(self.h42box)
      self.h42Lbox.addWidget(self.lbl_space_medium)

      self.v12box = QtGui.QVBoxLayout()
      # self.v12box.addLayout(self.h12Lbox)
      # self.v12box.addWidget(self.hFileTypeProtocolWidget)
      # self.v12box.addLayout(self.hFileTypeProtocolBox)
      self.v12box.addLayout(self.hFileTypeProtocolLBox)
      # self.v12box.addLayout(self.h22box)
      # self.v12box.addWidget(self.hFilenameBrowseWidget)
      self.v12box.addLayout(self.hFilenameBrowseBox)
      
      self.v12box.addLayout(self.h32box)
      self.v12box.addLayout(self.h42Lbox)
      self.v12box.setAlignment(QtCore.Qt.AlignLeft)

      self.h43box = QtGui.QHBoxLayout()

      if (self.parent_obj.sensor_cloud_enabled):
         self.h43box.addWidget(self.cmbox_editable_sensor_list)

         self.h43box.addWidget(self.lbl_gps_llh_cols)
         # self.h43box.addWidget(self.edt_gps_week_col)
         # self.h43box.addWidget(self.edt_gps_tow_col)
         self.h43box.addWidget(self.edt_gps_lat_col)
         self.h43box.addWidget(self.edt_gps_lon_col)
         self.h43box.addWidget(self.edt_gps_ht_col)

         self.h43box.setAlignment(QtCore.Qt.AlignLeft)
      # } if (self.parent_obj.sensor_cloud_enabled)..

      self.v12box.addLayout(self.h43box)

      if (self.parent_obj.sensor_cloud_enabled):
         self.v12box.addWidget(self.edt_device_id)
         if (self.parent_obj.key != None):
            self.v12box.addWidget(self.edt_key)
         # } if (self.parent_obj.key != None)..
      # } if (self.parent_obj.sensor_cloud_enabled)..
      
      self.h1box = QtGui.QHBoxLayout()
      self.h1box.addLayout(self.v11box)
      self.h1box.addLayout(self.v12box)

      self.h5box = QtGui.QHBoxLayout()
      self.h5box.addWidget(self.lbl_space_small)
      self.h5box.addWidget(self.clear_status_text_button)
      self.h5box.addWidget(self.submit_button)
      self.h5box.addWidget(self.lbl_space_small)

      self.h6box = QtGui.QHBoxLayout()
      self.h6box.addWidget(self.lbl_space_small)
      self.h6box.addWidget(self.lbl_status)
      self.h6box.addWidget(self.lbl_space_small)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.h0box)
      self.vbox.addLayout(self.h1box)
      self.vbox.addLayout(self.h5box)
      self.vbox.addLayout(self.h6box)

      self.setLayout(self.vbox)

   def selectFile(self):
      theInputDir = ""

      user_config = os.getcwd() + "/inertial_sensor.cfg"

      config = ConfigParser.ConfigParser()
      config.read(user_config)

      if config.has_section("dirs"):
         # if an entry exists then add the value to the form
         if config.has_option("dirs", "inputdir"):
            theInputDir = config.get("dirs", "inputdir")
         # } if config.has_option("dirs", "inputdir")..
      # } if config.has_section("dirs")..

      filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', theInputDir, '*.*')

      if filename:
         self.edt_filename.setText(filename)

         (inputDirName, fin_filename) = os.path.split(str(filename))

         if not config.has_section("dirs"):
            config.add_section("dirs")
         # } if not config.has_section("dirs")..

         config.set("dirs", "inputdir", inputDirName)

         # if not os.getcwd().exists(configFile):
         with open("inertial_sensor.cfg", 'w') as f:
            config.write(f)
         # } with open("inertial_sensor.cfg"..
      # } if filename..

   def validate(self):
      error_msg = ''

      if (self.edt_filename.text() == ''):
         error_msg += 'File name cannot be empty\n'
      # } if (self.edt_filename.text() == '')..

      if (self.cmbox_device_type_used.currentText() == 'SBG' and \
          self.cmbox_file_type.currentText() == 'CSV' and \
          self.edt_gps_week.text() == ''):
         error_msg += 'GPS Week cannot be empty for SBG\n'
      # } if (self.edt_gps_week.text() == '')..
      
      if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
         if (self.cmbox_editable_sensor_list.currentText() == ''):
            error_msg += 'Sensor name cannot be empty\n'
         # } if (self.cmbox_editable_sensor_list...
      # } if (self.chkbx_upload_to_sensor_cloud.checkState()..

      sensor_label = None

      parse_to_csv_action = ''
      load_csv_only = False
      command_line = ''

      if (self.cmbox_file_type.currentText() == 'CSV' and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Unchecked and \
          self.chkbx_load_csv.checkState() == QtCore.Qt.Unchecked and self.chkbx_create_kml_gpx.checkState() == QtCore.Qt.Unchecked and \
          self.chkbx_create_imr.checkState() == QtCore.Qt.Unchecked):

          error_msg += 'Must check at least one check-box: Load CSV, Create KML, IMR or Upload to SensorCloud'

      # elif (self.cmbox_file_type.currentText() == 'Binary' and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Unchecked and \
      elif ((self.cmbox_file_type.currentText() == 'Binary' or \
             self.cmbox_file_type.currentText() == 'VectorNav ASCII' or \
             self.cmbox_file_type.currentText() == 'VectorNav TSV') and \
             self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Unchecked and \
             self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Unchecked):

          error_msg += 'Must check at least one check-box: Parse to CSV or Upload to SensorCloud'

      # } if (self.cmbox_file_type.currentText() == 'CSV' and..

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
         return
      else:
         tmp_submit_timestamp = str(datetime.now())
         self.submit_timestamp = tmp_submit_timestamp
         tmp_submit_timestamp = tmp_submit_timestamp.strip().replace(" ", "_")
         tmp_submit_timestamp = tmp_submit_timestamp.replace(".", "_")
         tmp_submit_timestamp = tmp_submit_timestamp.replace(":", "_")
         self.submit_timestamp_no_spaces_spl_chr = tmp_submit_timestamp[:-7]

         if (self.cmbox_file_type.currentText() == 'Binary'):
            if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):
               parse_to_csv_action += 'p'

            if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
               parse_to_csv_action += 'u'

            parse_to_csv_action += 'f'

            if (self.cmbox_device_type_used.currentText() == 'MIP'):
               parse_to_csv_action += 'mb'
            elif (self.cmbox_device_type_used.currentText() == 'Novatel'):
               parse_to_csv_action += 'nb'
            else: # SBG
               parse_to_csv_action += 'sb'
            # } if (self.cmbox_device_type_used.currentText() == 'MIP')..

            desired_desc = self.edt_descriptor_filter_or_csv_object.text()

            if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked and self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

               command_line = PYTHON_DIR + 'python sensor_cloud_utils_LordInternal.pyc -d "' + self.parent_obj.device_id
               command_line += '" -sv "' + self.parent_obj.server
               command_line += '" -t "' + self.parent_obj.token
               command_line += '" -s "' + str(self.cmbox_editable_sensor_list.currentText())
               command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action + ' -i "'
               command_line += str(self.edt_filename.text())
               if (desired_desc != ''):
                  command_line += '" -dd "' + desired_desc
               command_line += '"'
               command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'
            
            elif (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked):

               command_line = PYTHON_DIR + 'python sensor_cloud_utils_LordInternal.pyc -i "'
               command_line += str(self.edt_filename.text())
               command_line += '" -a ' + parse_to_csv_action
               if (desired_desc != ''):
                  command_line += ' -dd "' + desired_desc + '"'
               command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'
            
            elif (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):

               command_line = PYTHON_DIR + 'python sensor_cloud_utils_LordInternal.pyc -d "' + self.parent_obj.device_id
               command_line += '" -sv "' + self.parent_obj.server
               command_line += '" -t "' + self.parent_obj.token
               command_line += '" -s "' + str(self.cmbox_editable_sensor_list.currentText())
               command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename.text()) + '"'
               if (desired_desc != ''):
                  command_line += ' -dd "' + desired_desc + '"'
               command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'
            # } if (self.chkbx_parse_to_csv.checkState() == QtCore.Qt.Checked)..

         elif (self.cmbox_file_type.currentText() == 'CSV'):

            if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
               parse_to_csv_action += 'u'
            # } if (self.chkbx_upload_to_sensor_cloud.checkState() ==..

            parse_to_csv_action += 'f'

            if (self.cmbox_device_type_used.currentText() == 'MIP'):
               parse_to_csv_action += 'mcsv'
            else:
               parse_to_csv_action += 'ncsv'
            # } if (self.cmbox_device_type_used.currentText() ==..

            if (self.chkbx_upload_to_sensor_cloud.checkState() == QtCore.Qt.Checked):
               command_line = PYTHON_DIR + 'python sensor_cloud_utils_LordInternal.pyc -d "' + self.parent_obj.device_id
               command_line += '" -sv "' + self.parent_obj.server
               command_line += '" -t "' + self.parent_obj.token
               command_line += '" -s "' + str(self.cmbox_editable_sensor_list.currentText())
               command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename.text()) + '"'
               command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'
            else:
               self.logFile.flush()

               if (self.chkbx_create_kml_gpx.checkState() == QtCore.Qt.Checked):
                  csv_to_kml_fn(str(self.edt_filename.text()), int(self.edt_gps_lat_col.text()), int(self.edt_gps_lon_col.text()), int(self.edt_gps_ht_col.text()))
                  if (self.cmbox_device_type_used.currentText() == 'MIP'):
                     csv_to_gpx_fn(str(self.edt_filename.text()),2,3,int(self.edt_gps_lat_col.text()), int(self.edt_gps_lon_col.text()), int(self.edt_gps_ht_col.text()))
                  else:
                     csv_to_gpx_fn(str(self.edt_filename.text()),1,2,int(self.edt_gps_lat_col.text()), int(self.edt_gps_lon_col.text()), int(self.edt_gps_ht_col.text()))
                  # } if (self.cmbox_device_type_used.currentText() == 'MIP')..

               if (self.chkbx_create_imr.checkState() == QtCore.Qt.Checked):
                  if (self.cmbox_device_type_used.currentText() == 'MIP'):
                     mip_csv_to_novatel_imu_binary_fn(str(self.edt_filename.text()),2,3)
                  else:
                     mip_csv_to_novatel_imu_binary_fn(str(self.edt_filename.text()),1,2)
                  # } if (self.cmbox_device_type_used.currentText()..
               # } if (self.chkbx_create_imr.checkState()..

               self.lbl_status.setText('Status: DONE')

               if (self.chkbx_load_csv.checkState() == QtCore.Qt.Checked):
                  self.parent_obj.switchToCSVDataTab()
               # } if (self.chkbx_load_csv.checkState() == QtCore.Qt.Checked)..
            # } if (self.chkbx_upload_to_sensor_cloud...
    
         elif (str(self.cmbox_file_type.currentText()).startswith('VectorNav')):

            parse_to_csv_action += 'pf'
            isASCII = (self.cmbox_file_type.currentText() == 'VectorNav ASCII')
    
            if (isASCII):
               parse_to_csv_action += 'va'
            else:  # VectorNav TSV
               parse_to_csv_action += 'vt'
            # } if (self.cmbox_device_type_used.currentText() == 'MIP')..

            command_line = PYTHON_DIR + 'python sensor_cloud_utils_LordInternal.pyc -i "'
            command_line += str(self.edt_filename.text())
            command_line += '" -a ' + parse_to_csv_action
    
            if (isASCII):
               command_line += ' -r ' + self.edt_descriptor_filter_or_csv_object.text()
            # } if (isASCII)..
       
            command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'
            
         # } if (self.cmbox_file_type.currentText() == 'Binary')..
      # } if (error_msg != '')..

      if (command_line != ''):
         # subprocess.call(command_line)

         self.logFile.write('\n\n--------------------------------------------------------------------------\n')
         self.logFile.write(' ******** Starting File processing command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
         # self.logFile.write(' ******** Starting File processing command log at local date/time: ' + str(datetime.now()) + ' ' + str(local_time.tzname) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')

         msg_txt = ''
         binary_input = False

         # If action string ends with 'b', it means input file is binary
         if (parse_to_csv_action[-1] == 'b'):
            msg_txt = 'BINARY INPUT: '
            binary_input = True
         elif (parse_to_csv_action[-1] == 'a'):
            msg_txt = 'VECTORNAV ASCII INPUT: '
         elif (parse_to_csv_action[-1] == 't'):
            msg_txt = 'VECTORNAV TSV INPUT: '
         else:
            msg_txt = 'CSV INPUT: '
         # } if (parse_to_csv_action[-1] == 'b')..

         # If action string begins with 'p', it means user wants to parse binary
         # If second character of action string is 'u', it means user wants to upload to sensor cloud
         if (parse_to_csv_action[:2] == 'pu'):
            msg_txt += 'PARSE TO CSV, UPLOAD TO SENSOR CLOUD CHECKED'
         elif (parse_to_csv_action[:1] == 'u'):
            msg_txt += 'UPLOAD TO SENSOR CLOUD CHECKED'
         elif (parse_to_csv_action[:1] == 'p' and parse_to_csv_action[1] != 'u'):
            msg_txt += 'ONLY PARSE TO CSV CHECKED'
         # } if (parse_to_csv_action[:2] == 'pu')..

         print('\n ***** ' + msg_txt + ': ' + command_line)
         self.logFile.write('\n ***** ' + msg_txt + ': ' + command_line)
         # self.logFile.flush()

         # run the process
         self.process.start(command_line)
      # } if (command_line != '')..

      return

   def declare_spaces(self):
   
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xxsmall = QtGui.QLabel()
      self.lbl_space_xxsmall.setFixedSize(1,25)
      
      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_xsmall_vis_toggle = QtGui.QLabel()
      self.lbl_space_xsmall_vis_toggle.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)
      
      self.lbl_space_resizable_filler = QtGui.QLabel()
      self.lbl_space_resizable_filler.setFixedSize(65,25)
      # self.lbl_space_resizable_filler.setFixedSize(125,25)
      
      self.lbl_space_resizable_filler2 = QtGui.QLabel()
      self.lbl_space_resizable_filler2.setFixedSize(15,25)
      # self.lbl_space_resizable_filler2.setFixedSize(95,25)

      self.lbl_space_resizable_filler3 = QtGui.QLabel()
      # self.lbl_space_resizable_filler3.setFixedSize(105,25)
      self.lbl_space_resizable_filler3.setFixedSize(80,25)
      self.lbl_space_resizable_filler3.hide()


