import csv

def load_mip_header_dictionary(dictionary_file_name):
    """Generate dictionary of column headers from specified dictionary file."""
    #create empty descriptor dictionary
    desc_dictionary = {}

    #generate a dictionary of the possible headers from their DS-FD pairs
    #using csv file provided
    with open(dictionary_file_name,'rUb') as csvfile:
        csvreader = csv.reader(csvfile)
        #loop over all rows in the csv and populate the dictionary
        for column in csvreader:
            #use a tuple from the DS-FD pair as the dictionary key as these are stored
            #in the first two columns of each row of the csv
            #then populate the value with a tuple of all the non-empty strings following
            #the second column and strip out the tabs
            desc_dictionary.update({(int(column[0]),int(column[1])):([x.translate(None,'\t') for x in column[2:] if (x != '')])})

    return desc_dictionary
