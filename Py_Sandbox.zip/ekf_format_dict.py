class EKF_8211_struct:
   def __init__(self):
      [self.ekf_week, self.ekf_tow, self.flags_82_11] = [0,0,0]

class EKF_8210_struct:
   def __init__(self):
      [self.ekf_tow, self.ekf_state, self.ekf_mode, self.flags_82_10] = [0,0,0]

class EKF_8201_struct:
   def __init__(self):
      [self.ekf_tow, self.ekf_pos_llh_lat, self.ekf_pos_llh_lon, self.ekf_pos_llh_ht, self.flags_82_01] = [0,0,0,0]

class EKF_8208_struct:
   def __init__(self):
      [self.ekf_tow, self.ekf_pos_llh_UC_lat, self.ekf_pos_llh_UC_lon, self.ekf_pos_llh_UC_ht, self.flags_82_08] = [0,0,0,0]

class EKF_8202_struct:
   def __init__(self):
      [self.ekf_tow, self.ekf_ned_vel_x, self.ekf_ned_vel_y, self.ekf_ned_vel_z, self.flags_82_02] = [0,0,0,0]

class EKF_8209_struct:
   def __init__(self):
      [self.ekf_tow, self.ekf_ned_vel_UC_x, self.ekf_ned_vel_UC_y, self.ekf_ned_vel_UC_z, self.flags_82_09] = [0,0,0,0]

class EKF_8205_struct:
   def __init__(self):
      [self.ekf_tow, self.euler_angle_roll, self.euler_angle_pitch, self.euler_angle_yaw, self.flags_82_05] = [0,0,0,0]

class EKF_820A_struct:
   def __init__(self):
      [self.ekf_tow, self.euler_angle_UC_roll, self.euler_angle_UC_pitch, self.euler_angle_UC_yaw, self.flags_82_0a] = [0,0,0,0]

class EKF_8203_struct:
   def __init__(self):
      [self.ekf_tow, self.quat_0, self.quat_1, self.quat_2, self.quat_3, self.flags_82_03] = [0,0,0,0,0]

class EKF_8212_struct:
   def __init__(self):
      [self.ekf_tow, self.quat_UC_0, self.quat_UC_1, self.quat_UC_2, self.quat_UC_3, self.flags_82_12] = [0,0,0,0,0]

class EKF_8207_struct:
   def __init__(self):
      [self.ekf_tow, self.accel_bias_x, self.accel_bias_y, self.accel_bias_z, self.flags_82_07] = [0,0,0,0]

class EKF_820C_struct:
   def __init__(self):
      [self.ekf_tow, self.accel_bias_UC_x, self.accel_bias_UC_y, self.accel_bias_UC_z, self.flags_82_0c] = [0,0,0,0]

class EKF_8217_struct:
   def __init__(self):
      [self.ekf_tow, self.accel_SF_x, self.accel_SF_y, self.accel_SF_z, self.flags_82_17] = [0,0,0,0]

class EKF_8219_struct:
   def __init__(self):
      [self.ekf_tow, self.accel_SF_UC_x, self.accel_SF_UC_y, self.accel_SF_UC_z, self.flags_82_19] = [0,0,0,0]

class EKF_8206_struct:
   def __init__(self):
      [self.ekf_tow, self.gyro_bias_x, self.gyro_bias_y, self.gyro_bias_z, self.flags_82_06] = [0,0,0,0]

class EKF_820B_struct:
   def __init__(self):
      [self.ekf_tow, self.gyro_bias_UC_x, self.gyro_bias_UC_y, self.gyro_bias_UC_z, self.flags_82_0b] = [0,0,0,0]

class EKF_8216_struct:
   def __init__(self):
      [self.ekf_tow, self.gyro_SF_x, self.gyro_SF_y, self.gyro_SF_z, self.flags_82_16] = [0,0,0,0]

class EKF_8218_struct:
   def __init__(self):
      [self.ekf_tow, self.gyro_SF_UC_x, self.gyro_SF_UC_y, self.gyro_SF_UC_z, self.flags_82_18] = [0,0,0,0]

class EKF_820D_struct:
   def __init__(self):
      [self.ekf_tow, self.lin_accel_x, self.lin_accel_y, self.lin_accel_z, self.flags_82_0d] = [0,0,0,0]

class EKF_821C_struct:
   def __init__(self):
      [self.ekf_tow, self.comp_accel_x, self.comp_accel_y, self.comp_accel_z, self.flags_82_1c] = [0,0,0,0]

class EKF_820E_struct:
   def __init__(self):
      [self.ekf_tow, self.comp_gyro_x, self.comp_gyro_y, self.comp_gyro_z, self.flags_82_0e] = [0,0,0,0]

class EKF_8213_struct:
   def __init__(self):
      [self.ekf_tow, self.grav_vect_x, self.grav_vect_y, self.grav_vect_z, self.flags_82_13] = [0,0,0,0]

class EKF_820F_struct:
   def __init__(self):
      [self.ekf_tow, self.grav_mag, self.flags_82_0f] = [0,0]

class EKF_8214_struct:
   def __init__(self):
      [self.ekf_tow, self.heading, self.heading_UC, self.heading_source, self.flags_82_14] = [0,0,0,0]

class EKF_8215_struct:
   def __init__(self):
      [self.ekf_tow, self.inten_N, self.inten_E, self.inten_D, self.inclination, self.declination, self.flags_82_15] = [0,0,0,0,0,0]

class EKF_8220_struct:
   def __init__(self):
      [self.ekf_tow, self.geom_alt, self.geopot_alt, self.temp, self.pressure, self.density, self.flags_82_20] = [0,0,0,0,0,0]

class EKF_8221_struct:
   def __init__(self):
      [self.ekf_tow, self.pressure_altitude, self.flags_82_21] = [0,0]

class EKF_8230_struct:
   def __init__(self):
      [self.ekf_tow, self.gps_ant_offset_corr_x, self.gps_ant_offset_corr_y, self.gps_ant_offset_corr_z, self.flags_82_30] = [0,0,0,0]

class EKF_8231_struct:
   def __init__(self):
      [self.ekf_tow, self.gps_ant_offset_corr_UC_x, self.gps_ant_offset_corr_UC_y, self.gps_ant_offset_corr_UC_z, self.flags_82_31] = [0,0,0,0]

class EKF_8204_struct:
   def __init__(self):
      [self.ekf_tow, self.matrix_m11, self.matrix_m12, self.matrix_m13, self.matrix_m21, self.matrix_m22, self.matrix_m23, self.matrix_m31, self.matrix_m32, self.matrix_m33, self.flags_82_04] = [0,0,0,0,0,0,0,0,0,0]







