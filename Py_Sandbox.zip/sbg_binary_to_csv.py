# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import sys
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from sbg_csv_format_using_dict import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

from sensor_cloud_api import *

import numpy
import math
import os
import re
import psutil

import struct

def sbg_binary_to_csv_fn(in_file_name):

   print('\n------------------------------------------------------------------')

   # if arguments sent in were not properly specified, tell the user and exit
   if (in_file_name == None):
      print('Input file name cannot be empty')
      sys.exit()
   # } if (in_file_name == None..
   
   (fin_filepath, fin_filename) = os.path.split(in_file_name)
   
   fout_filename = os.path.join(fin_filepath, fin_filename[:-4] + "_Log.csv")
   fout_sbg = open(os.path.join(fin_filepath, fout_filename), "w")
   
   sensStatus = 0
   
   found_bad_pkt = False
   message_cnt_of_bad_pkt = 0
   
   # Array to store the order of columns requested by the user (in binary log file):
   sbg_output_order_in_log = []

   # Array to store final, sorted output column order based on 'master sequence'
   sbg_output_order_final = []

   # Add GPS Week, GPS TOW for every category
   sbg_output_order_in_log.append(0)

   headers_printed = False

   gps_valid_tow_found = False

   sbg_format_dict_array = []
   sbg_format_dict = {}
   sbg_format_using_dict = SBG_CSV_format_using_dict()
   
   [sbg_01_struct, sbg_02_struct, sbg_03_struct, sbg_04_struct, sbg_06_struct, sbg_07_struct] = \
        [SBG_01_struct(), SBG_02_struct(), SBG_03_struct(), SBG_04_struct(), SBG_06_struct(), SBG_07_struct()]
   [sbg_08_struct, sbg_14_struct, sbg_13_struct, sbg_15_struct, sbg_09_struct] = \
        [SBG_08_struct(), SBG_14_struct(), SBG_13_struct(), SBG_15_struct(), SBG_09_struct()]
   [sbg_17_struct, sbg_16_struct, sbg_18_struct, sbg_32_struct, sbg_36_struct] = \
        [SBG_14_struct(), SBG_13_struct(), SBG_15_struct(), SBG_09_struct(), SBG_36_struct()]

   file_size = os.path.getsize(in_file_name)

   print(' ************ input file_size = ' + str(file_size))

   fin_bin = open(in_file_name, "rb")

   message_id_found_array = []
   
   k_start = 0

   svmem_obj = psutil.virtual_memory()

   # For sake of safety, consider 70% of free memory as available for this program
   avail_mem = numpy.uint64(0.7 * svmem_obj.free)

   print(' ********** Free memory: ' + str(svmem_obj.free) + ', Available memory: ' + str(avail_mem))

   if (avail_mem < file_size):
      nbr_of_loops = int(math.ceil(numpy.float(file_size)/avail_mem))
   else:
      nbr_of_loops = 1
   # } if (avail_mem < file_size)..

   print(' ************ SBG nbr_of_loops = ' + str(nbr_of_loops))

   bytes_read_trunc = None
   bytes_read_chopped_off = None
   found_last_SBG_pkt_prev = False

   total_message_cnt = 0
   message_cnt = 0
   message_set_cnt = 0
   crossed_40_sec = False
   found_first_time_since_powerup = False
   init_time_since_powerup = 0.0

   for n in range(nbr_of_loops):
      if (avail_mem < file_size):
         bytes_read = fin_bin.read(avail_mem)

         print('\n ****** LOOP n = ' + str(n) + ', len(bytes_read) = ' + str(len(bytes_read)))
         found_last_SBG_pkt = False
         k_start_of_last_SBG_pkt = 0
         k = len(bytes_read)-1

         # Find where last SBG packet begins in current block of bytes
         # and chop off that packet till end of block, for use with next block of bytes
         while(k > 1):
            if (hexlify(bytearray(bytes_read[k-1])) == 'FF' and \
                hexlify(bytearray(bytes_read[k])) == '5A'):

               print(' ***** Found last [0xFF 0x5A] SBG sync bytes at byte index: k-1: ' + str(k-1))
               k_start_of_last_SBG_pkt = k-1
               found_last_SBG_pkt = True
               break;
            k = k - 1
         # } while(k > 1)..

         if (found_last_SBG_pkt):
            bytes_read_to_use = []

            # First add chopped off bytes from previous read
            if (found_last_SBG_pkt_prev and bytes_read_chopped_off != None):
               print(' ******** first 2 bytes of bytes_read_chopped_off being added = ' + hexlify(bytes_read_chopped_off[:2]).upper())
               bytes_read_to_use.extend(bytes_read_chopped_off)
            # } if (found_last_SBG_pkt_prev..
            
            # If last block of bytes, take ALL bytes (no need to chop off last MIP packet from it)
            if (n == nbr_of_loops-1):
               bytes_read_to_use.extend(bytes_read)
            else:
               bytes_read_trunc = bytes_read[:k_start_of_last_SBG_pkt]
               print(' ******** last 2 bytes of bytes_read_trunc = ' + hexlify(bytes_read_trunc[-2:]).upper())

               # Now add the truncated bytes from current read
               bytes_read_to_use.extend(bytes_read_trunc)
            # } if (n == nbr_of_loops-1)..

            bytes_read_chopped_off = bytes_read[k_start_of_last_SBG_pkt:]
            found_last_SBG_pkt_prev = found_last_SBG_pkt
         # } if (found_last_SBG_pkt)..
         bytes_read = bytes_read_to_use
      else:
         bytes_read = fin_bin.read()
      # } if (avail_mem < file_size)..

      # Find first SNG packet begin index
      k = 0
      while(k < len(bytes_read)-2):
         if (hexlify(bytearray(bytes_read[k])).upper() == 'FF' and hexlify(bytearray(bytes_read[k+1])) == '5A'):
            print(' ***** Found first SYNC BYTE pair (FF 5A) at byte index: ' + str(k) + '\n')
            k_start = k;
            break;
         k = k + 1
      # } while(k < len(bytes_read))..

      k = k_start

      packet_size = 0
      data_length = 0
      data_length_dcp = 0
      message_id = 0
      gps_tow_ms = 0
      header_length = 6
      crc_length = 2
      gps_tow = 0
      # alt_msg_id_found = False
      alt_msg_id = 0
      time_since_powerup = 0
      time_since_powerup_prev = 0
      prev_sbg_08_struct_gps_tow = 0
      delta_t = 0

      # Look for beginning of a valid SBG packet (Bytes: 0xFF5A):
      while (k < len(bytes_read)):
         if (hexlify(bytearray(bytes_read[k])).upper() == 'FF' and hexlify(bytearray(bytes_read[k+1])).upper() == '5A'):
    
            total_message_cnt += 1

            [message_id, message_class, data_length] = unpack('<BBH', bytearray(bytes_read[k+2:k+header_length]) )
    
            # Check if data_length matches the SBG DCP:
            data_length_dcp = sbg_lengths_of_message_id_dict[message_id]
    
            if (data_length_dcp != data_length):
               print('****** data_length from message: ' + str(data_length_dcp) + ' IS NOT EQUAL TO: data_length_dcp ' + str(data_length_dcp))
            # } if (data_length_dcp != data_length)..   
       
            if (total_message_cnt < 10):
               print(' ***** found packet sync bytes at k = ' + str(k) + ', total_message_cnt = ' + str(total_message_cnt) + ', message_id = ' + str(message_id) + ', data_length = ' + str(data_length) + ', data_length_dcp = ' + str(data_length_dcp))

            # Get a list of unique message id's in the log file (useful if looking for new message id's added in the log but the parser currently does not handle)
            if (message_id not in message_id_found_array):
               # print(' ****** k = ' + str(k) + ', total_message_cnt = ' + str(total_message_cnt) + ', message_id = ' + str(message_id))
               print(' ****** Found new message_id = ' + str(message_id) + ', data_length = ' + str(data_length))
               message_id_found_array.append(message_id)
            # } if (message_id not in message_id_found_array)..
            
            if (len(bytes_read) - k < header_length + data_length_dcp + crc_length + 1):
               print(' ****** INCOMPLETE PACKET FOUND at k = ' + str(k) + ', total_message_cnt = ' + str(total_message_cnt) + ', len(bytes_read) = ' + str(len(bytes_read)) + ', data_length = ' + str(data_length) + ', message_id =' + str(message_id))
               found_bad_pkt = True
               break

            # if (message_id in sbg_valid_message_id_array or message_id in sbg_valid_message_id_alt_dict):
            if (message_id in sbg_valid_message_id_array):
               # Convert from alternate message id to "regular" message id
               # if (message_id in sbg_valid_message_id_alt_dict):
                  # alt_msg_id_found = True
                  # alt_msg_id = message_id
                  # message_id = sbg_valid_message_id_alt_dict[message_id]
               # else:
                  # alt_msg_id_found = False
               # } if (message_id in sbg_valid_message_id_alt_dict)..
          
               full_message_bytes = bytearray( bytes_read[k:k+header_length+data_length_dcp+crc_length+1] )
               message_bytes = bytearray( bytes_read[k+header_length:k+header_length+data_length_dcp] )
       
               # if (total_message_cnt < 10):
                  # tmp_str = hexlify( bytearray(full_message_bytes) ).upper()
                  # if (alt_msg_id_found):
                     # print(' ****** SBG Packet: total_message_cnt: ' + str(total_message_cnt) + ' ALTERNATE message_id: ' + str(alt_msg_id) + ', len(full_message_bytes): ' + str(len(full_message_bytes)) + ', len(message_bytes): ' + str(len(message_bytes)) + ', full_message_bytes:\n' + tmp_str + ', TWO BYTES AT A TIME:\n'),
                  # else:
                     # print(' ****** SBG Packet: total_message_cnt: ' + str(total_message_cnt) + ' REGULAR message_id: ' + str(message_id) + ', len(full_message_bytes): ' + str(len(full_message_bytes)) + ', len(message_bytes): ' + str(len(message_bytes)) + ', full_message_bytes:\n' + tmp_str + ', TWO BYTES AT A TIME:\n'),
                  # } if (alt_msg_id_found)..
     
                  # for i1 in range(0,len(tmp_str),2):
                     # print(tmp_str[i1] + tmp_str[i1+1]),
                  # print('\n')
  
               if (message_id == 1):
                  [time_since_powerup, general_status, temp_resvd_status1, temp_com_status,\
                   aiding_status, temp_resvd_status2, temp_resvd_status3, temp_up_time] = unpack('<IHHIIIHI', bytearray(message_bytes) )
  
                  time_since_powerup /= 1e6  # convert from microsec to sec
  
                  if (not found_first_time_since_powerup):
                     found_first_time_since_powerup = True
                     init_time_since_powerup = time_since_powerup
                     print(' ************* FIRST time since powerup: total_message_cnt = ' + str(total_message_cnt) + ', time_since_powerup: ' + str(time_since_powerup))
                  # } if (not found_first_time_since_powerup..
               # } if (message_id == 2)..
               
               if (found_first_time_since_powerup and not crossed_40_sec and (time_since_powerup - init_time_since_powerup) > 40.0):
                  crossed_40_sec = True
                  print(' ****** CROSSED 40 SEC at time_since_powerup = ' + str(time_since_powerup) + ' sec, with init_time_since_powerup = ' + str(init_time_since_powerup))
               # } if (found_first_time_since_powerup..
               
               if (found_first_time_since_powerup and time_since_powerup_prev != 0 and time_since_powerup_prev != time_since_powerup and time_since_powerup > time_since_powerup_prev):
                  if (total_message_cnt < 10):
                     print(' ******* time_since_powerup CHANGED at: message_set_cnt = ' + str(message_set_cnt) + ', total_message_cnt = ' + str(total_message_cnt) + ', time_since_powerup = ' + str(time_since_powerup) + ', time_since_powerup_prev = ' + str(time_since_powerup_prev))
  
                  # Collecting too many rows into the array of dictionaries can cause the application to hang, so it is important to collect dictionaries into an array only upto certain point in time.
                  # After that time, we print the dictionary representing current row to the csv file right there instead of storing into an array of dictionaries.
                  # We fix the 'certain point in time' as 40 sec.  We can be reasonably certain that no more 'new' message id's would appear after crossing the first 40 sec.
                  # Note that SBG allows only 1 Hz or slightly lower as the slowest rate of data logging.  So in theory, one should expect all message id's to show up in the first 1 or 2 sec of data.
                  # However, in reality, in spite of selecting the slowest logging rate, some of the messages do not appear until about 15 sec or so into the run.
                  # So to ensure that at least one message with selected message id does appear before printing the headers, a value of 40 sec is being selected here.
                  # If we did cross the 40 sec point, print the headers (if headers not already printed) and the stored dictionaries in the dict array.
                  # Then print the current dictionary to csv file.
                  # Otherwise if we haven't yet crossed the 40 sec point, add current dictionary to array of dict.
                  # If total duration of file is less than 40 sec, then we will print the whole dict array later, in one shot at the end.
                  if (crossed_40_sec):
                     if (not headers_printed):
                        sbg_output_order_in_log.sort()

                        fout_sbg.write('DATA_START\n')

                        for i, input_index in enumerate(sbg_output_order_in_log):
                           fout_sbg.write(sbg_format_using_dict.format_header(input_index, i == len(sbg_output_order_in_log)-1))
                        # } for i, input_index in enumerate(sbg_output_order_in_log)..

                        fout_sbg.write('\n')

                        headers_printed = True

                        # Next, print data values of dict array collected during first 2 sec:
                        for ndict in sbg_format_dict_array:
                           sbg_format_using_dict = SBG_CSV_format_using_dict(ndict)

                           for i, input_index in enumerate(sbg_output_order_in_log):
                              fout_sbg.write(sbg_format_using_dict.format(input_index, i == len(sbg_output_order_in_log)-1))
                           # } for i, input_index in enumerate(sbg_output_order_in_log)..

                           fout_sbg.write('\n')
                        # } for ndict in sbg_format_dict_array..
                     # } if (headers_printed == False)..

                     # Now print current data row to csv file
                     sbg_format_using_dict = SBG_CSV_format_using_dict(sbg_format_dict)

                     for i, input_index in enumerate(sbg_output_order_in_log):
                        fout_sbg.write(sbg_format_using_dict.format(input_index, i == len(sbg_output_order_in_log)-1))
                     # } for i, input_index in enumerate(sbg_output_order_in_log)..

                     fout_sbg.write('\n')
                  else:
                     sbg_format_dict_array.append(sbg_format_dict)
                  # } if (crossed_40_sec)..

                  # Track the number of 'message sets' (i.e. set of SBG messages at same GPS Timestamp)
                  message_set_cnt = message_set_cnt + 1

                  sbg_format_dict = {}
  
                  [sbg_01_struct, sbg_02_struct, sbg_03_struct, sbg_04_struct, sbg_06_struct, sbg_07_struct] = \
                      [SBG_01_struct(), SBG_02_struct(), SBG_03_struct(), SBG_04_struct(), SBG_06_struct(), SBG_07_struct()]
                  [sbg_08_struct, sbg_14_struct, sbg_13_struct, sbg_15_struct, sbg_09_struct] = \
                       [SBG_08_struct(), SBG_14_struct(), SBG_13_struct(), SBG_15_struct(), SBG_09_struct()]
                  [sbg_17_struct, sbg_16_struct, sbg_18_struct, sbg_32_struct, sbg_36_struct] = \
                       [SBG_14_struct(), SBG_13_struct(), SBG_15_struct(), SBG_09_struct(), SBG_36_struct()]

               # } if (found_first_time_since_powerup and time_since_powerup_prev != 0..

               message_cnt = message_cnt + 1

               if (found_bad_pkt):
                  print(' ***** found_bad_pkt = True, current message_cnt = ' + str(message_cnt))

               # Add index of Message ID to final output order array.
               index = sbg_valid_message_id_array.index(message_id)
               
               # Exclude indices of Message ID's already added to 'sbg_output_order_in_log':
               if (not crossed_40_sec and index not in sbg_output_order_in_log):
                  print('\n********* found NEW message_id: ' + str(message_id) + '\n***************************\n')
                  sbg_output_order_in_log.append(index)
               # } if (not crossed_40_sec and index not in sbg_output_order_in_log)..

               if (message_id == 1):
                  [sbg_01_struct.time_since_powerup, sbg_01_struct.general_status, temp_resvd_status1, temp_com_status,\
                   sbg_01_struct.aiding_status, temp_resvd_status2, temp_resvd_status3, temp_up_time] = unpack('<IHHIIIHI', bytearray(message_bytes) )
  
                  sbg_01_struct.time_since_powerup /= 1e6  # convert from microsec to sec
  
                  if (prev_sbg_01_struct_time_since_powerup != 0):
                     delta_t = sbg_01_struct.time_since_powerup - prev_sbg_01_struct_time_since_powerup
                  # } if (prev_sbg_01_struct_time_since_powerup != 0)..
     
                  prev_sbg_01_struct_time_since_powerup = sbg_01_struct.time_since_powerup
  
                  sbg_format_dict[message_id] = sbg_01_struct

               elif (message_id == 2):
                  try:
                     [sbg_02_struct.time_since_powerup, sbg_02_struct.clock_status,\
                      sbg_02_struct.utc_year, sbg_02_struct.utc_month, sbg_02_struct.utc_day,\
                      sbg_02_struct.utc_hour, sbg_02_struct.utc_min, sbg_02_struct.utc_sec,\
                      sbg_02_struct.utc_nanosec, sbg_02_struct.gps_tow] = unpack('<IHHBBBBBII', bytearray(message_bytes) )
     
                     sbg_02_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_02_struct.gps_tow /= 1000.0  # convert from millisec to sec

                     sbg_format_dict[message_id] = sbg_02_struct
     
                     # Add a calculated GPS TOW field on EKF Nav message, because it only has 'Time since powerup'
                     # if (sbg_08_struct.time_since_powerup != 0):
                        # sbg_08_struct.gps_tow = sbg_02_struct.gps_tow + (sbg_08_struct.time_since_powerup - sbg_02_struct.time_since_powerup)
                        # prev_sbg_08_struct_gps_tow = sbg_08_struct.gps_tow
                     # } if (sbg_08_struct.time_since_powerup != 0)..

                  except struct.error as err:
                     tmp_str = hexlify( bytearray(full_message_bytes) ).upper()
                     print(' ****** struct.error: SBG Packet: message_cnt: ' + str(message_cnt) + ' message_id: ' + str(message_id) + ', full_message_bytes = '),
                     for i1 in range(0,len(tmp_str),2):
                        print(tmp_str[i1] + tmp_str[i1+1]),
                     print('\n')

                     tmp_str = hexlify( bytearray(message_bytes) ).upper()
                     print(' ****** struct.error: SBG Packet: message_cnt: ' + str(message_cnt) + ' message_id: ' + str(message_id) + ', message_bytes = '),
                     for i1 in range(0,len(tmp_str),2):
                        print(tmp_str[i1] + tmp_str[i1+1]),
                     print('\n')
     
                     found_bad_pkt = True
     
                     message_cnt_of_bad_pkt = message_cnt
                     print(' ******* FOUND BAD PCKT: message_cnt = ' + str(message_cnt))
     
               elif (message_id == 3):
                  [sbg_03_struct.time_since_powerup, sbg_03_struct.imu_status,\
                   sbg_03_struct.filtered_accel_x, sbg_03_struct.filtered_accel_y, sbg_03_struct.filtered_accel_z,\
                   sbg_03_struct.filtered_gyro_x, sbg_03_struct.filtered_gyro_y, sbg_03_struct.filtered_gyro_z,\
                   sbg_03_struct.internal_temp, sbg_03_struct.delta_vel_x, sbg_03_struct.delta_vel_y, sbg_03_struct.delta_vel_z,\
                   sbg_03_struct.delta_theta_x, sbg_03_struct.delta_theta_y, sbg_03_struct.delta_theta_z] = unpack('<IHfffffffffffff', bytearray(message_bytes) )
  
                  sbg_03_struct.time_since_powerup /= 1e6  # convert from microsec to sec
  
                  sbg_format_dict[message_id] = sbg_03_struct

               elif (message_id == 4):
                  [sbg_04_struct.time_since_powerup, sbg_04_struct.mag_status, sbg_04_struct.mag_output_x, sbg_04_struct.mag_output_y, sbg_04_struct.mag_output_z,\
                   sbg_04_struct.accel_output_x, sbg_04_struct.accel_output_y, sbg_04_struct.accel_output_z] = unpack('<IHffffff', bytearray(message_bytes) )
  
                  sbg_04_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                  sbg_format_dict[message_id] = sbg_04_struct

               elif (message_id == 6):
                  [sbg_06_struct.time_since_powerup, sbg_06_struct.roll, sbg_06_struct.pitch, sbg_06_struct.yaw,\
                   sbg_06_struct.roll_acc, sbg_06_struct.pitch_acc, sbg_06_struct.yaw_acc, sbg_06_struct.global_soln_status] = unpack('<IffffffI', bytearray(message_bytes) )
  
                  sbg_06_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                  sbg_format_dict[message_id] = sbg_06_struct

               elif (message_id == 7):
                  [sbg_07_struct.time_since_powerup, sbg_07_struct.q0, sbg_07_struct.q1,\
                   sbg_07_struct.q2, sbg_07_struct.q3, sbg_07_struct.roll_acc,\
                   sbg_07_struct.pitch_acc, sbg_07_struct.yaw_acc, sbg_07_struct.global_soln_status] = unpack('<IfffffffI', bytearray(message_bytes) )
  
                  sbg_07_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                  sbg_format_dict[message_id] = sbg_07_struct

               elif (message_id == 8):
                  [sbg_08_struct.time_since_powerup, sbg_08_struct.vel_n, sbg_08_struct.vel_e, sbg_08_struct.vel_d,\
                   sbg_08_struct.vel_n_acc, sbg_08_struct.vel_e_acc, sbg_08_struct.vel_d_acc,\
                   sbg_08_struct.lat, sbg_08_struct.lon, sbg_08_struct.ht_MSL, sbg_08_struct.undulation,\
                   sbg_08_struct.lat_acc, sbg_08_struct.lon_acc, sbg_08_struct.vert_pos_acc, sbg_08_struct.global_soln_status] = unpack('<IffffffdddffffI', bytearray(message_bytes) )
  
                  sbg_08_struct.time_since_powerup /= 1e6  # convert from microsec to sec
  
                  # if (prev_sbg_08_struct_gps_tow != 0):
                     # sbg_08_struct.gps_tow = prev_sbg_08_struct_gps_tow
                  # } if (prev_sbg_08_struct_gps_tow != 0)..

                  sbg_format_dict[message_id] = sbg_08_struct

               elif (message_id == 9 or message_id == 32):
                  if (message_id == 9):
                     [sbg_09_struct.time_since_powerup, sbg_09_struct.heave_period_in_sec, sbg_09_struct.surge_at_main_loc,\
                      sbg_09_struct.sway_at_main_loc, sbg_09_struct.heave_at_main_loc, sbg_09_struct.longitudinal_accel_x,\
                      sbg_09_struct.lateral_accel_y, sbg_09_struct.lateral_accel_z, sbg_09_struct.longitudinal_vel_x,\
                      sbg_09_struct.lateral_vel_y, sbg_09_struct.lateral_vel_z, sbg_09_struct.ship_motion_output_status] = unpack('<IffffffffffH', bytearray(message_bytes) )
                  
                     sbg_09_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_format_dict[message_id] = sbg_09_struct
      
                  else: # message_id = 32
                     [sbg_32_struct.time_since_powerup, sbg_32_struct.heave_period_in_sec, sbg_32_struct.surge_at_main_loc,\
                      sbg_32_struct.sway_at_main_loc, sbg_32_struct.heave_at_main_loc, sbg_32_struct.longitudinal_accel_x,\
                      sbg_32_struct.lateral_accel_y, sbg_32_struct.lateral_accel_z, sbg_32_struct.longitudinal_vel_x,\
                      sbg_32_struct.lateral_vel_y, sbg_32_struct.lateral_vel_z, sbg_32_struct.ship_motion_output_status] = unpack('<IffffffffffH', bytearray(message_bytes) )
      
                     sbg_32_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_format_dict[message_id] = sbg_32_struct

                  # } if (message_id == 9)..

               elif (message_id == 13 or message_id == 16):
                  if (message_id == 13):
                     [sbg_13_struct.time_since_powerup, sbg_13_struct.gps_vel_status, sbg_13_struct.gps_tow,\
                      sbg_13_struct.vel_n, sbg_13_struct.vel_e, sbg_13_struct.vel_d,\
                      sbg_13_struct.vel_acc_n, sbg_13_struct.vel_acc_e, sbg_13_struct.vel_acc_d,\
                      sbg_13_struct.course_over_grnd, sbg_13_struct.course_over_grnd_acc] = unpack('<IIIffffffff', bytearray(message_bytes) )
                  
                     sbg_13_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_13_struct.gps_tow /= 1000.0  # convert from millisec to sec
     
                     sbg_format_dict[message_id] = sbg_13_struct
  
                  else: # message_id = 16
                     [sbg_16_struct.time_since_powerup, sbg_16_struct.gps_vel_status, sbg_16_struct.gps_tow,\
                      sbg_16_struct.vel_n, sbg_16_struct.vel_e, sbg_16_struct.vel_d,\
                      sbg_16_struct.vel_acc_n, sbg_16_struct.vel_acc_e, sbg_16_struct.vel_acc_d,\
                      sbg_16_struct.course_over_grnd, sbg_16_struct.course_over_grnd_acc] = unpack('<IIIffffffff', bytearray(message_bytes) )
      
                     sbg_16_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_16_struct.gps_tow /= 1000.0  # convert from millisec to sec
     
                     sbg_format_dict[message_id] = sbg_16_struct

                  # } if (message_id == 13)..
  
               elif (message_id == 14 or message_id == 17):
                  if (message_id == 14):
                     [sbg_14_struct.time_since_powerup, sbg_14_struct.gps_pos_fix_and_status, sbg_14_struct.gps_tow,\
                      sbg_14_struct.lat, sbg_14_struct.lon, sbg_14_struct.alt_MSL, sbg_14_struct.undulation,\
                      sbg_14_struct.pos_acc_lat, sbg_14_struct.pos_acc_lon, sbg_14_struct.pos_acc_alt,\
                      sbg_14_struct.nbr_of_svs_used, sbg_14_struct.base_station_id, sbg_14_struct.diff_age] = unpack('<IIIdddffffBHH', bytearray(message_bytes) )
     
                     sbg_14_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_14_struct.gps_tow /= 1000.0   # convert from millisec to sec
     
                     sbg_format_dict[message_id] = sbg_14_struct
    
                     # Add a calculated GPS TOW field on EKF Nav message, because it only has 'Time since powerup'
                     # if (sbg_08_struct.time_since_powerup != 0):
                        # sbg_08_struct.gps_tow = sbg_14_struct.gps_tow + (sbg_08_struct.time_since_powerup - sbg_14_struct.time_since_powerup)
                        # prev_sbg_08_struct_gps_tow = sbg_08_struct.gps_tow
                     # } if (sbg_08_struct.time_since_powerup != 0)..
     
                  else: # message_id = 17
                     [sbg_17_struct.time_since_powerup, sbg_17_struct.gps_pos_fix_and_status, sbg_17_struct.gps_tow,\
                      sbg_17_struct.lat, sbg_17_struct.lon, sbg_17_struct.alt_MSL, sbg_17_struct.undulation,\
                      sbg_17_struct.pos_acc_lat, sbg_17_struct.pos_acc_lon, sbg_17_struct.pos_acc_alt,\
                      sbg_17_struct.nbr_of_svs_used, sbg_17_struct.base_station_id, sbg_17_struct.diff_age] = unpack('<IIIdddffffBHH', bytearray(message_bytes) )
     
                     sbg_17_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_17_struct.gps_tow /= 1000.0   # convert from millisec to sec
     
                     sbg_format_dict[message_id] = sbg_17_struct
                  # } if (message_id == 14)..

               elif (message_id == 15 or message_id == 18):
                  if (message_id == 15):
                     [sbg_15_struct.time_since_powerup, sbg_15_struct.gps_true_heading_status, sbg_15_struct.gps_tow,\
                      sbg_15_struct.true_heading_angle, sbg_15_struct.true_heading_acc,\
                      sbg_15_struct.pitch_angle_master_to_rover, sbg_15_struct.pitch_acc] = unpack('<IHIffff', bytearray(message_bytes) )
     
                     sbg_15_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_15_struct.gps_tow /= 1000.0   # convert from millisec to sec
     
                     sbg_format_dict[message_id] = sbg_15_struct
                  else: # message_id = 18
                     [sbg_18_struct.time_since_powerup, sbg_18_struct.gps_true_heading_status, sbg_18_struct.gps_tow,\
                      sbg_18_struct.true_heading_angle, sbg_18_struct.true_heading_acc,\
                      sbg_18_struct.pitch_angle_master_to_rover, sbg_18_struct.pitch_acc] = unpack('<IHIffff', bytearray(message_bytes) )
     
                     sbg_18_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                     sbg_18_struct.gps_tow /= 1000.0   # convert from millisec to sec
     
                     sbg_format_dict[message_id] = sbg_18_struct
                  # } if (message_id == 15)..
  
               elif (message_id == 36):
                  [sbg_36_struct.time_since_powerup, sbg_36_struct.altimeter_status,\
                   sbg_36_struct.pressure, sbg_36_struct.altitude] = unpack('<IHff', bytearray(message_bytes) )
  
                  sbg_36_struct.time_since_powerup /= 1e6  # convert from microsec to sec
                  sbg_format_dict[message_id] = sbg_36_struct

               # } if (message_id == 1)..
       
               time_since_powerup_prev = time_since_powerup
       
               if (found_bad_pkt):
                  print(' ******* AFTER IF-ELSE STATEMENT and FOUND BAD PCKT: message_cnt = ' + str(message_cnt))
       
            # } if (message_id in sbg_valid_message_id_array ..

            if (found_bad_pkt):
               print(' ******* AFTER if (message_id in sbg_valid_message_id_array) STATEMENT and FOUND BAD PCKT: message_cnt = ' + str(message_cnt) + ', k = ' + str(k) + ', data_length = ' + str(data_length))

            k = k + header_length + data_length_dcp + crc_length + 1
         else:
            k = k + 1
         # } if (hexlify(bytearray(bytes_read[k])).upper() == 'FF' and..
      # } while (k < len(bytes_read))..
   # } for n in range(nbr_of_loops)..

   message_set_cnt += 1

   # Set the timestamp key to use in the last dict
   sbg_format_dict['TIMESTAMP'] = sbg_02_struct

   # Print content to csv if total data never crossed 40 sec, or the last packet set if data did cross 40 sec
   if (not crossed_40_sec):
      sbg_output_order_in_log.sort()

      fout_sbg.write('DATA_START\n')

      for i, input_index in enumerate(sbg_output_order_in_log):
         fout_sbg.write(sbg_format_using_dict.format_header(input_index, i == len(sbg_output_order_in_log)-1))
      # } for i, input_index in enumerate(sbg_output_order_in_log)..

      fout_sbg.write('\n')

      # Add the last dict to dict array (for this category), because there won't be any more timestamp change beyond this point
      sbg_format_dict_array.append(sbg_format_dict)

      # Next, print data values of dict array collected during first 40 sec:
      for ndict in sbg_format_dict_array:
         sbg_format_using_dict = SBG_CSV_format_using_dict(ndict)

         for i, input_index in enumerate(sbg_output_order_in_log):
            fout_sbg.write(sbg_format_using_dict.format(input_index, i == len(sbg_output_order_in_log)-1))
         # } for i, input_index in enumerate(sbg_output_order_in_log)..

         fout_sbg.write('\n')
      # } for ndict in sbg_format_dict_array..
   else:
      # Print last packet set to csv file (because we never got a 'next' timestamp to determine end of that packet set)
      sbg_format_using_dict = SBG_CSV_format_using_dict(sbg_format_dict)

      for i, input_index in enumerate(sbg_output_order_in_log):
         fout_sbg.write(sbg_format_using_dict.format(input_index, i == len(sbg_output_order_in_log)-1))
      # } for i, input_index in enumerate(sbg_output_order_in_log)..

      fout_sbg.write('\n')
   # } if (not crossed_40_sec)..

   # 
   # csv_curr_data_interp_at_prev_tow = numpy.interp(col_tow_values_to_use_prev, col_tow_values_to_use, col_values_to_use)
   
   fout_sbg.close()

   print('\n------------------------------------------------------------------')
   print ('\n************* Total nbr of SBG packets: ' + str(message_cnt) + ', Nbr of Packet Sets = ' + str(message_set_cnt) + ' len(sbg_format_dict_array) = ' + str(len(sbg_format_dict_array)))
   print('\n------------------------------------------------------------------')

   fin_bin.close()

if(__name__ == "__main__"):
  main_line(sys.argv)




