fin = open("C:\MP\Lord\SourceCode_Greg\Sensor_Sim\INS HIL From File\IMU_Log.bin", "rb")
bytes_read = fin.read()

# for b in bytes_read:
  # process_byte(b)

fout = open("C:\MP\Lord\SourceCode_Greg\Sensor_Sim\INS HIL From File\IMU_Log_Echo.bin", "wb")

fout.write(bytes_read)

fin.close()
fout.close()

# file = open("filename", "rb")
# try:
#   bytes_read = file.read(CHUNKSIZE)
#    while bytes_read:
#        for b in bytes_read:
#            process_byte(b)
#        bytes_read = file.read(CHUNKSIZE)
# finally:
#    file.close()
