import httplib
import xdrlib

def getDevices(server, username, password):
	url = "/SensorCloud/devices/?username=%s&password=%s&version=1" % (username, password)
	conn = httplib.HTTPSConnection(server)
	headers = {"Accept":"application/xdr"}
	
	conn.request("GET", url, None, headers)
	res = conn.getresponse()
	devices = []
	if res.status == 200:
		data = res.read()
		unpacker = xdrlib.Unpacker(data)
		#unpack version
		unpacker.unpack_int()
		#unpack number of devices
		numDevices = unpacker.unpack_int()
		for i in xrange(numDevices):
			serial = unpacker.unpack_string()
			label = unpacker.unpack_string()
			lastHeard = unpacker.unpack_string()
			lastIP = unpacker.unpack_string()
			devices.append({"serial":serial,"label":label,"lastHeard":lastHeard,"lastIP":lastIP})
		return devices
	print res.status,res.reason
	print res.read()

if __name__ == "__main__":
	username = "USERNAME"
	pwd = "PASSWORD"
	server = "dsx-dev.sensorcloud.microstrain.com"
	
	devices = getDevices(server, username, pwd)