#import libraries used
from mip import *              #local file should be in local folder
from mip_parser import *       #local file should be in local folder
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
  #print("Valid Packet Found")

  #loop over fields in received valid packet
  for field in mip_get_next_field(packet_bytes):
   #if this field is an ack/nack output it to show the user
   if(field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):
    print('field[1] = ' + str(field[1]) + ' Device response to command '+hex(field[2]).upper()+': '\
          +mip_ack_nacks[field[3]])

    # print('Device response to command '+hex(field[2]).upper()+': '\
          # +mip_ack_nacks[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM1'
port_baud = 115200

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-p' and len(argv) > i+1):
  port_name = argv[i+1]
 elif(argv[i] == '-b' and len(argv) > i+1):
  port_baud = int(argv[i+1])

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name,port_baud)

#Close port in case it was left open by other process
port.close()

#generate command bytearrays

# Enter Production Test Mode
enter_prod_mode_command = bytearray.fromhex('75650106067FD3C4A133D1FD')

# Enable all sensors
enable_all_sensors_command = bytearray.fromhex('75656107070D0100000000571E')

# Save Factory Bit setting
save_factory_bit_command = bytearray.fromhex('75656103030D0351A8')

# Reset the device
reset_device_command = bytearray.fromhex('7565FE020201DDBA')

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

#open specified port
port.open()

#set up background process to update data buffers
background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

#start the response parsing thread
background_data_update.start()

#send Enter Production Test Mode command
print('Sending Enter Production Test Mode command:')
port.write(enter_prod_mode_command)

#sleep while waiting for response
sleep(1)

#send Enable All Sensors command
print('Sending Enable All Sensors command:')
port.write(enable_all_sensors_command)

#sleep while waiting for response
sleep(1)

# Save Factory Bit setting command
print('Sending Save Factory Bit setting command:')
port.write(save_factory_bit_command)

#sleep while waiting for response
sleep(0.1)

#send reset device command
print('Sending reset device command:')
port.write(reset_device_command)

#sleep while waiting for response
sleep(1)

#stop background response parsing thread
background_data_update.stop()

#close port
port.close()

