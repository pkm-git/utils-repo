import csv
import sys
import numpy
import serial                  #library for accessing serial ports
from mip_csv_utils import *
from mip import *
from ublx import *

from struct import * #import all objects and functions from the struct library
from binascii import hexlify #hexlify is a function to print bytearrays as
                             #ascii strings for debugging (NOT NECESSARY FOR
                             #DATA CONVERSTIONS)

from time import sleep         #sleep
#from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                         #response update thread

def main_line(argv):
    """Main line program"""

    # rel_path = 'Vehicle_Logs/10_01_2015/RTSIM/GX4-45/2015_11_20/'
    # rel_path = 'Vehicle_Logs/2015_12_09/set2/'
    # rel_path = 'Vehicle_Logs/2015_12_09/set3/Vel/Vehicle/'
    # rel_path = 'Vehicle_Logs/2015_12_09/set3/Vel/useless/'
    # rel_path = 'Vehicle_Logs/2015_12_16/set2/Vehicle/'
    # rel_path = 'Vehicle_Logs/2015_12_21/set1/Vehicle/'
    rel_path = 'Vehicle_Logs/2016_01_06/set4/Vehicle/'

    # gps_in_file_name = 'GX4-45 Veh_GPS_Log 11-18-2015 4.34.25 PM_None.csv'
    # gps_in_file_name = 'GX4-45 Veh_GPS_Log 12-9-2015 3.20.16 PM Prod Vel.csv'
    # gps_in_file_name = 'GX4-45 Veh_GPS_Log 12-9-2015 2.35.03 PM MP Vel.csv'
    # gps_in_file_name = 'GX4-45 Veh_GPS_Log 12-9-2015 2.40.48 PM MP Mag.csv'
    # gps_in_file_name = 'RQ1-45 Veh_GPS_Log 12-21-2015 3.24.04 PM Vel.csv'
    gps_in_file_name = 'RQ1-45 Veh_GPS_Log 1-6-2016 2.04.19 PM Vel2.csv'

    cntGlobal = 0

    # while(True):
    while(cntGlobal < 1):
       gps_in_csvfile = open(rel_path + gps_in_file_name,'rUb')
       gps_csvreader = csv.reader(gps_in_csvfile, delimiter=',')

       gps_determine_headers = False
       gps_headers_found = False
       gps_n_input_rows = 0
       gps_n_output_rows = 0

       gps_row_cnt = 0
       gps_data_row_cnt = 0

       debug_mode = 0

       #default port settings
       # gps_port_name = 'COM10'
       gps_port_name = 'COM6'

       gps_port_baud = 115200
       # gps_port_baud = 230400

       #Assign serial port object
       gps_port = serial.Serial(gps_port_name, gps_port_baud)

       #Close port in case it was left open by other process
       gps_port.close()

       #open specified port
       gps_port.open()


       # ************* Repeat for IMU ****************

       # imu_in_file_name = 'GX4-45 Veh_IMU_Log 11-20-2015 2.35.10 PM_None.csv'
       # imu_in_file_name = 'GX4-45 Veh_IMU_Log 12-9-2015 3.20.16 PM Prod Vel.csv'
       # imu_in_file_name = 'GX4-45 Veh_IMU_Log 12-9-2015 2.40.48 PM MP Mag.csv'
       # imu_in_file_name = 'RQ1-45 Veh_IMU_Log 12-16-2015 2.05.48 PM Vel.csv'
       imu_in_file_name = 'RQ1-45 Veh_IMU_Log 1-6-2016 2.04.19 PM Vel2.csv'

       imu_in_csvfile = open(rel_path + imu_in_file_name,'rUb')
       imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')

       imu_determine_headers = False
       imu_headers_found = False
       imu_n_input_rows = 0
       imu_n_output_rows = 0

       imu_row_cnt = 0
       imu_data_row_cnt = 0

       #default port settings
       # imu_port_name = 'COM11'
       imu_port_name = 'COM10'
       imu_port_baud = 921600

       #Assign serial port object
       imu_port = serial.Serial(imu_port_name, imu_port_baud)

       #Close port in case it was left open by other process
       imu_port.close()

       #open specified port
       imu_port.open()

       #set up background process to update data buffers
       # background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

       #start the response parsing thread
       # background_data_update.start()

       #sleep while waiting for response
       #sleep(1)

       #stop background response parsing thread
       # background_data_update.stop()

       GPS_init_found = False

       # **********************************************
       # Store GPS data into an array of objects (rows)
       # **********************************************
       gps_row_data = []

       gps_init_tow = 0.0

       for gps_row_items in gps_csvreader:

           gps_row_cnt = gps_row_cnt + 1

           # print(" ***** gps_row cnt: " + str(gps_row_cnt) + ', gps_row_items = ' + str(gps_row_items) + ', len(gps_row_items) = ' + str(len(gps_row_items)) );

           # determined that last row in CSV indicated data start (headers are in this row)
           if (gps_determine_headers == True):
               # column headers have been found
               gps_headers_found = True

               # headers no longer need to be determined
               gps_determine_headers = False

           elif(gps_headers_found == True):
               gps_data_row_cnt = gps_data_row_cnt + 1

               if (gps_data_row_cnt == 1):
                   gps_init_tow = numpy.double(gps_row_items[2])

               gps_n_input_rows += 1

               # print(" ****** GPS: Week = " + str(gps_row_items[1]) + " TOW = " + str(gps_row_items[2]) );

               gps_row_data.append(gps_row_items)

           # this row is neither column headers nor data elements
           else:
               # test for DATA_START row (column headers to follow)
               # if(len(row_items) == 1 and row_items[0] == 'DATA_START'):
               if(len(gps_row_items) == 1 and gps_row_items[0] == 'DATA_START'):
                  gps_determine_headers = True
                  print("GPS DATA_START found, collecting headers")

       # *************************************************
       #           Now process IMU data
       # *************************************************
       print(' **************** Init GPS TOW found, now start main IMU processing loop')

       # Reset gps_n_input_rows to 0
       gps_n_input_rows = 0

       imu_tow_prev = 0.0
       imu_tow = 0.0

       for imu_row_items in imu_csvreader:

           imu_row_cnt = imu_row_cnt + 1

           # print(' *********** imu_row_cnt = ' + str(imu_row_cnt))

           # determined that last row in CSV indicated data start (headers are in this row)
           if (imu_determine_headers == True):
               # column headers have been found
               imu_headers_found = True

               # headers no longer need to be determined
               imu_determine_headers = False

           elif(imu_headers_found == True):

               imu_data_row_cnt = imu_data_row_cnt + 1

               # print(" ***** imu_data_row_cnt: " + str(imu_data_row_cnt)  );

               # if (debug_mode == 1 and imu_data_row_cnt % 500 == 1):
                   # raw_input("Press Enter to continue...")

               # *******************************************************************************
               # Check if it is time to output GPS data as well (assume 500 Hz IMU and 4 Hz GPS):
               # *******************************************************************************
               if (GPS_init_found == False):
                   imu_tow_prev = imu_tow
                   imu_tow = numpy.double(imu_row_items[2])
                   if (imu_tow > gps_init_tow):
                       GPS_init_found = True
                       if ((imu_tow - gps_init_tow) > (gps_init_tow - imu_tow_prev)):
                           GPS_init_found_index = imu_data_row_cnt - 1
                       else:
                           GPS_init_found_index = imu_data_row_cnt

               if ((GPS_init_found == True) and ((imu_data_row_cnt - GPS_init_found_index) % 125 == 0)):   # 125 = 500/4
                   # print( " ****** CROSS OVER: imu_data_row_cnt = " + str(imu_data_row_cnt) + " GPS_init_found_index = " + str(GPS_init_found_index) + " imu_tow = " + str(imu_tow) + " current imu_tow = " + str(imu_row_items[2]) )

                   if (len(gps_row_data)>0):
                       gps_row_item = gps_row_data.pop(0)  # get first item

                       # print(" ****** GPS: Week = " + str(gps_row_item[1]) + " TOW = " + str(gps_row_item[2]) );

                       if (debug_mode == 1):
                           raw_input("GPS: Press Enter to continue...")

                       packet_data = bytearray([])

                       ##################################
                       # NAV-TIMEGPS message (0x01 0x20):
                       ##################################
                       GPS_TOW_rounded_ms = numpy.uint32(numpy.rint(numpy.double(gps_row_item[2]) * 1000.0))
                       GPS_TOW_Real_Minus_Rounded_ms = numpy.double(gps_row_item[2]) * 1000.0 - numpy.uint32(numpy.rint(numpy.double(gps_row_item[2]) * 1000.0))
                       GPS_TOW_Real_Minus_Rounded_nano_s = GPS_TOW_Real_Minus_Rounded_ms * 1e6

                       # As of July 15, 2015, there were 26 leap seconds since 1970..
                       # Valid_flags = 7 is being sent here, to indicate valid TOW, Week, and leap seconds.

                       packet_data = pack('<IihbbI', GPS_TOW_rounded_ms, numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s), numpy.short(gps_row_item[1]), 26, 7, 0)

                       # print "********* NAV-TIMEGPS packet_data: " + hexlify(packet_data).upper()

                       ublxp = ublx_create_ublx_message(0x01, 0x20, 16, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp)

                       # print "\nNAV-TIMEGPS Packet after finalize: " + hexlify(ublxp).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp)
                       # port.flush()

                       ##################################
                       # NAV-STATUS message (0x01 0x03):
                       ##################################

                       packet_data = bytearray([])

                       packet_data = pack('<IBBBBII', GPS_TOW_rounded_ms, 2, 13, 0, 0, 0, 0)

                       # print "********* NAV-STATUS packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_status = ublx_create_ublx_message(0x01, 0x03, 16, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_status)

                       # print "\nNAV-STATUS Packet after finalize: " + hexlify(ublxp_nav_status).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_status)
                       gps_port.flush()

                       ##################################
                       # NAV-POSLLH message (0x01 0x02):
                       ##################################

                       packet_data = bytearray([])

                       packet_data = pack('<IiiiiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_item[4]) * 1e+07), numpy.int32(numpy.double(gps_row_item[3]) * 1e+07), numpy.int32(numpy.double(gps_row_item[5]) * 1e+03), numpy.int32(numpy.double(gps_row_item[6]) * 1e+03), numpy.int32(numpy.double(gps_row_item[7]) * 1e+03), numpy.int32(numpy.double(gps_row_item[8]) * 1e+03))

                       # print "********* NAV-POSLLH packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_llh = ublx_create_ublx_message(0x01, 0x02, 28, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_llh)

                       # print "\nNAV-POSLLH Packet after finalize: " + hexlify(ublxp_nav_llh).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_llh)
                       # port.flush()

                       ##################################
                       # NAV-VELNED message (0x01 0x12):
                       ##################################

                       packet_data = bytearray([])

                       packet_data = pack('<IiiiIIiII', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_item[15]) * 1e+02), numpy.int32(numpy.double(gps_row_item[16]) * 1e+02), numpy.int32(numpy.double(gps_row_item[17]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[18]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[19]) * 1e+02), numpy.int32(numpy.double(gps_row_item[20]) * 1e+05), numpy.uint32(numpy.double(gps_row_item[21]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[22]) * 1e+05))

                       # print "********* NAV-VELNED packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_vned = ublx_create_ublx_message(0x01, 0x12, 36, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_vned)

                       # print "\nNAV-VELNED Packet after finalize: " + hexlify(ublxp_nav_vned).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_vned)
                       # gps_port.flush()

                       ##################################
                       # NAV-TIMEUTC message (0x01 0x21):
                       ##################################

                       packet_data = bytearray([])

                       # valid = 7 meaning UTC, Wk Nbr, and TOW all valid
                       packet_data = pack('<IIiHBBBBBB', GPS_TOW_rounded_ms, 0, 0, numpy.short(gps_row_item[37]), numpy.uint8(gps_row_item[38]), numpy.uint8(gps_row_item[39]), numpy.uint8(gps_row_item[40]), numpy.uint8(gps_row_item[41]), numpy.uint8(gps_row_item[42]), 7 )

                       # print "********* NAV-TIMEUTC packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_timeutc = ublx_create_ublx_message(0x01, 0x21, 20, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_timeutc)

                       # print "\nNAV-TIMEUTC Packet after finalize: " + hexlify(ublxp).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_timeutc)
                       # gps_port.flush()

                       ##################################
                       # NAV-POSECEF message (0x01 0x01):
                       ##################################

                       packet_data = bytearray([])

                       packet_data = pack('<IiiiI', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_item[10]) * 1e+02), numpy.int32(numpy.double(gps_row_item[11]) * 1e+02), numpy.int32(numpy.double(gps_row_item[12]) * 1e+02), numpy.int32(numpy.double(gps_row_item[13]) * 1e+02))

                       # print "********* NAV-POSECEF packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_posecef = ublx_create_ublx_message(0x01, 0x01, 20, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_posecef)

                       # print "\nNAV-POSECEF Packet after finalize: " + hexlify(ublxp_nav_posecef).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_posecef)
                       # gps_port.flush()

                       ##################################
                       # NAV-VELECEF message (0x01 0x11):
                       ##################################

                       packet_data = bytearray([])

                       packet_data = pack('<IiiiI', GPS_TOW_rounded_ms, numpy.int32(numpy.double(gps_row_item[24]) * 1e+02), numpy.int32(numpy.double(gps_row_item[25]) * 1e+02), numpy.int32(numpy.double(gps_row_item[26]) * 1e+02), numpy.int32(numpy.double(gps_row_item[27]) * 1e+02))

                       # print "********* NAV-VELECEF packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_velecef = ublx_create_ublx_message(0x01, 0x11, 20, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_velecef)

                       # print "\nNAV-VELECEF Packet after finalize: " + hexlify(ublxp_nav_velecef).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_velecef)
                       # gps_port.flush()

                       ##################################
                       # NAV-DOP message (0x01 0x04):
                       ##################################

                       packet_data = bytearray([])

                       packet_data = pack('<IHHHHHHH', GPS_TOW_rounded_ms, numpy.uint32(numpy.double(gps_row_item[29]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[30]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[33]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[32]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[31]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[34]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[35]) * 1e+02) )

                       # print "********* NAV-DOP packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_dop = ublx_create_ublx_message(0x01, 0x04, 18, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_dop)

                       # print "\nNAV-DOP Packet after finalize: " + hexlify(ublxp_nav_dop).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_dop)
                       # gps_port.flush()

                       ##################################
                       # NAV-SOL message (0x01 0x06):
                       ##################################

                       packet_data = bytearray([])
                       # Number of SV's used in solution = 5 (spoof value):
                       packet_data = pack('<IihBBiiiIiiiIHBBI', GPS_TOW_rounded_ms, numpy.int32(GPS_TOW_Real_Minus_Rounded_nano_s), numpy.short(gps_row_item[1]), 2, 13, numpy.int32(numpy.double(gps_row_item[10]) * 1e+02), numpy.int32(numpy.double(gps_row_item[11]) * 1e+02), numpy.int32(numpy.double(gps_row_item[12]) * 1e+02), numpy.int32(numpy.double(gps_row_item[13]) * 1e+02), numpy.int32(numpy.double(gps_row_item[24]) * 1e+02), numpy.int32(numpy.double(gps_row_item[25]) * 1e+02), numpy.int32(numpy.double(gps_row_item[26]) * 1e+02), numpy.int32(numpy.double(gps_row_item[27]) * 1e+02), numpy.uint32(numpy.double(gps_row_item[30]) * 1e+02), 0, 5, 0)
                       # print "********* NAV-SOL packet_data: " + hexlify(packet_data).upper()

                       ublxp_nav_sol = ublx_create_ublx_message(0x01, 0x06, 52, packet_data)

                       #finalize packet
                       ublx_finalize(ublxp_nav_sol)

                       # print "\nNAV-SOL Packet after finalize: " + hexlify(ublxp_nav_sol).upper()

                       #send GPS UBLOX packet to device
                       gps_port.write(ublxp_nav_sol)

                       # gps_port.flush()

                       #sleep(0.001)
                       #sleep(0.01)
                       #sleep(0.25)
                       #sleep(1)

                       # break

                       gps_n_input_rows += 1

               # ************************************************
               # **** Continue processing IMU data **************
               # ************************************************

               mp = bytearray([])

               #initialize a packet for a base command
               mip_init(mp,0x80)

               # # print(" ****** row_items[1] = " + str(row_items[1]) + " row_items[2] = " + str(row_items[2]) + " row_items[15] = " + str(row_items[15]) + " row_items[16] = " + str(row_items[16])  + " row_items[17] = " + str(row_items[17]) );
               # print(" *** IMU: imu_data_row_cnt = " + str(imu_data_row_cnt) + " imu_row_items[1] = " + str(imu_row_items[1]) + " imu_row_items[2] = " + str(imu_row_items[2]));

               if ((debug_mode == 1) and (GPS_init_found == True) and ((imu_data_row_cnt - GPS_init_found_index) % 125 == 0)):
                   raw_input("IMU: Press Enter to continue...")

               #print "****** Packet after add field: " + hexlify(mp).upper()

               mip_add_field(mp, 0x12, pack('>dHH', numpy.double(imu_row_items[2]), numpy.ushort(imu_row_items[1]), numpy.ushort(imu_row_items[0])))

               # Accel (0x8004)
               mip_add_field(mp, 0x04, pack('>fff', float(imu_row_items[3]), float(imu_row_items[4]), float(imu_row_items[5])))

               # Gyro (0x8005)
               mip_add_field(mp, 0x05, pack('>fff', float(imu_row_items[6]), float(imu_row_items[7]), float(imu_row_items[8])))

               # Mag (0x8006)
               # # mip_add_field(mp, 0x06, pack('>fff', float(imu_row_items[15]), float(imu_row_items[16]), float(imu_row_items[17])))
               # mip_add_field(mp, 0x06, pack('>fff', float(imu_row_items[16]), float(imu_row_items[17]), float(imu_row_items[18])))
               # # mip_add_field(mp, 0x06, pack('>fff', 0, 0, 0))

               # Delta Theta (0x8007)
               mip_add_field(mp, 0x07, pack('>fff', float(imu_row_items[9]), float(imu_row_items[10]), float(imu_row_items[11])))

               # Delta Vel (0x8008)
               mip_add_field(mp, 0x08, pack('>fff', float(imu_row_items[12]), float(imu_row_items[13]), float(imu_row_items[14])))

               # Pressure (0x8017)
               # mip_add_field(mp, 0x17, pack('>f', float(imu_row_items[18])))
               mip_add_field(mp, 0x17, pack('>f', float(imu_row_items[15])))

               # mip_add_field(mp,0x12, bytearray.fromhex('2A895F'))

               # checksum = fletcher_check16(mp)

               #Print the checksum bytes
               #print "Checksum bytes: " + hexlify(checksum).upper()

               #finalize packet
               mip_finalize(mp)

               #print "Packet after finalize: " + hexlify(mp).upper()

               #send IMU MIP packet to device
               imu_port.write(mp)

               sleep(0.002)
               #sleep(0.01)
               #sleep(0.1)
               #sleep(1)

               imu_n_input_rows += 1

           # this row is neither column headers nor data elements
           else:
               # test for DATA_START row (column headers to follow)
               # if(len(row_items) == 1 and row_items[0] == 'DATA_START'):
               if(len(imu_row_items) == 1 and imu_row_items[0] == 'DATA_START'):
                   imu_determine_headers = True
                   print("IMU GPS Week found, collecting headers")


       #file complete
       print("IMU: " + str(imu_n_input_rows)+" input rows processed")

       #file complete
       print("GPS: " + str(gps_n_input_rows) + " input rows processed")

       imu_port.close()
       gps_port.close()

       cntGlobal = cntGlobal + 1

if(__name__ == "__main__"):
  main_line(sys.argv)


