import sys
import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder

from gsg_gps_format import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

import numpy
import os

def print_usage_message():
 """Output usage instructions"""

 print("usage: python parse_gsg_ublox_binary_log.py -i input_file_name\n")
 print("input_file_name\t\t-- the name of the input file including the path")

def main_line(argv):
 """Main line program"""

 # initialize command line arguments
 in_file_name = None

 print('\n------------------------------------------------------------------')

 # Define "Master columns" (i.e. all available columns in DCP) in a "master sequence"
 gps_default_cols_dict = {"0120":"1", "0102":"2", "0112":"3", "0101":"4", "0111":"5", "0104":"6", "0121":"7", "0107":"8", "0103":"9", "0130":"10", "0103":"11", "0106":"12", "0132":"13" }
 min_gps_default_cols_dict = {"0120":"1", "0102":"2", "0112":"3", "0101":"4", "0111":"5", "0104":"6", "0121":"7", "0107":"8" }

 # Now, get the order of columns requested by the user:
 gps_output_order = []

 no_desc_list_supplied_gps_headers_printed = False

 gps_invalid_packet_cnt = 0

 if (argv != None):
   # parse command line arguements
   for i in range(len(argv)):
     # assign specified filenames
     if(argv[i] == '-i' and len(argv) > i+1):
        in_file_name = argv[i+1]

 # if command line arguments were not properly specified tell the user and exit
 if(in_file_name == None):
   print_usage_message()
   sys.exit()

 gps_format_obj = GSG_GPS_format()

 fin_bin = open(in_file_name, "rb")

 (fin_filepath, fin_filename) = os.path.split(in_file_name)
 fout_gps = open(os.path.join(fin_filepath, "UBLOX_GPS_Log.csv"), "w")

 start_time = time()

 # print('\n------------------------------------------------------------------')
 print(' ************* Parse GSG UBLOX Binary Log: start_time = ' + str(start_time) );

 k_start = 0

 bytes_read = fin_bin.read();

 print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

 for k in range(0, len(bytes_read)):
    if (hexlify(bytearray(bytes_read[k])) == 'b5' and hexlify(bytearray(bytes_read[k+1])) == '62'):
       print(' ***** Found first [0xb5 0x62] UBLOX pair at byte index: ' + str(k) + '\n')
       k_start = k;
       break;

 packet_size = 0
 k = k_start

 packet_cnt = 0
 packet_set_cnt = 0
 temp_week = 0

 [gps_vned_N, gps_vned_E, gps_vned_D, gps_speed, gps_grnd_speed, gps_heading, gps_speed_acc, gps_heading_acc] = [0,0,0,0,0,0,0,0]
 [gps_pos_ecef_x, gps_pos_ecef_y, gps_pos_ecef_z, gps_pos_ecef_UC] = [0,0,0,0]
 [gps_vel_ecef_x, gps_vel_ecef_y, gps_vel_ecef_z, gps_vel_ecef_UC] = [0,0,0,0]

 [temp_geom_dop, temp_pos_dop, temp_horiz_dop, temp_vertical_dop, temp_time_dop, temp_northing_dop, temp_east_dop] = [0,0,0,0,0,0,0]

 [utc_yr, utc_mo, utc_day, utc_hr, utc_min, utc_sec] = [0,0,0,0,0,0]
 [gps_fix_type, gps_nbr_of_svs_used, gps_fix_flags] = [0,0,0]
 [gps_clock_bias, gps_clock_drift, gps_clock_acc_estimate] = [0,0,0]
 [gps_hw_status_sensor_state, gps_hw_status_antenna_state, gps_hw_status_antenna_power] = [0,0,0]

 [temp_frac_ns_from_ms, temp_leap_sec, temp_tow_ms, temp_tow_ns, tAcc] = [0,0,0,0,0]

 [temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_horiz_acc, temp_vert_acc, temp_heading, temp_hAcc] = [0,0,0,0,0,0,0,0]

 [temp_gpstime_valid, temp_gpstime_timeAccEstimate, temp_utctime_valid] = [0,0,0]

 [temp_gps_pos_ecef_x, temp_gps_pos_ecef_y, temp_gps_pos_ecef_z, temp_gps_pos_ecef_UC] = [0,0,0,0]

 [temp_gps_vel_ecef_x, temp_gps_vel_ecef_y, temp_gps_vel_ecef_z, temp_gps_vel_ecef_UC] = [0,0,0,0]

 [temp_speed, temp_grnd_speed, temp_gps_vned_N, temp_gps_vned_E, temp_gps_vned_D, temp_gps_fix_type, temp_gps_nbr_of_svs_used] = [0,0,0,0,0,0,0]

 [temp_pdop, temp_u1_reserved, temp_u2_reserved, temp_u4_reserved] = [0,0,0,0]

 [temp_nano, temp_speedAcc] = [0,0]

 field_desc_prev = None

 # Look for beginning of a valid MIP packet (Bytes: 0x7565):
 while (k < len(bytes_read)):

   if (hexlify(bytearray(bytes_read[k])) == 'b5' and hexlify(bytearray(bytes_read[k+1])) == '62'):
      packet_cnt = packet_cnt + 1

      desc_set = hexlify( bytearray(bytes_read[k+2]) ).upper()
      field_desc = hexlify( bytearray(bytes_read[k+3]) ).upper()
      packet_size = int(hexlify(bytearray(bytes_read[k+4])), 16)
      # packet_size = unpack('>H', bytearray(bytes_read[k+4]) )

      full_packet_bytes = bytearray( bytes_read[k:k+packet_size+8] )
      packet_bytes = bytearray( bytes_read[k+6:k+6+packet_size] )

      print('\n****** Packet Nbr: ' + str(packet_cnt) + ', Packet Set Nbr: ' + str(packet_set_cnt+1) + ', Desc Set: ' + desc_set + ', field_desc = ' + field_desc + ', Packet size = ' + str(packet_size) + ' len(packet_bytes) = ' + str(len(packet_bytes)) + ' and full_packet_bytes = ' + hexlify( bytearray(full_packet_bytes) ).upper())

      if (desc_set == '01'):
         # if (packet_set_cnt == 0):
         if (packet_set_cnt == 1):
            # gps_output_order.append(gps_default_cols_dict[desc_set + field_desc.upper()])
            if ((desc_set + field_desc.upper()) in min_gps_default_cols_dict):
               gps_output_order.append(min_gps_default_cols_dict[desc_set + field_desc.upper()])
               print('********* desc_set = ' + desc_set + ' and field_desc = ' + field_desc + ' does exist in dictionary, adding output_order: ' + str(min_gps_default_cols_dict[desc_set + field_desc.upper()]) )
            else:
               print('********* desc_set = ' + desc_set + ' and field_desc = ' + field_desc + ' does NOT exist in dictionary' )
         # else:
            # break

         if (field_desc == '20'):   # NAV-TIMEGPS
            # Print the headers collected in the first packet set:
            # if (packet_set_cnt == 1 and no_desc_list_supplied_gps_headers_printed == False):
            if (packet_set_cnt == 2 and no_desc_list_supplied_gps_headers_printed == False):
               gps_output_order.sort()

               fout_gps.write('DATA_START\n')
               print(' *********** writing headers, len(gps_output_order) = ' + str(len(gps_output_order)))
               for gps_output_index in range(len(gps_output_order)):
                  input_index = numpy.int32(gps_output_order[gps_output_index])
                  fout_gps.write(gps_format_obj.format_header(input_index))

               fout_gps.write('\n')
               no_desc_list_supplied_gps_headers_printed = True

            # Print the data rows from previous packet set
            # if (packet_set_cnt >= 1):
            if (packet_set_cnt >= 2):
               # Print values of last GPS set, before updating 'gps_format_obj' with new set of values:
               input_index = 0
               for gps_output_index in range(len(gps_output_order)):
                  input_index = numpy.int32(gps_output_order[gps_output_index])
                  fout_gps.write(gps_format_obj.format(input_index))

               fout_gps.write('\n')

            # if (packet_set_cnt == 2):
               # return

            # Count number of 'packet sets' (i.e. set of UBLOX packets at same GPS Timestamp):
            packet_set_cnt = packet_set_cnt + 1

            [gps_format_obj.gps_tow, temp_frac_ns_from_ms, gps_format_obj.gps_week, temp_leap_sec, temp_gpstime_valid, temp_gpstime_timeAccEstimate] = unpack('<IihbBI', bytearray(packet_bytes) )
            print('********* RAW GPS TOW: ' + str(gps_format_obj.gps_tow) + ' temp_frac_ns_from_ms: ' + str(temp_frac_ns_from_ms) )

            gps_format_obj.gps_tow = gps_format_obj.gps_tow/1e3 + temp_frac_ns_from_ms/1e9
            print(' ********** Final TOW: ' + str(gps_format_obj.gps_tow))

         elif (field_desc == '21'): # NAV-TIMEUTC
            [temp_tow_ms, tAcc, temp_tow_ns, gps_format_obj.utc_yr, gps_format_obj.utc_mo, gps_format_obj.utc_day, gps_format_obj.utc_hr, gps_format_obj.utc_min, gps_format_obj.utc_sec, temp_utctime_valid] = unpack('<IIiHBBBBBB', bytearray(packet_bytes) )
         elif (field_desc == '02'): # NAV-POSLLH
            [temp_tow_ms, temp_lon, temp_lat, temp_ht_above_ellip, temp_ht_above_MSL, temp_horiz_acc, temp_vert_acc] = unpack('<IiiiiII', bytearray(packet_bytes) )
            # [temp_tow_ms, temp_lat, temp_lon, temp_ht_above_ellip, temp_ht_above_MSL, temp_horiz_acc, temp_vert_acc] = unpack('<IiiiiII', bytearray(packet_bytes) )
            gps_format_obj.gps_lat = temp_lat * 1e-7
            gps_format_obj.gps_lon = temp_lon * 1e-7
            gps_format_obj.gps_ht_abv_ellip = temp_ht_above_ellip * 1e-3
            gps_format_obj.gps_ht_abv_MSL = temp_ht_above_MSL * 1e-3
            gps_format_obj.gps_horiz_acc = temp_horiz_acc * 1e-3
            gps_format_obj.gps_vert_acc = temp_vert_acc * 1e-3
         elif (field_desc == '12'): # NAV-VELNED
            [temp_tow_ms, temp_gps_vned_N, temp_gps_vned_E, temp_gps_vned_D, temp_speed, temp_grnd_speed, temp_heading, temp_speedAcc, temp_hAcc] = unpack('<IiiiIIiII', bytearray(packet_bytes) )

            gps_format_obj.gps_vned_N = temp_gps_vned_N * 1e-2
            gps_format_obj.gps_vned_E = temp_gps_vned_E * 1e-2
            gps_format_obj.gps_vned_D = temp_gps_vned_D * 1e-2

            gps_format_obj.gps_speed = temp_speed * 1e-2
            gps_format_obj.gps_grnd_speed = temp_grnd_speed * 1e-2

            gps_format_obj.gps_heading = temp_heading * 1e-5
            gps_format_obj.gps_speed_acc = temp_speedAcc * 1e-2
            gps_format_obj.gps_heading_acc = temp_hAcc * 1e-5

         elif (field_desc == '01'): # NAV-POSECEF
            [temp_tow_ms, temp_gps_pos_ecef_x, temp_gps_pos_ecef_y, temp_gps_pos_ecef_z, temp_gps_pos_ecef_UC] = unpack('<IiiiI', bytearray(packet_bytes) )
            gps_format_obj.gps_pos_ecef_x = temp_gps_pos_ecef_x * 1e-2
            gps_format_obj.gps_pos_ecef_y = temp_gps_pos_ecef_y * 1e-2
            gps_format_obj.gps_pos_ecef_z = temp_gps_pos_ecef_z * 1e-2
            gps_format_obj.gps_pos_ecef_UC = temp_gps_pos_ecef_UC * 1e-2
         elif (field_desc == '11'): # NAV-VELECEF
            [temp_tow_ms, temp_gps_vel_ecef_x, temp_gps_vel_ecef_y, temp_gps_vel_ecef_z, temp_gps_vel_ecef_UC] = unpack('<IiiiI', bytearray(packet_bytes) )
            gps_format_obj.gps_vel_ecef_x = temp_gps_vel_ecef_x * 1e-2
            gps_format_obj.gps_vel_ecef_y = temp_gps_vel_ecef_y * 1e-2
            gps_format_obj.gps_vel_ecef_z = temp_gps_vel_ecef_z * 1e-2
            gps_format_obj.gps_vel_ecef_UC = temp_gps_vel_ecef_UC * 1e-2

         elif (field_desc == '03'): # NAV_STATUS (FIX INFO)
            # [temp_tow_ms, gps_format_obj.gps_fix_type, temp_gps_fix_flags, temp_gps_fixStat, temp_gps_fix_flags2, temp_time_to_first_fix, ms_since_startup] = unpack('<IBBBBII', bytearray(packet_bytes) )
            [temp_tow_ms, temp_gps_fix_type, temp_gps_fix_flags, temp_gps_fixStat, temp_gps_fix_flags2, temp_time_to_first_fix, ms_since_startup] = unpack('<IBBBBII', bytearray(packet_bytes) )

         elif (field_desc == '06'): # NAV_SOL
            # [temp_tow_ms, temp_frac_ns_from_ms, temp_week, temp_gps_fix_type, temp_gps_fix_flags, temp_gps_pos_ecef_x, temp_gps_pos_ecef_y, temp_gps_pos_ecef_z, temp_gps_pos_ecef_UC, temp_gps_vel_ecef_x, temp_gps_vel_ecef_y, temp_gps_vel_ecef_z, temp_gps_vel_ecef_UC, temp_pdop, temp_u1_reserved, gps_format_obj.gps_nbr_of_svs_used, temp_u4_reserved] = unpack('<IihBBiiiIiiiIHBBI', bytearray(packet_bytes) )
            [temp_tow_ms, temp_frac_ns_from_ms, temp_week, temp_gps_fix_type, temp_gps_fix_flags, temp_gps_pos_ecef_x, temp_gps_pos_ecef_y, temp_gps_pos_ecef_z, temp_gps_pos_ecef_UC, temp_gps_vel_ecef_x, temp_gps_vel_ecef_y, temp_gps_vel_ecef_z, temp_gps_vel_ecef_UC, temp_pdop, temp_u1_reserved, temp_gps_nbr_of_svs_used, temp_u4_reserved] = unpack('<IihBBiiiIiiiIHBBI', bytearray(packet_bytes) )

         elif (field_desc == '07'): # NAV_PVT
            [temp_tow_ms, temp_utc_yr, temp_utc_mo, temp_utc_day, temp_utc_hr, temp_utc_min, temp_utc_sec, temp_utctime_valid, tAcc, temp_nano, gps_format_obj.gps_fix_type, gps_format_obj.gps_fix_flags, temp_u1_reserved, gps_format_obj.gps_nbr_of_svs_used, temp_lon, temp_lat, temp_ht_above_ellip, temp_ht_above_MSL, temp_horiz_acc, temp_vert_acc, temp_gps_vned_N, temp_gps_vned_E, temp_gps_vned_D, temp_grnd_speed, temp_heading, temp_speedAcc, temp_hAcc, temp_pdop, temp_u2_reserved, temp_u4_reserved] = unpack('<IHBBBBBBIiBBBBiiiiIIiiiiiIIHHI', bytearray(packet_bytes) )

         elif (field_desc == '04'): # NAV-DOP

            temp_geom_dop = 0
            temp_pos_dop = 0
            temp_time_dop = 0
            temp_vert_dop = 0
            temp_horiz_dop = 0
            temp_northing_dop = 0
            temp_easting_dop = 0

            [temp_tow_ms, temp_geom_dop, temp_pos_dop, temp_time_dop, temp_vert_dop, temp_horiz_dop, temp_northing_dop, temp_easting_dop] = unpack('<IHHHHHHH', bytearray(packet_bytes) )

            gps_format_obj.geom_dop = temp_geom_dop * 1e-2
            gps_format_obj.pos_dop = temp_pos_dop * 1e-2
            gps_format_obj.time_dop = temp_time_dop * 1e-2
            gps_format_obj.vert_dop = temp_vert_dop * 1e-2
            gps_format_obj.horiz_dop = temp_horiz_dop * 1e-2
            gps_format_obj.northing_dop = temp_northing_dop * 1e-2
            gps_format_obj.easting_dop = temp_easting_dop * 1e-2

         field_desc_prev = field_desc

      k = k + packet_size + 8

   else:
      k = k + 1

 # Print the last set of values from the 'gps_format_obj', because there won't be another occurrence of GPS Time message at this point:
 # if (packet_set_cnt >= 1):
 if (packet_set_cnt >= 2):
   input_index = 0
   for gps_output_index in range(len(gps_output_order)):
      input_index = numpy.int32(gps_output_order[gps_output_index])
      fout_gps.write(gps_format_obj.format(input_index))

   fout_gps.write('\n')

 print('\n------------------------------------------------------------------')
 print ('\n************* Total nbr of UBLOX packets: ' + str(packet_cnt) + ', Nbr of Packet Sets = ' + str(packet_set_cnt))
 print('\n------------------------------------------------------------------')

 fin_bin.close()
 fout_gps.close()

if(__name__ == "__main__"):
  main_line(sys.argv)




