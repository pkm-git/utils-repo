import sys
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder

from imu_format import *
from gps_format import *
from ekf_format import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

from sensor_cloud_api import *

import numpy
import os

NBR_OF_LEAP_SECONDS = 17 # (as of July 2016)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

def mip_binary_to_csv_or_sensor_cloud_fn(in_file_name, destination, desired_desc = None, server = None, token = None, device_id = None, sensor_name = None, sensor_label = None, sampleRate = 0, sampleRateType = HERTZ):

 print('\n ***** in mip_binary_to_csv_or_sensor_cloud_fn, destination = ' + destination + '\n------------------------------------------------------------------')

 # Define "Master columns" (i.e. all available columns in DCP) in a "master sequence"
 imu_default_cols_dict = {"8012":1, "8004":2, "8005":3, "8007":4, "8008":5, "8006":6, "8017":7, "8009":8, "800A":9, "800C":10, "8010":11, "8011":12}
 gps_default_cols_dict = {"8109":1, "8103":2, "8105":3, "8104":4, "8106":5, "8107":6, "810A":7, "810D":8, "810B":9, "8108":10 }
 ekf_default_cols_dict = {"8211":1, "8210":2, "8201":3, "8208":4, "8202":5, "8209":6, "8205":7, "820A":8, "8203":9, "8212":10, "8207":11, "820C":12, "8217":13, "8219":14, "8206":15, "820B":16, "8216":17, "8218":18, "820D":19, "821C":20, "820E":21, "8213":22, "820F":23, "8214":24, "8215":25, "8220":26, "8221":27, "8230":28, "8231":29, "8204":30}

 channel_names = []
 channel_data = {sensor_name:{}}

 # Get the order of columns requested by the user on the command line:
 imu_output_order_minus_d = []
 gps_output_order_minus_d = []
 ekf_output_order_minus_d = []

 # Get the order of columns obtained from the log file:
 imu_output_order_in_log = []
 gps_output_order_in_log = []
 ekf_output_order_in_log = []

 imu_output_order_final = []
 gps_output_order_final = []
 ekf_output_order_final = []

 found_d_option_in_command_line = False
 bad_descriptor_supplied = False

 no_desc_list_supplied_gps_headers_printed = False
 no_desc_list_supplied_ekf_headers_printed = False

 ekf_invalid_packet_cnt = 0
 gps_invalid_packet_cnt = 0
 imu_invalid_packet_cnt = 0
 other_invalid_packet_cnt = 0

 if (desired_desc == None):
    print('\n ************* NO DESCRIPTOR LIST SPECIFIED ************ ')
    imu_output_order_minus_d = []
    gps_output_order_minus_d = []
    ekf_output_order_minus_d = []
 else:
    found_d_option_in_command_line = True
    #is this only 1 descriptor?
    if(len(desired_desc) == 4):
      if ((desired_desc)[:2] == '80'):
         imu_output_order_minus_d.append(imu_default_cols_dict[desired_desc.upper()])
      elif ((desired_desc)[:2] == '81'):
         gps_output_order_minus_d.append(gps_default_cols_dict[desired_desc.upper()])
      elif ((desired_desc)[:2] == '82'):
         ekf_output_order_minus_d.append(ekf_default_cols_dict[desired_desc.upper()])

    #is this more than one descriptor?
    elif(len(desired_desc) % 4 == 0 and len(desired_desc) > 0):
      #loop over the specified bytes
      for j in range(0,len(desired_desc),4):
        print(' **** Descriptor Requested: ' + desired_desc[j:j+4].upper() )
        if ((desired_desc[j:j+4])[:2] == '80'):
           imu_output_order_minus_d.append(imu_default_cols_dict[desired_desc[j:j+4].upper()])
        elif ((desired_desc[j:j+4])[:2] == '81'):
           gps_output_order_minus_d.append(gps_default_cols_dict[desired_desc[j:j+4].upper()])
        elif ((desired_desc[j:j+4])[:2] == '82'):
           ekf_output_order_minus_d.append(ekf_default_cols_dict[desired_desc[j:j+4].upper()])

    #is this a badly specified descriptor list?
    else:
       print('\n ************* BAD DESCRIPTOR LIST SPECIFIED ************ ')
       bad_descriptor_supplied = True
       imu_output_order_minus_d = []
       gps_output_order_minus_d = []
       ekf_output_order_minus_d = []
    # } if(len(desired_desc) == 4)..
 # } if (desired_desc == None)..

 # if command line arguments were not properly specified tell the user and exit
 if (in_file_name == None):
    print('Input file name cannot be empty')
    sys.exit()

 fin_bin = open(in_file_name, "rb")

 imu_format_obj = IMU_format()
 gps_format_obj = GPS_format()
 ekf_format_obj = EKF_format()

 total_channel_cnt = 0

 sensStatus = 0
 if (destination != None):
    if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
       imu_channel_index_range_dict = {}
       gps_channel_index_range_dict = {}
       ekf_channel_index_range_dict = {}

       if(sensor_label != None):
          sensStatus = addSensor(server, token, device_id, sensor_name, "", sensor_label)
       else:
          sensStatus = addSensor(server, token, device_id, sensor_name)

       print(' ********** addSensor: status = ' + str(sensStatus))

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       (fin_filepath, fin_filename) = os.path.split(in_file_name)
       fout_imu = open(os.path.join(fin_filepath, "IMU_Log.csv"), "w")
       fout_gps = open(os.path.join(fin_filepath, "GPS_Log.csv"), "w")
       fout_ekf = open(os.path.join(fin_filepath, "EKF_Log.csv"), "w")

    if (destination.upper() != 'CSV' and destination.upper() != 'CLOUD' and destination.upper() != 'BOTH'):
       print(' ******* Destination must be either CSV, CLOUD or BOTH (case-insensitive) ********')
       sys.exit()
    # } if (destination.upper() != 'CSV'..
 else:
    print(' ******* Destination cannot be None; must be CSV, CLOUD or BOTH (case-insensitive) ********')
    sys.exit()
 # } if (destination != None)..
 k_start = 0

 bytes_read = fin_bin.read();

 print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

 for k in range(0, len(bytes_read)):
    if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
       print(' ***** Found first [0x75 0x65] MIP pair at byte index: ' + str(k) + '\n')
       k_start = k;
       break;

 packet_size = 0
 bad_packets = 0
 k = k_start

 found_imu = False
 found_gps = False
 found_ekf = False

 output_EKF = False

 ekf_packet_cnt = 0
 found_timestamp_ekf_packet_1 = False
 found_timestamp_ekf_packet_2 = False

 ekf_split_packets = False
 processed_first_EKF_packet_pair = False

 packet_cnt = 0
 imu_packet_cnt = 0
 gps_packet_cnt = 0
 gps_total_packet_cnt = 0
 ekf_total_packet_cnt = 0
 other_packet_cnt = 0

 found_timestamp_gps_packet_1 = False
 found_timestamp_gps_packet_2 = False

 found_timestamp_imu_packet_1 = False
 found_timestamp_imu_packet_2 = False
 imu_split_packets = False

 gps_split_packets = False
 processed_first_GPS_packet_pair = False

 # Look for beginning of a valid MIP packet (Bytes: 0x7565):
 while (k < len(bytes_read)):

   if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
      packet_cnt = packet_cnt + 1

      desc_set = hexlify( bytearray(bytes_read[k+2]) ).upper()
      [packet_size] = unpack('<B', bytearray(bytes_read[k+3]))
      packet_bytes = bytearray( bytes_read[k:k+packet_size+6] )

      # print('****** Packet Nbr: ' + str(packet_cnt) + ' Descriptor Set = ' + hexlify( bytearray(bytes_read[k+2]) ).upper() + ' Packet size = ' + str(packet_size) )

      if (desc_set == '82'):
         ekf_total_packet_cnt = ekf_total_packet_cnt + 1
      elif (desc_set == '81'):
         gps_total_packet_cnt = gps_total_packet_cnt + 1
      elif (desc_set == '80'):
         imu_packet_cnt = imu_packet_cnt + 1
      else:
         other_packet_cnt = other_packet_cnt + 1

      mip_check_ret_code = mip_is_mip_packet(packet_bytes)

      if (mip_check_ret_code != MIP_OK):
         if (mip_check_ret_code == MIP_CHECKSUM_ERROR):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has Checksum error')
         elif (mip_check_ret_code == MIP_ERROR):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP error')
         elif (mip_check_ret_code == MIP_INVALID_PACKET):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP Invalid error')
         elif (mip_check_ret_code == MIP_PAYLOAD_LENGTH_MISMATCH_ERROR):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP Payload length mismatch error')
            break

         if (desc_set == '82'):
            ekf_invalid_packet_cnt = ekf_invalid_packet_cnt + 1
         elif (desc_set == '81'):
            gps_invalid_packet_cnt = gps_invalid_packet_cnt + 1
         elif (desc_set == '80'):
            imu_invalid_packet_cnt = imu_invalid_packet_cnt + 1
         else:
            other_invalid_packet_cnt = other_invalid_packet_cnt + 1
      else:
         k_field_start = 4
         
         # Determine if GPS packets are split in two (when user selects several GPS fields, the output gets distributed in 2 separate GPS packets; only one of them containing the timestamp):
         if (desc_set == '81'):
            gps_packet_cnt = gps_packet_cnt + 1
            if (processed_first_GPS_packet_pair == False):
               j = k+k_field_start

               while(j < k+packet_size+4):
                  [field_size] = unpack('<B', bytearray(bytes_read[j]))
                  field_desc = hexlify( bytearray(bytes_read[j+1]) )
                  if (field_desc == '09'):
                     if (gps_packet_cnt == 1):
                        found_timestamp_gps_packet_1 = True
                     else:
                        found_timestamp_gps_packet_2 = True
                     # } if (gps_packet_cnt == 1)..

                  # } if (field_desc == '09')..
                  j = j + field_size
               # } while(j < k+packet_size+4)..

               if (gps_packet_cnt == 2):
                  # If only one packet in the first GPS packet pair in the file contains a timestamp, consider it "GPS split output" (i.e. GPS packet size more than 255 char):
                  if ((found_timestamp_gps_packet_1 == True and found_timestamp_gps_packet_2 == False) or (found_timestamp_gps_packet_1 == False and found_timestamp_gps_packet_2 == True) ):
                     gps_split_packets = True
                     print('\n************ SPLIT GPS PACKETS = TRUE ************\n')

                  elif (found_timestamp_gps_packet_1 == True and found_timestamp_gps_packet_2 == True):
                     gps_split_packets = False
                     print('\n************ SPLIT GPS PACKETS = FALSE ************\n')

                     # Since GPS packets are not split, setting the next set of fields would erase the fields read in first GPS packet.
                     # So, copy first GPS output data row right now before reading fields from second GPS packet (and use copied attributes later to print).
                     gps_format_obj.copy()
               # } if (gps_packet_cnt == 2)..
            # } if (processed_first_GPS_packet_pair == False)..

         # Determine if EKF packets are split in two (when user selects several EKF fields, the output gets distributed in 2 separate EKF packets; only one of them containing the timestamp):
         elif (desc_set == '82'):
            ekf_packet_cnt = ekf_packet_cnt + 1
            if (processed_first_EKF_packet_pair == False):
               j = k+k_field_start

               while(j < k+packet_size+4):
                  [field_size] = unpack('<B', bytearray(bytes_read[j]))
                  field_desc = hexlify( bytearray(bytes_read[j+1]) )

                  if (field_desc == '11'):
                     if (ekf_packet_cnt == 1):
                        found_timestamp_ekf_packet_1 = True
                     else:
                        found_timestamp_ekf_packet_2 = True

                  j = j + field_size
               # } while(j < k+packet_size+4)..

               if (ekf_packet_cnt == 2):
                  # If only one packet in the first EKF packet pair in the file contains a timestamp, consider it "EKF split output" (i.e. EKF packet size more than 255 char):
                  if ((found_timestamp_ekf_packet_1 == True and found_timestamp_ekf_packet_2 == False) or (found_timestamp_ekf_packet_1 == False and found_timestamp_ekf_packet_2 == True) ):
                     ekf_split_packets = True
                     print('\n************ SPLIT EKF PACKETS = TRUE ************\n')

                  elif (found_timestamp_ekf_packet_1 == True and found_timestamp_ekf_packet_2 == True):
                     ekf_split_packets = False
                     print('\n************ SPLIT EKF PACKETS = FALSE ************\n')

                     # Since EKF packets are not split, setting the next set of fields would erase the fields read in first EKF packet.
                     # So, copy first EKF output data row right now before reading fields from second EKF packet (and use copied attributes later to print).
                     ekf_format_obj.copy()
               # } if (ekf_packet_cnt == 2)..
            # } if (processed_first_EKF_packet_pair == False)..
         # } if (desc_set == '81')..
         
         # TEMP: Check if IMU packets are split:
         if (desc_set == '80' and imu_packet_cnt < 5):
            j = k+k_field_start
            while(j < k+packet_size+4):
               [field_size] = unpack('<B', bytearray(bytes_read[j]))
               field_desc = hexlify( bytearray(bytes_read[j+1]) )
               if (field_desc == '12'):
                  if (imu_packet_cnt == 1):
                     found_timestamp_imu_packet_1 = True
                  else:
                     found_timestamp_imu_packet_2 = True
                  # } if (imu_packet_cnt == 1)..

               # } if (field_desc == '12')..
               j = j + field_size
            # } while(j < k+packet_size+4)..
            
            if (imu_packet_cnt == 2):
               if ((found_timestamp_imu_packet_1 == True and found_timestamp_imu_packet_2 == False) or (found_timestamp_imu_packet_1 == False and found_timestamp_imu_packet_2 == True) ):
                  imu_split_packets = True
                  print('\n************ SPLIT IMU PACKETS = TRUE ************\n')

               elif (found_timestamp_imu_packet_1 == True and found_timestamp_imu_packet_2 == True):
                  imu_split_packets = False
                  print('\n************ SPLIT IMU PACKETS = FALSE ************\n')
            # } if (imu_packet_cnt == 2)..

         # } if (desc_set == '80')..
         
         # Reset 'j' back to beginning of first field in this packet
         j = k+k_field_start

         # Get all fields in the packet, and set attributes of appropriate format object:
         while(j < k+packet_size+4):
            [field_size] = unpack('<B', bytearray(bytes_read[j]))
            field_bytes = bytes_read[j+2:j+field_size]
            field_desc = hexlify( bytearray(bytes_read[j+1]) ).upper()
            packet_field_descr = desc_set + field_desc.upper()
            
            # if (packet_cnt < 25):
               # if (desc_set == '80'):
                  # print(' ********* IMU: packet_field_descr = ' + packet_field_descr )
               # elif (desc_set == '81'):
                  # print(' ********* GPS: packet_field_descr = ' + packet_field_descr )
               # elif (desc_set == '82'):
                  # print(' ********* EKF: packet_field_descr = ' + packet_field_descr )

            # if (desc_set == '80'):
               # print(' Field size = ' + str(field_size) + ', field_desc = ' + hexlify( bytearray(bytes_read[j+1:j+2]) ) + ' and field_bytes = ' + hexlify( bytearray(field_bytes) ).upper()   )
               # print(' Field size = ' + str(field_size) + ', field_desc = ' + hexlify( bytearray(bytes_read[j+1:j+2]) ).upper() )

            if (desc_set == '82'):
               found_ekf = True
               if (packet_field_descr in ekf_default_cols_dict and (processed_first_EKF_packet_pair == False and ekf_total_packet_cnt == 1 or (ekf_total_packet_cnt == 2 and ekf_split_packets == True))):
                  ekf_output_order_in_log.append(ekf_default_cols_dict[packet_field_descr])
                  print(' ********* EKF: packet_field_descr = ' + packet_field_descr + ', added to ekf_output_order_in_log: EKF index = ' + str(ekf_default_cols_dict[packet_field_descr]))

               if (field_desc == '11'):
                  [ekf_format_obj.ekf_tow, ekf_format_obj.ekf_week, ekf_format_obj.flags_82_11] = unpack('>dHH', bytearray(field_bytes) )
               elif (field_desc == '10'):
                  [ekf_format_obj.ekf_state, ekf_format_obj.ekf_mode, ekf_format_obj.flags_82_10] = unpack('>HHH', bytearray(field_bytes) )
               elif (field_desc == '01'):
                  [ekf_format_obj.ekf_pos_llh_lat, ekf_format_obj.ekf_pos_llh_lon, ekf_format_obj.ekf_pos_llh_ht, ekf_format_obj.flags_82_01] = unpack('>dddH', bytearray(field_bytes) )
               elif (field_desc == '08'):
                  [ekf_format_obj.ekf_pos_llh_UC_lat, ekf_format_obj.ekf_pos_llh_UC_lon, ekf_format_obj.ekf_pos_llh_UC_ht, ekf_format_obj.flags_82_08] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '02'):
                  [ekf_format_obj.ekf_ned_vel_x, ekf_format_obj.ekf_ned_vel_y, ekf_format_obj.ekf_ned_vel_z, ekf_format_obj.flags_82_02] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '09'):
                  [ekf_format_obj.ekf_ned_vel_UC_x, ekf_format_obj.ekf_ned_vel_UC_y, ekf_format_obj.ekf_ned_vel_UC_z, ekf_format_obj.flags_82_09] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '05'):
                  [ekf_format_obj.euler_angle_roll, ekf_format_obj.euler_angle_pitch, ekf_format_obj.euler_angle_yaw, ekf_format_obj.flags_82_05] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '0A'):
                  [ekf_format_obj.euler_angle_UC_roll, ekf_format_obj.euler_angle_UC_pitch, ekf_format_obj.euler_angle_UC_yaw, ekf_format_obj.flags_82_0a] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '03'):
                  [ekf_format_obj.quat_0, ekf_format_obj.quat_1, ekf_format_obj.quat_2, ekf_format_obj.quat_3, flags_82_03] = unpack('>ffffH', bytearray(field_bytes) )
               elif (field_desc == '12'):
                  [ekf_format_obj.quat_UC_0, ekf_format_obj.quat_UC_1, ekf_format_obj.quat_UC_2, ekf_format_obj.quat_UC_3, ekf_format_obj.flags_82_12] = unpack('>ffffH', bytearray(field_bytes) )
               elif (field_desc == '07'):
                  [ekf_format_obj.accel_bias_x, ekf_format_obj.accel_bias_y, ekf_format_obj.accel_bias_z, ekf_format_obj.flags_82_07] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '0C'):
                  [ekf_format_obj.accel_bias_UC_x, ekf_format_obj.accel_bias_UC_y, ekf_format_obj.accel_bias_UC_z, ekf_format_obj.flags_82_0c] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '17'):
                  [ekf_format_obj.accel_SF_x, ekf_format_obj.accel_SF_y, ekf_format_obj.accel_SF_z, ekf_format_obj.flags_82_17] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '19'):
                  [ekf_format_obj.accel_SF_UC_x, ekf_format_obj.accel_SF_UC_y, ekf_format_obj.accel_SF_UC_z, ekf_format_obj.flags_82_19] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '06'):
                  [ekf_format_obj.gyro_bias_x, ekf_format_obj.gyro_bias_y, ekf_format_obj.gyro_bias_z, ekf_format_obj.flags_82_06] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '0B'):
                  [ekf_format_obj.gyro_bias_UC_x, ekf_format_obj.gyro_bias_UC_y, ekf_format_obj.gyro_bias_UC_z, ekf_format_obj.flags_82_0b] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '16'):
                  [ekf_format_obj.gyro_SF_x, ekf_format_obj.gyro_SF_y, ekf_format_obj.gyro_SF_z, ekf_format_obj.flags_82_16] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '18'):
                  [ekf_format_obj.gyro_SF_UC_x, ekf_format_obj.gyro_SF_UC_y, ekf_format_obj.gyro_SF_UC_z, ekf_format_obj.flags_82_18] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '0D'):
                  [ekf_format_obj.lin_accel_x, ekf_format_obj.lin_accel_y, ekf_format_obj.lin_accel_z, ekf_format_obj.flags_82_0d] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '1C'):
                  [ekf_format_obj.comp_accel_x, ekf_format_obj.comp_accel_y, ekf_format_obj.comp_accel_z, ekf_format_obj.flags_82_1c] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '0E'):
                  [ekf_format_obj.comp_gyro_x, ekf_format_obj.comp_gyro_y, ekf_format_obj.comp_gyro_z, ekf_format_obj.flags_82_0e] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '13'):
                  [ekf_format_obj.grav_vect_x, ekf_format_obj.grav_vect_y, ekf_format_obj.grav_vect_z, ekf_format_obj.flags_82_13] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '0F'):
                  [ekf_format_obj.grav_mag, ekf_format_obj.flags_82_0f] = unpack('>fH', bytearray(field_bytes) )
               elif (field_desc == '14'):
                  [ekf_format_obj.heading, ekf_format_obj.heading_UC, ekf_format_obj.heading_source, ekf_format_obj.flags_82_14] = unpack('>ffHH', bytearray(field_bytes) )
               elif (field_desc == '15'):
                  [ekf_format_obj.inten_N, ekf_format_obj.inten_E, ekf_format_obj.inten_D, ekf_format_obj.inclination, ekf_format_obj.declination, ekf_format_obj.flags_82_15] = unpack('>fffffH', bytearray(field_bytes) )
               elif (field_desc == '21'):
                  [ekf_format_obj.pressure_altitude, ekf_format_obj.flags_82_21] = unpack('>fH', bytearray(field_bytes) )
               elif (field_desc == '20'):
                  [ekf_format_obj.geom_alt, ekf_format_obj.geopot_alt, ekf_format_obj.temp, ekf_format_obj.pressure, ekf_format_obj.density, ekf_format_obj.flags_82_20] = unpack('>fffffH', bytearray(field_bytes) )
               elif (field_desc == '30'):
                  [ekf_format_obj.gps_ant_offset_corr_x, ekf_format_obj.gps_ant_offset_corr_y, ekf_format_obj.gps_ant_offset_corr_z, ekf_format_obj.flags_82_30] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '31'):
                  [ekf_format_obj.gps_ant_offset_corr_UC_x, ekf_format_obj.gps_ant_offset_corr_UC_y, ekf_format_obj.gps_ant_offset_corr_UC_z, ekf_format_obj.flags_82_31] = unpack('>fffH', bytearray(field_bytes) )
               elif (field_desc == '04'):
                  [ekf_format_obj.matrix_m11, ekf_format_obj.matrix_m12, ekf_format_obj.matrix_m13, ekf_format_obj.matrix_m21, ekf_format_obj.matrix_m22, ekf_format_obj.matrix_m23, ekf_format_obj.matrix_m31, ekf_format_obj.matrix_m32, ekf_format_obj.matrix_m33, ekf_format_obj.flags_82_04] = unpack('>fffffffffH', bytearray(field_bytes) )

            elif (desc_set == '81'):
               found_gps = True

               if (packet_field_descr in gps_default_cols_dict and (processed_first_GPS_packet_pair == False and gps_total_packet_cnt == 1 or (gps_total_packet_cnt == 2 and gps_split_packets == True))):
                  gps_output_order_in_log.append(gps_default_cols_dict[packet_field_descr])
                  
               if (field_desc == '09'):
                  [gps_format_obj.gps_tow, gps_format_obj.gps_week, gps_format_obj.flags_81_09] = unpack('>dHH', bytearray(field_bytes) )
               elif (field_desc == '03'):
                  [gps_format_obj.gps_lat, gps_format_obj.gps_lon, gps_format_obj.gps_ht_abv_ellip, gps_format_obj.gps_ht_abv_MSL, gps_format_obj.gps_horiz_acc, gps_format_obj.gps_vert_acc, gps_format_obj.flags_81_03] = unpack('>ddddffH', bytearray(field_bytes) )
               elif (field_desc == '05'):
                  [gps_format_obj.gps_vned_N, gps_format_obj.gps_vned_E, gps_format_obj.gps_vned_D, gps_format_obj.gps_speed, gps_format_obj.gps_grnd_speed, gps_format_obj.gps_heading, gps_format_obj.gps_speed_acc, gps_format_obj.gps_heading_acc, gps_format_obj.flags_81_05] = unpack('>ffffffffH', bytearray(field_bytes) )
               elif (field_desc == '04'):
                  [gps_format_obj.gps_pos_ecef_x, gps_format_obj.gps_pos_ecef_y, gps_format_obj.gps_pos_ecef_z, gps_format_obj.gps_pos_ecef_UC, gps_format_obj.flags_81_04] = unpack('>dddfH', bytearray(field_bytes) )
               elif (field_desc == '06'):
                  [gps_format_obj.gps_vel_ecef_x, gps_format_obj.gps_vel_ecef_y, gps_format_obj.gps_vel_ecef_z, gps_format_obj.gps_vel_ecef_UC, gps_format_obj.flags_81_06] = unpack('>ffffH', bytearray(field_bytes) )
               elif (field_desc == '0B'):
                  [gps_format_obj.gps_fix_type, gps_format_obj.gps_nbr_of_svs_used, gps_format_obj.gps_fix_flags, gps_format_obj.flags_81_0b] = unpack('>BBHH', bytearray(field_bytes) )
               elif (field_desc == '0A'):
                  [gps_format_obj.gps_clock_bias, gps_format_obj.gps_clock_drift, gps_format_obj.gps_clock_acc_estimate, gps_format_obj.flags_81_0a] = unpack('>dddH', bytearray(field_bytes) )
               elif (field_desc == '0D'):
                  [gps_format_obj.gps_hw_status_sensor_state, gps_format_obj.gps_hw_status_antenna_state, gps_format_obj.gps_hw_status_antenna_power, gps_format_obj.flags_81_0d] = unpack('>BBBH', bytearray(field_bytes) )
               elif (field_desc == '07'):
                  [gps_format_obj.geom_dop, gps_format_obj.pos_dop, gps_format_obj.horiz_dop, gps_format_obj.vert_dop, gps_format_obj.time_dop, gps_format_obj.northing_dop, gps_format_obj.easting_dop, gps_format_obj.flags_81_07] = unpack('>fffffffH', bytearray(field_bytes) )
               elif (field_desc == '08'):
                  [gps_format_obj.utc_yr, gps_format_obj.utc_mo, gps_format_obj.utc_day, gps_format_obj.utc_hr, gps_format_obj.utc_min, gps_format_obj.utc_sec, gps_format_obj.utc_msec, gps_format_obj.flags_81_08] = unpack('>HBBBBBIH', bytearray(field_bytes) )

            elif (desc_set == '80'):
               found_imu = True
               
               if (imu_packet_cnt == 1 and packet_field_descr in imu_default_cols_dict):
                  imu_output_order_in_log.append(imu_default_cols_dict[packet_field_descr])
                  print(' ********* IMU: packet_field_descr = ' + packet_field_descr + ', added to imu_output_order_in_log: IMU index = ' + str(imu_default_cols_dict[packet_field_descr]))

               if (field_desc == '12'):
                  [imu_format_obj.imu_tow, imu_format_obj.imu_week, imu_format_obj.flags_80_12] = unpack('>dHH', bytearray(field_bytes) )
                  # if (imu_packet_cnt < 10):
                  # print(' ***** PARSED: imu_format_obj.imu_tow = ' + str(imu_format_obj.imu_tow) + ' imu_format_obj.imu_week = ' + str(imu_format_obj.imu_week) )
                  # else:
                     # sys.exit()

               elif (field_desc == '04'):
                  [imu_format_obj.scaled_accel_x, imu_format_obj.scaled_accel_y, imu_format_obj.scaled_accel_z] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '05'):
                  [imu_format_obj.scaled_gyro_x, imu_format_obj.scaled_gyro_y, imu_format_obj.scaled_gyro_z] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '07'):
                  [imu_format_obj.delta_theta_roll, imu_format_obj.delta_theta_pitch, imu_format_obj.delta_theta_yaw] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '08'):
                  [imu_format_obj.delta_vel_x, imu_format_obj.delta_vel_y, imu_format_obj.delta_vel_z] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '06'):
                  [imu_format_obj.mag_x, imu_format_obj.mag_y, imu_format_obj.mag_z] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '17'):
                  [imu_format_obj.ambient_pr] = unpack('>f', bytearray(field_bytes) )
               elif (field_desc == '09'):
                  [imu_format_obj.cf_matrix_m11, imu_format_obj.cf_matrix_m12, imu_format_obj.cf_matrix_m13, imu_format_obj.cf_matrix_m21, imu_format_obj.cf_matrix_m22, imu_format_obj.cf_matrix_m23, imu_format_obj.cf_matrix_m31, imu_format_obj.cf_matrix_m32, imu_format_obj.cf_matrix_m33] = unpack('>fffffffff', bytearray(field_bytes) )
               elif (field_desc == '0A'):
                  [imu_format_obj.cf_quat_0, imu_format_obj.cf_quat_1, imu_format_obj.cf_quat_2, imu_format_obj.cf_quat_3] = unpack('>ffff', bytearray(field_bytes) )
               elif (field_desc == '0C'):
                  [imu_format_obj.cf_euler_angle_roll, imu_format_obj.cf_euler_angle_pitch, imu_format_obj.cf_euler_angle_yaw] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '10'):
                  [imu_format_obj.cf_stabilized_mag_vector_north_x, imu_format_obj.cf_stabilized_mag_vector_north_y, imu_format_obj.cf_stabilized_mag_vector_north_z] = unpack('>fff', bytearray(field_bytes) )
               elif (field_desc == '11'):
                  [imu_format_obj.cf_stabilized_accel_vector_up_x, imu_format_obj.cf_stabilized_accel_vector_up_y, imu_format_obj.cf_stabilized_accel_vector_up_z] = unpack('>fff', bytearray(field_bytes) )

            # } if (desc_set == '82')..

            j = j + field_size
         # } while(j < k+packet_size+4)..

         # Use fields from packet to create one row of output to 'channel_data' structure being sent to Sensor Cloud:
         if (found_imu):
            # Add IMU headers as channel names being sent to Sensor Cloud:
            if (imu_packet_cnt == 1):
               if (found_d_option_in_command_line == False or bad_descriptor_supplied == True):
                  imu_output_order_final = imu_output_order_in_log
               else:
                  for im in imu_output_order_minus_d:
                     if (im in imu_output_order_in_log):
                        imu_output_order_final.append(im)
                  # } for im in imu_output_order_minus_d..
               # } if (found_d_option_in_command_line == False..

               imu_output_order_final.sort()

               for i in imu_output_order_final:
                  print(' ******** imu_output_order_final: i = ' + str(i))

               print('------------------------------------------------')

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_imu.write('DATA_START\n')

               for imu_output_index in range(len(imu_output_order_final)):
                  input_index = numpy.int32(imu_output_order_final[imu_output_index])
                  print(' ****** writing headers: imu_output_index = ' + str(imu_output_index) + ' input_index = ' + str(input_index))

                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_imu.write(imu_format_obj.format_header(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     tmp_channel_name_array = imu_format_obj.format_channel_name(input_index)

                     index_range_array = []

                     for c in tmp_channel_name_array:
                        channel_names.append(c)
                        chStatus = addChannel(server, token, device_id, sensor_name, c)
                        channel_data[sensor_name][total_channel_cnt] = []
                        index_range_array.append(total_channel_cnt)

                        total_channel_cnt += 1
                     # } for c in tmp_channel_name_array..

                     imu_channel_index_range_dict[input_index]  = index_range_array
                  # } if (destination.upper() == 'CLOUD'..
               # } for imu_output_index in range(len(imu_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_imu.write('\n')

            # } if (imu_packet_cnt == 1)..

            # Now add IMU data to these channels being sent to Sensor Cloud:
            if (imu_format_obj.imu_week > 0 and imu_format_obj.imu_tow > 0):
               input_index = 0
               for imu_output_index in range(len(imu_output_order_final)):
                  input_index = numpy.int32(imu_output_order_final[imu_output_index])
                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_imu.write(imu_format_obj.format(input_index))
                     # if (imu_packet_cnt < 10):
                        # print(' ******** wrote imu_format_obj.format(input_index) = ' + imu_format_obj.format(input_index) + ' to csv')
                     # else:
                        # sys.exit()

                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     gps_week = int(imu_format_obj.imu_week)
                     gps_tow = numpy.double(imu_format_obj.imu_tow)

                     gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                     utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                     # Convert UTC sec from UTC Epoch into unix nanosecond time
                     ts = utc_sec_from_utc_epoch * 1000000000

                     tmp_channel_value_array = imu_format_obj.format_channel_value(input_index)

                     tmp_channel_index_range_array = imu_channel_index_range_dict[input_index]

                     indx = 0
                     for c in tmp_channel_value_array:
                        try:
                           ch = channel_data_struct()
                           ch.ts = numpy.int64(ts)
                           ch.value = float(c)
                           channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                        except ValueError as err:
                           print(" ******** ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " gps_tow: " + str(gps_tow) + " 0-based column index = " + str(indx) + ", value = " + c + ", Error Msg: {0}".format(err))
                        indx = indx + 1
                     # } for c in tmp_channel_value_array..
                  # } if (destination.upper() == 'CLOUD'..
               # } for imu_output_index in range(len(imu_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_imu.write('\n')

            # } if (imu_format_obj.imu_week > 0 and imu_format_obj.imu_tow > 0)..
         # } if (found_imu)..

         if (found_gps and processed_first_GPS_packet_pair == False and gps_packet_cnt == 2):
            processed_first_GPS_packet_pair = True

         # if (found_gps):
         if (found_gps and processed_first_GPS_packet_pair == True and (gps_split_packets == False or (gps_split_packets == True and gps_packet_cnt == 2))):
            # Add GPS headers as channel names being sent to Sensor Cloud:
            if (no_desc_list_supplied_gps_headers_printed == False):

               if (found_d_option_in_command_line == False or bad_descriptor_supplied == True):
                  gps_output_order_final = gps_output_order_in_log
               else:
                  for g in gps_output_order_minus_d:
                     if (g in gps_output_order_in_log):
                        gps_output_order_final.append(g)
                  # } for g in gps_output_order_minus_d..
               # } if (found_d_option_in_command_line == False or..

               gps_output_order_final.sort()

               for i in gps_output_order_final:
                  print(' ******** gps_output_order_final: i = ' + str(i))

               print('------------------------------------------------')

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_gps.write('DATA_START\n')

               for gps_output_index in range(len(gps_output_order_final)):
                  input_index = numpy.int32(gps_output_order_final[gps_output_index])
                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_gps.write(gps_format_obj.format_header(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     tmp_channel_name_array = gps_format_obj.format_channel_name(input_index)

                     index_range_array = []

                     for c in tmp_channel_name_array:
                        channel_names.append(c)
                        chStatus = addChannel(server, token, device_id, sensor_name, c)
                        channel_data[sensor_name][total_channel_cnt] = []
                        index_range_array.append(total_channel_cnt)

                        total_channel_cnt += 1
                     # } for c in tmp_channel_name_array..

                     gps_channel_index_range_dict[input_index] = index_range_array
                  # } if (destination.upper() == 'CLOUD'..
               # } for gps_output_index in range(len(gps_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_gps.write('\n')

               no_desc_list_supplied_gps_headers_printed = True
            # } if (no_desc_list_supplied_gps_headers_printed == False)..

            # When GPS packets are not split, we need to add the first GPS packet now (from copy) because we waited for at least 2 GPS packets to determine if packets are split:
            if (gps_split_packets == False and gps_total_packet_cnt == 2 and gps_format_obj.gps_week_copy > 0 and gps_format_obj.gps_tow_copy > 0):
               input_index = 0
               for gps_output_index in range(len(gps_output_order_final)):
                  input_index = numpy.int32(gps_output_order_final[gps_output_index])
                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_gps.write(gps_format_obj.format_using_copy(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     gps_week = gps_format_obj.gps_week_copy
                     gps_tow = gps_format_obj.gps_tow_copy

                     gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                     utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                     # Convert UTC sec from UTC Epoch into unix nanosecond time
                     ts = utc_sec_from_utc_epoch * 1000000000

                     tmp_channel_value_array = gps_format_obj.format_channel_value_from_copy(input_index)

                     tmp_channel_index_range_array = gps_channel_index_range_dict[input_index]

                     indx = 0
                     for c in tmp_channel_value_array:
                        ch = channel_data_struct()
                        ch.ts = numpy.int64(ts)
                        ch.value = float(c)

                        channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                        indx = indx + 1
                     # } for c in tmp_channel_value_array..
                  # } if (destination.upper() == 'CSV'..
               # } for gps_output_index in range(len(gps_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_gps.write('\n')

            # } if (gps_split_packets == False and gps_total_packet_cnt == 2..

            # Now print the 'regular' GPS packet or add the 'regular' GPS packet to channel data being sent to Sensor Cloud:
            if (gps_format_obj.gps_week > 0 and gps_format_obj.gps_tow > 0):
               input_index = 0
               for gps_output_index in range(len(gps_output_order_final)):
                  input_index = numpy.int32(gps_output_order_final[gps_output_index])

                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_gps.write(gps_format_obj.format(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     gps_week = int(gps_format_obj.gps_week)
                     gps_tow = numpy.double(gps_format_obj.gps_tow)

                     gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                     utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                     # Convert UTC sec from UTC Epoch into unix nanosecond time
                     ts = utc_sec_from_utc_epoch * 1000000000

                     tmp_channel_value_array = gps_format_obj.format_channel_value(input_index)

                     tmp_channel_index_range_array = gps_channel_index_range_dict[input_index]

                     indx = 0
                     for c in tmp_channel_value_array:
                        ch = channel_data_struct()
                        ch.ts = numpy.int64(ts)
                        ch.value = float(c)

                        channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                        indx = indx + 1
                     # } for c in tmp_channel_value_array..
                  # } if (destination.upper() == 'CLOUD'..
               # } for gps_output_index in range(len(gps_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_gps.write('\n')

            # } if (gps_format_obj.gps_week > 0 and gps_format_obj.gps_tow > 0)..

            if (gps_split_packets == True):
               gps_packet_cnt = 0
         # } if (found_gps and..

         if (found_ekf and processed_first_EKF_packet_pair == False and ekf_packet_cnt == 2):
            processed_first_EKF_packet_pair = True

         if (found_ekf and processed_first_EKF_packet_pair == True and (ekf_split_packets == False or (ekf_split_packets == True and ekf_packet_cnt == 2))):
            # Add EKF headers as channel names being sent to Sensor Cloud:
            if (no_desc_list_supplied_ekf_headers_printed == False):
               if (found_d_option_in_command_line == False or bad_descriptor_supplied == True):
                  ekf_output_order_final = ekf_output_order_in_log
               else:
                  for e in ekf_output_order_minus_d:
                     if (e in ekf_output_order_in_log):
                        ekf_output_order_final.append(e)
                     # } if (e in ekf_output_order_in_log)..
                  # } for e in ekf_output_order_minus_d..
               # } if (found_d_option_in_command_line == False or..

               ekf_output_order_final.sort()

               for i in ekf_output_order_final:
                  print(' ******** ekf_output_order_final: i = ' + str(i))

               print('------------------------------------------------')

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_ekf.write('DATA_START\n')

               for ekf_output_index in range(len(ekf_output_order_final)):
                  input_index = numpy.int32(ekf_output_order_final[ekf_output_index])
                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_ekf.write(ekf_format_obj.format_header(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     tmp_channel_name_array = ekf_format_obj.format_channel_name(input_index)

                     index_range_array = []

                     for c in tmp_channel_name_array:
                        channel_names.append(c)
                        chStatus = addChannel(server, token, device_id, sensor_name, c)
                        channel_data[sensor_name][total_channel_cnt] = []
                        index_range_array.append(total_channel_cnt)

                        total_channel_cnt += 1
                     # } for c in tmp_channel_name_array..

                     ekf_channel_index_range_dict[input_index]  = index_range_array
                  # } if (destination.upper() == 'CLOUD'..
               # } for ekf_output_index in range(len(ekf_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_ekf.write('\n')

               no_desc_list_supplied_ekf_headers_printed = True

            # } if (no_desc_list_supplied_ekf_headers_printed == False)..

            # When EKF packets are not split, we need to add the first EKF packet now (from copy) because we waited for at least 2 EKF packets to determine if packets are split:
            if (ekf_split_packets == False and ekf_total_packet_cnt == 2 and ekf_format_obj.ekf_week_copy > 0 and ekf_format_obj.ekf_tow_copy > 0):
               input_index = 0
               for ekf_output_index in range(len(ekf_output_order_final)):
                  input_index = numpy.int32(ekf_output_order_final[ekf_output_index])
                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_ekf.write(ekf_format_obj.format_using_copy(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     gps_week = ekf_format_obj.ekf_week_copy
                     gps_tow = ekf_format_obj.ekf_tow_copy

                     gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                     utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                     # Convert UTC sec from UTC Epoch into unix nanosecond time
                     ts = utc_sec_from_utc_epoch * 1000000000

                     tmp_channel_value_array = ekf_format_obj.format_channel_value_from_copy(input_index)

                     tmp_channel_index_range_array = ekf_channel_index_range_dict[input_index]

                     indx = 0
                     for c in tmp_channel_value_array:
                        ch = channel_data_struct()
                        ch.ts = numpy.int64(ts)
                        ch.value = float(c)

                        channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                        indx = indx + 1
                     # } for c in tmp_channel_value_array..
                  # } if (destination.upper() == 'CSV'..
               # } for ekf_output_index in range(len(ekf_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_ekf.write('\n')

            # } if (ekf_split_packets == False and ekf_total_packet_cnt == 2)..

            # Now add the 'regular' EKF packet to channel data being sent to Sensor Cloud:
            if (ekf_format_obj.ekf_week > 0 and ekf_format_obj.ekf_tow > 0):
               input_index = 0
               for ekf_output_index in range(len(ekf_output_order_final)):
                  input_index = numpy.int32(ekf_output_order_final[ekf_output_index])
                  if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                     fout_ekf.write(ekf_format_obj.format(input_index))
                  if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
                     gps_week = int(ekf_format_obj.ekf_week)
                     gps_tow = numpy.double(ekf_format_obj.ekf_tow)

                     gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                     utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                     # Convert UTC sec from UTC Epoch into unix nanosecond time
                     ts = utc_sec_from_utc_epoch * 1000000000

                     tmp_channel_value_array = ekf_format_obj.format_channel_value(input_index)

                     tmp_channel_index_range_array = ekf_channel_index_range_dict[input_index]

                     indx = 0
                     for c in tmp_channel_value_array:
                        ch = channel_data_struct()
                        ch.ts = numpy.int64(ts)
                        ch.value = float(c)

                        channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                        indx = indx + 1
                     # } for c in tmp_channel_value_array..
                  # } if (destination.upper() == 'CSV'..
               # } for ekf_output_index in range(len(ekf_output_order_final))..

               if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
                  fout_ekf.write('\n')

            # } if (ekf_format_obj.ekf_week > 0 and ekf_format_obj.ekf_tow > 0)..

            if (ekf_split_packets == True):
               ekf_packet_cnt = 0

            # if (ekf_total_packet_cnt == 5):
              # break
         # } if (found_ekf and processed_first_EKF_packet_pair..
      # } if (mip_check_ret_code != MIP_OK)..

      k = k + packet_size + 6

      found_imu = False
      found_gps = False
      found_ekf = False

   else:
      k = k + 1
   # } if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65')..
 # } while (k < len(bytes_read))..

 # print('\n------------------------------------------------------------------')

 print ('\n************* Total nbr of MIP packets: ' + str(packet_cnt))
 print ('************** Nbr of valid IMU packets: ' + str(imu_packet_cnt))
 print ('************** Nbr of valid GPS packets: ' + str(gps_total_packet_cnt))
 print ('************** Nbr of valid EKF packets: ' + str(ekf_total_packet_cnt))
 print ('************** Nbr of valid Other packets: ' + str(other_packet_cnt))

 print ('************** Nbr of invalid IMU packets: ' + str(imu_invalid_packet_cnt))
 print ('************** Nbr of invalid GPS packets: ' + str(gps_invalid_packet_cnt))
 print ('************** Nbr of invalid EKF packets: ' + str(ekf_invalid_packet_cnt))
 print ('************** Nbr of invalid Other packets: ' + str(other_invalid_packet_cnt))

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_imu.close()
    fout_gps.close()
    fout_ekf.close()
 if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
    print("******* MIP Binary to Sensor Cloud: len(channel_data[sensor_name]) = " + str(len(channel_data[sensor_name])))

    # Upload one column (channel) at a time to Sensor Cloud:
    for index in range(len(channel_data[sensor_name])):
       print(' *********** index = ' + str(index) + ' channel_names[index] = ' + channel_names[index] + ' len(channel_data[sensor_name][index]) = ' + str(len(channel_data[sensor_name][index])))

       channel_data_list = channel_data[sensor_name][index]

       addTimeSeriesData(server, token, device_id, sensor_name, channel_names[index], sampleRate, sampleRateType, channel_data_list)

 print('\n------------------------------------------------------------------')

 fin_bin.close()





