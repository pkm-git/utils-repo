import numpy as np
import os
import pyqtgraph as pg
import calendar

from datetime import datetime
from PyQt4 import QtCore, QtGui
from sensor_cloud_api import *
from QInertialSensorUtils_GUI_TreeWidget import *
from time import sleep         #sleep

class MySensorListWidget(QtGui.QWidget):
   def __init__(self, parent, in_file_name = None):
      super(MySensorListWidget, self).__init__(parent)

      self.parent_obj = parent

      self.sensor_name = ''
      self.desired_action = 'gs'
      self.sensor_label = None
      self.sensor_being_deleted = ''
      self.from_delete_selected = False
      self.csv_data_dict_of_dicts = {}
      self.unix_timestamp_dict_of_dicts = {}
      self.child_count = 0
      self.selected_sensor_count = 0
      self.selected_sensor_being_deleted_count = 0
      self.nbrOfSubmitCalls = 0
      self.sensor_list_tree = None
      self.plotted_channels_dict = {}

      self.in_file_name = None
      self.appendMode = False
      self.csv_mode = False
      self.selected_sensor_names = []

      self.outputFile = open('InertialSensorUtils_DeleteSensor.log','a')

      if (in_file_name != None):
         self.in_file_name = in_file_name
         self.csv_mode = True

      # QProcess object for 'delete all sensors'
      self.process = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process.readyRead.connect(self.dataReady)

      self.process.started.connect(self.processStarted)
      self.process.finished.connect(self.processDone)

      # QProcess object for 'delete selected sensors'
      self.process_del_selected = QtCore.QProcess(self)

      self.process_del_selected.started.connect(self.processDelSelStarted)
      self.process_del_selected.finished.connect(self.processDelSelDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

      self.__controls()
      self.__layout()

   def closeEvent(self, event):
      print "Closing MySensorListWidget window"

      self.outputFile.close()

      super(MySensorListWidget, self).closeEvent(event)

   def processStarted(self):
      self.lbl_status.setText("Status: Deleting all sensors.. please wait")

      # Just to prevent accidentally running multiple times
      # Disable the delete buttons when process starts, and enable them when it finishes
      self.delete_all_sensors_button.setEnabled(False)
      self.delete_selected_sensors_button.setEnabled(False)
      self.doAction()

   def processDone(self):
      self.lbl_status.setText("Status: DONE deleting all sensors")

      # Re-enable the delete buttons after completing the command:
      self.delete_all_sensors_button.setEnabled(True)
      self.delete_selected_sensors_button.setEnabled(True)

      # Refresh list of sensors after deleting selected ones:
      self.sensor_list_tree.initUI()

   def processDelSelStarted(self):
      self.outputFile.write(' ******* Starting Delete Selected Sensors: ' + str(self.sensor_being_deleted) + '\n')

      strStatusLabel = "Status: Deleting sensor: " + str(self.sensor_being_deleted) + " [" + str(self.selected_sensor_being_deleted_count) + " of " + str(self.selected_sensor_count) + "]: Time elapsed: " + str(self.step) + " sec"
      self.lbl_status.setText(strStatusLabel)

      self.delete_selected_sensors_button.setEnabled(False)
      self.delete_all_sensors_button.setEnabled(False)
      self.doAction()

   def processDelSelDone(self):
      print(' ******** in processDelSelDone ****** ')
      self.lbl_status.setText("Status: DONE deleting sensor: " + str(self.sensor_being_deleted) + " [" + str(self.selected_sensor_being_deleted_count) + " of " + str(self.selected_sensor_count) + "]")
      self.step = 0

      if (self.selected_sensor_being_deleted_count == self.selected_sensor_count):
         self.delete_selected_sensors_button.setEnabled(True)
         self.delete_all_sensors_button.setEnabled(True)

         # Refresh list of sensors after deleting selected ones:
         self.sensor_list_tree.initUI()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith("Status: DONE")):
         if (self.from_delete_selected):
            if (self.selected_sensor_being_deleted_count == self.selected_sensor_count):
               self.timer.stop()
            else:
               self.nbrOfSubmitCalls += 1
               self.submitDeleteSelectedSensors(False)
            # } if (self.selected_sensor_being_deleted_count ==..
         else:
            self.timer.stop()
         # } if (self.from_delete_selected)..

         return
      # } if (self.lbl_status.text().startsWith("Status: DONE")..

      self.step = self.step + 1
      strStatusLabel = ''
      if (self.from_delete_selected):
         strStatusLabel = "Status: Deleting sensor: " + str(self.sensor_being_deleted) + " [" + str(self.selected_sensor_being_deleted_count) + " of " + str(self.selected_sensor_count) + "]: Time elapsed: " + str(self.step) + " sec"
      else:
         strStatusLabel = "Status: Doing.. Time elapsed: " + str(self.step) + " seconds"
      self.lbl_status.setText(strStatusLabel)

   def doAction(self):
      if (self.timer.isActive() and self.from_delete_selected == False):
         self.timer.stop()
         return

      self.step = 0
      self.timer.start(1000, self)

   def append_tree_obj_from_file(self, append_file_name):
      self.append_file_name = append_file_name
      self.appendMode = True
      self.csv_mode = True

      if (self.sensor_list_tree != None and self.append_file_name != None):
         self.sensor_list_tree.append_tree_obj_from_file(self.append_file_name)

   def clearStatusText(self):
      self.lbl_status.setText("Status:")

   def __controls(self):

      labelText = "Sensor List"

      self.lbl_space_xxsmall = QtGui.QLabel()
      self.lbl_space_xxsmall.setFixedWidth(2)
      self.lbl_space_xxsmall.setFixedHeight(25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedWidth(5)
      self.lbl_space_xsmall.setFixedHeight(25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedWidth(15)
      self.lbl_space_small.setFixedHeight(25)

      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedWidth(30)
      self.lbl_space.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedWidth(40)
      self.lbl_space_medium.setFixedHeight(25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedWidth(60)
      self.lbl_space_large.setFixedHeight(25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedWidth(180)
      self.lbl_space_xlarge.setFixedHeight(25)

      self.lbl_title = QtGui.QLabel(labelText)
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 5px;");
      self.lbl_status.setFixedWidth(475)
      self.lbl_status.setFixedHeight(25)

      self.lbl_sensor_name = QtGui.QLabel("Sensor Name:")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_sensor_name = MyLineEdit()
      self.edt_sensor_name.setStyleSheet("background-color: #E0E0E0;");
      self.edt_sensor_name.setReadOnly(True)

      self.clear_status_text_button = QtGui.QPushButton("Clear")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");
      self.clear_status_text_button.setFixedWidth(60)

      if (self.csv_mode == False):
         self.delete_all_sensors_button = QtGui.QPushButton("Delete All Sensors")
         self.delete_all_sensors_button.setCheckable(True)
         self.delete_all_sensors_button.toggle()
         self.delete_all_sensors_button.clicked.connect(self.submitDeleteAllSensors)
         self.delete_all_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      if (self.csv_mode == False):
         self.delete_selected_sensors_button = QtGui.QPushButton("Delete Selected Sensors")
         self.delete_selected_sensors_button.setCheckable(True)
         self.delete_selected_sensors_button.toggle()
         self.delete_selected_sensors_button.clicked.connect(lambda: self.submitDeleteSelectedSensors(True))
         self.delete_selected_sensors_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_selected_cols_button = None
      self.plot_diff_selected_cols_button = None

      if (self.csv_mode == True):
         self.plot_selected_cols_button = QtGui.QPushButton("Plot Selected Columns")
         self.plot_diff_selected_cols_button = QtGui.QPushButton("Plot Diff Selected Columns")
      else:
         self.plot_selected_cols_button = QtGui.QPushButton("Plot Selected Channels")
         self.plot_diff_selected_cols_button = QtGui.QPushButton("Plot Diff Selected Channels")

      self.plot_selected_cols_button.setCheckable(True)
      self.plot_selected_cols_button.toggle()
      self.plot_selected_cols_button.clicked.connect(lambda: self.submitPlotSelectedCols(False))
      self.plot_selected_cols_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      self.plot_diff_selected_cols_button.setCheckable(True)
      self.plot_diff_selected_cols_button.toggle()
      self.plot_diff_selected_cols_button.clicked.connect(lambda: self.submitPlotSelectedCols(True))
      self.plot_diff_selected_cols_button.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 5px;");

      if (self.csv_mode == False):
         self.sensor_list_tree = MyTreeWidget(self.parent_obj)
      elif (self.appendMode == False):
         self.sensor_list_tree = MyTreeWidget(self.parent_obj, self.in_file_name)

      self.sensor_list_tree.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()

      # -------------- TBD: -----------------------------
      if (0):
         if (desired_action == 'as'):
            if (sensor_label != None):
               addSensor(server, token, self.parent_obj.device_id, self.sensor_name, self.sensor_label)
            else:
               addSensor(server, token, self.parent_obj.device_id, self.sensor_name)
         elif (desired_action == 'us'):
            if (sensor_label != None):
               updateSensor(server, token, self.parent_obj.device_id, self.sensor_name, "", self.sensor_label)
            else:
               updateSensor(server, token, self.parent_obj.device_id, self.sensor_name, "")
         elif (desired_action == 'ac'):
            if (channel_label != None):
               addChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name, self.channel_label)
            else:
               addChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name)
         elif (desired_action == 'uc'):
            if (channel_label != None):
               updateChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name, self.channel_label)
            else:
               updateChannel(server, token, self.parent_obj.device_id, self.sensor_name, self.channel_name)
            # } if (channel_label != None)..
         # } if (desired_action == 'as')..
      # } if (0)..

   def submitDeleteSelectedSensors(self, firstCall):
      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()
      self.from_delete_selected = True
      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to delete')
         return

      if (firstCall):
         self.nbrOfSubmitCalls = 0
         self.selected_sensor_count = 0
         self.selected_sensor_names = []
         self.selected_sensor_being_deleted_count = 0

         for i in range(self.child_count):
             item = root.child(i)
             sensor_name = str(item.text(0))
             if (item != None and item.checkState(0) == QtCore.Qt.Checked):
                self.selected_sensor_count += 1
                # self.selected_sensor_names[i] = item.text(0) # OR: item.text(column)?
                self.selected_sensor_names.append(sensor_name)
             # } if (item != None and..
         # } for i in range(self.child_count)..

         if (self.selected_sensor_count == 0):
           QtGui.QMessageBox.about(self, "Msg Box", 'No sensors selected to delete')
           return
         # } if (self.selected_sensor_count == 0)..
      # } if (firstCall)..

      s = self.selected_sensor_names[self.nbrOfSubmitCalls]
      print(' ********** Deleting sensor name: ' + s)

      command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
      command_line += '" -sv "' + self.parent_obj.server
      command_line += '" -t "' + self.parent_obj.token
      command_line += '" -s "' + s
      command_line += '" -a ds'

      self.outputFile.write('\n ******** Starting Sensor Cloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n' )
      self.outputFile.write(' ******* Deleted Selected Sensors: Command = ' + command_line + '\n')

      print(' ********* DELETE SELECTED SENSOR: command_line = ' + command_line)
      self.sensor_being_deleted = s
      self.selected_sensor_being_deleted_count += 1
      self.process_del_selected.start(command_line)

   def submitPlotSelectedCols(self, isDiff):
      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()
      self.from_delete_selected = False
      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to plot')
         return

      selected_column_names_dict = {}
      selected_plot_col_count = {}
      selected_plot_total_col_count = 0
      c_tow_col = {}
      c_week_col = {}
      error_msg = ''

      for i in range(self.child_count):
         item = root.child(i)
         sensor_name = str(item.text(0))
         self.childs_child_count = item.childCount()

         print(' ********** sensor_name = ' + sensor_name + ' self.childs_child_count = ' + str(self.childs_child_count))

         for j in range(self.childs_child_count):
            items_child = item.child(j)
            # print(' ********** column name: items_child.text(0) = ' + str(items_child.text(0)))

            if (items_child.checkState(0) == QtCore.Qt.Checked):
               print(' ***** column is checked')
               col_name = str(items_child.text(0))
               if ('tow' in str(col_name).lower()):
                  c_tow_col[sensor_name] = col_name
               elif ('week' in str(col_name).lower()):
                  c_week_col[sensor_name] = col_name
               else:
                  if (sensor_name not in selected_plot_col_count):
                     print(' *********** adding sensor_name: ' + sensor_name  + ' to selected_column_names_dict')
                     selected_column_names_dict[sensor_name] = []
                     selected_plot_col_count[sensor_name] = 0

                  selected_column_names_dict[sensor_name].append(col_name)
                  selected_plot_col_count[sensor_name] += 1

                  selected_plot_total_col_count += 1
                  print(' ********* adding col_name to selected_column_names_dict[' + sensor_name + '], selected_plot_col_count = ' + str(selected_plot_col_count[sensor_name]))
               # } if ('tow' in col_name.lower())..
            # } if (items_child.checkState(0)..
         # } for j in range(self.childs_child_count)..

         if (sensor_name in selected_column_names_dict):
            # if (sensor_name in c_tow_col and len(selected_column_names_dict[sensor_name]) == 0):
            if (len(selected_column_names_dict[sensor_name]) == 0):
               error_msg += 'Must select at least one column for sensor: ' + sensor_name + '\n'
            elif (self.csv_mode == True and sensor_name not in c_tow_col and len(selected_column_names_dict[sensor_name]) > 0):
               error_msg += 'Must select a TOW column for sensor: ' + sensor_name + '\n'

            if (isDiff == True):
               if (len(selected_column_names_dict[sensor_name]) > 1):
                  error_msg += 'Cannot select more than one column for diff plot\n'
               elif ((sensor_name in c_tow_col and sensor_name not in c_week_col) or \
                     (sensor_name not in c_tow_col and sensor_name in c_week_col)): 
                  error_msg += 'For diff plot, must select Week if TOW selected, TOW if Week selected, or unselect both Week and TOW for both sensors\n'
               # } if (len(selected_column_names_dict[sensor_name])..
            # } if (isDiff == True)..
         # } if (sensor_name in selected_column_names_dict)..
      # } for i in range(self.child_count)..

      if (selected_plot_total_col_count == 0):
         QtGui.QMessageBox.about(self, "Msg Box", 'Must select at least 1 column to plot')
         return
      elif (isDiff == True and len(selected_column_names_dict.keys()) != 2):
         error_msg += 'Must select exactly 2 sensors to compare\n'

      if (error_msg != ''):
         QtGui.QMessageBox.about(self, "Msg Box", error_msg)
         return

      utcnow = datetime.utcnow().utctimetuple()
      utcunix_now = calendar.timegm(utcnow) * 1000000000

      cnt_sensor = 0

      csv_data_prev = []
      csv_data_tow_prev = []
      csv_data_week_prev = []

      s_prev = None
      col_name_prev = None
      csv_data_prev_interp = []
      csv_data_curr_interp = []

      if (self.csv_mode == False):
         unix_timestamp_dict_prev = {}

      for s in selected_column_names_dict.keys():
         print('\n----------------------------------------------------------------------')

         csv_data_dict = {}

         if (self.csv_mode == False):
            unix_timestamp_dict = {}

         print(' ******* sensor name: ' + s)
         cnt_sensor += 1

         if (s in self.csv_data_dict_of_dicts):
            print(' ************ sensor in self.csv_data_dict_of_dicts, getting csv_data_dict from it')
            csv_data_dict = self.csv_data_dict_of_dicts[s]
            if (self.csv_mode == False):
               unix_timestamp_dict = self.unix_timestamp_dict_of_dicts[s]

         # Get the TOW column data if selected to plot by the user and not already in the csv data structure
         if (s in c_tow_col and c_tow_col[s] not in csv_data_dict):
            print(' *********** s = ' + s + ' is in c_tow_col and c_tow_col[s] = ' + c_tow_col[s] + ' is not in csv_data_dict')
            if (self.csv_mode == True):
               csv_data_dict[c_tow_col[s]] = self.sensor_list_tree.csv_data_dict[s][c_tow_col[s]]
               print(' *************** len(csv_data_dict[c_tow_col[s]]) = ' + str(len(csv_data_dict[c_tow_col[s]])))
            else:
               csv_data_dict[c_tow_col[s]], unix_timestamp_dict[c_tow_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_tow_col[s], 0, utcunix_now)

         # Get the Week column data if selected to plot by the user and not already in the csv data structure
         if (s in c_week_col and c_week_col[s] not in csv_data_dict):
            print(' *********** s = ' + s + ' is in c_week_col and c_week_col[s] = ' + c_week_col[s] + ' is not in csv_data_dict')
            if (self.csv_mode == True):
               csv_data_dict[c_week_col[s]] = self.sensor_list_tree.csv_data_dict[s][c_week_col[s]]
               print(' *************** len(csv_data_dict[c_week_col[s]]) = ' + str(len(csv_data_dict[c_week_col[s]])))
            else:
               csv_data_dict[c_week_col[s]], unix_timestamp_dict[c_week_col[s]] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c_week_col[s], 0, utcunix_now)
         
         for c in selected_column_names_dict[s]:
            print('\n------------------------------------------------------------------------------------------------------------------------')
            print('\n******* sensor name: ' + s + ', column name: ' + c)

            if (c not in csv_data_dict):
               if (self.csv_mode == True):
                  # Column name is not in csv_data_dict, so get csv_data_dict[c] using tree widget
                  csv_data_dict[c] = self.sensor_list_tree.csv_data_dict[s][c]
               else:
                  # Channel name is not in csv_data_dict, so get csv_data_dict[c] and unix_timestamp_dict[c] using sensor cloud
                  csv_data_dict[c], unix_timestamp_dict[c] = downloadTimeSeriesData(self.parent_obj.server, self.parent_obj.token, self.parent_obj.device_id, s, c, 0, utcunix_now)

            if (isDiff == True and cnt_sensor == 1):
               col_name_prev = c

            if (isDiff == False or (isDiff == True and cnt_sensor == 2)):
               # pg.setConfigOption('background', 'w')
               pg.setConfigOption('background', '#A2C3F3')
               pg.setConfigOption('foreground', 'k')

               # mkPen('y', width=3, style=QtCore.Qt.DashLine)          ## Make a dashed yellow line 2px wide
               # mkPen(0.5)                                             ## solid grey line 1px wide
               # mkPen(color=(200, 200, 255), style=QtCore.Qt.DotLine)

               graphicsWidget = pg.GraphicsLayoutWidget()
               graphicsWidget.setStyleSheet("font-weight: bold; font-size: 12px; text-align: center; position: relative; background-color: #A2C3F3; border: 1px solid #330019;");

               # Enable antialiasing for prettier plots
               pg.setConfigOptions(antialias=True)

               # Generate the figure parameters for plotting output data
               p1 = graphicsWidget.addPlot()

               if (s in c_tow_col):
                  if (isDiff == True):
                     if (cnt_sensor == 2):
                        # Check if the first element in GPS Week arrays are same between the 2 sensors
                        gps_week_sensor1 = csv_data_dict[c_week_col[s]][0]
                        gps_week_sensor2 = csv_data_week_prev[0]
                        
                        print('******** gps_week_sensor1 = ' + str(gps_week_sensor1) + ', gps_week_sensor2 = ' + str(gps_week_sensor2))
                        
                        if (gps_week_sensor1 != gps_week_sensor2):
                           print(' *********** The 2 GPS Weeks are not same')
                           QtGui.QMessageBox.about(self, "Msg Box", 'GPS Week must be same between the two sensors for diff plot')
                           return

                        # Check if there is a need to interpolate.  If the time columns are same length
                        # and max difference between individual timestamp pairs is less than 1e-6, then
                        # we consider them to be identical
                        if ((len(csv_data_dict[c_tow_col[s]]) == len(csv_data_tow_prev)) and \
                           max( abs(np.array(csv_data_dict[c_tow_col[s]]) - np.array(csv_data_tow_prev)) ) < 1e-6 ):
                           # print('*********** len(csv_data_dict[c_tow_col[s]]) EQUAL TO len(csv_data_tow_prev) = ' + str(len(csv_data_dict[c_tow_col[s]])) + ' len(csv_data_dict[c]) = ' + str(len(csv_data_dict[c])) + ' len(csv_data_prev) = ' + str(len(csv_data_prev)) )
                           print(' *** TOW columns identical, no need to interpolate')

                           p1.plot(csv_data_dict[c_tow_col[s]], np.array(csv_data_dict[c])-np.array(csv_data_prev), pen='b')
                        else: # interpolate if there is an overlap of at least 20 percent
                           tmp_min_tow_sensor = 0
                           tmp_max_tow_sensor = 0
                           
                           min_tow_sensor2 = min( np.array(csv_data_dict[c_tow_col[s]]) )
                           max_tow_sensor2 = max( np.array(csv_data_dict[c_tow_col[s]]) )
                           
                           min_tow_sensor1 = min( np.array(csv_data_tow_prev) )
                           max_tow_sensor1 = max( np.array(csv_data_tow_prev) )
                           
                           # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
                           if (min_tow_sensor1 > min_tow_sensor2):
                              tmp_min_tow_sensor = min_tow_sensor1
                              tmp_max_tow_sensor = max_tow_sensor1
                              min_tow_sensor1 = min_tow_sensor2
                              max_tow_sensor1 = max_tow_sensor2
                              min_tow_sensor2 = tmp_min_tow_sensor
                              max_tow_sensor2 = tmp_max_tow_sensor
                              
                           if ( ((max_tow_sensor1 - min_tow_sensor2)/(max_tow_sensor1-min_tow_sensor1) > 0.2) ):
                              
                              # print(' *********** TOW time columns not same and have 20 percent overlap, need to interpolate')
                              # print(' *********** min_tow_sensor1: ' + str(min_tow_sensor1) + ', max_tow_sensor1 = ' + str(max_tow_sensor1) )
                              # print(' *********** min_tow_sensor2: ' + str(min_tow_sensor2) + ', max_tow_sensor2 = ' + str(max_tow_sensor2) )
                              # if ( (max_tow_sensor1 - min_tow_sensor2)/(max_tow_sensor1-min_tow_sensor1) > 0.1 ):
                                 # print(' ********** sensor1 behind sensor2, (max_tow_sensor1 - min_tow_sensor2) = ' + str(max_tow_sensor1 - min_tow_sensor2) + ', total diff: ' + str(max_tow_sensor1-min_tow_sensor1) + ', percent: ' + str((max_tow_sensor1 - min_tow_sensor2)/(max_tow_sensor1-min_tow_sensor1)))
                              # else:
                                 # print(' ********** sensor2 behind sensor1, (max_tow_sensor2 - min_tow_sensor1) = ' + str(max_tow_sensor2 - min_tow_sensor1) + ', total diff: ' + str(max_tow_sensor2-min_tow_sensor2) + ', percent: ' + str((max_tow_sensor2 - min_tow_sensor1)/(max_tow_sensor2-min_tow_sensor2)))
                                 
                              csv_data_prev_interp = np.interp(np.array(csv_data_dict[c_tow_col[s]]), np.array(csv_data_tow_prev), np.array(csv_data_prev))

                              # print(' ************* len(csv_data_dict[c_tow_col[s]]) = ' + str(len(csv_data_dict[c_tow_col[s]])) + ', len(csv_data_dict[c]) = ' + str(len(csv_data_dict[c])) + ', len(csv_data_prev) = ' + str(len(csv_data_prev)) + ', len(csv_data_prev_interp) = ' + str(len(csv_data_prev_interp)))

                              p1.plot(np.array(csv_data_dict[c_tow_col[s]]), np.array(csv_data_dict[c])-np.array(csv_data_prev_interp), pen='b')
                           else:
                              QtGui.QMessageBox.about(self, "Msg Box", 'TOW columns must have at least 20 percent overlap for diff plot')
                              return
                        # } if (len(csv_data_dict[c_tow_col[s]])..
                     # } if (cnt_sensor == 2)..
                  else:
                     p1.plot(csv_data_dict[c_tow_col[s]], csv_data_dict[c], pen='b')
                  # } if (isDiff == True)..
               else:
                  print(' *********** s NOT in c_tow_col, s = ' + s)
                  if (isDiff == True):
                     if (cnt_sensor == 2):
                        if ((len(unix_timestamp_dict[c]) == len(unix_timestamp_dict_prev[col_name_prev])) and \
                           max( abs(np.array(unix_timestamp_dict[c]) - np.array(unix_timestamp_dict_prev[col_name_prev])) ) < 1e-6 ):
                           print(' *** Unix timestamp columns identical, no need to interpolate')
                           
                           p1.plot(unix_timestamp_dict[c], np.array(csv_data_dict[c])-np.array(csv_data_prev), pen='b')
                        # else: # interpolate
                        else:
                           tmp_min_unix_timestamp_sensor = 0
                           tmp_max_unix_timestamp_sensor = 0

                           min_unix_timestamp_sensor2 = min( np.array(unix_timestamp_dict[c]) )
                           max_unix_timestamp_sensor2 = max( np.array(unix_timestamp_dict[c]) )
                           min_unix_timestamp_sensor1 = min( np.array(unix_timestamp_dict_prev[col_name_prev]) )
                           max_unix_timestamp_sensor1 = max( np.array(unix_timestamp_dict_prev[col_name_prev]) )

                           # Arrange the sensors such that sensor 1 start time is before sensor 2 start time
                           if (min_unix_timestamp_sensor1 > min_unix_timestamp_sensor2):
                              tmp_min_unix_timestamp_sensor = min_unix_timestamp_sensor1
                              tmp_max_unix_timestamp_sensor = max_unix_timestamp_sensor1
                              min_unix_timestamp_sensor1 = min_unix_timestamp_sensor2
                              max_unix_timestamp_sensor1 = max_unix_timestamp_sensor2
                              min_unix_timestamp_sensor2 = tmp_min_unix_timestamp_sensor
                              max_unix_timestamp_sensor2 = tmp_max_unix_timestamp_sensor

                           if ( ((max_unix_timestamp_sensor1 - min_unix_timestamp_sensor2)/(max_unix_timestamp_sensor1-min_unix_timestamp_sensor1) > 0.2) ):
                              
                              print(' *********** Unix time columns not same and have 20 percent overlap, need to interpolate')

                              # print(' *********** length of time column not same, need to interpolate')

                              csv_data_prev_interp = np.interp(np.array(unix_timestamp_dict[c]), np.array(unix_timestamp_dict_prev[col_name_prev]), np.array(csv_data_prev))

                              # print(' ************* len(unix_timestamp_dict[c]) = ' + str(len(unix_timestamp_dict[c])) + ', len(csv_data_dict[c]) = ' + str(len(csv_data_dict[c])) + ', len(csv_data_prev) = ' + str(len(csv_data_prev)) + ', len(csv_data_prev_interp) = ' + str(len(csv_data_prev_interp)))

                              p1.plot(np.array(unix_timestamp_dict[c]), np.array(csv_data_dict[c])-np.array(csv_data_prev_interp), pen='b')
                           else:
                              QtGui.QMessageBox.about(self, "Msg Box", 'Unix timestamp columns must have at least 20 percent overlap for diff plot')
                              return
                        # } if (len(csv_data_dict[c_tow_col[s]])..
                     # } if (cnt_sensor == 2)..
                  else:
                     p1.plot(unix_timestamp_dict[c], csv_data_dict[c], pen='b')
                  # } if (isDiff == True)..
               # } if (s in c_tow_col)..

               p1.enableAutoRange('xy', False)
               # p1.setXRange(0, data_rate/2.0, padding=0)

               p1.showGrid(x=True, y=True)

               xlabel = ''

               if (s in c_tow_col):
                  xlabel = 'TOW'
               else:
                  xlabel = 'Unix Time (Nanosec)'

               ylabel = ''

               if (isDiff == True):
                  ylabel = 'Diff in: ' + c
               else:
                  ylabel = c

               p1.setLabel('bottom', xlabel)
               p1.setLabel('left', ylabel)

               title = ''

               if (isDiff):
                  title += str(s_prev) + ' vs ' + str(s) + ': '
               else:
                  title = s + ': '

               title += ylabel

               if (isDiff == False):
                  title += ' vs ' + xlabel

               p1.setTitle(title)

               if (self.csv_mode == True):
                  tabLabel = "CSV Plot"
               else:
                  tabLabel = "Channel Plot"

               closeButton = QtGui.QPushButton()
               closeButton.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon.png")))
               closeButton.clicked.connect(lambda:self.parent_obj.whichbtn(closeButton))
               closeButton.setFixedWidth(15)
               closeButton.setFixedHeight(15)

               self.parent_obj.plot_tab_cnt += 1

               tabIndex = self.parent_obj.plot_tab_cnt
               if (self.parent_obj.sensor_cloud_enabled == True):
                  tabIndex += 1

               self.parent_obj.tabs.addTab(graphicsWidget, tabLabel)

               self.parent_obj.plot_tab_dict[closeButton] = self.parent_obj.plot_tab_cnt
               self.parent_obj.plot_tab_push_button_dict[closeButton] = self.parent_obj.tabs.indexOf(graphicsWidget)

               print(' ********* SensorListWidget: self.parent_obj.plot_tab_cnt = ' + str(self.parent_obj.plot_tab_cnt) + ', self.parent_obj.tabs.indexOf(graphicsWidget) = ' + str(self.parent_obj.tabs.indexOf(graphicsWidget)) + ' closeButton = ' + str(closeButton))

               self.parent_obj.tabs.tabBar().setTabButton(self.parent_obj.tabs.indexOf(graphicsWidget), QtGui.QTabBar.RightSide, closeButton)

               self.parent_obj.tabs.setCurrentIndex(self.parent_obj.tabs.indexOf(graphicsWidget))

               # if (s not in self.plotted_channels_dict):
                  # self.plotted_channels_dict[s] = []
               # } if (str(c) not in plotted_channels_dict[s])..

               # self.plotted_channels_dict[s].append(str(c))
            # } if (isDiff == False or..
         # } for c in selected_column_names_dict[s]..

         if (s not in self.csv_data_dict_of_dicts):
            self.csv_data_dict_of_dicts[s] = csv_data_dict
            if (self.csv_mode == False):
               self.unix_timestamp_dict_of_dicts[s] = unix_timestamp_dict

         if (isDiff == True and cnt_sensor == 1):
            s_prev = s
            csv_data_prev = csv_data_dict[col_name_prev]
            # print(' ******** csv_data_prev[0] = ' + str(csv_data_prev[0]) + ' csv_data_prev[1] = ' + str(csv_data_prev[1]) + ' csv_data_prev[2] = ' + str(csv_data_prev[2]))

            if (s in c_tow_col):
               if (c_tow_col[s] in csv_data_dict):
                  print(' ******** c_tow_col[s] = ' + c_tow_col[s] + ' in csv_data_dict, will set csv_data_tow_prev')
                  csv_data_tow_prev = csv_data_dict[c_tow_col[s]]
               if (c_week_col[s] in csv_data_dict):
                  csv_data_week_prev = csv_data_dict[c_week_col[s]]
               # } if (c_tow_col[s] in csv_data_dict)..
            elif (self.csv_mode == False):
               unix_timestamp_dict_prev = unix_timestamp_dict
            # } if (c_tow_col[s] in csv_data_dict)..
         # } if (isDiff == True)..
      # } for s in selected_column_names_dict.keys()..

      # Clear selected sensor(s)/channel(s) (make ready for next set of selections by user):
      self.sensor_list_tree.createCheckboxesForTree()

   def submitDeleteAllSensors(self):
      self.from_delete_selected = False

      root = self.sensor_list_tree.invisibleRootItem()
      self.child_count = root.childCount()

      if (self.child_count ==0):
         QtGui.QMessageBox.about(self, "Msg Box", 'No sensors to delete')
      else:
         command_line = 'python sensor_cloud_utils.pyc -d "' + self.parent_obj.device_id
         command_line += '" -sv "' + self.parent_obj.server
         command_line += '" -t "' + self.parent_obj.token
         command_line += '" -a das'

         self.outputFile.write('\n ******** Starting Sensor Cloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
         self.outputFile.write(' ******* Deleted ALL Sensors: Command = ' + command_line + '\n')
         print(' ********* DELETE ALL: command_line = ' + command_line)

         self.process.start(command_line)

      return

   def __layout(self):
      self.v1box = QtGui.QVBoxLayout()
      # self.v1box.addWidget(self.sensor_list_table)
      self.v1box.addWidget(self.sensor_list_tree)

      self.h2box = QtGui.QHBoxLayout()
      self.h2box.addWidget(self.lbl_space_small)
      self.h2box.addWidget(self.plot_diff_selected_cols_button)
      self.h2box.addWidget(self.lbl_space_small)

      if (self.csv_mode == True):
         self.h2box.addWidget(self.lbl_space_large)

      self.h2box.addWidget(self.plot_selected_cols_button)
      self.h2box.addWidget(self.lbl_space_small)

      if (self.csv_mode == True):
         self.h2box.addWidget(self.lbl_space_large)

      self.v2box = QtGui.QVBoxLayout()
      self.v2box.addLayout(self.h2box)

      if (self.csv_mode == False):
         self.h3box = QtGui.QHBoxLayout()
         self.h3box.addWidget(self.lbl_space_small)
         self.h3box.addWidget(self.delete_selected_sensors_button)
         self.h3box.addWidget(self.lbl_space_small)
         self.h3box.addWidget(self.delete_all_sensors_button)
         self.h3box.addWidget(self.lbl_space_small)

         self.v3box = QtGui.QVBoxLayout()
         self.v3box.addLayout(self.h3box)

         self.h4box = QtGui.QHBoxLayout()
         self.h4box.addWidget(self.lbl_status)
         self.h4box.addWidget(self.clear_status_text_button)

         self.v4box = QtGui.QVBoxLayout()
         self.v4box.addLayout(self.h4box)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.v1box)
      self.vbox.addLayout(self.v2box)

      if (self.csv_mode == False):
         self.vbox.addLayout(self.v3box)
         self.vbox.addLayout(self.v4box)

      # self.vbox.setSizeConstraint(QtGui.QLayout.SetFixedSize);

      self.setLayout(self.vbox)

