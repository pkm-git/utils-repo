import serial                    # import pySerial module
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder
from mip_parser import *         #local file should be in local folder

from time import sleep           #sleep
from time import time  #import time library

ComPort = serial.Serial('COM18')  # open the COM Port

# ComPort.baudrate = 460800        # set Baud rate
ComPort.baudrate = 115200        # set Baud rate
# ComPort.baudrate = 230400        # set Baud rate
# ComPort.baudrate = 9600            # set Baud rate

ComPort.bytesize = 8             # Number of data bits = 8
ComPort.parity   = 'N'           # No parity
ComPort.stopbits = 1             # Number of Stop bits = 1

#Close port in case it was left open by other process
ComPort.close()

start_time = time()
print(' ************* GSG Save Binary Dump: start_time = ' + str(start_time) );

# Open specified port
ComPort.open()

bytes_read = bytearray([])

fout = open("UBX_Port_Dump.txt", "w")
fout_bin = open("UBX_Port_Dump.bin", "wb")

print(' ******************* WILL START MAIN LOOP *************** ')

cnt = 0

# Now do the main loop
while(True):
# while(cnt < 25):
   bytes_read = ComPort.read()
   # print('******* READ OVER ')

   data_left = ComPort.inWaiting()        # Get the number of characters ready to be read
   # print('******* DATA LEFT OVER ')

   bytes_read += ComPort.read(data_left)  # Do the read and combine it with the first character

   # print('******* bytes_read OVER ')

   if (len(bytes_read) > 0):
     fout.write(hexlify(bytearray(bytes_read)).upper())
     fout_bin.write(bytearray(bytes_read))
     # print('cnt = ' + str(cnt) + ', bytes: ' + hexlify(bytearray(bytes_read)).upper())

   cnt = cnt + 1
   # if (cnt > 25):
      # break

end_time = time()

print(' ************* GSG Save Binary Dump: end_time = ' + str(end_time) );
# print(' *************** LENGTH OF BYTES READ = ' + str(len(bytes_read)));

ComPort.close()                  # Close the COM Port
fout.close()
fout_bin.close()
