# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os, sys
import ConfigParser
from datetime import datetime
from PyQt4 import QtCore, QtGui
# from PyQt4.QtGui import *
# from PyQt4.QtCore import *

from QInertialSensorUtils_GUI_CommonWidgets import *

from time import sleep         #sleep

from csv_to_sensor_cloud import *
from csv_to_kml import *

MAX_NBR_OF_ROWS = 5
PYTHON_DIR = 'python_2_7_6/'

class batch_process_row_struct:
   def __init__(self):
      self.row_nbr = 0
      self.file_type = ''
      self.protocol = ''
      self.desired_desc = ''
      self.sensor_name = ''
      self.file_name = ''
      self.status = ''

class MyBatchProcessFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyBatchProcessFormWidget, self).__init__(parent)

      print(' ***************** IN MyBatchProcessFormWidget INIT ***************** ')

      self.parent_obj = parent
      self.processError = False
      self.batchCommandError = False
      self.cmbox_editable_sensor_list_array = []
      self.nbrOfSubmitCalls = 0
      self.valid_batch_process_row_index_array = []
      self.batch_process_index_to_use = 0
      self.submit_timestamp = ''
      self.submit_timestamp_no_spaces_spl_chr = ''
      self.batch_status_dict = {}
      
      self.setFixedSize(600,275)

      self.loadSensorList()

      self.valid_batch_process_input_count = 0
      self.batch_process_in_progress_count = 0

      self.__controls()
      self.__layout()

   def closeEvent(self, event):
      print "Closing MyBatchProcessFormWidget window"

      self.logFile.close()
      self.batchReportFile.close()

      super(MyBatchProcessFormWidget, self).closeEvent(event)

   def __controls(self):
      
      self.declare_spaces()
      
      self.lbl_title = QtGui.QLabel("Batch Process for SensorCloud Upload")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");
      self.lbl_title.setFixedWidth(300)
      self.lbl_title.setFixedHeight(25)

      # self.lbl_filename = QtGui.QLabel("Upload Filename")
      self.lbl_filename = QtGui.QLabel("Filename")
      self.lbl_filename.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319;");
      self.lbl_filename.setFixedWidth(160)

      self.edt_filename_array = []
      for i in range(MAX_NBR_OF_ROWS):
         edt_filename = MyLineEdit()
         edt_filename.setStyleSheet("background-color: white;");
         edt_filename.setFixedWidth(150)
         edt_filename.setFixedHeight(20)
         self.edt_filename_array.append(edt_filename)
      # } for i in range(MAX_NBR_OF_ROWS)..
      
      self.lbl_sensor_name = QtGui.QLabel("Sensor Name")
      self.lbl_sensor_name.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319;");
      self.lbl_sensor_name.setFixedWidth(110)
      
      self.lbl_descriptor_filter_or_csv_object = QtGui.QLabel("Descriptor Filter")
      self.lbl_descriptor_filter_or_csv_object.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319;");

      # self.lbl_descriptor_filter_or_csv_object_help = QtGui.QLabel("[Optional: Ex: 8012800C810981038105]")
      # self.lbl_descriptor_filter_or_csv_object_help.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319");

      self.edt_descriptor_filter_or_csv_object_array = []
      for i in range(MAX_NBR_OF_ROWS):
         edt_descriptor_filter_or_csv_object = MyLineEdit()
         edt_descriptor_filter_or_csv_object.setStyleSheet("background-color: white;");
         edt_descriptor_filter_or_csv_object.setFixedWidth(85)
         edt_descriptor_filter_or_csv_object.setFixedHeight(20)
         edt_descriptor_filter_or_csv_object.setText('')
         self.edt_descriptor_filter_or_csv_object_array.append(edt_descriptor_filter_or_csv_object)
      # } for i in range(MAX_NBR_OF_ROWS)..
      
      self.lbl_file_type = QtGui.QLabel("File Type")
      self.lbl_file_type.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319;");
      self.lbl_file_type.setFixedWidth(70)

      self.cmbox_file_type_array = []
      for i in range(MAX_NBR_OF_ROWS):
         cmbox_file_type = MyComboBox('File')
         cmbox_file_type.setFixedWidth(70)
         cmbox_file_type.setFixedHeight(20)
         cmbox_file_type.setStyleSheet("background-color: white;");
         cmbox_file_type.currentIndexChanged.connect(self.handleChangeFileType)
         # print(' ******** i = ' + str(i) + ', cmbox_file_type = ' + str(cmbox_file_type))

         self.cmbox_file_type_array.append(cmbox_file_type)
      # } for i in range(MAX_NBR_OF_ROWS)..

      # self.lbl_device_type_used = QtGui.QLabel("Device Type")
      self.lbl_device_type_used = QtGui.QLabel("Protocol")
      self.lbl_device_type_used.setStyleSheet("font-weight: bold; font-size: 12px; color: #003319;");
      self.lbl_device_type_used.setFixedWidth(80)

      self.cmbox_device_type_used_array = []
      for i in range(MAX_NBR_OF_ROWS):
         cmbox_device_type_used = MyComboBox('Device')
         cmbox_device_type_used.setFixedWidth(70)
         cmbox_device_type_used.setFixedHeight(20)
         cmbox_device_type_used.setStyleSheet("background-color: white;");
         cmbox_device_type_used.currentIndexChanged.connect(self.handleProtocolChange)
         # print(' ******** i = ' + str(i) + ', cmbox_device_type_used = ' + str(cmbox_device_type_used))
         self.cmbox_device_type_used_array.append(cmbox_device_type_used)
      # } for i in range(MAX_NBR_OF_ROWS)..

      self.browse_button_array = []

      for i in range(MAX_NBR_OF_ROWS):
         browse_button = MyPushButton("Browse")
         browse_button.setCheckable(True)
         browse_button.toggle()
         browse_button.clicked.connect(self.selectFile)
         browse_button.setFixedWidth(60)
         browse_button.setFixedHeight(18)

         self.browse_button_array.append(browse_button)
      # } for i in range(MAX_NBR_OF_ROWS)..

      self.submit_button = MyPushButton("Submit")
      self.submit_button.setCheckable(True)
      self.submit_button.toggle()
      self.submit_button.clicked.connect(lambda: self.validate(True))
      self.submit_button.setFixedWidth(100)

      self.lbl_status = QtGui.QLabel("Status: ")
      self.lbl_status.setStyleSheet("font-weight: bold; font-size: 12px; color: #000033; background-color: #F2CFC0; border: 1px solid #330019; padding: 4px;");
      # self.lbl_status.setFixedWidth(450)
      self.lbl_status.setFixedWidth(500)
      self.lbl_status.setFixedHeight(25)

      self.clear_status_text_button = MyPushButton("Clear Status Text")
      self.clear_status_text_button.setCheckable(True)
      self.clear_status_text_button.toggle()
      self.clear_status_text_button.clicked.connect(self.clearStatusText)
      self.clear_status_text_button.setFixedWidth(120)

      # Open log file in append mode
      self.logFile = open('InertialSensorUtils_BatchProcess.log','a')
      # self.batchReportFile = open('BatchProcess_Report.log','w')

      # QProcess object for external app
      self.process = QtCore.QProcess(self)

      # QProcess emits 'readyRead' signal when there is data to be read
      # self.process.readyRead.connect(self.dataReady)

      self.process.readyReadStandardOutput.connect(self.readyReadStandardOutput)
      self.process.readyReadStandardError.connect(self.readyReadStandardError)

      # Just to prevent accidentally running multiple times
      # Disable the button when process starts, and enable it when it finishes
      self.process.started.connect(self.showStarted)
      self.process.finished.connect(self.showDone)

      self.timer = QtCore.QBasicTimer()
      self.step = 0

   def dataReady(self):
      self.process.setReadChannel(QtCore.QProcess.StandardOutput);

      self.logFile.write('\n')
      while (self.process.canReadLine()):
         current_line = str(self.process.readLine())
         self.logFile.write(current_line)
      # } while (self.process.canReadLine())..

      self.logFile.flush()

   def readyReadStandardOutput(self):
      stdOutputStr = str(self.process.readAllStandardOutput())

      self.logFile.write('\n' + stdOutputStr)
      self.logFile.flush()

   def readyReadStandardError(self):
      self.processError = True
      if (not self.batchCommandError):
         self.batchCommandError = True

      self.logFile.write('\n')
      errorLog = str(self.process.readAllStandardError())
      self.logFile.write(errorLog)
      self.logFile.flush()

   def timerEvent(self, e):
      if (self.lbl_status.text().startsWith("Status: DONE")):
         if (self.batch_process_in_progress_count == self.valid_batch_process_input_count):
            self.timer.stop()
         # else:
            # self.nbrOfSubmitCalls += 1
            # self.batch_process_in_progress_count += 1
            # self.validate(False)
         # } if (self.batch_process_in_progress_count ==..

         return
      # } if (self.lbl_status.text().startsWith("Status: DONE")..

      self.step = self.step + 1

      # self.lbl_status.setText("Status: Doing.. Time elapsed: " + str(self.step) + " seconds")
      self.lbl_status.setText('Status: Doing Batch Process: [' + str(self.batch_process_in_progress_count) + ' of ' + str(self.valid_batch_process_input_count) + '].. Time elapsed: ' + str(self.step) + ' seconds')

   def doAction(self):
      # if self.timer.isActive():
         # self.timer.stop()
      # else:
      self.step = 0
      self.timer.start(1000, self)
      # } if self.timer.isActive()..

   def showStarted(self):
      strStatusLabel = 'Status: Doing batch process: [' + str(self.batch_process_in_progress_count) + ' of ' + str(self.valid_batch_process_input_count) + ']'
      self.lbl_status.setText(strStatusLabel)
      self.logFile.write('\n' + strStatusLabel)
      
      self.doAction()

   def showDone(self):
      if (self.batch_process_in_progress_count == self.valid_batch_process_input_count):
         if (not self.processError):
            # Set the loaded_sensor_list flag on parent object to False,
            # so that when user clicks on View Sensors tab in future,
            # it would load the sensors from cloud
            self.parent_obj.loaded_sensor_list = False
            self.parent_obj.loaded_batch_sensor_list = False
         # } if (not self.processError)..
         
         self.parent_obj.sensor_list_needs_update = True
         
         if (self.processError):
            batchProcessLogMsg = 'DONE (w/ERRORS): Pl. check ' + 'BatchProcessReport_' + self.submit_timestamp_no_spaces_spl_chr + '.csv'
         else:
            batchProcessLogMsg = 'DONE: Pl. check ' + 'BatchProcessReport_' + self.submit_timestamp_no_spaces_spl_chr + '.csv'
         # } if (self.processError)..
         
         self.lbl_status.setText('Status: ' + batchProcessLogMsg)
      # } if (self.batch_process_in_progress_count ==..
         
      if (self.processError):
         # logMsg = 'ERROR.. Batch Process Nbr: ' + str(self.batch_process_in_progress_count) + ', please check batch processing log file for details.'
         logMsg = 'ERROR..please check batch processing log file for details.'
      else:
         # Look in config file to see if there were an errors logged for timestamp of last comamnd sent to QProcess
         errorMsg = None

         user_config = "inertial_sensor_errors_" + self.submit_timestamp_no_spaces_spl_chr + ".cfg"
         config = ConfigParser.ConfigParser()
         
         print(' *********** will look for cfg file called ' + user_config)
         
         if (os.path.exists(user_config)):
            config.read(user_config)

            if config.has_section("errors"):
               if config.has_option("errors", "message"):
                  errorMsg = config.get("errors", "message")
                  print(' ****** found errorMsg = ' + errorMsg)
               # } if config.has_option("errors"..
            # } if config.has_section("errors")..
            
            # print(' ********** will remove temp config file ****** ')
            
            # Remove the temporary cfg file for that timestamp
            os.remove(user_config)
         # } if os.path.exists(user_config)..

         if (errorMsg != None):
            logMsg = 'ERROR: ' + errorMsg
         else:
            logMsg = 'DONE Batch Process: [' + str(self.batch_process_in_progress_count) + ' of ' + str(self.valid_batch_process_input_count) + '].. Time taken: ' + str(self.step) + ' seconds'
         # } if (errorMsg != None)..
      # } if (self.processError)..
      
      if (self.batch_process_in_progress_count < self.valid_batch_process_input_count):
         self.lbl_status.setText('Status: ' + logMsg)
         self.logFile.write('\nStatus: ' + logMsg)
      # } if (self.batch_process_in_progress_count <..
      
      if (self.batch_process_in_progress_count == self.valid_batch_process_input_count):
         self.logFile.write('\nOverall Status: ' + batchProcessLogMsg)
      # } if (self.batch_process_in_progress_count ==..
      
      # Reset processError flag for next call
      self.processError = False
      self.timer.stop()

      self.step = 0
      self.logFile.flush()

      row_nbr = self.batch_process_index_to_use + 1
      file_type = self.cmbox_file_type_array[self.batch_process_index_to_use].currentText()
      protocol = self.cmbox_device_type_used_array[self.batch_process_index_to_use].currentText()
      desired_desc = self.edt_descriptor_filter_or_csv_object_array[self.batch_process_index_to_use].text()
      sensor_name = self.cmbox_editable_sensor_list_array[self.batch_process_index_to_use].currentText()
      file_name = self.edt_filename_array[self.batch_process_index_to_use].text()
      
      batch_row = batch_process_row_struct()
      batch_row.row_nbr = row_nbr
      batch_row.file_type = file_type
      batch_row.protocol = protocol
      batch_row.desired_desc = desired_desc
      batch_row.sensor_name = sensor_name
      # batch_row.file_name = file_name
      (filepath_only, filename_only) = os.path.split(str(file_name))
      batch_row.file_name = filename_only
      batch_row.status = logMsg
      
      self.batch_status_dict[self.batch_process_index_to_use + 1] = batch_row

      print(' ********** self.batch_process_in_progress_count  = ' + str(self.batch_process_in_progress_count) + ', self.valid_batch_process_input_count = ' + str(self.valid_batch_process_input_count))
      
      # Send the command for remaining files selected for batch process
      if (self.batch_process_in_progress_count < self.valid_batch_process_input_count):
         self.nbrOfSubmitCalls += 1
         self.batch_process_in_progress_count += 1
         print(' ******* will call validate function for next row of batch')
         self.validate(False)
      else:
         for k, v in sorted(self.batch_status_dict.items()):
            self.batchReportFile.write('{:-2d},{:s},{:s},{:s},{:s},{:s},{:s}\n'.format(v.row_nbr, v.file_type, v.protocol, v.file_name, v.desired_desc, v.sensor_name, v.status))
         # } for k, v in sorted(self.batch_status_dict.items())..
         
         self.batchReportFile.flush()
         self.batchReportFile.close()
         
         # Refresh list of sensors:
         self.loadSensorList()

         # Notify other tabs of change in sensor list
         self.parent_obj.sensor_list_needs_update = True

         # Refresh list of sensors on View Sensors tab as well:
         if (self.parent_obj.sensor_list_widget != None):
            self.parent_obj.sensor_list_widget.sensor_list_tree.initUI()
         
         # Refresh list of sensors on Main (Log File Processing) tab as well:
         # Uncheck the Upload to CSV Check-box on Main page (Log File Processing)
         # so that when user checks it again, the sensor list would be updated
         # self.parent_obj.form_widget.chkbx_upload_to_sensor_cloud.setCheckState(0, QtCore.Qt.Unchecked)
         # self.parent_obj.form_widget.chkbx_upload_to_sensor_cloud.setChecked(False)
         self.parent_obj.updateSensorList()
         
      # } if (self.batch_process_in_progress_count <..
      
   def clearStatusText(self):
      self.lbl_status.setText("Status:")

   def loadSensorList(self):
      print(' ********* in BatchProcesss: loadSensorList() ******** ')
      self.parent_obj.updateSensorList()

      for i in range(MAX_NBR_OF_ROWS):
         cmbox_editable_sensor_list = QtGui.QComboBox()
         cmbox_editable_sensor_list.setFixedWidth(120)
         cmbox_editable_sensor_list.setFixedHeight(20)
         cmbox_editable_sensor_list.setStyleSheet("background-color: white;");
         cmbox_editable_sensor_list.setEditable(True)
         cmbox_editable_sensor_list.lineEdit().setMaxLength(120)

         cmbox_editable_sensor_list.addItems(self.parent_obj.sensorList)

         self.cmbox_editable_sensor_list_array.append(cmbox_editable_sensor_list)
      # } for i in range(MAX_NBR_OF_ROWS)..

   def handleChangeFileType(self, state):
      file_type_cmbbox = self.sender()
      # print(' ************** file type combo-box sender: ' + str(file_type_cmbbox))
      
      indx = 0
      if (file_type_cmbbox in self.cmbox_file_type_array):
         indx = self.cmbox_file_type_array.index(file_type_cmbbox)
         # print(' ************* found the file type cmbbox at index: ' + str(indx))
         self.edt_descriptor_filter_or_csv_object_array[indx].setText('')
         
         if (file_type_cmbbox.currentText() == 'Binary' and self.cmbox_device_type_used_array[indx].currentText() == 'MIP'):
            self.edt_descriptor_filter_or_csv_object_array[indx].setReadOnly(False)
            self.edt_descriptor_filter_or_csv_object_array[indx].setStyleSheet("background-color: white;")
         else:
            self.edt_descriptor_filter_or_csv_object_array[indx].setReadOnly(True)
            self.edt_descriptor_filter_or_csv_object_array[indx].setStyleSheet("background-color: #E0E0E0;");
         # } if (file_type_cmbbox.currentText() == 'Binary'..
      # } if (file_type_cmbbox in self.cmbox_file_type_array)..

   def handleProtocolChange(self, state):
      device_type_cmbbox = self.sender()
      # print(' ************** device type combo-box sender: ' + str(device_type_cmbbox))
      
      indx = 0
      if (device_type_cmbbox in self.cmbox_device_type_used_array):
         indx = self.cmbox_device_type_used_array.index(device_type_cmbbox)
         # print(' ************* found the device type cmbbox at index: ' + str(indx))
      # } if (device_type_cmbbox in..

      if (state == 0 and self.cmbox_file_type_array[indx].currentText() == 'Binary'):  # MIP
         self.edt_descriptor_filter_or_csv_object_array[indx].setReadOnly(False)
         self.edt_descriptor_filter_or_csv_object_array[indx].setStyleSheet("background-color: white;");
      elif (state == 1): # Novatel
         self.edt_descriptor_filter_or_csv_object_array[indx].setReadOnly(True)
         self.edt_descriptor_filter_or_csv_object_array[indx].setStyleSheet("background-color: #E0E0E0;");
      # } if (state == 0)..

   def __layout(self):

      self.hTitlebox = QtGui.QHBoxLayout()
      self.hTitlebox.addWidget(self.lbl_space_large)
      self.hTitlebox.addWidget(self.lbl_title)
      self.hTitlebox.addWidget(self.lbl_space_large)
      self.hTitlebox.addWidget(self.lbl_space_small)

      self.hColumnHeaderBox = QtGui.QHBoxLayout()
      # self.hColumnHeaderBox.addWidget(self.lbl_space_xsmall)
      self.hColumnHeaderBox.addWidget(self.lbl_file_type)
      self.hColumnHeaderBox.addWidget(self.lbl_device_type_used)
      self.hColumnHeaderBox.addWidget(self.lbl_filename)
      # self.hColumnHeaderBox.addWidget(self.lbl_space_med_large)
      self.hColumnHeaderBox.addWidget(self.lbl_space_medium)
      self.hColumnHeaderBox.addWidget(self.lbl_descriptor_filter_or_csv_object)
      self.hColumnHeaderBox.addWidget(self.lbl_sensor_name)

      self.vTableBox = QtGui.QVBoxLayout()

      for i in range(MAX_NBR_OF_ROWS):
         hbox = QtGui.QHBoxLayout()
         hbox.addWidget(self.cmbox_file_type_array[i])
         hbox.addWidget(self.cmbox_device_type_used_array[i])
         hbox.addWidget(self.edt_filename_array[i])
         hbox.addWidget(self.browse_button_array[i])
         hbox.addWidget(self.edt_descriptor_filter_or_csv_object_array[i])
         hbox.addWidget(self.cmbox_editable_sensor_list_array[i])
         self.vTableBox.addLayout(hbox)
      # } for i in range(MAX_NBR_OF_ROWS)..
      
      self.hClearSubmitBox = QtGui.QHBoxLayout()
      self.hClearSubmitBox.addWidget(self.lbl_space_medium_taller)
      self.hClearSubmitBox.addWidget(self.clear_status_text_button)
      self.hClearSubmitBox.addWidget(self.submit_button)
      self.hClearSubmitBox.addWidget(self.lbl_space_small)

      self.hStatusBox = QtGui.QHBoxLayout()
      self.hStatusBox.addWidget(self.lbl_space_small)
      self.hStatusBox.addWidget(self.lbl_status)
      self.hStatusBox.addWidget(self.lbl_space_small)

      self.vbox = QtGui.QVBoxLayout()
      self.vbox.addLayout(self.hTitlebox)
      self.vbox.addLayout(self.hColumnHeaderBox)
      self.vbox.addLayout(self.vTableBox)
      self.vbox.addLayout(self.hClearSubmitBox)
      self.vbox.addLayout(self.hStatusBox)

      self.setLayout(self.vbox)

   def selectFile(self):
      theInputDir = ""

      user_config = os.getcwd() + "/inertial_sensor.cfg"

      config = ConfigParser.ConfigParser()
      config.read(user_config)

      if config.has_section("dirs"):
         # if an entry exists then add the value to the form
         if config.has_option("dirs", "inputdir"):
            theInputDir = config.get("dirs", "inputdir")

      filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', theInputDir, '*.*')

      if filename:
         sdr = self.sender()
         print(' ************** browse button sender: ' + str(sdr))

         if (sdr in self.browse_button_array):
            indx = self.browse_button_array.index(sdr)
            print(' ************* found the browse button at index: ' + str(indx))
      
            self.edt_filename_array[indx].setText(filename)

            (inputDirName, fin_filename) = os.path.split(str(filename))

            if not config.has_section("dirs"):
               config.add_section("dirs")

            config.set("dirs", "inputdir", inputDirName)

            # if not os.getcwd().exists(configFile):
            with open("inertial_sensor.cfg", 'w') as f:
               config.write(f)
            # } with open("inertial_sensor.cfg"..
      # } if filename..
      
   def validate(self, firstCall):
      print(' ************** in validate: firstCall = ' + str(firstCall))

      if (firstCall):
         self.nbrOfSubmitCalls = 1
         self.batch_process_index_to_use  = 0
         self.batch_process_in_progress_count = 1
         self.valid_batch_process_row_index_array = []
         self.batchCommandError = False
         self.batch_status_dict = {}
         
         self.logFile.write('\n\n--------------------------------------------------------------------------\n')
         self.logFile.write(' ******** firstCall is TRUE: Starting Batch File Upload to SensorCloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')

         for i in range(MAX_NBR_OF_ROWS):
            error_msg = ''

            if (self.edt_filename_array[i].text() == '' and self.cmbox_editable_sensor_list_array[i].currentText() != ''):
               error_msg = 'ERROR: File name cannot be empty'
            elif (self.edt_filename_array[i].text() != '' and self.cmbox_editable_sensor_list_array[i].currentText() == ''):
               error_msg = 'ERROR: Sensor name cannot be empty'
            # } if (self.edt_filename_array[i].text() == '')..

            if (error_msg != ''):
               self.logFile.write('\n ***** ERROR in Batch Row Nbr: ' + str(i+1) + '\nDetails: ' + error_msg)
               self.logFile.flush()

               batch_row = batch_process_row_struct()
               batch_row.row_nbr = i+1
               batch_row.file_type = self.cmbox_file_type_array[i].currentText()
               batch_row.protocol = self.cmbox_device_type_used_array[i].currentText()
               batch_row.desired_desc = self.edt_descriptor_filter_or_csv_object_array[i].text()
               batch_row.sensor_name = self.cmbox_editable_sensor_list_array[i].currentText()
               (filepath_only, filename_only) = os.path.split(str(self.edt_filename_array[i].text()))
               batch_row.file_name = filename_only
               batch_row.status = error_msg
               
               self.batch_status_dict[i+1] = batch_row
            elif (self.edt_filename_array[i].text() != '' and self.cmbox_editable_sensor_list_array[i].currentText() != ''):
               print(' **** i = ' + str(i) + ', self.edt_filename_array[i].text() = ' + str(self.edt_filename_array[i].text()) + ', self.cmbox_editable_sensor_list_array[i].currentText() = ' + str(self.cmbox_editable_sensor_list_array[i].currentText()))
               self.valid_batch_process_input_count += 1
               self.valid_batch_process_row_index_array.append(i)
            # } if (error_msg != '')..
         # } for i in range(MAX_NBR_OF_ROWS)..

         if (len(self.valid_batch_process_row_index_array) == 0):
            QtGui.QMessageBox.about(self, "Msg Box", "Must specify filename and sensor name for at least one row")
            return
         else:
            tmp_submit_timestamp = str(datetime.now())
            self.submit_timestamp = tmp_submit_timestamp
            tmp_submit_timestamp = tmp_submit_timestamp.strip().replace(" ", "_")
            tmp_submit_timestamp = tmp_submit_timestamp.replace(".", "_")
            tmp_submit_timestamp = tmp_submit_timestamp.replace(":", "_")
            self.submit_timestamp_no_spaces_spl_chr = tmp_submit_timestamp[:-7]
         
            print(' ************ batch command: self.submit_timestamp = ' + str(self.submit_timestamp))

            self.batchReportFile = open('BatchProcessReport_' + self.submit_timestamp_no_spaces_spl_chr + '.csv','w')

            self.batchReportFile.write('********* Batch Process Report for command issued at: ' + self.submit_timestamp[:-7] + '\n')
            self.batchReportFile.write('Batch Row #,File Type,Protocol,Filename,Desc Filter Str,Sensor Name,Status\n')

            if (error_msg != ''):
               QtGui.QMessageBox.about(self, "Msg Box", "Found errors in input:\n" + error_msg + "\n\nDoing the " + str(self.valid_batch_process_input_count) + " valid batch process jobs")
            # } if (error_msg != '')..
         # } if (len(self.valid_batch_process_row_index_array) == 0)..  
      # } if (firstCall)..

      # if (len(self.valid_batch_process_row_index_array) == 0):
         # QtGui.QMessageBox.about(self, "Msg Box", "Must specify filename and sensor name for at least one row")
         # return
      # else:
      parse_to_csv_action = ''
      command_line = ''

      print(' *********** validate: firstCall = ' + str(firstCall) + ', self.nbrOfSubmitCalls = ' + str(self.nbrOfSubmitCalls) + ', len(self.valid_batch_process_row_index_array) = ' + str(len(self.valid_batch_process_row_index_array)) + ', self.valid_batch_process_row_index_array:\n' )
      for j in self.valid_batch_process_row_index_array:
         print(' ************ self.valid_batch_process_row_index_array index = ' + str(j))

      self.batch_process_index_to_use = self.valid_batch_process_row_index_array[self.nbrOfSubmitCalls-1]

      print(' ********** self.batch_process_index_to_use = ' + str(self.batch_process_index_to_use))
      
      sensor_cloud_filename_to_use = 'sensor_cloud_utils.pyc'
      
      if (self.parent_obj.lord_internal_user):
         sensor_cloud_filename_to_use = 'sensor_cloud_utils_LordInternal.pyc'
      # } if (self.parent_obj.lord_internal_user)..
         
      if (self.cmbox_file_type_array[self.batch_process_index_to_use].currentText() == 'Binary'):
         parse_to_csv_action += 'uf'

         if (self.cmbox_device_type_used_array[self.batch_process_index_to_use].currentText() == 'MIP'):
            parse_to_csv_action += 'mb'
         else:
            parse_to_csv_action += 'nb'
         # } if (self.cmbox_device_type_used_array[..

         desired_desc = self.edt_descriptor_filter_or_csv_object_array[self.batch_process_index_to_use].text()

         command_line = PYTHON_DIR + 'python ' + sensor_cloud_filename_to_use + ' -d "' + self.parent_obj.device_id
         command_line += '" -sv "' + self.parent_obj.server
         command_line += '" -t "' + self.parent_obj.token
         command_line += '" -s "' + str(self.cmbox_editable_sensor_list_array[self.batch_process_index_to_use].currentText())
         command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename_array[self.batch_process_index_to_use].text()) + '"'
         if (desired_desc != ''):
            command_line += ' -dd "' + desired_desc + '"'
         # } if (desired_desc != '')..
         command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'
         
      elif (self.cmbox_file_type_array[self.batch_process_index_to_use].currentText() == 'CSV'):

         parse_to_csv_action += 'uf'

         if (self.cmbox_device_type_used_array[self.batch_process_index_to_use].currentText() == 'MIP'):
            parse_to_csv_action += 'mcsv'
         else:
            parse_to_csv_action += 'ncsv'
         # } if (self.cmbox_device_type_used_array[self.batch_process_index_to_use].currentText() == 'MIP')..
         
         command_line = PYTHON_DIR + 'python ' + sensor_cloud_filename_to_use + ' -d "' + self.parent_obj.device_id
         command_line += '" -sv "' + self.parent_obj.server
         command_line += '" -t "' + self.parent_obj.token
         command_line += '" -s "' + str(self.cmbox_editable_sensor_list_array[self.batch_process_index_to_use].currentText())
         command_line += '" -r 100 -rt "HERTZ" -a ' + parse_to_csv_action  + ' -i "' + str(self.edt_filename_array[self.batch_process_index_to_use].text()) + '"'
         command_line += ' -ts "' + self.submit_timestamp_no_spaces_spl_chr + '"'

      # } if (self.cmbox_file_type_array[...

      if (command_line != ''):
         self.logFile.write('\n\n--------------------------------------------------------------------------\n')
         self.logFile.write(' ******** Batch Row Nbr: ' + str(self.batch_process_index_to_use+1) + ', Starting Batch File Upload to SensorCloud command log at local date/time: ' + str(datetime.now()) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')
         # self.logFile.write(' ******** Just before sending the command, starting Batch File Upload to SensorCloud command log at local date/time: ' + str(datetime.now()) + ' ' + str(local_time.tzname) + ', UTC Date/Time: ' + str(datetime.utcnow()) + '\n')

         msg_txt = ''
         binary_input = False

         # If action string ends with 'b', it means input file is binary
         if (parse_to_csv_action[-1] == 'b'):
            msg_txt = 'BINARY INPUT: '
            binary_input = True
         else:
            msg_txt = 'CSV INPUT: '
         # } if (parse_to_csv_action[-1] == 'b')..
         
         print('\n ***** ' + msg_txt + ': ' + command_line)
         self.logFile.write('\n ***** ' + msg_txt + ', Command:\n' + command_line)
         
         # run the process
         self.process.start(command_line)
      # } if (command_line != '')..

      self.logFile.flush()
      # } if (len(self.valid_batch_process_row_index_array) == 0)..
      
      return

   def declare_spaces(self):
   
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_small_med = QtGui.QLabel()
      self.lbl_space_small_med.setFixedWidth(35)
      self.lbl_space_small_med.setFixedHeight(25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_medium_taller = QtGui.QLabel()
      self.lbl_space_medium_taller.setFixedSize(60,50)

      self.lbl_space_med_large = QtGui.QLabel()
      self.lbl_space_med_large.setFixedSize(70,25)
      self.lbl_space_med_large.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000;");

      self.lbl_space_100 = QtGui.QLabel()
      self.lbl_space_100.setFixedSize(100,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(140,25)

