# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import csv
import sys
import numpy
import re
import configparser

from time import time  #import time library

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from time import sleep         #sleep

from datetime import datetime

from sensor_cloud_api import *

NBR_OF_LEAP_SECONDS_2016 = 17 # (as of July 2016)
NBR_OF_LEAP_SECONDS = 18 # (as of Jan 2017)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800
MAX_ROWS_SENSOR_CLOUD_UPLOAD = 100000
# MAX_ROWS_SENSOR_CLOUD_UPLOAD = 100 # TEST ONLY

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

def writeErrorMsgToFile(submit_timestamp):
   errorMsg = 'CSV File must have GPS Time of Week column for upload to SensorCloud'

   config = configparser.ConfigParser()
   config.add_section("errors")

   config.set("errors", "message", errorMsg)

   user_config = "inertial_sensor_errors_" + submit_timestamp + ".cfg"

   with open(user_config, 'w') as f:
      config.write(f)
   # } with open(user_config..

def csv_to_sensor_cloud_fn(server, token, device_id, submit_timestamp, sensor_name, sensor_label, sampleRate, sampleRateType, in_file_name, gps_week_col = 2, gps_tow_col = 3):
   
   print(' *********** in csv_to_sensor_cloud: ')
   
   if (server == None or token == None or device_id == None or sensor_name == None):
      print(' ***** Must provide valid Server, Token, Device_Id, Key and Sensor Name for SensorCloud Upload')
      sys.exit()
   # } if (sensor_name == None..
   
   print(' *********** in csv_to_sensor_cloud: sensor_name = ' + sensor_name)
   
   # Spaces not allowed in Sensor Name, replace with _:
   sensor_name = sensor_name.strip().replace(" ", "_")
   sensor_name = sensor_name.replace("/", "_")

   # All characters other than (AlphaNumeric, _, -, and .): Replace with empty char:
   sensor_name = re.sub(r'[^a-zA-Z0-9_.-]', r'', sensor_name)

   in_csvfile = open(in_file_name,'rUb')
   csvreader = csv.reader(in_csvfile, delimiter=',')

   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   channel_data = {sensor_name:{}}
   n_data_columns = 0
   channel_names = []
   chStatus = 0

   leap_sec_to_use = NBR_OF_LEAP_SECONDS

   for row_item in csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers == True):
         n_data_columns =  len(row_item)
         print(' ******* len(row_item) = ' + str(len(row_item)) + ', n_data_columns = ' + str(n_data_columns))

         # Create a list of channel names from the headers
         for i in range(n_data_columns):
            # Spaces not allowed in Channel Name, replace with _:
            tmp_channel_name = row_item[i].strip().replace(" ", "_")
            tmp_channel_name = tmp_channel_name.replace("/", "_")

            # All characters other than AlphaNumeric, _, -, and .: Replace with empty char:
            tmp_channel_name = re.sub(r'[^a-zA-Z0-9_.-]', r'', tmp_channel_name)

            channel_names.append(tmp_channel_name)
         # } for i in range(n_data_columns)..
         
         # Check for presence of GPS TOW column in the csv file.  If not found, return back to caller with an error
         found_tow = False
         for c in channel_names:
            if ('tow' in c.lower()):
               found_tow = True
            # } if ('tow' in c.lower())..
         # } for c in channel_names..
         
         if (not found_tow):
            writeErrorMsgToFile(submit_timestamp)
            return
         else:
            sensStatus = 0
            if (sensor_label != None):
               sensStatus = addSensor(server, token, device_id, sensor_name, "", sensor_label)
            else:
               sensStatus = addSensor(server, token, device_id, sensor_name)
            # } if (sensor_label != None)..
            
            print(' ********** addSensor: status = ' + str(sensStatus))
            
            i = 0
            for c in channel_names:
               chStatus = addChannel(server, token, device_id, sensor_name, c)
               channel_data[sensor_name][i] = []
               i += 1
            # } for c in channel_names..

            # column headers have been found
            headers_found = True

            # headers no longer need to be determined
            determine_headers = False
         # } if (not found_tow)..
      elif(headers_found == True):
         data_row_cnt = data_row_cnt + 1

         if (len(row_item) > 0):
            # Default values of GPS Week column = 2, GPS TOW column = 3 (counting 1st column as column 1)
            # These defaults are valid for MIP-based csv files created from the 'Sensor_Cloud_utils' Python script.
            # If GPS Week and TOW columns are different from the default, send the actual column numbers to this function (counting 1st column as column 1)
            try:
               gps_week = int(row_item[gps_week_col-1])
               gps_tow = numpy.double(row_item[gps_tow_col-1])

               if (gps_week < 1930):
                  leap_sec_to_use = NBR_OF_LEAP_SECONDS_2016
               # } if (gps_week < 1930)..

               gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
               utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - leap_sec_to_use + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

               # Convert UTC sec from UTC Epoch into unix nanosecond time
               ts = utc_sec_from_utc_epoch * 1000000000

               index = 0

               # Now iterate the values for all columns
               for i in range(n_data_columns):
                  # try:
                  # Exclude empty cells from going to SensorCloud
                  if (row_item[i] != ''):
                     ch = channel_data_struct()
                     ch.ts = numpy.int64(ts)
                     ch.value = float(row_item[i])
                     channel_data[sensor_name][i].append(ch)
                  # } if (row_item[i] != '')..  
                  # except ValueError as err:
                     # print(" ******** ValueError: Total nbr of columns: " + str(n_data_columns-1) + " gps_tow: " + str(gps_tow) + " 0-based column index i = " + str(i) + ", Channel Name: " + channel_names[i] + ", Value: " + row_item[i] + ", Error Msg: {0}".format(err))
                  # } try..
               # } for i in range(n_data_columns)..

               # SensorCloud can only take certain (max) nbr of rows in each upload
               # If that threshold is reached, upload to cloud now and reset the channel_data struct for subsequent data values
               if (data_row_cnt % MAX_ROWS_SENSOR_CLOUD_UPLOAD == 0):
                  print(' ************ data_row_cnt = ' + str(data_row_cnt) + ', will upload to cloud')
                  for index in range(len(channel_data[sensor_name])):
                     print(' *********** index = ' + str(index) + ' channel_names[index] = ' + channel_names[index] + ' len(channel_data[sensor_name][index]) = ' + str(len(channel_data[sensor_name][index])))

                     channel_data_list = channel_data[sensor_name][index]

                     addTimeSeriesData(server, token, device_id, sensor_name, channel_names[index], sampleRate, sampleRateType, channel_data_list)
                  # } for index in range(len(channel_data[sensor_name]))..

                  channel_data = {sensor_name:{}}

                  for i in range(n_data_columns):
                     channel_data[sensor_name][i] = []
                  # } for i in range(n_data_columns)..
               # } if (data_row_cnt % MAX_ROWS_SENSOR_CLOUD_UPLOAD == 0)..
            except ValueError as err:
               print(" ******** ValueError: Error Msg: {0}".format(err))
            # } try..
         # } if (len(row_item) > 0)..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(row_item) > 0 and row_item[0] == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers == True)..

   # } for row_item in csvreader..

   print("******* CSV to SensorCloud: " + str(n_data_columns) + ' input headers found, ' + str(data_row_cnt) + " input data rows processed")

   print("******* CSV to SensorCloud: len(channel_data[sensor_name]) = " + str(len(channel_data[sensor_name])))

   print(" ********* Uploading last set (leftover) rows to sensor cloud... ************* ")

   # Upload the last set of (leftover rows) one column (channel) at a time to SensorCloud:
   for index in range(len(channel_data[sensor_name])):
      print(' *********** index = ' + str(index) + ' channel_names[index] = ' + channel_names[index] + ' len(channel_data[sensor_name][index]) = ' + str(len(channel_data[sensor_name][index])))

      channel_data_list = channel_data[sensor_name][index]
      if (len(channel_data_list) > 0):
         addTimeSeriesData(server, token, device_id, sensor_name, channel_names[index], sampleRate, sampleRateType, channel_data_list)
      # } if (len(channel_data_list) > 0)..
   # } for index in range(len(channel_data[sensor_name]))..


