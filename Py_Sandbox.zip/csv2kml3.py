import geocoding_for_kml
import csv
import xml.dom.minidom
import sys

def extractAddress(row):
  # This extracts an address from a row and returns it as a string. This requires knowing
  # ahead of time what the columns are that hold the address information.
  return '%s,%s,%s,%s,%s' % (row['Address1'], row['Address2'], row['City'], row['State'], row['Zip'])

def createPlacemark(kmlDoc, row, order):
  # This creates a <Placemark> element for a row of data.
  # A row is a dict.
  placemarkElement = kmlDoc.createElement('Placemark')
  extElement = kmlDoc.createElement('ExtendedData')
  placemarkElement.appendChild(extElement)

  # Loop through the columns and create a <Data> element for every field that has a value.
  for key in order:
    if row[key]:
      dataElement = kmlDoc.createElement('Data')
      dataElement.setAttribute('name', key)
      valueElement = kmlDoc.createElement('value')
      dataElement.appendChild(valueElement)
      valueText = kmlDoc.createTextNode(row[key])
      valueElement.appendChild(valueText)
      extElement.appendChild(dataElement)

  pointElement = kmlDoc.createElement('Point')
  placemarkElement.appendChild(pointElement)
  coordinates = geocoding_for_kml.geocode(extractAddress(row))
  coorElement = kmlDoc.createElement('coordinates')
  coorElement.appendChild(kmlDoc.createTextNode(coordinates))
  pointElement.appendChild(coorElement)
  return placemarkElement

def createKML(csvReader, fileName, order):
  # This constructs the KML document from the CSV file.
  kmlDoc = xml.dom.minidom.Document()

  kmlElement = kmlDoc.createElementNS('http://earth.google.com/kml/2.2', 'kml')
  kmlElement.setAttribute('xmlns', 'http://earth.google.com/kml/2.2')
  kmlElement = kmlDoc.appendChild(kmlElement)
  documentElement = kmlDoc.createElement('Document')
  documentElement = kmlElement.appendChild(documentElement)

  # Skip the header line.
  csvReader.next()

  for row in csvReader:
    placemarkElement = createPlacemark(kmlDoc, row, order)
    documentElement.appendChild(placemarkElement)

  kmlFile = open(fileName, 'w')
  kmlFile.write(kmlDoc.toprettyxml('  ', newl = '\n', encoding = 'utf-8'))

def main():
  # This reader opens up 'google-addresses.csv', which should be replaced with your own.
  # It creates a KML file called 'google.kml'.

  # If an argument was passed to the script, it splits the argument on a comma
  # and uses the resulting list to specify an order for when columns get added.
  # Otherwise, it defaults to the order used in the sample.

  if len(sys.argv) >1:
     order = sys.argv[1].split(',')
  else:
     order = ['GPS TFlags','GPS Week','GPS TOW','Lat [x8103]','Long [x8103]','Height [x8103]','MSL Height [x8103]','Horz Acc [x8103]','Vert Acc [x8103]','Flags [x8103]','ECEF X [x8104]','ECEF Y [x8104]','ECEF Z [x8104]','ECEF Acc [x8104]','Flags [x8104]','Vel N [x8105]','Vel E [x8105]','Vel D [x8105]','Speed [x8105]','Gnd Speed [x8105]','Heading [x8105]','Speed Acc [x8105]','Heading Acc [x8105]','Flags [x8105]','ECEF Vel X [x8106]','ECEF Vel Y [x8106]','ECEF Vel Z [x8106]','ECEF Vel Acc [x8106]','Flags [x8106]','Geo DOP [x8107]','Pos DOP [x8107]','Hor DOP [x8107]','Vert DOP [x8107]','Time DOP [x8107]','Northing DOP [x8107]','Easting DOP [x8107]','Flags [x8107]','UTC Year [x8108]','UTC Month [x8108]','UTC Day [x8108]','UTC Hour [x8108]','UTC Minute [x8108]','UTC Second [x8108]','UTC Millesecond [x8108]','Flags [x8108]','Clock Bias [x810A]','Clock Drift [x810A]','Clock Acc [x810A]','Flags [x810A]','GPS Fix [x810B]','GPS SVs Used [x810B]','GPS Fix Flags [x810B]','Flags [x810B]','HW Sensor Stat [x810D]','HW Ant Stat [x810D]','HW Ant Pwr [x810D]','Flags [x810D]']
     # order = ['Office','Address1','Address2','Address3','City','State','Zip','Phone','Fax']
   
  # csvreader = csv.DictReader(open('google-addresses.csv'), order)
  csvreader = csv.DictReader(open('U:\Lord\Python_HIL_Sim_From_File\Vehicle_Logs\2016_07_12\diff\GX4-45 GPS_Log_match_for_kml.csv'), order)

  kml = createKML(csvreader, 'GX4-45 GPS match.kml', order)

if __name__ == '__main__':
  main()
