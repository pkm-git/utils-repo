# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

EKF_FORMAT_DICT_UNINITIALIZED = 0

class EKF_8211_struct:
   def __init__(self):
      [self.ekf_week, self.ekf_tow, self.flags_82_11] = [0,0,0]

class EKF_8210_struct:
   def __init__(self):
      [self.ekf_state, self.ekf_mode, self.flags_82_10, self.imu_unavailable, self.gps_unavailable, self.matrix_sing_in_calc, \
       self.pos_cov_var_high, self.vel_cov_var_high, self.att_cov_var_high, self.NaN_in_soln, self.gyro_bias_est_high, self.accel_bias_est_high, \
       self.gyro_sf_est_high, self.accel_sf_est_high, self.att_not_initialized, self.pos_vel_not_initialized, self.mag_bias_est_high, \
       self.gps_antenna_offset_corr_est_high, self.mag_hard_iron_est_high, self.mag_soft_iron_est_high] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8201_struct:
   def __init__(self):
      [self.ekf_pos_llh_lat, self.ekf_pos_llh_lon, self.ekf_pos_llh_ht, self.flags_82_01] = [0,0,0,0]

class EKF_8208_struct:
   def __init__(self):
      [self.ekf_pos_llh_UC_lat, self.ekf_pos_llh_UC_lon, self.ekf_pos_llh_UC_ht, self.flags_82_08] = [0,0,0,0]

class EKF_8202_struct:
   def __init__(self):
      [self.ekf_vned_N, self.ekf_vned_E, self.ekf_vned_D, self.flags_82_02] = [0,0,0,0]

class EKF_8209_struct:
   def __init__(self):
      # [self.ekf_ned_vel_UC_x, self.ekf_ned_vel_UC_y, self.ekf_ned_vel_UC_z, self.flags_82_09] = [0,0,0,0]
      [self.ekf_vned_UC_N, self.ekf_vned_UC_E, self.ekf_vned_UC_D, self.flags_82_09] = [0,0,0,0]

class EKF_8205_struct:
   def __init__(self):
      [self.euler_angle_roll, self.euler_angle_pitch, self.euler_angle_yaw, self.flags_82_05] = [0,0,0,0]

class EKF_820A_struct:
   def __init__(self):
      [self.euler_angle_UC_roll, self.euler_angle_UC_pitch, self.euler_angle_UC_yaw, self.flags_82_0a] = [0,0,0,0]

class EKF_8203_struct:
   def __init__(self):
      [self.quat_0, self.quat_1, self.quat_2, self.quat_3, self.flags_82_03] = [0,0,0,0,0]

class EKF_8212_struct:
   def __init__(self):
      [self.quat_UC_0, self.quat_UC_1, self.quat_UC_2, self.quat_UC_3, self.flags_82_12] = [0,0,0,0,0]

class EKF_8207_struct:
   def __init__(self):
      [self.accel_bias_x, self.accel_bias_y, self.accel_bias_z, self.flags_82_07] = [0,0,0,0]

class EKF_820C_struct:
   def __init__(self):
      [self.accel_bias_UC_x, self.accel_bias_UC_y, self.accel_bias_UC_z, self.flags_82_0c] = [0,0,0,0]

class EKF_8217_struct:
   def __init__(self):
      [self.accel_SF_x, self.accel_SF_y, self.accel_SF_z, self.flags_82_17] = [0,0,0,0]

class EKF_8219_struct:
   def __init__(self):
      [self.accel_SF_UC_x, self.accel_SF_UC_y, self.accel_SF_UC_z, self.flags_82_19] = [0,0,0,0]

class EKF_8206_struct:
   def __init__(self):
      [self.gyro_bias_x, self.gyro_bias_y, self.gyro_bias_z, self.flags_82_06] = [0,0,0,0]

class EKF_820B_struct:
   def __init__(self):
      [self.gyro_bias_UC_x, self.gyro_bias_UC_y, self.gyro_bias_UC_z, self.flags_82_0b] = [0,0,0,0]

class EKF_8216_struct:
   def __init__(self):
      [self.gyro_SF_x, self.gyro_SF_y, self.gyro_SF_z, self.flags_82_16] = [0,0,0,0]

class EKF_8218_struct:
   def __init__(self):
      [self.gyro_SF_UC_x, self.gyro_SF_UC_y, self.gyro_SF_UC_z, self.flags_82_18] = [0,0,0,0]

class EKF_820D_struct:
   def __init__(self):
      [self.lin_accel_x, self.lin_accel_y, self.lin_accel_z, self.flags_82_0d] = [0,0,0,0]

class EKF_821C_struct:
   def __init__(self):
      [self.comp_accel_x, self.comp_accel_y, self.comp_accel_z, self.flags_82_1c] = [0,0,0,0]

class EKF_820E_struct:
   def __init__(self):
      [self.comp_gyro_x, self.comp_gyro_y, self.comp_gyro_z, self.flags_82_0e] = [0,0,0,0]

class EKF_8213_struct:
   def __init__(self):
      [self.grav_vect_x, self.grav_vect_y, self.grav_vect_z, self.flags_82_13] = [0,0,0,0]

class EKF_820F_struct:
   def __init__(self):
      [self.grav_mag, self.flags_82_0f] = [0,0]

class EKF_8214_struct:
   def __init__(self):
      [self.heading, self.heading_UC, self.heading_source, self.flags_82_14] = [0,0,0,0]

class EKF_8215_struct:
   def __init__(self):
      [self.inten_N, self.inten_E, self.inten_D, self.inclination, self.declination, self.flags_82_15] = [0,0,0,0,0,0]

class EKF_8220_struct:
   def __init__(self):
      [self.geom_alt, self.geopot_alt, self.temp, self.pressure, self.density, self.flags_82_20] = [0,0,0,0,0,0]

class EKF_8221_struct:
   def __init__(self):
      [self.pressure_altitude, self.flags_82_21] = [0,0]

class EKF_8230_struct:
   def __init__(self):
      [self.gps_ant_offset_corr_x, self.gps_ant_offset_corr_y, self.gps_ant_offset_corr_z, self.flags_82_30] = [0,0,0,0]

class EKF_8231_struct:
   def __init__(self):
      [self.gps_ant_offset_corr_UC_x, self.gps_ant_offset_corr_UC_y, self.gps_ant_offset_corr_UC_z, self.flags_82_31] = [0,0,0,0]

class EKF_8204_struct:
   def __init__(self):
      [self.matrix_m11, self.matrix_m12, self.matrix_m13, self.matrix_m21, self.matrix_m22, self.matrix_m23, self.matrix_m31, self.matrix_m32, self.matrix_m33, self.flags_82_04] = [0,0,0,0,0,0,0,0,0,0]

class EKF_8227_struct:
   def __init__(self):
      [self.mag_comp_x, self.mag_comp_y, self.mag_comp_z, self.flags_82_27] = [0,0,0,0]

class EKF_821A_struct:
   def __init__(self):
      [self.mag_bias_x, self.mag_bias_y, self.mag_bias_z, self.flags_82_1a] = [0,0,0,0]

class EKF_821B_struct:
   def __init__(self):
      [self.mag_bias_UC_x, self.mag_bias_UC_y, self.mag_bias_UC_z, self.flags_82_1b] = [0,0,0,0]

class EKF_8223_struct:
   def __init__(self):
      [self.mag_SF_x, self.mag_SF_y, self.mag_SF_z, self.flags_82_23] = [0,0,0,0]

class EKF_8224_struct:
   def __init__(self):
      [self.mag_SF_UC_x, self.mag_SF_UC_y, self.mag_SF_UC_z, self.flags_82_24] = [0,0,0,0]

class EKF_8225_struct:
   def __init__(self):
      [self.mag_auto_hard_iron_offset_x, self.mag_auto_hard_iron_offset_y, self.mag_auto_hard_iron_offset_z, self.flags_82_25] = [0,0,0,0]

class EKF_8228_struct:
   def __init__(self):
      [self.mag_auto_hard_iron_offset_UC_x, self.mag_auto_hard_iron_offset_UC_y, self.mag_auto_hard_iron_offset_UC_z, self.flags_82_28] = [0,0,0,0]

class EKF_8226_struct:
   def __init__(self):
      [self.mag_auto_soft_iron_m11, self.mag_auto_soft_iron_m12, self.mag_auto_soft_iron_m13, self.mag_auto_soft_iron_m21, self.mag_auto_soft_iron_m22, self.mag_auto_soft_iron_m23, self.mag_auto_soft_iron_m31, self.mag_auto_soft_iron_m32, self.mag_auto_soft_iron_m33, self.flags_82_26] = [0,0,0,0,0,0,0,0,0,0]

class EKF_8229_struct:
   def __init__(self):
      [self.mag_auto_soft_iron_UC_m11, self.mag_auto_soft_iron_UC_m12, self.mag_auto_soft_iron_UC_m13, self.mag_auto_soft_iron_UC_m21, self.mag_auto_soft_iron_UC_m22, self.mag_auto_soft_iron_UC_m23, self.mag_auto_soft_iron_UC_m31, self.mag_auto_soft_iron_UC_m32, self.mag_auto_soft_iron_UC_m33, self.flags_82_29] = [0,0,0,0,0,0,0,0,0,0]

class EKF_822A_struct:
   def __init__(self):
      [self.mag_cov_m11, self.mag_cov_m12, self.mag_cov_m13, self.mag_cov_m21, self.mag_cov_m22, self.mag_cov_m23, self.mag_cov_m31, self.mag_cov_m32, self.mag_cov_m33, self.flags_82_2a] = [0,0,0,0,0,0,0,0,0,0]

class EKF_822B_struct:
   def __init__(self):
      [self.grav_auto_adap_noise_m11, self.grav_auto_adap_noise_m12, self.grav_auto_adap_noise_m13, self.grav_auto_adap_noise_m21, self.grav_auto_adap_noise_m22, self.grav_auto_adap_noise_m23, self.grav_auto_adap_noise_m31, self.grav_auto_adap_noise_m32, self.grav_auto_adap_noise_m33, self.flags_82_2b] = [0,0,0,0,0,0,0,0,0,0]

class EKF_822C_struct:
   def __init__(self):
      [self.mag_residual_x, self.mag_residual_y, self.mag_residual_z, self.flags_82_2c] = [0,0,0,0]

class EKF_822D_struct:
   def __init__(self):
      [self.mag_filt_residual_x, self.mag_filt_residual_y, self.mag_filt_residual_z, self.flags_82_2d] = [0,0,0,0]

class EKF_8250_struct:
   def __init__(self):
      [self.attitude_init_roll_pitch_start_time, self.global_time_ms, self.rel_global_time_ms, self.delta_v_x, self.delta_v_y, self.delta_v_z, \
       self.delta_theta_x, self.delta_theta_y, self.delta_theta_z, \
       self.pressure_mbar, self.pressure_temp_degc, self.mag_meas_time_ms, self.mag_x, self.mag_y, self.mag_z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8251_struct:
   def __init__(self):
      [self.attitude_initialized, self.rel_covariance_process_start_time_ms,\
       self.P_covariance_dt_accum, self.covariance_dt_accum, self.mag_dt_accum,\
       self.grav_x, self.grav_y, self.grav_z,\
       self.q_ned2body_q0, self.q_ned2body_q1, self.q_ned2body_q2, self.q_ned2body_q3]\
        = [0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8252_struct:
   def __init__(self):
      [self.gps_tow_filter_class_attr,\
       self.last_attitude_buffer_stored_ms,\
       self.has_interpolated_attitude,\
       self.interp_att_q0, self.interp_att_q1, self.interp_att_q2, self.interp_att_q3,\
       self.interp_att_tow, self.interp_att_wk, self.interp_att_flags]\
        = [0,0,0,0,0,0,0,0,0,0]

class EKF_8253_struct:
   def __init__(self):
      [self.gps_tow_filter_class_attr,\
       self.last_state_buffer_stored_ms,\
       self.has_interpolated_state,\
       self.interp_state_lat, self.interp_state_lon, self.interp_state_ht,\
       self.interp_state_vned_n, self.interp_state_vned_e, self.interp_state_vned_d,\
       self.interp_state_q0, self.interp_state_q1, self.interp_state_q2, self.interp_state_q3,\
       self.interp_state_gyro_rate_x, self.interp_state_gyro_rate_y, self.interp_state_gyro_rate_z,\
       self.interp_state_gyro_bias_x, self.interp_state_gyro_bias_y, self.interp_state_gyro_bias_z,\
       self.interp_state_gyro_sf_x, self.interp_state_gyro_sf_y, self.interp_state_gyro_sf_z,\
       self.interp_state_ant_lever_arm_error_x, self.interp_state_ant_lever_arm_error_y, self.interp_state_ant_lever_arm_error_z,
       self.interp_state_tow, self.interp_state_wk, self.interp_state_flags]\
        = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
       
class EKF_8254_struct:
   def __init__(self):
      [self.manual_init_timestamp_ms,\
       self.local_inclination, self.local_declination, self.local_magnitude,\
       self.has_reference_position, \
       self.lat_ref, self.lon_ref, self.ht_ref,\
       self.init_attitude_roll, self.init_attitude_pitch, self.init_attitude_yaw,\
       self.Q_Gyro_White_Noise_x, self.Q_Gyro_White_Noise_y, self.Q_Gyro_White_Noise_z]\
         = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8255_struct:
   def __init__(self):
      [self.P_omega_accum_x, self.P_omega_accum_y, self.P_omega_accum_z,\
       self.P_omega_prime_accum_x, self.P_omega_prime_accum_y, self.P_omega_prime_accum_z, \
       self.P_a_accum_x, self.P_a_accum_y, self.P_a_accum_z, \
       self.P_a_prime_accum_x, self.P_a_prime_accum_y, self.P_a_prime_accum_z, \
       self.F_0, self.F_1, self.F_2, self.F_3, self.F_4, self.F_5, self.F_6, self.F_7, self.F_8, self.F_9, self.F_10, self.F_11, self.F_12, self.F_13, self.F_14, self.F_15,\
       self.P_Euler_x, self.P_Euler_y, self.P_Euler_z, \
       self.P_Tilt_Yaw_x, self.P_Tilt_Yaw_y, self.P_Tilt_Yaw_z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
      
class EKF_8256_struct:
   def __init__(self):
      [self.mag_data_new, self.mag_model_valid_start_time, self.mag_valid_start_time, \
       self.mag_model_valid, self.magnetometer_rate_limit_start_time, \
       self.adaptive_filter_autoadaptive_flag, self.adaptive_filter_legacy_flag,\
       self.mag_dip_angle_error_adaptive_measurement_enable, self.Q_boost_enable,\
       self.rate_limit_mag_dt_accum, self.hard_iron_white_noise_1sigma_x, self.hard_iron_white_noise_1sigma_y, self.hard_iron_white_noise_1sigma_z,\
       self.mag_soft_iron_white_noise_00, self.mag_soft_iron_white_noise_11, self.mag_soft_iron_white_noise_22,\
       self.mag_white_noise_x, self.mag_white_noise_y, self.mag_white_noise_z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8257_struct:
   def __init__(self):
      [self.gps_data_new, self.gps_tow_from_gps_rcvr, self.gps_tow_filter_class_attr,\
       self.gps_meas_time_ms, self.filter_tow_at_gps_meas,\
       self.gps_latency, self.gps_outage,\
       self.last_pps_set_ms, self.pps_flag, self.gps_time_valid_flags,\
       self.gps_lat, self.gps_lon, self.gps_ht,\
       self.gps_vel_n, self.gps_vel_e, self.gps_vel_d,\
       self.gps_pos_n_1sigma, self.gps_pos_e_1sigma, self.gps_pos_d_1sigma,\
       self.gps_vel_n_1sigma, self.gps_vel_e_1sigma, self.gps_vel_d_1sigma,\
       self.gps_fix_type,\
       self.horizontal_accuracy, self.vertical_accuracy,\
       self.speed, self.ground_speed, self.heading,\
       self.speed_accuracy, self.heading_accuracy]\
        = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8258_struct:
   def __init__(self):
      [self.gps_rate_limit_start_tme_ms, self.rate_limit_gps_tow, self.rate_limit_filter_tow,\
       self.rate_limit_lat_ref, self.rate_limit_lon_ref, self.rate_limit_ht_ref,\
       self.rate_limit_gps_lat, self.rate_limit_gps_lon, self.rate_limit_gps_ht,\
       self.rate_limit_gps_vel_n, self.rate_limit_gps_vel_e, self.rate_limit_gps_vel_d,\
       self.r_position_x, self.r_position_y, self.r_position_z,\
       self.r_velocity_x, self.r_velocity_y, self.r_velocity_z,\
       self.S_resid_position_x, self.S_resid_position_y, self.S_resid_position_z,\
       self.S_resid_velocity_x, self.S_resid_velocity_y, self.S_resid_velocity_z] \
        = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

class EKF_8259_struct:
   def __init__(self):
      [self.heading_rate_limit_start_time, self.residual_heading,\
       self.z_heading, self.y_heading, self.R_heading,\
       self.INV_PARAM_Heading, self.H_heading_X_Real, self.H_heading_X_I,\
       self.H_heading_X_J, self.H_heading_X_K] = [0,0,0,0,0,0,0,0,0,0]

class EKF_825A_struct:
   def __init__(self):
       [self.gravity_limit_start_time_ms,\
        self.r_gravity_x, self.r_gravity_y, self.r_gravity_z,\
        self.S_gravity_cov_x, self.S_gravity_cov_y, self.S_gravity_cov_z,\
        self.pressure_limit_start_time_ms,\
        self.r_pressure, self.z_pressure, self.y_pressure,\
        self.R_pressure]\
        = [0,0,0,0,0,0,0,0,0,0,0,0]
  
class EKF_825B_struct:
   def __init__(self):
       [self.omega_earth_rate_x, self.omega_earth_rate_y, self.omega_earth_rate_z,\
        self.omega_transport_rate_x, self.omega_transport_rate_y, self.omega_transport_rate_z,\
        self.v_x, self.v_y, self.v_z,\
        self.a_corrected_x, self.a_corrected_y, self.a_corrected_z,\
        self.a_misc_x, self.a_misc_y, self.a_misc_z,\
        self.a_curr_x, self.a_curr_y, self.a_curr_z,\
        self.x_pos_ned_n, self.x_pos_ned_e, self.x_pos_ned_d,\
        self.x_pos_ned_delta_n, self.x_pos_ned_delta_e, self.x_pos_ned_delta_d,\
        self.filter_tow_recalc_llh_ref, self.global_time_ms_recalc_llh_ref,\
        self.sensor2vehicle_offset_recalc_x, self.sensor2vehicle_offset_recalc_y, self.sensor2vehicle_offset_recalc_z,\
        self.recalc_llh_lat, self.recalc_llh_lon, self.recalc_llh_ht]\
        = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

# Define "Master columns" (i.e. all available columns in DCP) in a "master sequence"
ekf_default_cols_seq_array =       ["8211", "8210", "8201", "8208", "8202", "8209", "8205", "820A", "8203", "8212", "8207", "820C", "8217", "8219", "8206", "820B", "8216", "8218", "820D", "821C", "820E", "8213", "820F", "8214", "8215", "8220", "8221", "8230", "8231", "8204", "8225", "8228", "8226", "8229"]
ekf_debug_default_cols_seq_array = ["8211", "8210", "8250", "8257", "8251", "8252", "8253", "8254", "8255", "8256", "8258", "8259", "825A", "825B", "822A", "822B", "822C", "822D"]
ekf_gnss_debug_default_cols_seq_array = ["8211", "8257"]

class EKF_format_using_dict(object):

 #default 'constructor'
 def __init__(self, ekf_format_dict = None):
    """Class default initialization function"""
    try:
       self.init(ekf_format_dict)
    except:
       self.state = EKF_FORMAT_DICT_UNINITIALIZED

 #class initializer function
 def init(self, ekf_format_dict):
   """Class initialization function"""

   [self.ekf_8211_struct, self.ekf_8210_struct, self.ekf_8201_struct, self.ekf_8208_struct, self.ekf_8202_struct] = [None, None, None, None, None]
   [self.ekf_8209_struct, self.ekf_8205_struct, self.ekf_820A_struct, self.ekf_8203_struct, self.ekf_8212_struct] = [None, None, None, None, None]

   [self.ekf_8207_struct, self.ekf_820C_struct, self.ekf_8217_struct, self.ekf_8219_struct, self.ekf_8206_struct] = [None, None, None, None, None]
   [self.ekf_820B_struct, self.ekf_8216_struct, self.ekf_8218_struct, self.ekf_820D_struct, self.ekf_821C_struct] = [None, None, None, None, None]

   [self.ekf_820E_struct, self.ekf_8213_struct, self.ekf_820F_struct, self.ekf_8214_struct, self.ekf_8215_struct] = [None, None, None, None, None]
   [self.ekf_8220_struct, self.ekf_8221_struct, self.ekf_8230_struct, self.ekf_8231_struct, self.ekf_8204_struct] = [None, None, None, None, None]

   [self.ekf_8227_struct, self.ekf_821A_struct, self.ekf_821B_struct, self.ekf_8223_struct, self.ekf_8224_struct] = [None, None, None, None, None]
   [self.ekf_8225_struct, self.ekf_8228_struct, self.ekf_8226_struct, self.ekf_8229_struct, self.ekf_822A_struct] = [None, None, None, None, None]
   [self.ekf_822B_struct, self.ekf_822C_struct, self.ekf_822D_struct] = [None, None, None]
   
   [self.ekf_8250_struct, self.ekf_8251_struct, self.ekf_8252_struct, self.ekf_8253_struct, self.ekf_8254_struct] = [None, None, None, None, None]
   [self.ekf_8255_struct, self.ekf_8256_struct, self.ekf_8257_struct, self.ekf_8258_struct, self.ekf_8259_struct] = [None, None, None, None, None]
   [self.ekf_825A_struct, self.ekf_825B_struct] = [None, None]

   if (ekf_format_dict != None):
      for k in ekf_default_cols_seq_array:
         if (k in ekf_format_dict):
            if (k == "8211"):
               self.ekf_8211_struct = ekf_format_dict[k]
            elif (k == "8210"):
               self.ekf_8210_struct = ekf_format_dict[k]
            elif (k == "8201"):
               self.ekf_8201_struct = ekf_format_dict[k]
            elif (k == "8208"):
               self.ekf_8208_struct = ekf_format_dict[k]
            elif (k == "8202"):
               self.ekf_8202_struct = ekf_format_dict[k]
            elif (k == "8209"):
               self.ekf_8209_struct = ekf_format_dict[k]
            elif (k == "8205"):
               self.ekf_8205_struct = ekf_format_dict[k]
            elif (k == "820A"):
               self.ekf_820A_struct = ekf_format_dict[k]
            elif (k == "8203"):
               self.ekf_8203_struct = ekf_format_dict[k]
            elif (k == "8212"):
               self.ekf_8212_struct = ekf_format_dict[k]

            elif (k == "8207"):
               self.ekf_8207_struct = ekf_format_dict[k]
            elif (k == "820C"):
               self.ekf_820C_struct = ekf_format_dict[k]
            elif (k == "8217"):
               self.ekf_8217_struct = ekf_format_dict[k]
            elif (k == "8219"):
               self.ekf_8219_struct = ekf_format_dict[k]
            elif (k == "8206"):
               self.ekf_8206_struct = ekf_format_dict[k]
            elif (k == "820B"):
               self.ekf_820B_struct = ekf_format_dict[k]
            elif (k == "8216"):
               self.ekf_8216_struct = ekf_format_dict[k]
            elif (k == "8218"):
               self.ekf_8218_struct = ekf_format_dict[k]
            elif (k == "820D"):
               self.ekf_820D_struct = ekf_format_dict[k]
            elif (k == "821C"):
               self.ekf_821C_struct = ekf_format_dict[k]

            elif (k == "820E"):
               self.ekf_820E_struct = ekf_format_dict[k]
            elif (k == "8213"):
               self.ekf_8213_struct = ekf_format_dict[k]
            elif (k == "820F"):
               self.ekf_820F_struct = ekf_format_dict[k]
            elif (k == "8214"):
               self.ekf_8214_struct = ekf_format_dict[k]
            elif (k == "8215"):
               self.ekf_8215_struct = ekf_format_dict[k]
            elif (k == "8220"):
               self.ekf_8220_struct = ekf_format_dict[k]
            elif (k == "8221"):
               self.ekf_8221_struct = ekf_format_dict[k]
            elif (k == "8230"):
               self.ekf_8230_struct = ekf_format_dict[k]
            elif (k == "8231"):
               self.ekf_8231_struct = ekf_format_dict[k]
            elif (k == "8204"):
               self.ekf_8204_struct = ekf_format_dict[k]

            elif (k == "8227"):
               self.ekf_8227_struct = ekf_format_dict[k]
            elif (k == "821A"):
               self.ekf_821A_struct = ekf_format_dict[k]
            elif (k == "821B"):
               self.ekf_821B_struct = ekf_format_dict[k]
            elif (k == "8223"):
               self.ekf_8223_struct = ekf_format_dict[k]
            elif (k == "8224"):
               self.ekf_8224_struct = ekf_format_dict[k]
            elif (k == "8225"):
               self.ekf_8225_struct = ekf_format_dict[k]
            elif (k == "8228"):
               self.ekf_8228_struct = ekf_format_dict[k]
            elif (k == "8226"):
               self.ekf_8226_struct = ekf_format_dict[k]
            elif (k == "8229"):
               self.ekf_8229_struct = ekf_format_dict[k]
    
            # } if (k == "8211")..
         # } if (k in ekf_format_dict)..
      # } for k in ekf_default_cols_seq_array..
      
      for k in ekf_debug_default_cols_seq_array:
         if (k in ekf_format_dict):
            if (k == "8250"):
               self.ekf_8250_struct = ekf_format_dict[k]
            elif (k == "8251"):
               self.ekf_8251_struct = ekf_format_dict[k]
            elif (k == "8252"):
               self.ekf_8252_struct = ekf_format_dict[k]
            elif (k == "8253"):
               self.ekf_8253_struct = ekf_format_dict[k]
            elif (k == "8254"):
               self.ekf_8254_struct = ekf_format_dict[k]
            elif (k == "8255"):
               self.ekf_8255_struct = ekf_format_dict[k]
            elif (k == "8256"):
               self.ekf_8256_struct = ekf_format_dict[k]
            elif (k == "8257"):
               self.ekf_8257_struct = ekf_format_dict[k]
            elif (k == "8258"):
               self.ekf_8258_struct = ekf_format_dict[k]
            elif (k == "8259"):
               self.ekf_8259_struct = ekf_format_dict[k]
            elif (k == "825A"):
               self.ekf_825A_struct = ekf_format_dict[k]
            elif (k == "825B"):
               self.ekf_825B_struct = ekf_format_dict[k]
            elif (k == "822A"):
               self.ekf_822A_struct = ekf_format_dict[k]
            elif (k == "822B"):
               self.ekf_822B_struct = ekf_format_dict[k]
            elif (k == "822C"):
               self.ekf_822C_struct = ekf_format_dict[k]
            elif (k == "822D"):
               self.ekf_822D_struct = ekf_format_dict[k]
       
         # } if (k in ekf_format_dict)..
      # } for k in ekf_debug_default_cols_seq_array..

   # } if (ekf_format_dict != None)..

 def format_header(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       ret_str = 'EKF TFlags,EKF Week,EKF TOW,'
    elif (format_in == 1):
       ret_str = 'EKF State [x8210],EKF Mode [x8210],Flags [x8210],Flag_IMU_Unavailable [x8210],Flag_GPS_Unavailable [x8210],Flag_Matrix_Singularity [x8210],Flag_Pos_Cov_High [x8210],Flag_Vel_Cov_High [x8210],Flag_Att_Cov_High [x8210],Flag_NaN_in_Soln [x8210],Flag_Gyro_Bias_Est_High [x8210],Flag_Accel_Bias_Est_High [x8210],Flag_Gyro_SF_Est_High [x8210],Flag_Accel_SF_Est_High [x8210],Flag_Att_Uninitialized [x8210],Flag_Pos_Vel_Uninitialized [x8210],Flag_Mag_Bias_Est_High [x8210],Flag_GPS_Ant_Off_Corr_Est_High [x8210],Flag_Mag_Hard_Iron_Est_High [x8210],Flag_Mag_Soft_Iron_Est_High [x8210],'
    elif (format_in == 2):
       ret_str = 'Lat [x8201],Lon [x8201],Ht Abv Ellips [x8201],Flags [x8201],'
    elif (format_in == 3):
       ret_str = 'LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],'
    elif (format_in == 4):
       ret_str = 'Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],'
    elif (format_in == 5):
       ret_str = 'Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],'
    elif (format_in == 6):
       ret_str = 'Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],'
    elif (format_in == 7):
       ret_str = 'Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],'
    elif (format_in == 8):
       ret_str = 'q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],'
    elif (format_in == 9):
       ret_str = 'q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],'

    elif (format_in == 10):
       ret_str = 'X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],'
    elif (format_in == 11):
       ret_str = 'X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],'
    elif (format_in == 12):
       ret_str = 'X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],'
    elif (format_in == 13):
       ret_str = 'X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],'
    elif (format_in == 14):
       ret_str = 'X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],'
    elif (format_in == 15):
       ret_str = 'X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],'
    elif (format_in == 16):
       ret_str = 'X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],'
    elif (format_in == 17):
       ret_str = 'X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],'
    elif (format_in == 18):
       ret_str = 'X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],'
    elif (format_in == 19):
       ret_str = 'X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],'

    elif (format_in == 20):
       ret_str = 'X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],'
    elif (format_in == 21):
       ret_str = 'X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],'
    elif (format_in == 22):
       ret_str = 'WGS84 Gravity [x820F],Flags [x820F],'
    elif (format_in == 23):
       ret_str = 'True Heading [x8214],Heading UC [x8214],Head Src [x8214],Flags [x8214],'
    elif (format_in == 24):
       ret_str = 'Inten N [x8215],Inten E [x8215],Inten D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],'
    elif (format_in == 25):
       ret_str = 'SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],'
    elif (format_in == 26):
       ret_str = 'Pressure Alt [x8221],Flags [x8221],'
    elif (format_in == 27):
       ret_str = 'X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],'
    elif (format_in == 28):
       ret_str = 'X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231],'
    elif (format_in == 29):
       ret_str = 'M11 [x8204],M12 [x8204],M13 [x8204],M21 [x8204],M22 [x8204],M23 [x8204],M31 [x8204],M32 [x8204],M33 [x8204],Flags [x8204],'

    elif (format_in == 30):
       ret_str = 'X Mag Auto Hard Iron Offset [x8225],Y Mag Auto Hard Iron Offset [x8225],Z Mag Auto Hard Iron Offset [x8225],Flags [x8225],'
    elif (format_in == 31):
       ret_str = 'X Mag Auto Hard Iron Offset UC [x8228],Y Mag Auto Hard Iron Offset UC [x8228],Z Mag Auto Hard Iron Offset UC [x8228],Flags [x8228],'
    elif (format_in == 32):
       ret_str = 'Mag Auto Soft Iron M11 [x8226],Mag Auto Soft Iron M12 [x8226],Mag Auto Soft Iron M13 [x8226],Mag Auto Soft Iron M21 [x8226],Mag Auto Soft Iron M22 [x8226],Mag Auto Soft Iron M23 [x8226],Mag Auto Soft Iron M31 [x8226],Mag Auto Soft Iron M32 [x8226],Mag Auto Soft Iron M33 [x8226],Flags [x8226],'
    elif (format_in == 33):
       ret_str = 'Mag Auto Soft Iron UC M11 [x8229],Mag Auto Soft Iron UC M12 [x8229],Mag Auto Soft Iron UC M13 [x8229],Mag Auto Soft Iron UC M21 [x8229],Mag Auto Soft Iron UC M22 [x8229],Mag Auto Soft Iron UC M23 [x8229],Mag Auto Soft Iron UC M31 [x8229],Mag Auto Soft Iron UC M32 [x8229],Mag Auto Soft Iron UC M33 [x8229],Flags [x8229],'

    # elif (format_in == 30):
       # ret_str = 'X Mag Comp [x8227],Y Mag Comp [x8227],Z Mag Comp [x8227],Flags [x8227],'
    # elif (format_in == 31):
       # ret_str = 'X Mag Bias [x821A],Y Mag Bias [x821A],Z Mag Bias [x821A],Flags [x821A],'
    # elif (format_in == 32):
       # ret_str = 'X Mag Bias UC [x821B],Y Mag Bias UC [x821B],Z Mag Bias UC [x821B],Flags [x821B],'
    # elif (format_in == 33):
       # ret_str = 'X Mag SF [x8223],Y Mag SF [x8223],Z Mag SF [x8223],Flags [x8223],'
    # elif (format_in == 34):
       # ret_str = 'X Mag SF UC [x8224],Y Mag SF UC [x8224],Z Mag SF UC [x8224],Flags [x8224],'
       
    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format_header_debug(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       ret_str = 'EKF TFlags,EKF Week,EKF TOW,'
    
    elif (format_in == 1):
       ret_str = 'EKF State [x8210],EKF Mode [x8210],Flags [x8210],Flag_IMU_Unavailable [x8210],Flag_GPS_Unavailable [x8210],Flag_Matrix_Singularity [x8210],Flag_Pos_Cov_High [x8210],Flag_Vel_Cov_High [x8210],Flag_Att_Cov_High [x8210],Flag_NaN_in_Soln [x8210],Flag_Gyro_Bias_Est_High [x8210],Flag_Accel_Bias_Est_High [x8210],Flag_Gyro_SF_Est_High [x8210],Flag_Accel_SF_Est_High [x8210],Flag_Att_Uninitialized [x8210],Flag_Pos_Vel_Uninitialized [x8210],Flag_Mag_Bias_Est_High [x8210],Flag_GPS_Ant_Off_Corr_Est_High [x8210],Flag_Mag_Hard_Iron_Est_High [x8210],Flag_Mag_Soft_Iron_Est_High [x8210],'

    elif (format_in == 2):
       ret_str = 'Att_init_roll_pitch_start_tme [x8250],Global Tme MS [x8250],Rel Global Tme MS [x8250],\
                  X DeltaV [x8250],Y DeltaV [x8250],Z DeltaV [x8250],X DeltaTheta [x8250],Y DeltaTheta [x8250],Z DeltaTheta [x8250],\
                  Pressure mbar [x8250],Pressure Temp DegC [x8250],Mag Meas Tme MS [x8250],X Mag [x8250],Y Mag [x8250],Z Mag [x8250],'\
    
    elif (format_in == 3):
       ret_str = 'GPS_data_new [x8257],GPS TmeWk_From_Rcvr [x8257],GPS_TmeWk_Filter_Class_Attr [x8257],\
                  GPS_Meas_Tme_MS [x8257],GPS Filter_TmeWk_at_GPS_Meas [x8257],\
                  GPS_Latency [x8257],GPS_Outage [x8257],\
                  Last PPS Set MS [x8257],PPS Flag [x8257],GPS Tme Valid Flags [x8257],\
                  GPS_Lat [x8257],GPS_Lon [x8257],GPS_Ht [x8257],\
                  GPS_Vel_N [x8257],GPS_Vel_E [x8257],GPS_Vel_D [x8257],\
                  GPS_Pos_N_UC [x8257],GPS_Pos_E_UC [x8257],GPS_Pos_D_UC [x8257],\
                  GPS_Vel_N_UC [x8257],GPS_Vel_E_UC [x8257],GPS_Vel_D_UC [x8257],GPS_Fix_Type [x8257],\
                  Horiz Accuracy [x8257],Vert Accuracy [x8257],\
                  Speed [x8257],Ground_speed [x8257],Heading [x8257],\
                  Speed Accuracy [x8257],Heading Accuracy [x8257],'

    elif (format_in == 4):
       ret_str = 'Att_initialized [x8251],Rel Cov Process Start Tme MS [x8251],\
                  P_cov_dt_accum [x8251],cov_dt_accum [x8251],mag_dt_accum [x8251],\
                  X Grav [x8251],Y Grav [x8251],Z Grav [x8251],\
                  q_ned2body_q0 [x8251],q_ned2body_q1 [x8251],q_ned2body_q2 [x8251],q_ned2body_q3 [x8251],'
  
                  # Gravity Limit Start Tme MS [x8251],\
                  # Gravity Residual X [x8251],Gravity Residual Y [x8251],Gravity Residual Z [x8251],\
                  # Gravity Cov X [x8251],Gravity Cov Y [x8251],Gravity Cov Z [x8251],'

    elif (format_in == 5):
       ret_str = 'GPS TmeWk Filter Class Attr [x8252],\
                  Last Att Buffer ms [x8252],Has Interp Att [x8252],Interp Att TmeWk [x8252],\
                  Interp Att q0 [x8252],Interp Att q1 [x8252],Interp Att q2 [x8252],Interp Att q3 [x8252],'

    elif (format_in == 6):
       ret_str = 'GPS TmeWk Filter Class Attr [x8253],\
                  Last State Buffer ms [x8253],Has Interp State [x8253],Interp State TmeWk [x8253],\
                  Interp State LLH Lat [x8253],Interp State LLH Lon [x8253],Interp State LLH Ht [x8253],\
                  Interp State NED Vel N [x8253],Interp State NED Vel E [x8253],Interp State NED Vel D [x8253],\
                  Interp State q0 [x8253],Interp State q1 [x8253],Interp State q2 [x8253],Interp State q3 [x8253],\
                  Interp State gyro_rate X [x8253],Interp State gyro_rate Y [x8253],Interp State gyro_rate Z [x8253],\
                  Interp State gyro_bias X [x8253],Interp State gyro_bias Y [x8253],Interp State gyro_bias Z [x8253],\
                  Interp State gyro_sf X [x8253],Interp State gyro_sf Y [x8253],Interp State gyro_sf Z [x8253],\
                  Interp State Ant Lvr Arm Err X [x8253],Interp State Ant Lvr Arm Err Y [x8253],Interp State Ant Lvr Arm Err Z [x8253],'
          
    elif (format_in == 7):
       ret_str = 'Manual Init Tmestamp MS [x8254],\
                  Local Inclination [x8254],Local Declination [x8254],Local Magnitude [x8254],\
                  Has_Ref_Pos [x8254],Lat Ref [x8254],Lon Ref [x8254],Ht Ref [x8254],\
                  Init Attitude Roll [x8254],Init Attitude Pitch [x8254],Init Attitude Yaw [x8254],\
                  Q_Gyro_White_Noise_x [x8254],Q_Gyro_White_Noise_y [x8254],Q_Gyro_White_Noise_z [x8254],'

    elif (format_in == 8):
       ret_str = 'X P_omega_accum [x8255],Y P_omega_accum [x8255],Z P_omega_accum [x8255],\
                  X P_omega_prime_accum [x8255],Y P_omega_prime_accum [x8255],Z P_omega_prime_accum [x8255],\
                  X P_a_accum [x8255],Y P_a_accum [x8255],Z P_a_accum [x8255],\
                  X P_a_prime_accum [x8255],Y P_a_prime_accum [x8255],Z P_a_prime_accum [x8255],\
                  F_Real_Real [x8255],F_Real_I [x8255],F_Real_J [x8255],F_Real_K [x8255],F_I_Real [x8255],F_I_I [x8255],F_I_J [x8255],F_I_K [x8255],\
                  F_J_Real [x8255],F_J_I [x8255],F_J_J [x8255],F_J_K [x8255],F_K_Real [x8255],F_K_I [x8255],F_K_J [x8255],F_K_K [x8255],\
                  X P_Euler [x8255],Y P_Euler [x8255],Z P_Euler [x8255],X P_Tilt_Yaw [x8255],Y P_Tilt_Yaw [x8255],Z P_Tilt_Yaw [x8255],'

    elif (format_in == 9):
       ret_str = 'Mag_data_new [x8256],Mag_model_valid_start_tme [x8256],\
                  Mag_valid_start_tme [x8256],Mag_model_valid [x8256],Mag_rate_limit_start_tme [x8256],\
                  AutoAdaptive Flag [x8256],Adaptive Legacy Flag [x8256],\
                  Mag Dip Angle Adap Enable [x8256],Q_boost_enable [x8256],\
                  Rate Limit Mag dt accum [x8256],\
                  X Hard Iron White Noise 1sigma [x8256],Y Hard Iron White Noise 1sigma [x8256],Z Hard Iron White Noise 1sigma [x8256],\
                  Soft Iron White Noise Matrix M00 [x8256],Soft Iron White Noise Matrix M11 [x8256],Soft Iron White Noise Matrix M22 [x8256],\
                  X Mag White Noise [x8256],Y Mag White Noise [x8256],Z Mag White Noise [x8256],'

    elif (format_in == 10):
       ret_str = 'GPS_rate_limit_start_tme [x8258],GPS Rate Limit TmeWk [x8258],GPS Rate Limit Filter TmeWk [x8258],\
                  Rate_Limit_Lat_Ref [x8258],Rate_Limit_Lon_Ref [x8258],Rate_Limit_Ht_Ref [x8258],\
                  Rate_Limit_GPS_Lat [x8258],Rate_Limit_GPS_Lon [x8258],Rate_Limit_GPS_Ht [x8258],\
                  Rate_Limit_Vel_N [x8258],Rate_Limit_Vel_E [x8258],Rate_Limit_Vel_D [x8258],\
                  GPS_Residual_Pos X [x8258],GPS_Residual_Pos Y [x8258],GPS_Residual_Pos Z [x8258],\
                  GPS_Residual_Vel X [x8258],GPS_Residual_Vel Y [x8258],GPS_Residual_Vel Z [x8258],\
                  GPS_Residual_Cov_Pos X [x8258],GPS_Residual_Cov_Pos Y [x8258],GPS_Residual_Cov_Pos Z [x8258],\
                  GPS_Residual_Cov_Vel X [x8258],GPS_Residual_Cov_Vel Y [x8258],GPS_Residual_Cov_Vel Z [x8258],'

    elif (format_in == 11):
       ret_str = 'Heading_rate_limit_start_tme [x8259],Residual_Heading [x8259],\
                  z_heading [x8259],y_heading [x8259],R_Heading [x8259],\
                  INV_PARAM_Heading [x8259],H_heading_X_Real [x8259],H_heading_X_I [x8259],\
                  H_heading_X_J [x8259],H_heading_X_K [x8259],'
    
    elif (format_in == 12):
       ret_str = 'Gravity Limit Start Tme MS [x825A],\
                  Gravity Residual X [x825A],Gravity Residual Y [x825A],Gravity Residual Z [x825A],\
                  Gravity Cov X [x825A],Gravity Cov Y [x825A],Gravity Cov Z [x825A],\
                  Pressure Limit Start Tme MS [x825A],Residual_Pressure [x825A],\
                  z_pressure [x825A],y_pressure [x825A],R_pressure [x825A],'

    elif (format_in == 13):
       ret_str = 'Omega Earth Rate X [x825B],Omega Earth Rate Y [x825B],Omega Earth Rate Z [x825B],\
                  Omega Transport Rate X [x825B],Omega Transport Rate Y [x825B],Omega Transport Rate Z [x825B],\
                  velocity X [x825B],velocity Y [x825B],velocity Z [x825B],\
                  a_corrected X [x825B],a_corrected Y [x825B],a_corrected Z [x825B],\
                  a_misc X [x825B],a_misc Y [x825B],a_misc Z [x825B],a_curr X [x825B],a_curr Y [x825B],a_curr Z [x825B],\
                  x_pos_ned N [x825B],x_pos_ned E [x825B],x_pos_ned D [x825B],\
                  x_pos_ned_delta N [x825B],x_pos_ned_delta E [x825B],x_pos_ned_delta D [x825B],\
                  Filter TmeWk Recalc LLH_Ref [x825B],Global Tme Recalc LLH_Ref [x825B],\
                  sensor2vehicle Offset Recalc X [x825B],sensor2vehicle Offset Recalc Y [x825B],sensor2vehicle Offset Recalc Z [x825B],\
                  Recalc LLH Lat Ref [x825B],Recalc LLH Lon Ref [x825B],Recalc LLH Height Ref [x825B],'

    elif (format_in == 14):
       ret_str = 'Mag Cov M11 [x822A],Mag Cov M12 [x822A],Mag Cov M13 [x822A],Mag Cov M21 [x822A],Mag Cov M22 [x822A],Mag Cov M23 [x822A],Mag Cov M31 [x822A],Mag Cov M32 [x822A],Mag Cov M33 [x822A],Flags [x822A],'
    elif (format_in == 15):
       ret_str = 'Grav Auto Adap Noise M11 [x822B],Grav Auto Adap Noise M12 [x822B],Grav Auto Adap Noise M13 [x822B],Grav Auto Adap Noise M21 [x822B],Grav Auto Adap Noise M22 [x822B],Grav Auto Adap Noise M23 [x822B],Grav Auto Adap Noise M31 [x822B],Grav Auto Adap Noise M32 [x822B],Grav Auto Adap Noise M33 [x822B],Flags [x8226],'
    elif (format_in == 16):
       ret_str = 'X Mag Residual [x822C],Y Mag Residual [x822C],Z Mag Residual [x822C],Flags [x822C],'
    elif (format_in == 17):
       ret_str = 'X Mag Filt Residual [x822D],Y Mag Filt Residual [x822D],Z Mag Filt Residual [x822D],Flags [x822D],'

    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format_header_gnss_debug(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       ret_str = 'EKF TFlags,EKF Week,EKF TOW,'
    elif (format_in == 1):
       ret_str = 'GPS_data_new [x8257],GPS TmeWk_From_Rcvr [x8257],GPS_TmeWk_Filter_Class_Attr [x8257],\
                  GPS_Meas_Tme_MS [x8257],GPS Filter_TmeWk_at_GPS_Meas [x8257],\
                  GPS_Latency [x8257],GPS_Outage [x8257],\
                  Last PPS Set MS [x8257],PPS Flag [x8257],GPS Tme Valid Flags [x8257],\
                  GPS_Lat [x8257],GPS_Lon [x8257],GPS_Ht [x8257],\
                  GPS_Vel_N [x8257],GPS_Vel_E [x8257],GPS_Vel_D [x8257],\
                  GPS_Pos_N_UC [x8257],GPS_Pos_E_UC [x8257],GPS_Pos_D_UC [x8257],\
                  GPS_Vel_N_UC [x8257],GPS_Vel_E_UC [x8257],GPS_Vel_D_UC [x8257],GPS_Fix_Type [x8257],\
                  Horiz Accuracy [x8257],Vert Accuracy [x8257],\
                  Speed [x8257],Ground_speed [x8257],Heading [x8257],\
                  Speed Accuracy [x8257],Heading Accuracy [x8257],'
    
    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..


 # Master Format (all available columns from DCP, in a 'master sequence'):
 # GPS TFlags,GPS Week,GPS TOW,      EKF State [x8210],EKF Mode [x8210],Flags [x8210],   Lat [x8201],Long [x8201],Height [x8201],Flags [x8201],            LLH UC N [x8208],LLH UC E [x8208],LLH UC D [x8208],Flags [x8208],           Vel N [x8202],Vel E [x8202],Vel D [x8202],Flags [x8202],     Vel UC N [x8209],Vel UC E [x8209],Vel UC D [x8209],Flags [x8209],     Roll [x8205],Pitch [x8205],Yaw [x8205],Flags [x8205],                 Roll UC [x820A],Pitch UC [x820A],Yaw UC [x820A],Flags [x820A],                  q0 [x8203],q1 [x8203],q2 [x8203],q3 [x8203],Flags [x8203],   q0 UC [x8212],q1 UC [x8212],q2 UC [x8212],q3 UC [x8212],Flags [x8212],   X Acc Bias [x8207],Y Acc Bias [x8207],Z Acc Bias [x8207],Flags [x8207],   X Acc Bias UC [x820C],Y Acc Bias UC [x820C],Z Acc Bias UC [x820C],Flags [x820C],   X Acc SF [x8217],Y Acc SF [x8217],Z Acc SF [x8217],Flags [x8217],   X Acc SF UC [x8219],Y Acc SF UC [x8219],Z Acc SF UC [x8219],Flags [x8219],   X Gyro Bias [x8206],Y Gyro Bias [x8206],Z Gyro Bias [x8206],Flags [x8206],   X Gyro Bias UC [x820B],Y Gyro Bias UC [x820B],Z Gyro Bias UC [x820B],Flags [x820B],  X Gyro SF [x8216],Y Gyro SF [x8216],Z Gyro SF [x8216],Flags [x8216],    X Gyro SF UC [x8218],Y Gyro SF UC [x8218],Z Gyro SF UC [x8218],Flags [x8218],   X Acc Lin [x820D],Y Acc Lin [x820D],Z Acc Lin [x820D],Flags [x820D],      X Acc Comp [x821C],Y Acc Comp [x821C],Z Acc Comp [x821C],Flags [x821C],   X Gyro Comp [x820E],Y Gyro Comp [x820E],Z Gyro Comp [x820E],Flags [x820E],    X Gravity [x8213],Y Gravity [x8213],Z Gravity [x8213],Flags [x8213],    WGS84 Gravity [x820F],Flags [x820F],   True North [x8214],North UC [x8214],Head Src [x8214],Flags [x8214],   WMM N [x8215],WMM E [x8215],WMM D [x8215],Incl [x8215],Decl [x8215],Flags [x8215],   SAM Geomet Alt [x8220],SAM Geopot Alt [x8220],SAM Temperature [x8220],SAM Pressure [x8220],SAM Density [x8220],Flags [x8220],    Pressure Alt [x8221],Flags [x8221],   X Ant Off Err [x8230],Y Ant Off Err [x8230],Z Ant Off Err [x8230],Flags [x8230],    X Ant Off Err UC [x8231],Y Ant Off Err UC [x8231],Z Ant Off Err UC [x8231],Flags [x8231]     Matrix M11[x8204],Matrix M12[x8204],Matrix M13[x8204],Matrix M21[x8204],Matrix M22[x8204],Matrix M23[x8204],Matrix M31[x8204],Matrix M32[x8204],Matrix M33[x8204],Flags [x8204]
 # flags_82_11,ekf_week, ekf_tow,    ekf_state, ekf_mode, flags_82_10,                   ekf_pos_llh_lat, ekf_pos_llh_lon, ekf_pos_llh_ht, flags_82_01,    ekf_pos_llh_UC_lat, ekf_pos_llh_UC_lon, ekf_pos_llh_UC_ht, flags_82_08,     ekf_vned_N, ekf_vned_E, ekf_vned_D, flags_82_02,             ekf_vned_UC_N, ekf_vned_UC_E, ekf_vned_UC_D, flags_82_09,             euler_angle_roll, euler_angle_pitch, euler_angle_yaw, flags_82_05,    euler_angle_UC_roll, euler_angle_UC_pitch, euler_angle_UC_yaw, flags_82_0a,     quat_0, quat_1, quat_2, quat_3, flags_82_03,                 quat_UC_0, quat_UC_1, quat_UC_2, quat_UC_3, flags_82_12,                  accel_bias_x, accel_bias_y, accel_bias_z, flags_82_07,                  accel_bias_UC_x, accel_bias_UC_y, accel_bias_UC_z, flags_82_0c,                     accel_SF_x, accel_SF_y, accel_SF_z, flags_82_17,                    accel_SF_UC_x, accel_SF_UC_y, accel_SF_UC_z, flags_82_19,                    gyro_bias_x, gyro_bias_y, gyro_bias_z, flags_82_06,                          gyro_bias_UC_x, gyro_bias_UC_y, gyro_bias_UC_z, flags_82_0b,                         gyro_SF_x, gyro_SF_y, gyro_SF_z, flags_82_16,                           gyro_SF_UC_x, gyro_SF_UC_y, gyro_SF_UC_z, flags_82_18,                          lin_accel_x, lin_accel_y, lin_accel_z, flags_82_0d,                       comp_accel_x, comp_accel_y, comp_accel_z, flags_82_1c,                    comp_gyro_x, comp_gyro_y, comp_gyro_z, flags_82_1e,                           grav_vect_x, grav_vect_y, grav_vect_z, flags_82_13,                     grav_mag, flags_82_0f,                 heading, heading_UC, heading_source, flags_82_14,                     inten_N, inten_E, inten_D, inclination, declination, flags_82_15,                    geom_alt, geopot_alt, temp, pressure, density, flags_82_20,                                                                      pressure_altitude, flags_82_21,       gps_ant_offset_corr_x, gps_ant_offset_corr_y, gps_ant_offset_corr_z, flags_82_30,   gps_ant_offset_corr_UC_x, gps_ant_offset_corr_UC_y, gps_ant_offset_corr_UC_z, flags_82_31    matrix_m11, matrix_m12, matrix_m13, matrix_m21, matrix_m22, matrix_m23, matrix_m31, matrix_m32, matrix_m33, flags_82_04
 # %d,%4d,%12.4f,                    %d,%d,%d,                                           %14.8f,%14.8f,%14.8f,%d,                                          %14.8f,%14.8f,%14.8f,%d,                                                    %14.8f,%14.8f,%14.8f,%d,                                     %14.8f,%14.8f,%14.8f,%d,                                              %14.8f,%14.8f,%14.8f,%d,                                              %14.8f,%14.8f,%14.8f,%d,                                                        %14.8f,%14.8f,%14.8f,%14.8f,%d,                               %14.8f,%14.8f,%14.8f,%14.8f,%d,                                          %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%14.8f,%14.8f,%d,                                                            %14.8f,%14.8f,%14.8f,%d,                                            %14.8f,%14.8f,%14.8f,%d,                                                     %14.8f,%14.8f,%14.8f,%d,                                                     %14.8f,%14.8f,%14.8f,%d,                                                             %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%14.8f,%14.8f,%d,                                                        %14.8f,%14.8f,%14.8f,%d,                                                  %14.8f,%14.8f,%14.8f,%d,                                                  %14.8f,%14.8f,%14.8f,%d,                                                      %14.8f,%14.8f,%14.8f,%d,                                                %14.8f,%d,                             %14.8f,%14.8f,%d,%d,                                                  %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                               %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d,                                                                                           %14.8f,%d,                            %14.8f,%14.8f,%14.8f,%d,                                                            %14.8f,%14.8f,%14.8f,%d                                                                      %14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%d

 def format(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       if (self.ekf_8211_struct != None):
          ret_str = '{:-4d},{:-4d},{:-12.4f},'.format(self.ekf_8211_struct.flags_82_11, self.ekf_8211_struct.ekf_week, self.ekf_8211_struct.ekf_tow)
       else:
          ret_str = ',,,'

    elif (format_in == 1):
       if (self.ekf_8210_struct != None):
          ret_str = '{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},'.format(self.ekf_8210_struct.ekf_state, self.ekf_8210_struct.ekf_mode, self.ekf_8210_struct.flags_82_10, \
                                                self.ekf_8210_struct.imu_unavailable, self.ekf_8210_struct.gps_unavailable, self.ekf_8210_struct.matrix_sing_in_calc, \
                                                self.ekf_8210_struct.pos_cov_var_high, self.ekf_8210_struct.vel_cov_var_high, self.ekf_8210_struct.att_cov_var_high, self.ekf_8210_struct.NaN_in_soln, self.ekf_8210_struct.gyro_bias_est_high, self.ekf_8210_struct.accel_bias_est_high, \
                                                self.ekf_8210_struct.gyro_sf_est_high, self.ekf_8210_struct.accel_sf_est_high, self.ekf_8210_struct.att_not_initialized, self.ekf_8210_struct.pos_vel_not_initialized, self.ekf_8210_struct.mag_bias_est_high, self.ekf_8210_struct.gps_antenna_offset_corr_est_high, \
                                                self.ekf_8210_struct.mag_hard_iron_est_high, self.ekf_8210_struct.mag_soft_iron_est_high)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 2):
       if (self.ekf_8201_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8201_struct.ekf_pos_llh_lat, self.ekf_8201_struct.ekf_pos_llh_lon, self.ekf_8201_struct.ekf_pos_llh_ht, self.ekf_8201_struct.flags_82_01)
       else:
          ret_str = ',,,,'
    elif (format_in == 3):
       if (self.ekf_8208_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8208_struct.ekf_pos_llh_UC_lat, self.ekf_8208_struct.ekf_pos_llh_UC_lon, self.ekf_8208_struct.ekf_pos_llh_UC_ht, self.ekf_8208_struct.flags_82_08)
       else:
          ret_str = ',,,,'
    elif (format_in == 4):
       if (self.ekf_8202_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8202_struct.ekf_vned_N, self.ekf_8202_struct.ekf_vned_E, self.ekf_8202_struct.ekf_vned_D, self.ekf_8202_struct.flags_82_02)
       else:
          ret_str = ',,,,'
    elif (format_in == 5):
       if (self.ekf_8209_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8209_struct.ekf_vned_UC_N, self.ekf_8209_struct.ekf_vned_UC_E, self.ekf_8209_struct.ekf_vned_UC_D, self.ekf_8209_struct.flags_82_09)
       else:
          ret_str = ',,,,'
    elif (format_in == 6):
       if (self.ekf_8205_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8205_struct.euler_angle_roll, self.ekf_8205_struct.euler_angle_pitch, self.ekf_8205_struct.euler_angle_yaw, self.ekf_8205_struct.flags_82_05)
       else:
          ret_str = ',,,,'
    elif (format_in == 7):
       if (self.ekf_820A_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_820A_struct.euler_angle_UC_roll, self.ekf_820A_struct.euler_angle_UC_pitch, self.ekf_820A_struct.euler_angle_UC_yaw, self.ekf_820A_struct.flags_82_0a)
       else:
          ret_str = ',,,,'
    elif (format_in == 8):
       if (self.ekf_8203_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8203_struct.quat_0, self.ekf_8203_struct.quat_1, self.ekf_8203_struct.quat_2, self.ekf_8203_struct.quat_3, self.ekf_8203_struct.flags_82_03)
       else:
          ret_str = ',,,,,'
    elif (format_in == 9):
       if (self.ekf_8212_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8212_struct.quat_UC_0, self.ekf_8212_struct.quat_UC_1, self.ekf_8212_struct.quat_UC_2, self.ekf_8212_struct.quat_UC_3, self.ekf_8212_struct.flags_82_12)
       else:
          ret_str = ',,,,,'

    elif (format_in == 10):
       if (self.ekf_8207_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8207_struct.accel_bias_x, self.ekf_8207_struct.accel_bias_y, self.ekf_8207_struct.accel_bias_z, self.ekf_8207_struct.flags_82_07)
       else:
          ret_str = ',,,,'
    elif (format_in == 11):
       if (self.ekf_820C_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_820C_struct.accel_bias_UC_x, self.ekf_820C_struct.accel_bias_UC_y, self.ekf_820C_struct.accel_bias_UC_z, self.ekf_820C_struct.flags_82_0c)
       else:
          ret_str = ',,,,'
    elif (format_in == 12):
       if (self.ekf_8217_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8217_struct.accel_SF_x, self.ekf_8217_struct.accel_SF_y, self.ekf_8217_struct.accel_SF_z, self.ekf_8217_struct.flags_82_17)
       else:
          ret_str = ',,,,'
    elif (format_in == 13):
       if (self.ekf_8219_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8219_struct.accel_SF_UC_x, self.ekf_8219_struct.accel_SF_UC_y, self.ekf_8219_struct.accel_SF_UC_z, self.ekf_8219_struct.flags_82_19)
       else:
          ret_str = ',,,,'
    elif (format_in == 14):
       if (self.ekf_8206_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8206_struct.gyro_bias_x, self.ekf_8206_struct.gyro_bias_y, self.ekf_8206_struct.gyro_bias_z, self.ekf_8206_struct.flags_82_06)
       else:
          ret_str = ',,,,'
    elif (format_in == 15):
       if (self.ekf_820B_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_820B_struct.gyro_bias_UC_x, self.ekf_820B_struct.gyro_bias_UC_y, self.ekf_820B_struct.gyro_bias_UC_z, self.ekf_820B_struct.flags_82_0b)
       else:
          ret_str = ',,,,'
    elif (format_in == 16):
       if (self.ekf_8216_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8216_struct.gyro_SF_x, self.ekf_8216_struct.gyro_SF_y, self.ekf_8216_struct.gyro_SF_z, self.ekf_8216_struct.flags_82_16)
       else:
          ret_str = ',,,,'
    elif (format_in == 17):
       if (self.ekf_8218_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8218_struct.gyro_SF_UC_x, self.ekf_8218_struct.gyro_SF_UC_y, self.ekf_8218_struct.gyro_SF_UC_z, self.ekf_8218_struct.flags_82_18)
       else:
          ret_str = ',,,,'
    elif (format_in == 18):
       if (self.ekf_820D_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_820D_struct.lin_accel_x, self.ekf_820D_struct.lin_accel_y, self.ekf_820D_struct.lin_accel_z, self.ekf_820D_struct.flags_82_0d)
       else:
          ret_str = ',,,,'
    elif (format_in == 19):
       if (self.ekf_821C_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_821C_struct.comp_accel_x, self.ekf_821C_struct.comp_accel_y, self.ekf_821C_struct.comp_accel_z, self.ekf_821C_struct.flags_82_1c)
       else:
          ret_str = ',,,,'
    elif (format_in == 20):
       if (self.ekf_820E_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_820E_struct.comp_gyro_x, self.ekf_820E_struct.comp_gyro_y, self.ekf_820E_struct.comp_gyro_z, self.ekf_820E_struct.flags_82_0e)
       else:
          ret_str = ',,,,'
    elif (format_in == 21):
       if (self.ekf_8213_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8213_struct.grav_vect_x, self.ekf_8213_struct.grav_vect_y, self.ekf_8213_struct.grav_vect_z, self.ekf_8213_struct.flags_82_13)
       else:
          ret_str = ',,,,'
    elif (format_in == 22):
       if (self.ekf_820F_struct != None):
          ret_str = '{:-14.8f},{:-d},'.format(self.ekf_820F_struct.grav_mag, self.ekf_820F_struct.flags_82_0f)
       else:
          ret_str = ',,'
    elif (format_in == 23):
       if (self.ekf_8214_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-d},{:-d},'.format(self.ekf_8214_struct.heading, self.ekf_8214_struct.heading_UC, self.ekf_8214_struct.heading_source, self.ekf_8214_struct.flags_82_14)
       else:
          ret_str = ',,,,'
    elif (format_in == 24):
       if (self.ekf_8215_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8215_struct.inten_N, self.ekf_8215_struct.inten_E, self.ekf_8215_struct.inten_D, self.ekf_8215_struct.inclination, self.ekf_8215_struct.declination, self.ekf_8215_struct.flags_82_15)
       else:
          ret_str = ',,,,,,'
    elif (format_in == 25):
       if (self.ekf_8220_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8220_struct.geom_alt, self.ekf_8220_struct.geopot_alt, self.ekf_8220_struct.temp, self.ekf_8220_struct.pressure, self.ekf_8220_struct.density, self.ekf_8220_struct.flags_82_20)
       else:
          ret_str = ',,,,,,'
    elif (format_in == 26):
       if (self.ekf_8221_struct != None):
          ret_str = '{:-14.8f},{:-d},'.format(self.ekf_8221_struct.pressure_altitude, self.ekf_8221_struct.flags_82_21)
       else:
          ret_str = ',,'
    elif (format_in == 27):
       if (self.ekf_8230_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8230_struct.gps_ant_offset_corr_x, self.ekf_8230_struct.gps_ant_offset_corr_y, self.ekf_8230_struct.gps_ant_offset_corr_z, self.ekf_8230_struct.flags_82_30)
       else:
          ret_str = ',,,,'
    elif (format_in == 28):
       if (self.ekf_8231_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8231_struct.gps_ant_offset_corr_UC_x, self.ekf_8231_struct.gps_ant_offset_corr_UC_y, self.ekf_8231_struct.gps_ant_offset_corr_UC_z, self.ekf_8231_struct.flags_82_31)
       else:
          ret_str = ',,,,'
    elif (format_in == 29):
       if (self.ekf_8204_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8204_struct.matrix_m11, self.ekf_8204_struct.matrix_m12, self.ekf_8204_struct.matrix_m13, self.ekf_8204_struct.matrix_m21, self.ekf_8204_struct.matrix_m22, self.ekf_8204_struct.matrix_m23, self.ekf_8204_struct.matrix_m31, self.ekf_8204_struct.matrix_m32, self.ekf_8204_struct.matrix_m33, self.ekf_8204_struct.flags_82_04)
       else:
          ret_str = ',,,,,,,,,,'

    elif (format_in == 30):
       if (self.ekf_8225_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8225_struct.mag_auto_hard_iron_offset_x, self.ekf_8225_struct.mag_auto_hard_iron_offset_y, self.ekf_8225_struct.mag_auto_hard_iron_offset_z, self.ekf_8225_struct.flags_82_25)
       else:
          ret_str = ',,,,'
    elif (format_in == 31):
       if (self.ekf_8228_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8228_struct.mag_auto_hard_iron_offset_UC_x, self.ekf_8228_struct.mag_auto_hard_iron_offset_UC_y, self.ekf_8228_struct.mag_auto_hard_iron_offset_UC_z, self.ekf_8228_struct.flags_82_28)
       else:
          ret_str = ',,,,'
    elif (format_in == 32):
       if (self.ekf_8226_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8226_struct.mag_auto_soft_iron_m11, self.ekf_8226_struct.mag_auto_soft_iron_m12, self.ekf_8226_struct.mag_auto_soft_iron_m13, self.ekf_8226_struct.mag_auto_soft_iron_m21, self.ekf_8226_struct.mag_auto_soft_iron_m22, self.ekf_8226_struct.mag_auto_soft_iron_m23, self.ekf_8226_struct.mag_auto_soft_iron_m31, self.ekf_8226_struct.mag_auto_soft_iron_m32, self.ekf_8226_struct.mag_auto_soft_iron_m33, self.ekf_8226_struct.flags_82_26)
       else:
          ret_str = ',,,,,,,,,,'
    elif (format_in == 33):
       if (self.ekf_8229_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8229_struct.mag_auto_soft_iron_UC_m11, self.ekf_8229_struct.mag_auto_soft_iron_UC_m12, self.ekf_8229_struct.mag_auto_soft_iron_UC_m13, self.ekf_8229_struct.mag_auto_soft_iron_UC_m21, self.ekf_8229_struct.mag_auto_soft_iron_UC_m22, self.ekf_8229_struct.mag_auto_soft_iron_UC_m23, self.ekf_8229_struct.mag_auto_soft_iron_UC_m31, self.ekf_8229_struct.mag_auto_soft_iron_UC_m32, self.ekf_8229_struct.mag_auto_soft_iron_UC_m33, self.ekf_8229_struct.flags_82_29)
       else:
          ret_str = ',,,,,,,,,,'
  
    # elif (format_in == 30):
       # if (self.ekf_8227_struct != None):
          # ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8227_struct.mag_comp_x, self.ekf_8227_struct.mag_comp_y, self.ekf_8227_struct.mag_comp_z, self.ekf_8227_struct.flags_82_27)
       # else:
          # ret_str = ',,,,'
    # elif (format_in == 31):
       # if (self.ekf_821A_struct != None):
          # ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_821A_struct.mag_bias_x, self.ekf_821A_struct.mag_bias_y, self.ekf_821A_struct.mag_bias_z, self.ekf_821A_struct.flags_82_1a)
       # else:
          # ret_str = ',,,,'
    # elif (format_in == 32):
       # if (self.ekf_821B_struct != None):
          # ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_821B_struct.mag_bias_UC_x, self.ekf_821B_struct.mag_bias_UC_y, self.ekf_821B_struct.mag_bias_UC_z, self.ekf_821B_struct.flags_82_1b)
       # else:
          # ret_str = ',,,,'
    # elif (format_in == 33):
       # if (self.ekf_8223_struct != None):
          # ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8223_struct.mag_SF_x, self.ekf_8223_struct.mag_SF_y, self.ekf_8223_struct.mag_SF_z, self.ekf_8223_struct.flags_82_23)
       # else:
          # ret_str = ',,,,'
    # elif (format_in == 34):
       # if (self.ekf_8224_struct != None):
          # ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_8224_struct.mag_SF_UC_x, self.ekf_8224_struct.mag_SF_UC_y, self.ekf_8224_struct.mag_SF_UC_z, self.ekf_8224_struct.flags_82_24)
       # else:
          # ret_str = ',,,,'

    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format_debug(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       if (self.ekf_8211_struct != None):
          ret_str = '{:-4d},{:-4d},{:-12.4f},'.format(self.ekf_8211_struct.flags_82_11, self.ekf_8211_struct.ekf_week, self.ekf_8211_struct.ekf_tow)
       else:
          ret_str = ',,,'

    elif (format_in == 1):
       if (self.ekf_8210_struct != None):
          ret_str = '{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},{:-d},'.format(self.ekf_8210_struct.ekf_state, self.ekf_8210_struct.ekf_mode, self.ekf_8210_struct.flags_82_10, \
                                                self.ekf_8210_struct.imu_unavailable, self.ekf_8210_struct.gps_unavailable, self.ekf_8210_struct.matrix_sing_in_calc, \
                                                self.ekf_8210_struct.pos_cov_var_high, self.ekf_8210_struct.vel_cov_var_high, self.ekf_8210_struct.att_cov_var_high, self.ekf_8210_struct.NaN_in_soln, self.ekf_8210_struct.gyro_bias_est_high, self.ekf_8210_struct.accel_bias_est_high, \
                                                self.ekf_8210_struct.gyro_sf_est_high, self.ekf_8210_struct.accel_sf_est_high, self.ekf_8210_struct.att_not_initialized, self.ekf_8210_struct.pos_vel_not_initialized, self.ekf_8210_struct.mag_bias_est_high, self.ekf_8210_struct.gps_antenna_offset_corr_est_high, \
                                                self.ekf_8210_struct.mag_hard_iron_est_high, self.ekf_8210_struct.mag_soft_iron_est_high)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 2):
       if (self.ekf_8250_struct != None):
          ret_str = '{:-10d},{:-10d},{:-10d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-10d},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8250_struct.attitude_init_roll_pitch_start_time, self.ekf_8250_struct.global_time_ms, self.ekf_8250_struct.rel_global_time_ms,\
                            self.ekf_8250_struct.delta_v_x, self.ekf_8250_struct.delta_v_y, self.ekf_8250_struct.delta_v_z,\
                            self.ekf_8250_struct.delta_theta_x, self.ekf_8250_struct.delta_theta_y, self.ekf_8250_struct.delta_theta_z,\
                            self.ekf_8250_struct.pressure_mbar, self.ekf_8250_struct.pressure_temp_degc, self.ekf_8250_struct.mag_meas_time_ms, self.ekf_8250_struct.mag_x, self.ekf_8250_struct.mag_y, self.ekf_8250_struct.mag_z)
       else:
          ret_str = ',,,,,,,,,,,,,,,'

    elif (format_in == 3):
       if (self.ekf_8257_struct != None):
          ret_str = '{:-2d},{:-12.4f},{:-12.4f},{:-10d},{:-12.4f},{:-12.4f},{:-2d},{:-10d},{:-2d},{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-2d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8257_struct.gps_data_new, self.ekf_8257_struct.gps_tow_from_gps_rcvr, self.ekf_8257_struct.gps_tow_filter_class_attr,\
                            self.ekf_8257_struct.gps_meas_time_ms, self.ekf_8257_struct.filter_tow_at_gps_meas,\
                            self.ekf_8257_struct.gps_latency, self.ekf_8257_struct.gps_outage,\
                            self.ekf_8257_struct.last_pps_set_ms, self.ekf_8257_struct.pps_flag, self.ekf_8257_struct.gps_time_valid_flags,\
                            self.ekf_8257_struct.gps_lat, self.ekf_8257_struct.gps_lon,self.ekf_8257_struct.gps_ht,\
                            self.ekf_8257_struct.gps_vel_n, self.ekf_8257_struct.gps_vel_e, self.ekf_8257_struct.gps_vel_d, \
                            self.ekf_8257_struct.gps_pos_n_1sigma, self.ekf_8257_struct.gps_pos_e_1sigma, self.ekf_8257_struct.gps_pos_d_1sigma, \
                            self.ekf_8257_struct.gps_vel_n_1sigma, self.ekf_8257_struct.gps_vel_e_1sigma, self.ekf_8257_struct.gps_vel_d_1sigma, \
                            self.ekf_8257_struct.gps_fix_type, \
                            self.ekf_8257_struct.horizontal_accuracy, self.ekf_8257_struct.vertical_accuracy, \
                            self.ekf_8257_struct.speed, self.ekf_8257_struct.ground_speed, self.ekf_8257_struct.heading, \
                            self.ekf_8257_struct.speed_accuracy, self.ekf_8257_struct.heading_accuracy)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 4):
       if (self.ekf_8251_struct != None):
          ret_str = '{:-2d},{:-10d},{:-10.4f},{:-10.4f},{:-10.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8251_struct.attitude_initialized, self.ekf_8251_struct.rel_covariance_process_start_time_ms,\
                            self.ekf_8251_struct.P_covariance_dt_accum, self.ekf_8251_struct.covariance_dt_accum, self.ekf_8251_struct.mag_dt_accum,\
                            self.ekf_8251_struct.grav_x, self.ekf_8251_struct.grav_y, self.ekf_8251_struct.grav_z,\
                            self.ekf_8251_struct.q_ned2body_q0, self.ekf_8251_struct.q_ned2body_q1, self.ekf_8251_struct.q_ned2body_q2, self.ekf_8251_struct.q_ned2body_q3)
                            # self.ekf_8251_struct.gravity_limit_start_time_ms,\
                            # self.ekf_8251_struct.r_gravity_x, self.ekf_8251_struct.r_gravity_y, self.ekf_8251_struct.r_gravity_z,\
                            # self.ekf_8251_struct.S_gravity_cov_x, self.ekf_8251_struct.S_gravity_cov_y, self.ekf_8251_struct.S_gravity_cov_z)
       else:  
          ret_str = ',,,,,,,,,,,,'

    elif (format_in == 5):
       if (self.ekf_8252_struct != None):
          ret_str = '{:-12.4f},{:-10d},{:-2d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8252_struct.gps_tow_filter_class_attr, self.ekf_8252_struct.last_attitude_buffer_stored_ms,\
                            self.ekf_8252_struct.has_interpolated_attitude, self.ekf_8252_struct.interp_att_tow,\
                            self.ekf_8252_struct.interp_att_q0, self.ekf_8252_struct.interp_att_q1, self.ekf_8252_struct.interp_att_q2, self.ekf_8252_struct.interp_att_q3)
       else:  
          ret_str = ',,,,,,,,'

    elif (format_in == 6):
       if (self.ekf_8253_struct != None):
          ret_str = '{:-12.4f},{:-10d},{:-2d},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},\
                     {:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8253_struct.gps_tow_filter_class_attr, self.ekf_8253_struct.last_state_buffer_stored_ms,\
                            self.ekf_8253_struct.has_interpolated_state, self.ekf_8253_struct.interp_state_tow,\
                            self.ekf_8253_struct.interp_state_lat, self.ekf_8253_struct.interp_state_lon, self.ekf_8253_struct.interp_state_ht,\
                            self.ekf_8253_struct.interp_state_vned_n, self.ekf_8253_struct.interp_state_vned_e, self.ekf_8253_struct.interp_state_vned_d,\
                            self.ekf_8253_struct.interp_state_q0, self.ekf_8253_struct.interp_state_q1, self.ekf_8253_struct.interp_state_q2, self.ekf_8253_struct.interp_state_q3,\
                            self.ekf_8253_struct.interp_state_gyro_rate_x, self.ekf_8253_struct.interp_state_gyro_rate_y, self.ekf_8253_struct.interp_state_gyro_rate_z,\
                            self.ekf_8253_struct.interp_state_gyro_bias_x, self.ekf_8253_struct.interp_state_gyro_bias_y, self.ekf_8253_struct.interp_state_gyro_bias_z,\
                            self.ekf_8253_struct.interp_state_gyro_sf_x, self.ekf_8253_struct.interp_state_gyro_sf_y, self.ekf_8253_struct.interp_state_gyro_sf_z,\
                            self.ekf_8253_struct.interp_state_ant_lever_arm_error_x, self.ekf_8253_struct.interp_state_ant_lever_arm_error_y, self.ekf_8253_struct.interp_state_ant_lever_arm_error_z)
       else:  
          ret_str = ',,,,,,,,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 7):
       if (self.ekf_8254_struct != None):
          ret_str = '{:-10d},{:-14.8f},{:-14.8f},{:-14.8f},{:-2d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8254_struct.manual_init_timestamp_ms,\
                            self.ekf_8254_struct.local_inclination, self.ekf_8254_struct.local_declination, self.ekf_8254_struct.local_magnitude,\
                            self.ekf_8254_struct.has_reference_position,\
                            self.ekf_8254_struct.lat_ref, self.ekf_8254_struct.lon_ref, self.ekf_8254_struct.ht_ref,\
                            self.ekf_8254_struct.init_attitude_roll, self.ekf_8254_struct.init_attitude_pitch, self.ekf_8254_struct.init_attitude_yaw,\
                            self.ekf_8254_struct.Q_Gyro_White_Noise_x, self.ekf_8254_struct.Q_Gyro_White_Noise_y, self.ekf_8254_struct.Q_Gyro_White_Noise_z)
       else:  
          ret_str = ',,,,,,,,,,,,,,'

    elif (format_in == 8):
       if (self.ekf_8255_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},\
                     {:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},\
                     {:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8255_struct.P_omega_accum_x, self.ekf_8255_struct.P_omega_accum_y, self.ekf_8255_struct.P_omega_accum_z, \
                            self.ekf_8255_struct.P_omega_prime_accum_x, self.ekf_8255_struct.P_omega_prime_accum_y, self.ekf_8255_struct.P_omega_prime_accum_z, \
                            self.ekf_8255_struct.P_a_accum_x, self.ekf_8255_struct.P_a_accum_y, self.ekf_8255_struct.P_a_accum_z, \
                            self.ekf_8255_struct.P_a_prime_accum_x, self.ekf_8255_struct.P_a_prime_accum_y, self.ekf_8255_struct.P_a_prime_accum_z, \
                            self.ekf_8255_struct.F_0, self.ekf_8255_struct.F_1, self.ekf_8255_struct.F_2, self.ekf_8255_struct.F_3, \
                            self.ekf_8255_struct.F_4, self.ekf_8255_struct.F_5, self.ekf_8255_struct.F_6, self.ekf_8255_struct.F_7, \
                            self.ekf_8255_struct.F_8, self.ekf_8255_struct.F_9, self.ekf_8255_struct.F_10, self.ekf_8255_struct.F_11, \
                            self.ekf_8255_struct.F_12, self.ekf_8255_struct.F_13, self.ekf_8255_struct.F_14, self.ekf_8255_struct.F_15, \
                            self.ekf_8255_struct.P_Euler_x, self.ekf_8255_struct.P_Euler_y, self.ekf_8255_struct.P_Euler_z, \
                            self.ekf_8255_struct.P_Tilt_Yaw_x, self.ekf_8255_struct.P_Tilt_Yaw_y, self.ekf_8255_struct.P_Tilt_Yaw_z)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 9):
       if (self.ekf_8256_struct != None):
          ret_str = '{:-2d},{:-10d},{:-10d},{:-2d},{:-10d},{:-2d},{:-2d},{:-2d},{:-2d},{:-10.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8256_struct.mag_data_new, self.ekf_8256_struct.mag_model_valid_start_time,\
                            self.ekf_8256_struct.mag_valid_start_time, self.ekf_8256_struct.mag_model_valid,\
                            self.ekf_8256_struct.magnetometer_rate_limit_start_time,\
                            self.ekf_8256_struct.adaptive_filter_autoadaptive_flag, self.ekf_8256_struct.adaptive_filter_legacy_flag,\
                            self.ekf_8256_struct.mag_dip_angle_error_adaptive_measurement_enable, self.ekf_8256_struct.Q_boost_enable,\
                            self.ekf_8256_struct.rate_limit_mag_dt_accum,\
                            self.ekf_8256_struct.hard_iron_white_noise_1sigma_x, self.ekf_8256_struct.hard_iron_white_noise_1sigma_y, self.ekf_8256_struct.hard_iron_white_noise_1sigma_z,\
                            self.ekf_8256_struct.mag_soft_iron_white_noise_00, self.ekf_8256_struct.mag_soft_iron_white_noise_11, self.ekf_8256_struct.mag_soft_iron_white_noise_22, \
                            self.ekf_8256_struct.mag_white_noise_x, self.ekf_8256_struct.mag_white_noise_y, self.ekf_8256_struct.mag_white_noise_z)
       else:  
          ret_str = ',,,,,,,,,,,,,,,,,,,'

    elif (format_in == 10):
       if (self.ekf_8258_struct != None):
          ret_str = '{:-10d},{:-12.4f},{:-12.4f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8258_struct.gps_rate_limit_start_tme_ms, self.ekf_8258_struct.rate_limit_gps_tow, self.ekf_8258_struct.rate_limit_filter_tow,\
                            self.ekf_8258_struct.rate_limit_lat_ref, self.ekf_8258_struct.rate_limit_lon_ref, self.ekf_8258_struct.rate_limit_ht_ref,\
                            self.ekf_8258_struct.rate_limit_gps_lat, self.ekf_8258_struct.rate_limit_gps_lon, self.ekf_8258_struct.rate_limit_gps_ht,\
                            self.ekf_8258_struct.rate_limit_gps_vel_n, self.ekf_8258_struct.rate_limit_gps_vel_e, self.ekf_8258_struct.rate_limit_gps_vel_d,\
                            self.ekf_8258_struct.r_position_x, self.ekf_8258_struct.r_position_y, self.ekf_8258_struct.r_position_z,\
                            self.ekf_8258_struct.r_velocity_x, self.ekf_8258_struct.r_velocity_y, self.ekf_8258_struct.r_velocity_z,\
                            self.ekf_8258_struct.S_resid_position_x, self.ekf_8258_struct.S_resid_position_y, self.ekf_8258_struct.S_resid_position_z,\
                            self.ekf_8258_struct.S_resid_velocity_x, self.ekf_8258_struct.S_resid_velocity_y, self.ekf_8258_struct.S_resid_velocity_z)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 11):
       if (self.ekf_8259_struct != None):
          ret_str = '{:-10d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8259_struct.heading_rate_limit_start_time, self.ekf_8259_struct.residual_heading,\
                            self.ekf_8259_struct.z_heading, self.ekf_8259_struct.y_heading,\
                            self.ekf_8259_struct.R_heading, self.ekf_8259_struct.INV_PARAM_Heading,\
                            self.ekf_8259_struct.H_heading_X_Real, self.ekf_8259_struct.H_heading_X_I,\
                            self.ekf_8259_struct.H_heading_X_J, self.ekf_8259_struct.H_heading_X_K)
       else:
          ret_str = ',,,,,,,,,,'

    elif (format_in == 12):
       if (self.ekf_825A_struct != None):
          ret_str = '{:-10d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-10d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_825A_struct.gravity_limit_start_time_ms,\
                            self.ekf_825A_struct.r_gravity_x, self.ekf_825A_struct.r_gravity_y, self.ekf_825A_struct.r_gravity_z,\
                            self.ekf_825A_struct.S_gravity_cov_x, self.ekf_825A_struct.S_gravity_cov_y, self.ekf_825A_struct.S_gravity_cov_z,\
                            self.ekf_825A_struct.pressure_limit_start_time_ms, self.ekf_825A_struct.r_pressure, self.ekf_825A_struct.z_pressure,\
                            self.ekf_825A_struct.y_pressure, self.ekf_825A_struct.R_pressure)
       else:
          ret_str = ',,,,,,,,,,,,'

    elif (format_in == 13):
       if (self.ekf_825B_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_825B_struct.omega_earth_rate_x, self.ekf_825B_struct.omega_earth_rate_y, self.ekf_825B_struct.omega_earth_rate_z,\
                            self.ekf_825B_struct.omega_transport_rate_x, self.ekf_825B_struct.omega_transport_rate_y, self.ekf_825B_struct.omega_transport_rate_z,\
                            self.ekf_825B_struct.v_x, self.ekf_825B_struct.v_y, self.ekf_825B_struct.v_z,\
                            self.ekf_825B_struct.a_corrected_x, self.ekf_825B_struct.a_corrected_y, self.ekf_825B_struct.a_corrected_z,\
                            self.ekf_825B_struct.a_misc_x, self.ekf_825B_struct.a_misc_y, self.ekf_825B_struct.a_misc_z,\
                            self.ekf_825B_struct.a_curr_x, self.ekf_825B_struct.a_curr_y, self.ekf_825B_struct.a_curr_z,\
                            self.ekf_825B_struct.x_pos_ned_n, self.ekf_825B_struct.x_pos_ned_e, self.ekf_825B_struct.x_pos_ned_d,\
                            self.ekf_825B_struct.x_pos_ned_delta_n, self.ekf_825B_struct.x_pos_ned_delta_e, self.ekf_825B_struct.x_pos_ned_delta_d,\
                            self.ekf_825B_struct.filter_tow_recalc_llh_ref, self.ekf_825B_struct.global_time_ms_recalc_llh_ref,\
                            self.ekf_825B_struct.sensor2vehicle_offset_recalc_x, self.ekf_825B_struct.sensor2vehicle_offset_recalc_y, self.ekf_825B_struct.sensor2vehicle_offset_recalc_z,\
                            self.ekf_825B_struct.recalc_llh_lat, self.ekf_825B_struct.recalc_llh_lon, self.ekf_825B_struct.recalc_llh_ht)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'

    elif (format_in == 14):
       if (self.ekf_822A_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_822A_struct.mag_cov_m11, self.ekf_822A_struct.mag_cov_m12, self.ekf_822A_struct.mag_cov_m13, self.ekf_822A_struct.mag_cov_m21, self.ekf_822A_struct.mag_cov_m22, self.ekf_822A_struct.mag_cov_m23, self.ekf_822A_struct.mag_cov_m31, self.ekf_822A_struct.mag_cov_m32, self.ekf_822A_struct.mag_cov_m33, self.ekf_822A_struct.flags_82_2a)
       else:
          ret_str = ',,,,,,,,,,'
    elif (format_in == 15):
       if (self.ekf_822B_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_822B_struct.grav_auto_adap_noise_m11, self.ekf_822B_struct.grav_auto_adap_noise_m12, self.ekf_822B_struct.grav_auto_adap_noise_m13, self.ekf_822B_struct.grav_auto_adap_noise_m21, self.ekf_822B_struct.grav_auto_adap_noise_m22, self.ekf_822B_struct.grav_auto_adap_noise_m23, self.ekf_822B_struct.grav_auto_adap_noise_m31, self.ekf_822B_struct.grav_auto_adap_noise_m32, self.ekf_822B_struct.grav_auto_adap_noise_m33, self.ekf_822B_struct.flags_82_2b)
       else:
          ret_str = ',,,,,,,,,,'
    elif (format_in == 16):
       if (self.ekf_822C_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_822C_struct.mag_residual_x, self.ekf_822C_struct.mag_residual_y, self.ekf_822C_struct.mag_residual_z, self.ekf_822C_struct.flags_82_2c)
       else:
          ret_str = ',,,,'
    elif (format_in == 17):
       if (self.ekf_822D_struct != None):
          ret_str = '{:-14.8f},{:-14.8f},{:-14.8f},{:-d},'.format(self.ekf_822D_struct.mag_filt_residual_x, self.ekf_822D_struct.mag_filt_residual_y, self.ekf_822D_struct.mag_filt_residual_z, self.ekf_822D_struct.flags_82_2d)
       else:
          ret_str = ',,,,'

    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format_gnss_debug(self, format_in, is_last_format = False):
    ret_str = ''
    if (format_in == 0):
       if (self.ekf_8211_struct != None):
          ret_str = '{:-4d},{:-4d},{:-12.4f},'.format(self.ekf_8211_struct.flags_82_11, self.ekf_8211_struct.ekf_week, self.ekf_8211_struct.ekf_tow)
       else:
          ret_str = ',,,'

    elif (format_in == 1):
       if (self.ekf_8257_struct != None):
          ret_str = '{:-2d},{:-12.4f},{:-12.4f},{:-10d},{:-12.4f},{:-12.4f},{:-2d},{:-10d},{:-2d},{:-4d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-2d},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},{:-14.8f},'.\
                     format(self.ekf_8257_struct.gps_data_new, self.ekf_8257_struct.gps_tow_from_gps_rcvr, self.ekf_8257_struct.gps_tow_filter_class_attr,\
                            self.ekf_8257_struct.gps_meas_time_ms, self.ekf_8257_struct.filter_tow_at_gps_meas,\
                            self.ekf_8257_struct.gps_latency, self.ekf_8257_struct.gps_outage,\
                            self.ekf_8257_struct.last_pps_set_ms, self.ekf_8257_struct.pps_flag, self.ekf_8257_struct.gps_time_valid_flags,\
                            self.ekf_8257_struct.gps_lat, self.ekf_8257_struct.gps_lon,self.ekf_8257_struct.gps_ht,\
                            self.ekf_8257_struct.gps_vel_n, self.ekf_8257_struct.gps_vel_e, self.ekf_8257_struct.gps_vel_d, \
                            self.ekf_8257_struct.gps_pos_n_1sigma, self.ekf_8257_struct.gps_pos_e_1sigma, self.ekf_8257_struct.gps_pos_d_1sigma, \
                            self.ekf_8257_struct.gps_vel_n_1sigma, self.ekf_8257_struct.gps_vel_e_1sigma, self.ekf_8257_struct.gps_vel_d_1sigma, \
                            self.ekf_8257_struct.gps_fix_type, \
                            self.ekf_8257_struct.horizontal_accuracy, self.ekf_8257_struct.vertical_accuracy, \
                            self.ekf_8257_struct.speed, self.ekf_8257_struct.ground_speed, self.ekf_8257_struct.heading, \
                            self.ekf_8257_struct.speed_accuracy, self.ekf_8257_struct.heading_accuracy)
       else:
          ret_str = ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,'

    # } if (format_in == 0)..

    # Exclude the comma at the end if it is the last format set:
    if (is_last_format):
       return ret_str[:-1]
    else:
       return ret_str
    # } if (is_last_format)..

 def format_channel_name(self, format_in):
    if (format_in == 0):
       return ['EKF_TFlags', 'EKF_Week', 'EKF_TOW']
    elif (format_in == 1):
       # return ['EKF_State_x8210','EKF_Mode_x8210','Flags_x8210']
       return ['EKF_State_x8210','EKF_Mode_x8210','Flags_x8210','Flag_IMU_Unavailable_x8210','Flag_GPS_Unavailable_x8210','Flag_Matrix_Singularity_x8210','Flag_Pos_Cov_High_x8210','Flag_Vel_Cov_High_x8210','Flag_Att_Cov_High_x8210','Flag_NaN_in_Soln_x8210','Flag_Gyro_Bias_Est_High_x8210','Flag_Accel_Bias_Est_High_x8210','Flag_Gyro_SF_Est_High_x8210','Flag_Accel_SF_Est_High_x8210','Flag_Att_Uninitialized_x8210','Flag_Pos_Vel_Uninitialized_x8210','Flag_Mag_Bias_Est_High_x8210','Flag_GPS_Ant_Off_Corr_Est_High_x8210','Flag_Mag_Hard_Iron_Est_High_x8210','Flag_Mag_Soft_Iron_Est_High_x8210']
    elif (format_in == 2):
       return ['Lat_x8201','Long_x8201','Ht_Abv_Ellips_x8201','Flags_x8201']
    elif (format_in == 3):
       return ['LLH_UC_N_x8208','LLH_UC_E_x8208','LLH_UC_D_x8208','Flags_x8208']
    elif (format_in == 4):
       return ['Vel_N_x8202','Vel_E_x8202','Vel_D_x8202','Flags_x8202']
    elif (format_in == 5):
       return ['Vel_UC_N_x8209','Vel_UC_E_x8209','Vel_UC_D_x8209','Flags_x8209']
    elif (format_in == 6):
       return ['Roll_x8205','Pitch_x8205','Yaw_x8205','Flags_x8205']
    elif (format_in == 7):
       return ['Roll_UC_x820A','Pitch_UC_x820A','Yaw_UC_x820A','Flags_x820A']
    elif (format_in == 8):
       return ['q0_x8203','q1_x8203','q2_x8203','q3_x8203','Flags_x8203']
    elif (format_in == 9):
       return ['q0_UC_x8212','q1_UC_x8212','q2_UC_x8212','q3_UC_x8212','Flags_x8212']
    elif (format_in == 10):
       return ['X_Acc_Bias_x8207','Y_Acc_Bias_x8207','Z_Acc_Bias_x8207','Flags_x8207']
    elif (format_in == 11):
       return ['X_Acc_Bias_UC_x820C','Y_Acc_Bias_UC_x820C','Z_Acc_Bias_UC_x820C','Flags_x820C']
    elif (format_in == 12):
       return ['X_Acc_SF_x8217','Y_Acc_SF_x8217','Z_Acc_SF_x8217','Flags_x8217']
    elif (format_in == 13):
       return ['X_Acc_SF_UC_x8219','Y_Acc_SF_UC_x8219','Z_Acc_SF_UC_x8219','Flags_x8219']
    elif (format_in == 14):
       return ['X_Gyro_Bias_x8206','Y_Gyro_Bias_x8206','Z_Gyro_Bias_x8206','Flags_x8206']
    elif (format_in == 15):
       return ['X_Gyro_Bias_UC_x820B','Y_Gyro_Bias_UC_x820B','Z_Gyro_Bias_UC_x820B','Flags_x820B']
    elif (format_in == 16):
       return ['X_Gyro_SF_x8216','Y_Gyro_SF_x8216','Z_Gyro_SF_x8216','Flags_x8216']
    elif (format_in == 17):
       return ['X_Gyro_SF_UC_x8218','Y_Gyro_SF_UC_x8218','Z_Gyro_SF_UC_x8218','Flags_x8218']
    elif (format_in == 18):
       return ['X_Acc_Lin_x820D','Y_Acc_Lin_x820D','Z_Acc_Lin_x820D','Flags_x820D']
    elif (format_in == 19):
       return ['X_Acc_Comp_x821C','Y_Acc_Comp_x821C','Z_Acc_Comp_x821C','Flags_x821C']
    elif (format_in == 20):
       return ['X_Gyro_Comp_x820E','Y_Gyro_Comp_x820E','Z_Gyro_Comp_x820E','Flags_x820E']
    elif (format_in == 21):
       return ['X_Gravity_x8213','Y_Gravity_x8213','Z_Gravity_x8213','Flags_x8213']
    elif (format_in == 22):
       return ['WGS84_Gravity_x820F','Flags_x820F']
    elif (format_in == 23):
       return ['True_North_x8214','North_UC_x8214','Head_Src_x8214','Flags_x8214']
    elif (format_in == 24):
       return ['WMM_N_x8215','WMM_E_x8215','WMM_D_x8215','Incl_x8215','Decl_x8215','Flags_x8215']
    elif (format_in == 25):
       return ['SAM_Geomet_Alt_x8220','SAM_Geopot_Alt_x8220','SAM_Temperature_x8220','SAM_Pressure_x8220','SAM_Density_x8220','Flags_x8220']
    elif (format_in == 26):
       return ['Pressure_Alt_x8221','Flags_x8221']
    elif (format_in == 27):
       return ['X_Ant_Off_Err_x8230','Y_Ant_Off_Err_x8230','Z_Ant_Off_Err_x8230','Flags_x8230']
    elif (format_in == 28):
       return ['X_Ant_Off_Err_UC_x8231','Y_Ant_Off_Err_UC_x8231','Z_Ant_Off_Err_UC_x8231','Flags_x8231']
    elif (format_in == 29):
       return ['M11_x8204','M12_x8204','M13_x8204','M21_x8204','M22_x8204','M23_x8204','M31_x8204','M32_x8204','M33_x8204','Flags_x8204']

    elif (format_in == 30):
       return ['X_Mag_Comp_x8227','Y_Mag_Comp_x8227','Z_Mag_Comp_x8227','Flags_x8227']
    elif (format_in == 31):
       return ['X_Mag_Bias_x821A','Y_Mag_Bias_x821A','Z_Mag_Bias_x821A','Flags_x821A']
    elif (format_in == 32):
       return ['X_Mag_Bias_UC_x821B','Y_Mag_Bias_UC_x821B','Z_Mag_Bias_UC_x821B','Flags_x821B']
    elif (format_in == 33):
       return ['X_Mag_SF_x8223','Y_Mag_SF_x8223','Z_Mag_SF_x8223','Flags_x8223']
    elif (format_in == 34):
       return ['X_Mag_SF_UC_x8224','Y_Mag_SF_UC_x8224','Z_Mag_SF_UC_x8224','Flags_x8224']
    elif (format_in == 35):
       return ['X_Mag_Auto_Hard_Iron_Offset_x8225','Y_Mag_Auto_Hard_Iron_Offset_x8225','Z_Mag_Auto_Hard_Iron_Offset_x8225','Flags_x8225']
    elif (format_in == 36):
       return ['X_Mag_Auto_Hard_Iron_Offset_UC_x8228','Y_Mag_Auto_Hard_Iron_Offset_UC_x8228','Z_Mag_Auto_Hard_Iron_Offset_UC_x8228','Flags_x8228']
    elif (format_in == 37):
       return ['Mag_Auto_Soft_Iron_M11_x8226','Mag_Auto_Soft_Iron_M12_x8226','Mag_Auto_Soft_Iron_M13_x8226','Mag_Auto_Soft_Iron_M21_x8226','Mag_Auto_Soft_Iron_M22_x8226','Mag_Auto_Soft_Iron_M23_x8226','Mag_Auto_Soft_Iron_M31_x8226','Mag_Auto_Soft_Iron_M32_x8226','Mag_Auto_Soft_Iron_M33_x8226','Flags_x8226']
    elif (format_in == 38):
       return ['Mag_Auto_Soft_Iron_UC_M11_x8229','Mag_Auto_Soft_Iron_UC_M12_x8229','Mag_Auto_Soft_Iron_UC_M13_x8229','Mag_Auto_Soft_Iron_UC_M21_x8229','Mag_Auto_Soft_Iron_UC_M22_x8229','Mag_Auto_Soft_Iron_UC_M23_x8229','Mag_Auto_Soft_Iron_UC_M31_x8229','Mag_Auto_Soft_Iron_UC_M32_x8229','Mag_Auto_Soft_Iron_UC_M33_x8229','Flags_x8229']
    elif (format_in == 39):
       return ['Mag_Auto_Adap_Noise_M11_x822A','Mag_Auto_Adap_Noise_M12_x822A','Mag_Auto_Adap_Noise_M13_x822A','Mag_Auto_Adap_Noise_M21_x822A','Mag_Auto_Adap_Noise_M22_x822A','Mag_Auto_Adap_Noise_M23_x822A','Mag_Auto_Adap_Noise_M31_x822A','Mag_Auto_Adap_Noise_M32_x822A','Mag_Auto_Adap_Noise_M33_x822A','Flags_x8226']
    elif (format_in == 40):
       return ['Grav_Auto_Adap_Noise_M11_x822B','Grav_Auto_Adap_Noise_M12_x822B','Grav_Auto_Adap_Noise_M13_x822B','Grav_Auto_Adap_Noise_M21_x822B','Grav_Auto_Adap_Noise_M22_x822B','Grav_Auto_Adap_Noise_M23_x822B','Grav_Auto_Adap_Noise_M31_x822B','Grav_Auto_Adap_Noise_M32_x822B','Grav_Auto_Adap_Noise_M33_x822B','Flags_x8226']
    elif (format_in == 41):
       return ['X_Mag_Residual_x822C','Y_Mag_Residual_x822C','Z_Mag_Residual_x822C','Flags_x822C']
    elif (format_in == 42):
       return ['X_Mag_Filt_Residual_x822D','Y_Mag_Filt_Residual_x822D','Z_Mag_Filt_Residual_x822D','Flags_x822D']

    return 'EKF_format_channel_name'

 def format_channel_value(self, format_in):
    if (format_in == 0):
       if (self.ekf_8211_struct != None):
          return [self.ekf_8211_struct.flags_82_11, self.ekf_8211_struct.ekf_week, self.ekf_8211_struct.ekf_tow]
       else:
          return None
    elif (format_in == 1):
       if (self.ekf_8210_struct != None):
          # return [self.ekf_8210_struct.ekf_state, self.ekf_8210_struct.ekf_mode, self.ekf_8210_struct.flags_82_10]
          return [self.ekf_8210_struct.ekf_state, self.ekf_8210_struct.ekf_mode, self.ekf_8210_struct.flags_82_10, \
                  self.ekf_8210_struct.imu_unavailable, self.ekf_8210_struct.gps_unavailable, self.ekf_8210_struct.matrix_sing_in_calc, \
                  self.ekf_8210_struct.pos_cov_var_high, self.ekf_8210_struct.vel_cov_var_high, self.ekf_8210_struct.att_cov_var_high, \
                  self.ekf_8210_struct.NaN_in_soln, self.ekf_8210_struct.gyro_bias_est_high, self.ekf_8210_struct.accel_bias_est_high, \
                  self.ekf_8210_struct.gyro_sf_est_high, self.ekf_8210_struct.accel_sf_est_high, self.ekf_8210_struct.att_not_initialized, \
                  self.ekf_8210_struct.pos_vel_not_initialized, self.ekf_8210_struct.mag_bias_est_high, self.ekf_8210_struct.gps_antenna_offset_corr_est_high, \
                  self.ekf_8210_struct.mag_hard_iron_est_high, self.ekf_8210_struct.mag_soft_iron_est_high]
       else:
          return None
    elif (format_in == 2):
       if (self.ekf_8201_struct != None):
          return [self.ekf_8201_struct.ekf_pos_llh_lat, self.ekf_8201_struct.ekf_pos_llh_lon, self.ekf_8201_struct.ekf_pos_llh_ht, self.ekf_8201_struct.flags_82_01]
       else:
          return None
    elif (format_in == 3):
       if (self.ekf_8208_struct != None):
          return [self.ekf_8208_struct.ekf_pos_llh_UC_lat, self.ekf_8208_struct.ekf_pos_llh_UC_lon, self.ekf_8208_struct.ekf_pos_llh_UC_ht, self.ekf_8208_struct.flags_82_08]
       else:
          return None
    elif (format_in == 4):
       if (self.ekf_8202_struct != None):
          return [self.ekf_8202_struct.ekf_vned_N, self.ekf_8202_struct.ekf_vned_E, self.ekf_8202_struct.ekf_vned_D, self.ekf_8202_struct.flags_82_02]
       else:
          return None
    elif (format_in == 5):
       if (self.ekf_8209_struct != None):
          return [self.ekf_8209_struct.ekf_vned_UC_N, self.ekf_8209_struct.ekf_vned_UC_E, self.ekf_8209_struct.ekf_vned_UC_D, self.ekf_8209_struct.flags_82_09]
       else:
          return None
    elif (format_in == 6):
       if (self.ekf_8205_struct != None):
          return [self.ekf_8205_struct.euler_angle_roll, self.ekf_8205_struct.euler_angle_pitch, self.ekf_8205_struct.euler_angle_yaw, self.ekf_8205_struct.flags_82_05]
       else:
          return None
    elif (format_in == 7):
       if (self.ekf_820A_struct != None):
          return [self.ekf_820A_struct.euler_angle_UC_roll, self.ekf_820A_struct.euler_angle_UC_pitch, self.ekf_820A_struct.euler_angle_UC_yaw, self.ekf_820A_struct.flags_82_0a]
       else:
          return None
    elif (format_in == 8):
       if (self.ekf_8203_struct != None):
          return [self.ekf_8203_struct.quat_0, self.ekf_8203_struct.quat_1, self.ekf_8203_struct.quat_2, self.ekf_8203_struct.quat_3, self.ekf_8203_struct.flags_82_03]
       else:
          return None
    elif (format_in == 9):
       if (self.ekf_8212_struct != None):
          return [self.ekf_8212_struct.quat_UC_0, self.ekf_8212_struct.quat_UC_1, self.ekf_8212_struct.quat_UC_2, self.ekf_8212_struct.quat_UC_3, self.ekf_8212_struct.flags_82_12]
       else:
          return None

    elif (format_in == 10):
       if (self.ekf_8207_struct != None):
          return [self.ekf_8207_struct.accel_bias_x, self.ekf_8207_struct.accel_bias_y, self.ekf_8207_struct.accel_bias_z, self.ekf_8207_struct.flags_82_07]
       else:
          return None
    elif (format_in == 11):
       if (self.ekf_820C_struct != None):
          return [self.ekf_820C_struct.accel_bias_UC_x, self.ekf_820C_struct.accel_bias_UC_y, self.ekf_820C_struct.accel_bias_UC_z, self.ekf_820C_struct.flags_82_0c]
       else:
          return None
    elif (format_in == 12):
       if (self.ekf_8217_struct != None):
          return [self.ekf_8217_struct.accel_SF_x, self.ekf_8217_struct.accel_SF_y, self.ekf_8217_struct.accel_SF_z, self.ekf_8217_struct.flags_82_17]
       else:
          return None
    elif (format_in == 13):
       if (self.ekf_8219_struct != None):
          return [self.ekf_8219_struct.accel_SF_UC_x, self.ekf_8219_struct.accel_SF_UC_y, self.ekf_8219_struct.accel_SF_UC_z, self.ekf_8219_struct.flags_82_19]
       else:
          return None
    elif (format_in == 14):
       if (self.ekf_8206_struct != None):
          return [self.ekf_8206_struct.gyro_bias_x, self.ekf_8206_struct.gyro_bias_y, self.ekf_8206_struct.gyro_bias_z, self.ekf_8206_struct.flags_82_06]
       else:
          return None
    elif (format_in == 15):
       if (self.ekf_820B_struct != None):
          return [self.ekf_820B_struct.gyro_bias_UC_x, self.ekf_820B_struct.gyro_bias_UC_y, self.ekf_820B_struct.gyro_bias_UC_z, self.ekf_820B_struct.flags_82_0b]
       else:
          return None
    elif (format_in == 16):
       if (self.ekf_8216_struct != None):
          return [self.ekf_8216_struct.gyro_SF_x, self.ekf_8216_struct.gyro_SF_y, self.ekf_8216_struct.gyro_SF_z, self.ekf_8216_struct.flags_82_16]
       else:
          return None
    elif (format_in == 17):
       if (self.ekf_8218_struct != None):
          return [self.ekf_8218_struct.gyro_SF_UC_x, self.ekf_8218_struct.gyro_SF_UC_y, self.ekf_8218_struct.gyro_SF_UC_z, self.ekf_8218_struct.flags_82_18]
       else:
          return None
    elif (format_in == 18):
       if (self.ekf_820D_struct != None):
          return [self.ekf_820D_struct.lin_accel_x, self.ekf_820D_struct.lin_accel_y, self.ekf_820D_struct.lin_accel_z, self.ekf_820D_struct.flags_82_0d]
       else:
          return None
    elif (format_in == 19):
       if (self.ekf_821C_struct != None):
          return [self.ekf_821C_struct.comp_accel_x, self.ekf_821C_struct.comp_accel_y, self.ekf_821C_struct.comp_accel_z, self.ekf_821C_struct.flags_82_1c]
       else:
          return None

    elif (format_in == 20):
       if (self.ekf_820E_struct != None):
          return [self.ekf_820E_struct.comp_gyro_x, self.ekf_820E_struct.comp_gyro_y, self.ekf_820E_struct.comp_gyro_z, self.ekf_820E_struct.flags_82_0e]
       else:
          return None
    elif (format_in == 21):
       if (self.ekf_8213_struct != None):
          return [self.ekf_8213_struct.grav_vect_x, self.ekf_8213_struct.grav_vect_y, self.ekf_8213_struct.grav_vect_z, self.ekf_8213_struct.flags_82_13]
       else:
          return None
    elif (format_in == 22):
       if (self.ekf_820F_struct != None):
          return [self.ekf_820F_struct.grav_mag, self.ekf_820F_struct.flags_82_0f]
       else:
          return None
    elif (format_in == 23):
       if (self.ekf_8214_struct != None):
          return [self.ekf_8214_struct.heading, self.ekf_8214_struct.heading_UC, self.ekf_8214_struct.heading_source, self.ekf_8214_struct.flags_82_14]
       else:
          return None
    elif (format_in == 24):
       if (self.ekf_8215_struct != None):
          return [self.ekf_8215_struct.inten_N, self.ekf_8215_struct.inten_E, self.ekf_8215_struct.inten_D, self.ekf_8215_struct.inclination, self.ekf_8215_struct.declination, self.ekf_8215_struct.flags_82_15]
       else:
          return None
    elif (format_in == 25):
       if (self.ekf_8220_struct != None):
          return [self.ekf_8220_struct.geom_alt, self.ekf_8220_struct.geopot_alt, self.ekf_8220_struct.temp, self.ekf_8220_struct.pressure, self.ekf_8220_struct.density, self.ekf_8220_struct.flags_82_20]
       else:
          return None
    elif (format_in == 26):
       if (self.ekf_8221_struct != None):
          return [self.ekf_8221_struct.pressure_altitude, self.ekf_8221_struct.flags_82_21]
       else:
          return None
    elif (format_in == 27):
       if (self.ekf_8230_struct != None):
          return [self.ekf_8230_struct.gps_ant_offset_corr_x, self.ekf_8230_struct.gps_ant_offset_corr_y, self.ekf_8230_struct.gps_ant_offset_corr_z, self.ekf_8230_struct.flags_82_30]
       else:
          return None
    elif (format_in == 28):
       if (self.ekf_8231_struct != None):
          return [self.ekf_8231_struct.gps_ant_offset_corr_UC_x, self.ekf_8231_struct.gps_ant_offset_corr_UC_y, self.ekf_8231_struct.gps_ant_offset_corr_UC_z, self.ekf_8231_struct.flags_82_31]
       else:
          return None
    elif (format_in == 29):
       if (self.ekf_8204_struct != None):
          return [self.ekf_8204_struct.matrix_m11, self.ekf_8204_struct.matrix_m12, self.ekf_8204_struct.matrix_m13, self.ekf_8204_struct.matrix_m21, self.ekf_8204_struct.matrix_m22, self.ekf_8204_struct.matrix_m23, self.ekf_8204_struct.matrix_m31, self.ekf_8204_struct.matrix_m32, self.ekf_8204_struct.matrix_m33, self.ekf_8204_struct.flags_82_04]
       else:
          return None

    elif (format_in == 30):
       if (self.ekf_8227_struct != None):
          return [self.ekf_8227_struct.mag_comp_x, self.ekf_8227_struct.mag_comp_y, self.ekf_8227_struct.mag_comp_z, self.ekf_8227_struct.flags_82_27]
       else:
          return None
    elif (format_in == 31):
       if (self.ekf_821A_struct != None):
          return [self.ekf_821A_struct.mag_bias_x, self.ekf_821A_struct.mag_bias_y, self.ekf_821A_struct.mag_bias_z, self.ekf_821A_struct.flags_82_1a]
       else:
          return None
    elif (format_in == 32):
       if (self.ekf_821B_struct != None):
          return [self.ekf_821B_struct.mag_bias_UC_x, self.ekf_821B_struct.mag_bias_UC_y, self.ekf_821B_struct.mag_bias_UC_z, self.ekf_821B_struct.flags_82_1b]
       else:
          return None
    elif (format_in == 33):
       if (self.ekf_8223_struct != None):
          return [self.ekf_8223_struct.mag_SF_x, self.ekf_8223_struct.mag_SF_y, self.ekf_8223_struct.mag_SF_z, self.ekf_8223_struct.flags_82_23]
       else:
          return None
    elif (format_in == 34):
       if (self.ekf_8224_struct != None):
          return [self.ekf_8224_struct.mag_SF_UC_x, self.ekf_8224_struct.mag_SF_UC_y, self.ekf_8224_struct.mag_SF_UC_z, self.ekf_8224_struct.flags_82_24]
       else:
          return None
    elif (format_in == 35):
       if (self.ekf_8225_struct != None):
          return [self.ekf_8225_struct.mag_auto_hard_iron_offset_x, self.ekf_8225_struct.mag_auto_hard_iron_offset_y, self.ekf_8225_struct.mag_auto_hard_iron_offset_z, self.ekf_8225_struct.flags_82_25]
       else:
          return None
    elif (format_in == 36):
       if (self.ekf_8228_struct != None):
          return [self.ekf_8228_struct.mag_auto_hard_iron_offset_UC_x, self.ekf_8228_struct.mag_auto_hard_iron_offset_UC_y, self.ekf_8228_struct.mag_auto_hard_iron_offset_UC_z, self.ekf_8228_struct.flags_82_28]
       else:
          return None
    elif (format_in == 37):
       if (self.ekf_8226_struct != None):
          return [self.ekf_8226_struct.mag_auto_soft_iron_m11, self.ekf_8226_struct.mag_auto_soft_iron_m12, self.ekf_8226_struct.mag_auto_soft_iron_m13, self.ekf_8226_struct.mag_auto_soft_iron_m21, self.ekf_8226_struct.mag_auto_soft_iron_m22, self.ekf_8226_struct.mag_auto_soft_iron_m23, self.ekf_8226_struct.mag_auto_soft_iron_m31, self.ekf_8226_struct.mag_auto_soft_iron_m32, self.ekf_8226_struct.mag_auto_soft_iron_m33, self.ekf_8226_struct.flags_82_26]
       else:
          return None
    elif (format_in == 38):
       if (self.ekf_8229_struct != None):
          return [self.ekf_8229_struct.mag_auto_soft_iron_UC_m11, self.ekf_8229_struct.mag_auto_soft_iron_UC_m12, self.ekf_8229_struct.mag_auto_soft_iron_UC_m13, self.ekf_8229_struct.mag_auto_soft_iron_UC_m21, self.ekf_8229_struct.mag_auto_soft_iron_UC_m22, self.ekf_8229_struct.mag_auto_soft_iron_UC_m23, self.ekf_8229_struct.mag_auto_soft_iron_UC_m31, self.ekf_8229_struct.mag_auto_soft_iron_UC_m32, self.ekf_8229_struct.mag_auto_soft_iron_UC_m33, self.ekf_8229_struct.flags_82_29]
       else:
          return None
    elif (format_in == 39):
       if (self.ekf_822A_struct != None):
          return [self.ekf_822A_struct.mag_cov_m11, self.ekf_822A_struct.mag_cov_m12, self.ekf_822A_struct.mag_cov_m13, self.ekf_822A_struct.mag_cov_m21, self.ekf_822A_struct.mag_cov_m22, self.ekf_822A_struct.mag_cov_m23, self.ekf_822A_struct.mag_cov_m31, self.ekf_822A_struct.mag_cov_m32, self.ekf_822A_struct.mag_cov_m33, self.ekf_822A_struct.flags_82_2a]
       else:
          return None
    elif (format_in == 40):
       if (self.ekf_822B_struct != None):
          return [self.ekf_822B_struct.grav_auto_adap_noise_m11, self.ekf_822B_struct.grav_auto_adap_noise_m12, self.ekf_822B_struct.grav_auto_adap_noise_m13, self.ekf_822B_struct.grav_auto_adap_noise_m21, self.ekf_822B_struct.grav_auto_adap_noise_m22, self.ekf_822B_struct.grav_auto_adap_noise_m23, self.ekf_822B_struct.grav_auto_adap_noise_m31, self.ekf_822B_struct.grav_auto_adap_noise_m32, self.ekf_822B_struct.grav_auto_adap_noise_m33, self.ekf_822B_struct.flags_82_2b]
       else:
          return None
    elif (format_in == 41):
       if (self.ekf_822C_struct != None):
          return [self.ekf_822C_struct.mag_residual_x, self.ekf_822C_struct.mag_residual_y, self.ekf_822C_struct.mag_residual_z, self.ekf_822C_struct.flags_82_2c]
       else:
          return None
    elif (format_in == 42):
       if (self.ekf_822D_struct != None):
          return [self.ekf_822D_struct.mag_filt_residual_x, self.ekf_822D_struct.mag_filt_residual_y, self.ekf_822D_struct.mag_filt_residual_z, self.ekf_822C_struct.flags_82_2d]
       else:
          return None

    return []


