# lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");

from PyQt4 import QtCore, QtGui
import sys

# QtGui.QTabBar.close-button("image: url(close_icon.png);subcontrol-position: left;")

# class Ui_TabWidget(object):
# class Ui_TabWidget(QtGui.QTabWidget):
class Ui_TabWidget(QtGui.QWidget):
    def setupUi(self, tabWidget):
        tabWidget.setObjectName("TabWidget")
        tabWidget.resize(400, 300)
        tabWidget.currentChanged.connect(self.onChangeTab)

        icon = QtGui.QIcon()

        # widget = QtGui.QWidget()
        # widget.setWindowIcon(icon)

        # QTabBar::close-button { image: url(close.png) subcontrol-position: left; } QTabBar::close-button:hover { image: url(close-hover.png) }

        icon.addPixmap(QtGui.QPixmap(":/close_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        # icon.setStyleSheet("subcontrol-position: left;")
        # QtGui.QIcon.Normal, QtGui.QIcon.Off)

        self.tabBar = QtGui.QTabBar(tabWidget)
        self.tabBar.setTabsClosable(True)
        self.tabBar.tabCloseRequested.connect(self.closeTab)
      
        # self.tabBar.setStyleSheet(image: url(close_icon.png).setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");
        # self.tabBar.setStyleSheet("image: url(close_icon.png); font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");
      
        # QtGui.QTabWidget.tabBar().setTabButton(0, QtGui.QTabBar.RightSide, None)
      
        # closeButton = QtGui.QPushButton(icon, '')
      
        # self.closeButton1 = QtGui.QPushButton('X')
        self.closeButton1 = QtGui.QPushButton()
        self.closeButton1.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon2.png")))
        self.closeButton1.clicked.connect(lambda:self.whichbtn(self.closeButton1))
        self.closeButton1.setFixedWidth(15)
        self.closeButton1.setFixedHeight(15)
        # closeButton1.hide()
        # closeButton1.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000; border: 1px solid #330019;");
        # self.closeButton1.setStyleSheet("background-image: url(./close_icon2.png); font-size: 14px; text-align: center; position: relative; color: #660000; border: 1px solid #330019;");
        # closeButton1.setStyleSheet("background-image: url(close_icon.png);")

        self.closeButton2 = QtGui.QPushButton()
        self.closeButton2.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon2.png")))
        self.closeButton2.clicked.connect(lambda:self.whichbtn(self.closeButton2))
        self.closeButton2.setFixedWidth(15)
        self.closeButton2.setFixedHeight(15)
        # closeButton2.hide()
        # closeButton2.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000; border: 1px solid #330019;");
        # self.closeButton2.setStyleSheet("background-image: url(./close_icon2.png); font-size: 14px; text-align: center; position: relative; color: #660000; border: 1px solid #330019;");
        # closeButton2.setStyleSheet("background-image: url(close_icon.png);")
      
        # set icon and size for PushButton, ...
        # connect Signal clicked() from closeButton with Slot closeCurrentTab(), ...

        # next line sets closeButton in right corner on tab with index 0
        # self.tabBar.setTabButton(0, QtGui.QTabBar.RightSide, closeButton);
      
        # self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: center; position: relative; color: #660000");
      
        # self.tabBar.setStyleSheet("QTabBar{left-margin:20;right-margin:20;}")

        # tmpTabButton = self.tabBar.tabButton(0, QtGui.QTabBar.RightSide)
        # tmpTabButton.resize(0, 0)
      
        # tmpTabButton.hide()
      
        self.tabBar.addTab("Tab1")
        # self.tabBar.addTab(tmpTabButton, "Tab1")
        self.tabBar.setTabText(0,"Hello")
        self.tabBar.setTabButton(0, QtGui.QTabBar.RightSide, None)

        self.tabBar.addTab("Tab2")
        self.tabBar.setTabText(1,"Hawaii")
        self.tabBar.setTabButton(1, QtGui.QTabBar.RightSide, self.closeButton1)

        self.tabBar.addTab("Tab3")
        self.tabBar.setTabText(2,"Hai")
        self.tabBar.setTabButton(2, QtGui.QTabBar.RightSide, self.closeButton2)
      
        tabWidget.setTabBar(self.tabBar)

        self.retranslateUi(tabWidget)

        QtCore.QMetaObject.connectSlotsByName(tabWidget)

    def whichbtn(self, b):
       # print "Clicked button is " + b.text()
       # QtGui.QMessageBox.about(self, "Msg Box", "Clicked button is " + b.text())
       # QtGui.QMessageBox.about(self, "Msg Box", "Clicked button is " + str(b))
       if (b == self.closeButton1):
          QtGui.QMessageBox.about(self, "Msg Box", "Clicked button is closeButton1")
          self.tabBar.removeTab(1)
       elif (b == self.closeButton2):
          QtGui.QMessageBox.about(self, "Msg Box", "Clicked button is closeButton2")
      
    def retranslateUi(self, tabWidget):
        tabWidget.setWindowTitle(QtGui.QApplication.translate("TabWidget", "TabWidget", None, QtGui.QApplication.UnicodeUTF8))


    def onChangeTab(self, i):
       # QtGui.QMessageBox.information(self,
                   # "Tab Index Changed!",
                   # "Current Tab Index: %d" % i ) #changed!

       QtGui.QMessageBox.about(self, "Msg Box", 'Loading sensors.., i = ' + str(i))

    def closeTab(self, i):
       self.tabBar.removeTab(i)


def main():
   app = QtGui.QApplication(sys.argv)

   # ex = Ui_TabWidget()
   # ex.show()

   tabWidget = QtGui.QTabWidget()
   ui = Ui_TabWidget()
   ui.setupUi(tabWidget)
   tabWidget.show()

   sys.exit(app.exec_())

if __name__ == '__main__':
   main()


