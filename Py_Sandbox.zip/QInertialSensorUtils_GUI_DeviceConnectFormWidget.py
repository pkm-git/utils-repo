# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

import os, sys
import ConfigParser
import serial.tools.list_ports

from datetime import datetime
from PyQt4 import QtCore, QtGui

from QInertialSensorUtils_GUI_CommonWidgets import *
from QInertialSensorUtils_GUI_MIP_Utils import *

from time import sleep         #sleep
from serial import *

BAUD_RATE = 12000000
# BAUD_RATE = 115200
# BAUD_RATE = 921600

# currentItemBackgroundColor = QtGui.QColor("#F8F3FC")
# currentItemBackgroundColor = QtGui.QColor("#DDC7F3")
currentItemBackgroundColor = QtGui.QColor("#ACCCFA")
# currentItemBackgroundColor.setNamedColor("#F8F3FC")

currentItemForegroundColor = QtGui.QColor("#257219")
# currentItemForegroundColor.setNamedColor("#F8F3FC")
# currentItemForegroundColor.setNamedColor("#333300")

currentForegroundBrush = QtGui.QBrush()
# currentForegroundBrush.setColor('w')
# currentForegroundBrush.setColor(currentItemForegroundColor)
currentForegroundBrush.setColor(QtCore.Qt.white)

# otherItemBackgroundColor = QtGui.QColor("#C9E0F5")
otherItemBackgroundColor = QtGui.QColor("#F2EBE3")
# otherItemBackgroundColor.setNamedColor("#F3FDFC")
 
otherItemForegroundColor = QtGui.QColor("#2C15A1")

otherForegroundBrush = QtGui.QBrush()
# otherForegroundBrush.setColor('w')
otherForegroundBrush.setColor(otherItemForegroundColor)

class MyDeviceConnectFormWidget(QtGui.QWidget):

   def __init__(self, parent):
      super(MyDeviceConnectFormWidget, self).__init__(parent)
      self.parent_obj = parent
      self.deviceList = None
      self.multi_select = False
      
      self.get_device_info_command = bytearray.fromhex('756501020203E2C8')
      
      self.declare_spaces()
      
      # # self.setFixedSize(600,120)
      # self.setMinimumHeight(110)
      # # self.setFixedWidth(600)
      # self.setFixedWidth(590)
      
      # self.setSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
      
      # self.setStyleSheet("background-color: #CCE5FF;");
      
      self.__controls()
      self.__layout()
      
   def closeEvent(self, event):
      print "Closing MyDeviceConnectFormWidget window"

      super(MyDeviceConnectFormWidget, self).closeEvent(event)

   def __controls(self):
      self.lbl_title = QtGui.QLabel("Device Connect Form")
      self.lbl_title.setStyleSheet("font-weight: bold; font-size: 14px; text-align: left; position: relative; color: #0A138B; background-color: #EBEED8; border: 1px solid #330019;");

      self.lbl_title.setFixedWidth(80)
      self.lbl_title.setFixedHeight(25)
      
      print('****************************************************************************')
      print(' ****** WILL CALL REFRESH METHOD FROM INIT ************ ')
      print('****************************************************************************')

      self.loadDeviceList()
  
   def clearDeviceAarray(self):
      cnt = 0
      for d in self.device_array:
         cnt += 1
         # Skip the header item
         if (cnt > 1):
            if (d.port_obj.ComPort.is_open):
               d.port_obj.ComPort.close()
            # } if (d.port_obj.ComPort.is_open)..
    
            if (d.port_obj.fout_bin != None):
               d.port_obj.fout_bin.close()
            # } if (d.port_obj.fout_bin != None)..    
         # } if (cnt > 1)..   
      # } for d in self.device_array..
      
      if (self.deviceList != None):
         self.deviceList.destroy()
         self.deviceList.clear()
         self.deviceList = None
      # } if (self.deviceList != None)..
      
   def loadDeviceList(self):

      self.deviceList = QtGui.QListWidget(self)
      
      # self.deviceList.setSelectionMode(QtGui.QAbstractItemView.ExtendedSelection)
      
      list = serial.tools.list_ports.comports()
      
      ComPort = None
      bytes_read = bytearray()
      
      # Add the table column headers as a 'dummy' port object
      port_obj = comp_port_data_struct()
      port_obj.model_name = 'Model Name'
      port_obj.serial_nbr = 'Serial Number'
      port_obj.fw_version = 'FW Ver'
      port_obj.model_nbr = 'Model Number'
      port_obj.options = 'Options'
      port_obj.port_nbr = 'COM'
      port_obj.is_header = True
      
      str_port = '{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}'.format('Model Name', 'Serial Nbr', 'FW Ver', 'Model Nbr', 'Options', 'COM', 'Status')
      
      item = MyListWidgetItem(str_port, port_obj)
      
      self.deviceList.addItem(item)
      
      # item.setStyleSheet("background-color: #CCE5FF; font-weight: bold;");
      # item.setBackgroundColor(QtGui.QColor("#D6D2F7"))
      # item.setBackgroundColor(QtGui.QColor("#1E1380")) # Dark blue
      # item.setBackgroundColor(QtGui.QColor("#305812")) # Dark green
      # item.setBackgroundColor(QtGui.QColor("#2D5111")) # Very Dark green
      # item.setBackgroundColor(QtGui.QColor("#76985B")) # Light green
      # item.setBackgroundColor(QtGui.QColor("#F2CFC0")) # Light orange
      # item.setBackgroundColor(QtGui.QColor("#F5B39F")) # Light orange
      # item.setBackgroundColor(QtGui.QColor("#ACE1FF")) # Light blue
      # item.setBackgroundColor(QtGui.QColor("#B7DFF6")) # Light dull blue
      # item.setBackgroundColor(QtGui.QColor("#EFB479")) # Dull orange
      # item.setBackgroundColor(QtGui.QColor("#D1ABD8")) # Dull orange
      item.setBackgroundColor(QtGui.QColor("#E8A17E")) # Dull orange
      # item.setStyleSheet("font-weight: bold; font-size: 11px; color:white; background-color: #E8A17E;");
      
      currentForegroundBrush = QtGui.QBrush()
      # currentForegroundBrush.setColor(QtCore.Qt.white)
      currentForegroundBrush.setColor(QtCore.Qt.black)
      # currentForegroundBrush.setColor(currentItemForegroundColor)
      
      item.setForeground(currentForegroundBrush)
      
      cnt = 0
      
      for element in list:
         # port_name = element.device.text()
         port_name = element.device
 
         port_nbr = port_name.replace('COM', '')
  
         print(' **** port_name = ' + str(port_name) + ', port_nbr = ' + str(port_nbr))
 
         try:
            # try:
            # ComPort = Serial(port_name, BAUD_RATE)  # open the COM Port
    
            ComPort = serial.Serial( \
                        port = port_name,\
                        baudrate = BAUD_RATE,\
                        parity = serial.PARITY_NONE,\
                        stopbits = serial.STOPBITS_ONE,\
                        bytesize = serial.EIGHTBITS\
                        # timeout=0.5, \
                        # inter_byte_timeout=0.1\
                     )
    
            try:
               if (not ComPort.is_open):
                  ComPort.open()
               # } if (not ComPort.is_open)...
            except SerialException:
               print('Port: ' + port_name + ' already open')

            ComPort.reset_input_buffer()
            ComPort.reset_output_buffer()
    
            sleep(0.05)
    
            # Send 'Get Device Info' command
            print(' ****** Will send get_device_info_command **** ')
            ComPort.write(self.get_device_info_command)
    
            # In the sleep call below, if 0.02 is used, it gets GX5-45 but not GX4-45.
            # With 0.03, it gets both.
            # sleep(0.03)
            sleep(0.2)
            
            data_left = int(ComPort.in_waiting)    # Get the number of characters ready to be read
        
            print(' ****** data_left = ' + str(data_left))
    
            if (data_left > 0):
               bytes_read = ComPort.read(data_left)
               if (bytes_read == None):
                  print(' ****** bytes_read is None ****** ')
               else:  
                  print(' ***** len(bytes_read) = ' + str(len(bytes_read)))
       
                  # tmp_str = hexlify( bytearray(bytes_read) ).upper()
                  # print(' ****** Device Form Widget bytes_read: '),
                  # for i1 in range(0,len(tmp_str),2):
                     # print(tmp_str[i1] + tmp_str[i1+1]),
                  # print('\n')

                  command_echo, error_code, fw_version, model_name, model_nbr, serial_nbr, options = parse_mip_packet(bytes_read, CMD_STREAM)
                  
                  print(' **** model_name: ' + model_name)
                  print(' **** serial_nbr: ' + serial_nbr)
                  print(' **** fw_version: ' + str(fw_version))
                  print(' **** model_nbr: ' + model_nbr)
                  print(' **** port_nbr: ' + port_nbr)

                  # str_filter_status = get_filter_status(ComPort)
                  str_filter_status = 'Not Connected'
                  # str_filter_status = 'Idle'
       
                  str_port = '{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}\t{:s}'.format(model_name.strip(), serial_nbr.strip(), str(fw_version), model_nbr.strip(), options.strip(), port_nbr.strip(), str_filter_status)

                  port_obj = comp_port_data_struct()
                  port_obj.ComPort = ComPort
                  port_obj.port_name = port_name
                  port_obj.port_baud = BAUD_RATE
                  port_obj.model_name = model_name
                  port_obj.serial_nbr = serial_nbr
                  port_obj.fw_version = fw_version
                  port_obj.model_nbr = model_nbr
                  port_obj.options = options
                  port_obj.port_nbr = port_nbr
                  port_obj.filter_status = str_filter_status
  
                  cnt = cnt + 1
  
                  item = MyListWidgetItem(str_port, port_obj)   

                  self.deviceList.addItem(item)
  
               # } if (bytes_read == None)..  
            # } if (data_left > 0)..
    
            sleep(0.05)
            ComPort.close()
            sleep(0.05)
    
         except SerialException as err:
            print(" **** SerialException: Port: " + port_name + ", Error Msg: {0}".format(err))
         # } try..
      
      # } for element in list..
      
      print(' ***** len(self.deviceList) = ' + str(len(self.deviceList)))
      
      cnt = 0
      self.device_array = []
      for index in xrange(self.deviceList.count()):
         d_curr = self.deviceList.item(index)
         cnt = cnt + 1
         # Skip the top 'header' row
         if (cnt > 1):
            self.device_array.append(d_curr)
         # } if (cnt > 1)..
      # } for index in..

      self.deviceList.clicked.connect(self.onDeviceSelect)
   
   def onMultiSelect(self):
      selected_items = self.deviceList.selectedItems()
      
      self.multi_select = True
      
      print(' **** onMultiSelect: len(selected_items) = ' + str(len(selected_items)))
      
      for d in selected_items:
         d.setBackgroundColor(QtGui.QColor("#1E1380")) # Dark blue
         d.setForeground(currentForegroundBrush)
      # } for d in selected_items..
      
   def onDeviceSelect(self):
      d_curr = self.deviceList.currentItem()
      
      self.multi_select = False

      # Use values from current port row object to set state of streaming and record buttons
      self.parent_obj.start_stop_recording_button.setState(d_curr.port_obj.recording_state)

      # if (d_curr.port_obj.recording_state == 1):
         # self.parent_obj.edt_filename.setReadOnly(False)
      # } if (d_curr.port_obj.recording_state == 1)..
    
      self.parent_obj.start_streaming_button.setState(d_curr.port_obj.streaming_on)
      self.parent_obj.start_streaming_button.enableBorder(d_curr.port_obj.streaming_on)
      
      self.parent_obj.edt_filename.setText(d_curr.port_obj.bin_filename)
      
      if (d_curr.port_obj.recording_state != 0):
         self.parent_obj.edt_filename.setReadOnly(True)
      else: 
         self.parent_obj.edt_filename.setReadOnly(False) 
      # } if (d_curr.port_obj.recording_state != 0)..
      
      self.parent_obj.start_streaming_button.switchIcon()
      
      self.parent_obj.start_stop_recording_button.enableWaitingToRecord(d_curr.port_obj.waiting_to_rec)
      self.parent_obj.start_stop_recording_button.enableBorder(d_curr.port_obj.recording_state != 0)
      self.parent_obj.start_stop_recording_button.switchIcon()
      
      if (not self.multi_select):
         cnt = 0
         for d in self.device_array:
            cnt += 1
            if (d != self.deviceList.currentItem()):
               d.setBackgroundColor(otherItemBackgroundColor)
               d.setForeground(otherForegroundBrush)
            else:
               # d.setBackgroundColor(currentItemBackgroundColor)
               d.setBackgroundColor(QtGui.QColor("#1E1380")) # Dark blue
               d.setForeground(currentForegroundBrush)
            # } if (d != self.deviceList.currentItem())..
            # } if (cnt > 1)..   
         # } for d in self.device_array..
      # } if (not self.multi_select)..
      
   def __layout(self):

      self.vDeviceListBox = QtGui.QVBoxLayout()
      self.vDeviceListBox.addWidget(self.deviceList)

      self.setLayout(self.vDeviceListBox)

   def declare_spaces(self):
      self.lbl_space = QtGui.QLabel()
      self.lbl_space.setFixedSize(30,25)

      self.lbl_space_xsmall = QtGui.QLabel()
      self.lbl_space_xsmall.setFixedSize(5,25)

      self.lbl_space_small = QtGui.QLabel()
      self.lbl_space_small.setFixedSize(15,25)

      self.lbl_space_medium = QtGui.QLabel()
      self.lbl_space_medium.setFixedSize(60,25)

      self.lbl_space_large = QtGui.QLabel()
      self.lbl_space_large.setFixedSize(90,25)

      self.lbl_space_xlarge = QtGui.QLabel()
      self.lbl_space_xlarge.setFixedSize(110,25)

