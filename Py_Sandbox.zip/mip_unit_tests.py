from mip import *
from binascii import hexlify
from fletcher_check import fletcher_check16

mp = bytearray([])

#initialize a packet for a base command
mip_init(mp,0x01)

#add the command ping to the packet
mip_add_field(mp,0x01)

#finalize packet
mip_finalize(mp)

#test packet validity
if(mip_is_mip_packet(mp)==MIP_OK):
 print "Valid Packet Found"

print hexlify(mp)

print "Getting Payload"

pl = mip_get_payload(mp)

print hexlify(pl)

print "Generating test packet from valid command packet"

test_packet = bytearray.fromhex('75650C16160801060400010500010600010A00010C00011200015ED1')

print "Testing packet Validity"

if(mip_is_mip_packet(test_packet)==MIP_OK):
 print "Valid Packet Found"
else:
 print "Packet Invalid"

print hexlify(test_packet)

tpl=mip_get_payload(test_packet)

print hexlify(tpl)

print "Using User entered multifield packet"

multi_field_packet = bytearray.fromhex('75650C0804F1060004830064D46B')

mfp = bytearray(multi_field_packet)

offset = mip_get_first_field_offset(mfp)

print hexlify(mip_get_field_at_offset(mfp, offset))

offset = mip_get_next_field_offset(mfp, offset)

print hexlify(mip_get_field_at_offset(mfp, offset))


