import threading       #import thread library
from time import time  #import time library
from time import clock  #import time library
from time import sleep           #sleep
from gsg_imu import *

class Producer_PKM(threading.Thread):
    # Produces random integers to a list
    def __init__(self, done, gsg_imu_obj, condition):
        threading.Thread.__init__(self)
        self.done = done
        self.condition = condition
        self.cnt = 0
        self.gsg_imu_obj = gsg_imu_obj
        print (' *********** in Producer_PKM constr')

    def run(self):
        # Thread run method. Append random integers to the integers list at random time.
        while (self.cnt < 100):
            # print ('\n ------------------------------ \n *********** in Producer_PKM run')
            self.cnt = self.cnt + 1

            self.condition.acquire()
            # print '\n condition acquired by Producer_PKM'

            self.done = False

            current_time = clock()
            # print(' in Producer, cnt = %d, BEFORE sleep: current_time = %14.8f\n', current_time)
            # print 'in Producer, cnt = %d, BEFORE sleep: current_time = %14.8f\n' % (self.cnt, current_time)
            current_time_before = current_time

            sleep(0.002)

            self.done = True

            current_time = clock()
            # print(' in Producer, AFTER sleep: current_time = %14.8f\n', current_time)
            # print 'in Producer, cnt = %d, AFTER sleep: current_time = %14.8f\n' % (self.cnt, current_time)
            print 'Producer, cnt = %d, sleep time = %14.8f' % (self.cnt, (current_time - current_time_before))

            self.gsg_imu_obj.imu_tow = current_time

            # print 'condition notified by Producer_PKM'
            self.condition.notify()

            # print 'condition released by Producer_PKM'
            self.condition.release()

