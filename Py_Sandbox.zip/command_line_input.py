COMMAND_LINE_INPUT_UNINITIALIZED = 0

class COMMAND_LINE_INPUT(object):

   #default 'constructor'
   def __init__(self):
      """Class default initialization function"""
      try:
         self.init()
      except:
         self.state = COMMAND_LINE_INPUT_UNINITIALIZED

   # class initializer function
   def init(self):
      """Class initialization function"""
      self.str_command_line = ''
      self.done = False


