import csv
import sys
from mip_csv_utils import *

from mip import *

from struct import * #import all objects and functions from the struct library
from binascii import hexlify #hexlify is a function to print bytearrays as
                             #ascii strings for debugging (NOT NECESSARY FOR
                             #DATA CONVERSTIONS)

def main_line(argv):
    """Main line program"""

    # in_file_name = 'IMU_Log_wHeaders_6-30-2015 10.13.55 AM.csv';
    in_file_name = 'IMU_Log_wHeaders_6-30-2015 10.13.55 AM_short.csv';

    out_file_name = 'IMU_Log.csv';

    in_csvfile = open(in_file_name,'rUb')
    out_csvfile = open(out_file_name, 'wb')

    csvreader = csv.reader(in_csvfile, delimiter=',')
    csvwriter = csv.writer(out_csvfile, delimiter=',')

    determine_headers = False
    n_data_columns = 0
    output_descriptors = []
    output_headers = True
    dictionary_file_name = "Desc-Header strings.csv"
    ignore_empty_rows = False
    headers_found = False
    headers = []
    output_order = []
    n_input_rows = 0
    n_output_rows = 0

    print( " ******* len(argv) = " + str(len(argv)) );
    #parse command line arguements
    for i in range(len(argv)):
        #assign specified filenames
        if(argv[i] == '-d' and len(argv) > i+1):
            #is this only 1 descriptor?
            if(len(argv[i+1]) == 4):
                #split up the 2 bytes into DS and FD
                output_descriptors.append((bytearray.fromhex(argv[i+1])[0], \
                                           bytearray.fromhex(argv[i+1])[1]))
            #is this more than one descriptor?
            elif(len(argv[i+1]) % 4 == 0 and len(argv[i+1]) > 0):
                #loop over the specified bytes
                # print(" i = " + str(i) + " bytearray.fromhex(argv[i+1])[0] = " + hexlify(bytearray.fromhex(argv[i+1])[0]) + " bytearray.fromhex(argv[i+1])[1] = " + hexlify(bytearray.fromhex(argv[i+1])[1]) );
                # print(" bytearray.fromhex(argv[i+1])[0] = " + hexlify(bytearray.fromhex(argv[i+1])[0])  );
                # print(" argv[i+1] = " + argv[i+1] );
                #print(" Length of argv = " + str(len(argv)) + " and len(argv[i+1]) = " + str(len(argv[i+1])));
                for j in range(0,len(argv[i+1]),4):
                    #print(" bytearray.fromhex(argv[i+1][j:j+4])[0] = " + hexlify(bytearray.fromhex(argv[i+1][j:j+4])[0]) );
                    #print(" bytearray.fromhex(argv[i+1][j:j+4]) = " + hexlify(bytearray.fromhex(argv[i+1][j:j+4])) );
                    #print(" i = " + str(i) + " j = " + str(j) + ", bytearray.fromhex(argv[i+1][j:j+4])[0] = " + str(bytearray.fromhex(argv[i+1][j:j+4])[0]) + ", bytearray.fromhex(argv[i+1][j:j+4])[1] = " + str(bytearray.fromhex(argv[i+1][j:j+4])[1]) );
                
                    output_descriptors.append((bytearray.fromhex(argv[i+1][j:j+4])[0], \
                                               bytearray.fromhex(argv[i+1][j:j+4])[1]))
            #is this a badly specified descriptor list?
            else:
                output_descriptors = []

    desc_dictionary = load_mip_header_dictionary(dictionary_file_name)

    consolidated_time_headers = (['GPS TFlags','GPS Week','GPS TOW'])
    desc_dictionary.update({(0x80,0x12):consolidated_time_headers})
    desc_dictionary.update({(0x81,0x09):consolidated_time_headers})
    desc_dictionary.update({(0x82,0x11):consolidated_time_headers})

    ignore_empty_rows = True

    row_cnt = 0

    for row_items in csvreader:

        row_cnt = row_cnt + 1
        
        print(" ***** row: " + str(row_cnt)  );
        
        # determined that last row in CSV indicated data start (headers are in this row)
        if (determine_headers == True):
        
            # determine the number of columns
            #n_data_columns =  len(row_items)
        
            #print(" **** n_data_columns = " + str(n_data_columns) );
            # create a list of the headers
            #for i in range(n_data_columns):
                #headers.append(row_items[i])

            # determine the order of the desired outputs in terms of the input column indices
            # generate the output row for the output csv
            output_header_row = []

            #output_desc_cnt = 0
            #col_hdr_cumul_cnt = 0;
        
            # loop over specified output descriptors
            #for descriptor in output_descriptors:
                #output_desc_cnt = output_desc_cnt + 1;
                # add the headings for the output file to the output header row
                #try:
                    #print(" ************** output_desc_cnt = " + str(output_desc_cnt) + ", str(descriptor) = " + str(descriptor) )
                    #print(" ************** descriptor = " + hexlify(descriptor) + " desc_dictionary[descriptor] = " + hexlify(desc_dictionary[descriptor][0]) );
                    #print(" ************** str(desc_dictionary[descriptor]) = " + str(desc_dictionary[descriptor]) )
                    #output_header_row.extend(desc_dictionary[descriptor])
                    # print(" ************** output_header_row = " + str(output_header_row) );
                    # loop over all headings associated with this descriptor
                    #col_hdr_cnt = 0;
                    #for column_header in desc_dictionary[descriptor]:
                        #col_hdr_cnt = col_hdr_cnt + 1
                        #col_hdr_cumul_cnt = col_hdr_cumul_cnt + 1
                        #print(" ************** col_hdr_cnt = " + str(col_hdr_cnt) + ", column_header = " + str(column_header) + ", headers.index(column_header) = " + str(headers.index(column_header)) + ", headers[headers.index(column_header)] = " + str(headers[headers.index(column_header)]) )
                        #print(" **** output_desc_cnt = " + str(output_desc_cnt) + " col_hdr_cumul_cnt = " + str(col_hdr_cumul_cnt) + ", column_header = " + str(column_header) )
                        
                        # is the specified data in the input file?
                        #try:
                            #output_order.append(headers.index(column_header))
                        # if not put in placeholder indices
                        #except ValueError:
                            #output_order.append(-1)
                #except KeyError:
                    #print(hex(descriptor[0])[-2:]+hex(descriptor[1])[-2:]+" not found in dictionary.")
                    #sys.exit()

            # write the output header row
            #if (output_headers == True):
                #csvwriter.writerow(['DATA_START'])
                #csvwriter.writerow(output_header_row)

            # column headers have been found
            headers_found = True

            # headers no longer need to be determined
            determine_headers = False

        elif(headers_found == True):
            # create the empty output_row
            output_row = len(output_order)*[[]]

            # set flag to ignore this row until valid data is found in it
            if(ignore_empty_rows == True):
                ignore_row = True
            else:
                ignore_row = False

            #loop over all requested columns in current input row
            # print(" ********* len(output_order) = " + str(len(output_order)));
        
            mp = bytearray([])

            #initialize a packet for a base command
            mip_init(mp,0x80)

            # x_data = 1.6
            # y_data = 2.8
            # z_data = 3.9

            # float_bytes = pack('>fff',x_data, y_data, z_data);
            # float_bytes2 = pack('>f',x_data);
            # hexlify(float_bytes2).upper()

            print(" ****** row_items[1] = " + str(row_items[1]) + " row_items[2] = " + str(row_items[2]) );
        
            mip_add_field(mp, 0x12, pack('>ss', row_items[1], row_items[2]))

            print "****** Packet after add field: " + hexlify(mp).upper()
        
            # mip_add_field(mp,0x12, bytearray.fromhex('2A895F'))

            # checksum = fletcher_check16(mp)

            #Print the checksum bytes
            #print "Checksum bytes: " + hexlify(checksum).upper()

            #finalize packet
            #mip_finalize(mp)

            #print "Packet after finalize: " + hexlify(mp).upper()

            n_input_rows += 1
        # this row is neither column headers nor data elements
        else:
            # print(" ELSE **************** : len(row_items) = " + str(len(row_items)) + " and row_items[0] = " + row_items[0]);
            # print(row_items)
            # test for DATA_START row (column headers to follow)
            #if(len(row_items) == 1 and row_items[0] == 'DATA_START'):
            if(row_items[0] == 'DATA_START'):
                determine_headers = True
                print("DATA_START found, collecting headers")
                
    #file complete
    print(str(n_input_rows)+" input rows processed")
    print("Output file generation complete")
    print(str(n_output_rows)+" output rows written.")

if(__name__ == "__main__"):
  main_line(sys.argv)


