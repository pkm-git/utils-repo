#import libraries used
from mip import *              #local file should be in local folder
from mip_parser import *       #local file should be in local folder
import serial                  #library for accessing serial ports
import sys                     #library for dealing with OS I/O
from binascii import hexlify   #function to display hexadecimal bytes as ascii
                               #text
from time import sleep         #sleep
from async_mip_update_thread import AsyncMIPDataUpdater #Asynchronous MIP
                                                        #response update thread

#Callback function for mip packet parser
def mip_parser_callback(packet_bytes, callback_type):
 """Packet parser callback"""
 print("****** mip_parser_callback: callback_type = " + str(callback_type))
 print(' *********** Original REPLY packet: ' + hexlify(bytearray(packet_bytes)).upper() )

 if(callback_type == MIP_PARSER_CALLBACK_VALID_PACKET):
  print("Valid Packet Found")

  #loop over fields in received valid packet
  for field in mip_get_next_field(packet_bytes):
   #if this field is an ack/nack output it to show the user
   if(field[1] == MIP_REPLY_DESC_GLOBAL_ACK_NACK):
    print('field[1] = ' + str(field[1]) + ' Device response to command '+hex(field[2]).upper()+': '\
          +mip_ack_nacks[field[3]])

    # print('Device response to command '+hex(field[2]).upper()+': '\
          # +mip_ack_nacks[field[3]])

 #handle 'bad' packet callbacks
 elif(callback_type == MIP_PARSER_CALLBACK_TIMEOUT):
  print("Packet Timeout Callback")
 elif(callback_type == MIP_PARSER_CALLBACK_CHECKSUM_ERROR):
  print("Bad Checksum Found")
 else:
  print("Unrecognized Callback Type")

#Assign script command line vector from sys.argv
argv = sys.argv

#default port settings
port_name = 'COM1'
port_baud = 115200

#parse command line arguments
for i in range(len(argv)):
 print('**********  argv[i] = ' + argv[i]);
 if(argv[i] == '-p' and len(argv) > i+1):
  port_name = argv[i+1]
 elif(argv[i] == '-b' and len(argv) > i+1):
  port_baud = int(argv[i+1])

print('**********  PORT : '+ port_name);

#Assign serial port object
port = serial.Serial(port_name,port_baud)

#Close port in case it was left open by other process
port.close()

#generate command bytearrays

#command for putting nav processor into IMU DIRECT mode
imu_direct_mode_command = bytearray.fromhex('75657F040410010274BD')

#command for putting nav processor into STANDARD node
standard_mode_command = bytearray.fromhex('75657F040410010173BC')

#command for putting device into HIL mode
hil_mode_command = bytearray.fromhex('7565010B0B7C01E183F766000000002FB1')

#command for putting device into normal (non-HIL) mode
non_hil_mode_command = bytearray.fromhex('7565010B0B7C00E183F766000000002EA8')

# Enable, no parameter  - 0x75 0x65 0x01 0x0B 0x0B 0x7C 0x01 0xE1 0x83 0xF7 0x66 0x00 0x00 0x00 0x00 0x2F 0xB1
# Disable, no parameter - 0x75 0x65 0x01 0x0B 0x0B 0x7C 0x00 0xE1 0x83 0xF7 0x66 0x00 0x00 0x00 0x00 0x2E 0xA8

#Set up mip packet response parser
mip_parser = MipParser(10000, 0, mip_parser_callback)

#open specified port
port.open()

#set up background process to update data buffers
background_data_update = AsyncMIPDataUpdater(port, mip_parser, 10000)

#start the response parsing thread
background_data_update.start()

#send IMU DIRECT mode command
print('Sending IMU DIRECT mode command: (7F,10)')
port.write(imu_direct_mode_command)

#sleep while waiting for response
sleep(1)

#send HIL command
print('Sending Non-HIL command: (01,7C)')
port.write(non_hil_mode_command)

#sleep while waiting for response
sleep(1)

#send STANDARD mode command
print('Sending STANDARD mode command: (7F,10)')
port.write(standard_mode_command)

#sleep while waiting for response
sleep(0.1)

#send HIL command
print('Sending Non-HIL command: (01,7C)')
port.write(non_hil_mode_command)

#sleep while waiting for response
sleep(1)

#stop background response parsing thread
background_data_update.stop()

#close port
port.close()

