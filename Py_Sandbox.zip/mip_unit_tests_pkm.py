from mip import *
from binascii import hexlify

mp = bytearray([])

#initialize a packet for a base command
#mip_init(mp,0x01)
mip_init(mp,0x80)

print "Packet after init: " + hexlify(mp).upper()

#add the command ping to the packet
#mip_add_field(mp,0x01)
mip_add_field(mp,0x04, bytearray.fromhex('2A895F'))

print "Packet after add field: " + hexlify(mp).upper()

checksum = fletcher_check16(mp)

#Print the checksum bytes
print "Checksum bytes: " + hexlify(checksum).upper()

#finalize packet
mip_finalize(mp)

print "Packet after finalize: " + hexlify(mp).upper()

#test packet validity
if(mip_is_mip_packet(mp)==MIP_OK):
 print "\nValid Packet Found"

print "Full packet: " + hexlify(mp).upper()

pl = mip_get_payload(mp)

print "Payload: " + hexlify(pl).upper()

print "\n********************************************"
print "Example: Get Descriptor Set from mip packet"
print "********************************************"

resume_filter_command = bytearray.fromhex('75651C050511010301061E');

desc_bytes = bytearray(mip_get_packet_descriptor_set(resume_filter_command))

print("\n*********** resume_filter_command Descriptor Set: " + hexlify(bytearray(desc_bytes)).upper())
# print("\n*********** resume_filter_command Descriptor Set: (using hex) " + hex(resume_filter_command[2]).upper() )
print("\n*********** resume_filter_command Descriptor Set (using hexlify) : " + hexlify(bytearray(resume_filter_command[2])).upper() )

# hexlify(bytearray(bytes_read[k+410])) == 'a6' and hexlify(bytearray(bytes_read[k+411])) == '72'

if (0):
 print "\n********************************************"
 print "Example: IMU MIP data packet (accel: 0x80, 0x04)"
 print "********************************************"

 # 7565 800E 0E04 3E7A 63A0 BB8E 3B29 7FE5 BF7F 92C0

 test_packet = bytearray.fromhex('7565800E0E043E7A63A0BB8E3B297FE5BF7F92C0')

 expected_checksum = fletcher_check16(test_packet[0:len(test_packet)-2])

 # Compare with current checksum
 if(expected_checksum == test_packet[-2:]):
    print "Checksum matched expected value: " + hexlify(expected_checksum).upper()
 else:
    print "Checksum DID NOT match expected value: Found: " + hexlify(test_packet[0:len(test_packet)-2]).upper() + " Expected: " + hexlify(expected_checksum).upper()

 print "Full packet with checksum bytes: " + hexlify(test_packet).upper()
 print " *********************************************************************\n "

 #test_packet2 = bytearray.fromhex('000103F6')
 test_packet2 = bytearray.fromhex('B5620120')
 print "Packet 2 from C test driver : " + hexlify(test_packet2).upper()

 expected_checksum = fletcher_check16(test_packet2)

 print "Expected Checksum for Packet 2: " + hexlify(expected_checksum).upper()

 test_packet3 = bytearray.fromhex('3FCCCCCD 40333333 4079999A') # 1.6, 2.8 and 3.9 in float (Big Endian) format
 print "Packet 3 from C test driver : " + hexlify(test_packet3).upper()

 expected_checksum = fletcher_check16(test_packet3)

 print "Expected Checksum for Packet 3: " + hexlify(expected_checksum).upper()

 test_packet4 = bytearray.fromhex('75650C0F0F37013FCCCCCD403333334079999A') # MIP Header + 01 + 1.6, 2.8 and 3.9 in float (Big Endian) format
 print "Packet 4 from C test driver : " + hexlify(test_packet4).upper()

 expected_checksum = fletcher_check16(test_packet4)

 print "Expected Checksum for Packet 4: " + hexlify(expected_checksum).upper()


 print "\n********************************************"
 print "Generating MIP packet from valid byte array"
 print "********************************************"

 test_packet = bytearray.fromhex('75650C16160801060400010500010600010A00010C00011200015ED1')

 # print "************ Testing packet Validity"

 if(mip_is_mip_packet(test_packet)==MIP_OK):
     print "Valid Packet Found"
 else:
     print "Packet Invalid"

 print hexlify(test_packet).upper()

 tpl=mip_get_payload(test_packet)

 print "Payload: " + hexlify(tpl).upper()

 print "\n ********************************** "
 print "      Add Checksum Bytes to Packet  "
 print " ********************************** "

 # pkm_packet = bytearray.fromhex('75650C16160801060400010500010600010A00010C0001120001')

 # pkm_packet = bytearray.fromhex('75650C0804F1060004830064')

 pkm_packet = bytearray.fromhex('75650C0404F10600')

 print "Input Packet: " + hexlify(pkm_packet).upper()

 print "Length of packet: " + str(len(pkm_packet))

 pl = mip_get_payload(pkm_packet)
 print "Payload BEFORE adding checksum: " + hexlify(pl).upper()

 #calculate the checksum
 checksum = fletcher_check16(pkm_packet)

 #Print the checksum bytes (should show: E5B6)
 print "Checksum bytes: " + hexlify(checksum).upper()

 #add the checksum to the packet
 pkm_packet.extend(checksum)

 #Print the length of the packet
 print "Length of packet after checksum added: " + str(len(pkm_packet))

 print "Full packet with checksum bytes: " + hexlify(pkm_packet).upper()

 pl = mip_get_payload(pkm_packet)
 print "Payload AFTER adding checksum: " + hexlify(pl).upper()

 # Validate packet checksum:
 print "\n ********************************************** "
 print "     Validate packet checksum (expected vs actual)"
 print " ************************************************ "

 expected_checksum = fletcher_check16(pkm_packet[0:len(pkm_packet)-2])

 # Compare with current checksum
 if(expected_checksum == pkm_packet[-2:]):
    print "Checksum matched expected value: " + hexlify(expected_checksum).upper()
 else:
    print "Checksum DID NOT match expected value: Found: " + hexlify(pkm_packet[0:len(pkm_packet)-2]).upper() + " Expected: " + hexlify(expected_checksum).upper()

 print "\n ********************************** "
 print "      Multi-field packet test "
 print " ********************************** "

 # multi_field_packet = bytearray.fromhex('75650C0804F1060004830064D46B')
 # multi_field_packet = bytearray.fromhex('75 65 0C 08   04 F1 06 00   04 83 00 64   D4 6B')
 multi_field_packet = bytearray.fromhex('75650C0C04F1060004830064040ADE09')
 checksum = fletcher_check16(multi_field_packet)
 multi_field_packet.extend(checksum)
 mfp = bytearray(multi_field_packet)

 offset = mip_get_first_field_offset(mfp)

 while(offset != 0):
     # yield mip_get_field_at_offset(mfp, offset)
     print hexlify(mip_get_field_at_offset(mfp, offset)).upper()
     #get offset of next field
     offset = mip_get_next_field_offset(mfp, offset)

 print " Full packet with checksum: " +  hexlify(mfp).upper()

 expected_checksum = fletcher_check16(mfp[0:len(mfp)-2])
 print "Checksum bytes: " + hexlify(mfp[-2:]).upper() + ", Expected checksum: " + hexlify(expected_checksum).upper()

 # print hexlify(mip_get_field_at_offset(mfp, offset)).upper()
 # offset = mip_get_next_field_offset(mfp, offset)
 # print hexlify(mip_get_field_at_offset(mfp, offset)).upper()


