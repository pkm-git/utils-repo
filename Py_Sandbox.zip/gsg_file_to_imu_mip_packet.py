import sys
import os
import visa
import numpy
import serial                  #library for accessing serial ports
import csv

from gpstime import *

from mip import *

from time import sleep           #sleep
from time import time  #import time library
from time import clock

from struct import * #import all objects and functions from the struct library
from binascii import hexlify   #hexlify is a function to print bytearrays as
                               #ascii strings for debugging (NOT NECESSARY FOR
                               #DATA CONVERSIONS)

from async_user_input_thread import AsyncUserInput # Asynchronous User Input thread

from gsg_user_input import *

def print_usage_message(errorMsg):
 """Output usage instructions"""
 print("\n************* PLEASE USE CORRECT SYNTAX FOR THIS COMMAND *************************************")
 print("  ERROR(S) FOUND: " + errorMsg)
 print("---------------------------------------------------------------------- " )
 print("Usage: python gsg_to_imu_mip_packet.py -ip imu_port_name -ib imu_port_baud -ir imu_data_rate -mip_or_save_500Hz_imu send_imu_mip_or_save_500Hz_IMU -if in_imu_file_name -save_folder save_folder_path -debug debug_mode\n")
 print("imu_port_name\t\t: the name of the IMU port (example: COM10). Optional if send_imu_mip_or_save_500Hz_IMU = i")
 print("imu_port_baud\t\t: the baud rate of the IMU port (example: -ib 921600). Optional if send_imu_mip_or_save_500Hz_IMU = i")
 print("imu_data_rate\t\t: the rate of input IMU data [use one of: 100 Hz, 250 Hz and 500 Hz.  Example: for 250 Hz, use: -ir 250]. Optional: Defaults to 500 Hz")
 print("send_imu_mip_or_save_500Hz_IMU\t: Optional: Use 'm' if you want mip packets to be sent to IMU (default) or 'i' if you want to save 500 Hz interpolated IMU values to csv file")
 print("in_imu_file_name\t: the name of the input IMU csv data file including the path (required)")
 print("save_folder_path\t: the folder to save 500 Hz IMU data file. Optional; defaults to current folder where this script runs from.")
 print("debug_mode\t\t: Optional: use y to get processing times in csv file, n to disable it (default)")
 print("Note: -ir clause is optional.  If not present, it will assume 500 Hz IMU input data rate. But this rate must match the one used to create 10 Hz IMU data csv file.")
 print("**********************************************************************************************")

def main_line(argv):
    """Main line program"""

    # default IMU input data rate to 500Hz
    imu_data_rate = 500

    imu_port_name = None
    imu_port_baud = 0

    send_imu_mip_or_save_500Hz_IMU = 'm'

    # default folder that has 10 Hz IMU data file captured using 'save_10Hz_gsg_to_file' script
    save_folder_path = '.'

    debug_mode = 'n'

    in_imu_file_name = None

    #parse command line arguments
    for i in range(len(argv)):
       print('**********  argv[i] = ' + argv[i]);
       if(argv[i] == '-ip' and len(argv) > i+1):
         imu_port_name = argv[i+1]
       elif(argv[i] == '-ib' and len(argv) > i+1):
         imu_port_baud = int(argv[i+1])
       elif(argv[i] == '-ir' and len(argv) > i+1):
         imu_data_rate = int(argv[i+1])
       elif(argv[i] == '-mip_or_save_500Hz_imu' and len(argv) > i+1):
         send_imu_mip_or_save_500Hz_IMU = argv[i+1].lower()
       elif(argv[i] == '-if' and len(argv) > i+1):
         in_imu_file_name = argv[i+1]
       elif(argv[i] == '-save_folder' and len(argv) > i+1):
         save_folder_path = argv[i+1]
       elif(argv[i] == '-debug' and len(argv) > i+1):
         debug_mode = argv[i+1]

    # If command line arguments were not properly specified tell the user and exit
    if (in_imu_file_name == None or (imu_data_rate <> 100 and imu_data_rate <> 250 and imu_data_rate <> 500) \
       or (send_imu_mip_or_save_500Hz_IMU == 'm' and \
       (imu_port_name == None or imu_port_baud == 0))):

       if (in_imu_file_name == None):
          errorMsg = 'IMU input file [-if clause] needs to be specified'
       elif (imu_data_rate <> 100 and imu_data_rate <> 250 and imu_data_rate <> 500):
          errorMsg = 'IMU data rate [-ir clause] must be one of 100 Hz, 250 Hz, and 500 Hz'
       else:
          errorMsg = 'Must specify IMU port name [-ip clause] and baud rate [-ib clause] if sending MIP packets to IMU'
       # } if (in_imu_file_name == None)..

       print_usage_message(errorMsg)
       sys.exit()

    dt_imu = numpy.double(1)/imu_data_rate

    # Create altitude array (in feet above sea level)
    # altitude_array = [0, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000 ]

    # Create altitude array (in meters above sea level)
    altitude_array = [0, 153, 305, 458, 610, 763, 915, 1068, 1220, 1373, 1526, 1831, 2136, 2441, 2746, 3050, 4577, 6102, 7628, 9153, 10679, 12204, 13730, 15255]

    # Create ambient pressure array (in bar)
    ambient_pressure_array = [1.0133, 0.9949, 0.9763, 0.9591, 0.9419, 0.9246, 0.9081, 0.8915, 0.8749, 0.8591, 0.8433, 0.8122, 0.7819, 0.7522, 0.7240, 0.6964, 0.5716, 0.4661, 0.3765, 0.3013, 0.2393, 0.1882, 0.1482, 0.1165]

    ambient_pressure = 0

    fout_imu_500Hz_hil = None
    fout_imu_10Hz_wBackCalc_hil = None

    if (debug_mode == 'y'):
       fout_processing_time = open(os.path.join(save_folder_path, "Processing_time.csv"), "w")
       fout_processing_time.write('Input Row Cnt,Runtime (sec),Interp_Loops,Sum MIP Creation Time,Ave MIP Creation Time,Sum MIP Creation+Sleep,Ave MIP Cr+Sleep,10Hz Proc Time,10Hz Proc Time+Sleep\n')

    imu_in_csvfile = open(in_imu_file_name,'rUb')
    imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')

    if (send_imu_mip_or_save_500Hz_IMU == 'i'):
       # Create a file to log the IMU data that was supplied as input to the HIL
       fout_imu_10Hz_wBackCalc_hil = open(os.path.join(save_folder_path, "GSG_10Hz_IMU_wBackCalc_Input.csv"), "w")
       fout_imu_10Hz_wBackCalc_hil.write('IMU interp loops,Scen Run Time,GPS Week,GPS TOW,X Accel,Y Accel,Z Accel,X Gyro,Y Gyro,Z Gyro,Gyro X from Delta Theta,Gyro Y from Delta Theta,Gyro Z from Delta Theta,Accel X from Delta Vel,Accel Y from Delta Vel,Accel Z from Delta Vel,Ambient Pressure\n')

       fout_imu_500Hz_hil = open(os.path.join(save_folder_path, "GSG_500Hz_IMU_Interp.csv"), "w")
       fout_imu_500Hz_hil.write('IMU interp loops,Scen Run Time,GPS Week,GPS TOW,X Accel,Y Accel,Z Accel,X Gyro,Y Gyro,Z Gyro,Delta Theta X,Delta Theta Y,Delta Theta Z,Delta Vel X,Delta Vel Y,Delta Vel Z,Ambient Pressure\n')
    # }

    cnt = 0

    print(' **************************************************************************************** ')
    print(' ************ SCENARIO START ************* ')
    print(' **************************************************************************************** ')

    imu_data_row_cnt =  0

    runtime = 0
    sum_deltaT = 0
    sum_deltaT_500Hz = 0
    imu_interp_loops = 0

    llh_lat = 0
    llh_lon = 0
    llh_ht = 0
    imu_interp_loops = 0
    imu_tow_prev = 0
    runtime_prev = 0

    # ********************************************************************
    # Store IMU data into an array of objects (rows)
    # [by doing so, at the time of sending MIP packet to device,
    # one can pop the object from the stack and minimize processing time]
    # ********************************************************************
    imu_row_10Hz_data = []

    imu_10Hz_mip_list_of_lists = []
    imu_10Hz_list_of_lists = []

    imu_row_500Hz_mip_list = []
    imu_row_500Hz_list = []

    imu_determine_headers = False
    imu_headers_found = False

    for imu_row_items in imu_csvreader:
       # determined that last row in CSV indicated data start (headers are in this row)
       if (imu_determine_headers == True):
          # column headers have been found
          imu_headers_found = True

          # headers no longer need to be determined
          imu_determine_headers = False

       elif(imu_headers_found == True):
          imu_data_row_cnt = imu_data_row_cnt + 1

          imu_row_10Hz_data.append(imu_row_items)

          if (imu_data_row_cnt > 1):
             dt = numpy.double(imu_row_items[3]) - numpy.double(imu_row_items_prev[3])

             if (dt > 0):
                imu_interp_loops = int(dt/dt_imu)   # Interpolation loops based on 500 Hz (0.002 sec) IMU required rate, dt_imu = 0.002
                dt_interp = (numpy.double(imu_row_items[3]) - numpy.double(imu_row_items_prev[3]))/imu_interp_loops

                sum_delta_theta_x = 0.0
                sum_delta_theta_y = 0.0
                sum_delta_theta_z = 0.0

                sum_delta_vel_x = 0.0
                sum_delta_vel_y = 0.0
                sum_delta_vel_z = 0.0

                for i in range(imu_interp_loops):
                   temp_imu_row_item = [0] * (len(imu_row_items_prev)+6)

                   temp_imu_row_item[1] = numpy.double(imu_row_items_prev[1]) + (numpy.double(imu_row_items[1]) - numpy.double(imu_row_items_prev[1])) * i/imu_interp_loops
                   temp_imu_row_item[2] = imu_row_items_prev[2]
                   temp_imu_row_item[3] = numpy.double(imu_row_items_prev[3]) + (numpy.double(imu_row_items[3]) - numpy.double(imu_row_items_prev[3])) * i/imu_interp_loops

                   for j in range(4, 10):
                      temp_imu_row_item[j] = float(imu_row_items_prev[j]) + (float(imu_row_items[j]) - float(imu_row_items_prev[j])) * i/imu_interp_loops
                   # }

                   # Read ambient pressure and move it to the last column (after deltaTheta, deltaV):
                   j = 10
                   temp_imu_row_item[16] = float(imu_row_items_prev[j]) + (float(imu_row_items[j]) - float(imu_row_items_prev[j])) * i/imu_interp_loops

                   # Compute deltaTheta, deltaV from gyro, accel:
                   for j in range(10, len(imu_row_items_prev)+5):
                      # print(' ***** j = ' + str(j))
                      if (j < 13): # Compute DeltaTheta from Gyro values
                         temp_imu_row_item[j] = (float(imu_row_items_prev[j-3]) + (float(imu_row_items[j-3]) - float(imu_row_items_prev[j-3])) * (i-0.5)/imu_interp_loops) * dt_interp
                      else: # Compute DeltaV from Accel values
                         temp_imu_row_item[j] = (float(imu_row_items_prev[j-9]) + (float(imu_row_items[j-9]) - float(imu_row_items_prev[j-9])) * (i-0.5)/imu_interp_loops) * dt_interp
                      # } if (j < 13)..
                   # } for j in range(10, len..

                   if (send_imu_mip_or_save_500Hz_IMU == 'i'):
                      sum_delta_theta_x += temp_imu_row_item[10]
                      sum_delta_theta_y += temp_imu_row_item[11]
                      sum_delta_theta_z += temp_imu_row_item[12]

                      sum_delta_vel_x += temp_imu_row_item[13]
                      sum_delta_vel_y += temp_imu_row_item[14]
                      sum_delta_vel_z += temp_imu_row_item[15]

                      fout_imu_500Hz_hil.write('%2d,%10.4f,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%15.12f,%15.12f,%15.12f,%15.12f,%15.12f,%15.12f,%14.8f\n'%(imu_interp_loops, temp_imu_row_item[1], int(temp_imu_row_item[2]), temp_imu_row_item[3], temp_imu_row_item[4], temp_imu_row_item[5], temp_imu_row_item[6], temp_imu_row_item[7], temp_imu_row_item[8], temp_imu_row_item[9], temp_imu_row_item[10], temp_imu_row_item[11], temp_imu_row_item[12], temp_imu_row_item[13], temp_imu_row_item[14], temp_imu_row_item[15], temp_imu_row_item[16]))
                   else: # want to send IMU MIP Packets to device
                      mp = bytearray([])

                      #initialize a packet for a base command
                      mip_init(mp,0x80)

                      mip_add_field(mp, 0x12, pack('>dHH', numpy.double(temp_imu_row_item[3]), numpy.ushort(temp_imu_row_item[2]), numpy.ushort(7)))

                      # Accel (0x8004) Flip the x and y axes and use -z (GSG to Lord frame conversion)
                      mip_add_field(mp, 0x04, pack('>fff', temp_imu_row_item[5], temp_imu_row_item[4], -temp_imu_row_item[6]))

                      # Gyro (0x8005) Flip the x and y axes and use +z (GSG to Lord frame conversion; GSG Yaw does NOT follow Right-Hand Rule)
                      mip_add_field(mp, 0x05, pack('>fff', temp_imu_row_item[8], temp_imu_row_item[7], temp_imu_row_item[9]))

                      # Mag (0x8006)
                      # # mip_add_field(mp, 0x06, pack('>fff', temp_imu_row_item[15], temp_imu_row_item[16], temp_imu_row_item[17]))
                      # mip_add_field(mp, 0x06, pack('>fff', temp_imu_row_item[16], temp_imu_row_item[17], temp_imu_row_item[18]))
                      # # mip_add_field(mp, 0x06, pack('>fff', 0, 0, 0))

                      # Delta Theta (0x8007) Flip the x and y axes and use +z (GSG to Lord frame conversion; GSG Yaw does NOT follow Right-Hand Rule)
                      mip_add_field(mp, 0x07, pack('>fff', temp_imu_row_item[11], temp_imu_row_item[10], temp_imu_row_item[12]))

                      # Delta Vel (0x8008) Flip the x and y axes and use -z (GSG to Lord frame conversion)
                      mip_add_field(mp, 0x08, pack('>fff', temp_imu_row_item[14], temp_imu_row_item[13], -temp_imu_row_item[15]))

                      # Pressure (0x8017)
                      mip_add_field(mp, 0x17, pack('>f', temp_imu_row_item[16]))

                      #finalize packet
                      mip_finalize(mp)

                      #print "Packet after finalize: " + hexlify(mp).upper()

                      imu_row_500Hz_mip_list.append(mp)
                      imu_row_500Hz_list.append(temp_imu_row_item)

                   # } if (send_imu_..
                # } for i in range(1,..

                if (send_imu_mip_or_save_500Hz_IMU == 'i'):
                   # 'Back-calculate' 10 Hz Gyro, Accel from 500 Hz DeltaTheta, DeltaV:
                   gyro_x_from_delta_theta = sum_delta_theta_x / dt
                   gyro_y_from_delta_theta = sum_delta_theta_y / dt
                   gyro_z_from_delta_theta = sum_delta_theta_z / dt

                   accel_x_from_delta_vel = sum_delta_vel_x / dt
                   accel_y_from_delta_vel = sum_delta_vel_y / dt
                   accel_z_from_delta_vel = sum_delta_vel_z / dt

                   fout_imu_10Hz_wBackCalc_hil.write('%2d,%10.4f,%4d,%14.5f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%15.12f,%15.12f,%15.12f,%14.8f,%14.8f,%14.8f,%14.8f\n'%(imu_interp_loops, numpy.double(imu_row_items[1]), int(imu_row_items[2]), numpy.double(imu_row_items[3]), numpy.double(imu_row_items[4]), numpy.double(imu_row_items[5]), numpy.double(imu_row_items[6]), numpy.double(imu_row_items[7]), numpy.double(imu_row_items[8]), numpy.double(imu_row_items[9]), gyro_x_from_delta_theta, gyro_y_from_delta_theta, gyro_z_from_delta_theta, accel_x_from_delta_vel, accel_y_from_delta_vel, accel_z_from_delta_vel, numpy.double(imu_row_items[10])))
                else:
                   imu_10Hz_mip_list_of_lists.append(imu_row_500Hz_mip_list)
                   imu_10Hz_list_of_lists.append(imu_row_500Hz_list)

                   imu_row_500Hz_mip_list = []
                   imu_row_500Hz_list = []
                # } if (send_imu_mip..
             # } if (dt > 0)..
          # } if (imu_data_row_cnt > 1)..

          imu_row_items_prev = [0] * (len(imu_row_items))
          for k in range(len(imu_row_items)):
             imu_row_items_prev[k] = imu_row_items[k]
          # }
       # this row is neither column headers nor data elements
       else:
          # test for DATA_START row (column headers to follow)
          if(len(imu_row_items) == 1 and imu_row_items[0] == 'DATA_START'):
             imu_determine_headers = True
             # print("IMU DATA_START found, collecting headers")
       # } if (imu_determine_headers ..
    # } for imu_row_items in imu_csvreader..

    # **********************************************************************
    #       Now pop the IMU data from the stack (created earlier)
    # **********************************************************************

    rm = None

    if (send_imu_mip_or_save_500Hz_IMU == 'm'):
       print(" ************************************************************************************ " )
       print(" ***** DONE CREATING THE MIP PACKET STACK OF LENGTH: " + str(len(imu_10Hz_mip_list_of_lists)) + ", WILL NOW SEND TO DEVICE AT : " + str(imu_data_rate) + " Hz");
       print(" ************************************************************************************ " )

       if (os.name == 'nt'):
          rm = visa.ResourceManager()       # for Windows
       elif (os.name == 'posix'):
          rm = visa.ResourceManager('@py')  # for Ubuntu

       # inst = rm.open_resource('USB0::0x14EB::0x0060::201038::INSTR')
       inst = rm.open_resource('TCPIP::10.6.2.76::inst0::INSTR')

       print("****** SOUR:SCEN:CONT?")
       print(str(inst.query("SOUR:SCEN:CONT?")))

       str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

       scenario_started = False

       if (str_scen_running[0:5] == 'START'):
          scenario_started = True
       else:
          print(' *********** No scenario running, will start scenario ***********')

          print("SOUR:SCEN:CONT start; *WAI;")
          str_start_scen = "%s" %(str(inst.write("SOUR:SCEN:CONT start; *WAI;")))
          print('********* str_start_scen: ' + str_start_scen)

          if (str_start_scen[0:2] == 'Ok'):
             print('********* SCENARIO STARTED: ')
          else:
             # Typically, GSG takes about 20 sec to start a scenario.  So we wait for 14 sec (to be on the safe side)
             # then check every second if the scenario has started.  We don't want to miss the exact start of the scenario.
             sleep(14)
             cnt = 0
             while(cnt < 20):
                cnt = cnt + 1

                str_scen_running = "%s" %(str(inst.query("SOUR:SCEN:CONT?")))

                if (str_scen_running[0:5] == 'START'):
                   print('******** SCENARIO STARTED' )
                   scenario_started = True
                   break
                else:
                   sleep(1)
                # } if (str_scen_running[0:5]...
             # } while(cnt < 20)...
          # } if (str_start_scen[0:2]...
       # }

       if (scenario_started == True):

          print("SOUR:SCEN:SENS:REG ACC")
          print(str(inst.write("SOUR:SCEN:SENS:REG ACC")))

          print("SOUR:SCEN:SENS:REG? ACC")
          print(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))
          str_acc_reg_status = "%s" %(str(inst.query("SOUR:SCEN:SENS:REG? ACC")))

          print("SOUR:SCEN:SENS:REG GYR")
          print(str(inst.write("SOUR:SCEN:SENS:REG GYR")))

          print("***** SOUR:SCEN:SENS:REG? GYR")
          print(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))
          str_gyr_reg_status = "%s" %(str(inst.query("SOUR:SCEN:SENS:REG? GYR")))

          # Proceed further only if ACC and GYR sensors are both registered with GSG
          if (str_acc_reg_status[0:2] == 'ON' and str_gyr_reg_status[0:2] == 'ON'):
             print('********** IMU PORT : '+ imu_port_name);
             #Assign serial port object
             imu_port = serial.Serial(imu_port_name, imu_port_baud)

             #Close port in case it was left open by other process
             imu_port.close()

             #open specified port
             imu_port.open()

             imu_data_row_cnt = 0

             str_runtime = "%s" %(str(inst.query("SOUR:SCEN:RUN?")))
             print('******* str_runtime : ' + str_runtime)
             runtime = numpy.double(str_runtime)

             foundMatch = False

             [imu_tow, imu_week, flags_80_12] = [0, 0, 0]
             [scaled_accel_x, scaled_accel_y, scaled_accel_z] = [0, 0, 0]
             [scaled_gyro_x, scaled_gyro_y, scaled_gyro_z] = [0, 0, 0]

             print(' ********* BEFORE POP: len(imu_10Hz_mip_list_of_lists) = ' + str(len(imu_10Hz_mip_list_of_lists)) )

             cnt_10Hz_pop = 0

             for imu_row_item in imu_row_10Hz_data:
                cnt_10Hz_pop = cnt_10Hz_pop + 1

                if (numpy.double(imu_row_item[1]) > runtime):
                   print(' *********** found match at cnt_10Hz_pop = ' + str(cnt_10Hz_pop) + ', imu_row_item[1] = ' + str(imu_row_item[1]) + ' and TOW = ' + str(imu_row_item[3]) + ' and runtime = ' + str(runtime))
                   foundMatch = True
                   for j in range(cnt_10Hz_pop-2):
                      imu_10Hz_mip_list_of_lists.pop(0)
                      imu_10Hz_list_of_lists.pop(0)
                      imu_row_10Hz_data.pop(0)
                   break
                # } if (numpy...
             # } for i in range(1, ..

             print(' ********** AFTER POP: foundMatch = ' + str(foundMatch) + ' cnt_10Hz_pop = ' + str(cnt_10Hz_pop) + ' len(imu_10Hz_mip_list_of_lists) = ' + str(len(imu_10Hz_mip_list_of_lists)) )

             user_input_object = GSG_USER_INPUT()

             #set up background process to accept user input such as pressing Enter key (to exit this script)
             background_user_input = AsyncUserInput(user_input_object, 10000)

             #start the user input thread
             background_user_input.start()

             if (foundMatch == True):
                for i in range(len(imu_10Hz_mip_list_of_lists)):
                   # Check if user pressed Enter key to stop recording
                   if (user_input_object.stop_recording == True):
                      break

                   if (os.name == 'nt'):
                      packet_process_start_time_10Hz = clock()    # Windows
                   elif (os.name == 'posix'):
                      packet_process_start_time_10Hz = time()     # Ubuntu

                   sum_deltaT_10Hz_final = 0

                   imu_data_row_cnt = imu_data_row_cnt + 1

                   # Get list of 50 MIP packets (at the current 10 Hz epoch) and send to device
                   imu_mip_packet_list = imu_10Hz_mip_list_of_lists.pop(0)  # get first item

                   # Get current 10 Hz IMU row for getting runtime (debug only)
                   imu_row_item = imu_row_10Hz_data.pop(0)

                   cntPck = 0
                   sum_deltaT = 0
                   sum_deltaT_500Hz = 0

                   for mp in imu_mip_packet_list:
                      if (os.name == 'nt'):
                         packet_process_start_time = clock()    # Windows
                      elif (os.name == 'posix'):
                         packet_process_start_time = time()     # Ubuntu
                      # } if (os.name..

                      cntPck = cntPck + 1

                      #send IMU MIP packet to device
                      imu_port.write(mp)
                      imu_port.flush()

                      if (os.name == 'nt'):
                         packet_process_end_time = clock()     # Windows
                      elif (os.name == 'posix'):
                         packet_process_end_time = time()      # Ubuntu

                      deltaT = packet_process_end_time - packet_process_start_time
                      sum_deltaT = sum_deltaT + deltaT

                      # Sleep only for the remainder of the 2 ms time step (after deducting the time taken to pop the MIP packet and write to device)
                      # Note: Sleep call itself needs about 0.1 millisec (= 0.0001 sec), so use (0.002 - 0.0001) = 0.0019 sec as 500 Hz time available
                      if (deltaT < 0.0019):
                          sleep(0.0019 - deltaT)
                      # }

                      if (debug_mode == 'y'):
                         if (os.name == 'nt'):
                            packet_process_final_end_time = clock()   # Windows
                         elif (os.name == 'posix'):
                            packet_process_final_end_time = time()    # Ubuntu
                         # } if (os.name..

                         sum_deltaT_500Hz = sum_deltaT_500Hz + (packet_process_final_end_time - packet_process_start_time)
                      # } if (debug_mode == 'y')..

                   # } for mp in imu_ ..

                   if (os.name == 'nt'):
                      packet_process_end_time_10Hz = clock()    # Windows
                   elif (os.name == 'posix'):
                      packet_process_end_time_10Hz = time()     # Ubuntu
                   # } if (os.name..

                   deltaT_10Hz = packet_process_end_time_10Hz - packet_process_start_time_10Hz

                   # Sleep only for the remainder of the 10 ms time step (after deducting the time taken to process the 10 Hz data); this is better than *OPC?
                   # Note: Sleep call itself needs about 0.1 millisec (= 0.0001 sec), so use (0.1 - 0.0001) = 0.0999 sec as 10 Hz time available
                   if (deltaT_10Hz < 0.0999):
                       sleep(0.0999 - deltaT_10Hz)
                   # }

                   if (debug_mode == 'y'):
                      if (os.name == 'nt'):
                         packet_process_final_end_time_10Hz = clock()  # Windows
                      elif (os.name == 'posix'):
                         packet_process_final_end_time_10Hz = time()   # Ubuntu
                      # } if (os.name..

                      sum_deltaT_10Hz_final = sum_deltaT_10Hz_final + (packet_process_final_end_time_10Hz - packet_process_start_time_10Hz)

                      # print(' **** runtime: ' + str(numpy.double(imu_row_item[1])) + ', imu_data_row_cnt: ' + str(imu_data_row_cnt) + ', imu_interp_loops: ' + str(len(imu_mip_packet_list)) + ', sum_deltaT = ' + str(sum_deltaT) + ', sum_deltaT_500Hz = ' + str(sum_deltaT_500Hz) + ', deltaT_10Hz = ' + str(deltaT_10Hz) + ' sum_deltaT_10Hz_final = ' + str(sum_deltaT_10Hz_final))
                      fout_processing_time.write('%2d,%6.2f,%2d,%15.13f,%15.13f,%15.13f,%15.13f,%15.13f,%15.13f\n'%(imu_data_row_cnt,numpy.double(imu_row_item[1]), len(imu_mip_packet_list), sum_deltaT, sum_deltaT/len(imu_mip_packet_list), sum_deltaT_500Hz, sum_deltaT_500Hz/len(imu_mip_packet_list), deltaT_10Hz, sum_deltaT_10Hz_final))
                   # } if (debug_mode == 'y')..

                   # inst.query("*OPC?")
                # } for i in range(len(imu_10Hz ..

             # } if (foundMatch == True)..

             print('****** DONE PROCESSING: ' + str(imu_data_row_cnt) + ' IMU input rows processed.')

             # else:
                # print(' *********** COULD NOT REGISTER ACC AND GYRO SENSORS WITH GSG, EXITING....')
          # } if (str_acc_reg_status[0:2] == 'ON' and...

          if (debug_mode == 'y'):
             fout_processing_time.close()

          imu_in_csvfile.close()

          # Stop background user input thread
          background_user_input.stop()

          print(' ******* Will stop scenario **** ')
          # Stop the scenario
          inst.write("SOUR:SCEN:CONT stop")

          # Close IMU HIL port
          imu_port.close()

       # } if (scenario_started == True)..

    else:
       print(" ************************************************************************************ " )
       print(" ***** DONE SAVING 500 HZ IMU DATA TO CSV FILE" );
       print(" ************************************************************************************ " )

       fout_imu_500Hz_hil.close()
       fout_imu_10Hz_wBackCalc_hil.close()

    # } if (send_imu_mip_ ..

if(__name__ == "__main__"):
  main_line(sys.argv)

