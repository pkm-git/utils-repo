import sys
from binascii import hexlify     #function to display hexadecimal bytes as ascii
                                 #text
from mip import *                #local file should be in local folder

from imu_format_using_dict import *
from gps_format_using_dict import *
from ekf_format_using_dict import *

from struct import * #import all objects and functions from the struct library
from time import time  #import time library

from sensor_cloud_api import *

from collections import OrderedDict

import numpy
import os

NBR_OF_LEAP_SECONDS = 17 # (as of July 2016)
UTC_EPOCH_TO_GPS_EPOCH_IN_SECS = 315964800
SECONDS_IN_A_WEEK = 604800

class channel_data_struct:
   def __init__(self):
      self.ts = 0
      self.value = 0

# def mip_binary_to_csv_or_sensor_cloud_fn(in_file_name, destination, desired_desc = None, server = None, token = None, device_id = None, sensor_name = None, sensor_label = None, sampleRate = 0, sampleRateType = HERTZ):
def mip_binary_to_csv_or_sensor_cloud_fn(in_file_name, destination, desired_desc = None, server = None, token = None, device_id = None, sensor_name = None, sensor_label = None, sampleRate = 0, sampleRateType = HERTZ):

 print(' *********** in mip_binary_to_csv_or_sensor_cloud_fn(), destination = ' + destination)

 # Define "Master columns" (i.e. all available columns in DCP) in a "master sequence"
 imu_default_cols_dict = {"8012":1, "8004":2, "8005":3, "8007":4, "8008":5, "8006":6, "8017":7, "8009":8, "800A":9, "800C":10, "8010":11, "8011":12}
 gps_default_cols_dict = {"8109":1, "8103":2, "8105":3, "8104":4, "8106":5, "810B":6, "810A":7, "810D":8, "8107":9, "8108":10, "810C":11}
 ekf_default_cols_dict = {"8211":1, "8210":2, "8201":3, "8208":4, "8202":5, "8209":6, "8205":7, "820A":8, "8203":9, "8212":10, "8207":11, "820C":12, "8217":13, "8219":14, "8206":15, "820B":16, "8216":17, "8218":18, "820D":19, "821C":20, "820E":21, "8213":22, "820F":23, "8214":24, "8215":25, "8220":26, "8221":27, "8230":28, "8231":29, "8204":30, "8227":31, "821A":32, "821B":33, "8223":34, "8224":35, "8225":36, "8228":37, "8226":38, "8229":39, "822A":40, "822B":41, "822C":42, "822D":43}

 # imu_default_cols_dict.keys()[imu_default_cols_dict.values().index(4)] = "8007"

 channel_names = []
 channel_data = {sensor_name:{}}

 # Get the order of columns requested by the user on the command line:
 imu_output_order_minus_d = []
 gps_output_order_minus_d = []
 ekf_output_order_minus_d = []

 # Get the order of columns obtained from the log file:
 imu_output_order_in_log = []
 gps_output_order_in_log = []
 ekf_output_order_in_log = []

 imu_output_order_final = []
 gps_output_order_final = []
 ekf_output_order_final = []

 found_d_option_in_command_line = False
 bad_descriptor_supplied = False

 ekf_invalid_packet_cnt = 0
 gps_invalid_packet_cnt = 0
 imu_invalid_packet_cnt = 0
 other_invalid_packet_cnt = 0

 if (desired_desc == None):
    print('\n ************* NO DESCRIPTOR LIST SPECIFIED ************ ')
    imu_output_order_minus_d = []
    gps_output_order_minus_d = []
    ekf_output_order_minus_d = []
 else:
    found_d_option_in_command_line = True
    #is this only 1 descriptor?
    if(len(desired_desc) == 4):
      if ((desired_desc)[:2] == '80'):
         imu_output_order_minus_d.append(imu_default_cols_dict[desired_desc.upper()])
      elif ((desired_desc)[:2] == '81'):
         gps_output_order_minus_d.append(gps_default_cols_dict[desired_desc.upper()])
      elif ((desired_desc)[:2] == '82'):
         ekf_output_order_minus_d.append(ekf_default_cols_dict[desired_desc.upper()])

    #is this more than one descriptor?
    elif(len(desired_desc) % 4 == 0 and len(desired_desc) > 0):
      #loop over the specified bytes
      for j in range(0,len(desired_desc),4):
        print(' **** Descriptor Requested: ' + desired_desc[j:j+4].upper() )
        if ((desired_desc[j:j+4])[:2] == '80'):
           imu_output_order_minus_d.append(imu_default_cols_dict[desired_desc[j:j+4].upper()])
        elif ((desired_desc[j:j+4])[:2] == '81'):
           gps_output_order_minus_d.append(gps_default_cols_dict[desired_desc[j:j+4].upper()])
        elif ((desired_desc[j:j+4])[:2] == '82'):
           ekf_output_order_minus_d.append(ekf_default_cols_dict[desired_desc[j:j+4].upper()])

    #is this a badly specified descriptor list?
    else:
       print('\n ************* BAD DESCRIPTOR LIST SPECIFIED ************ ')
       bad_descriptor_supplied = True
       imu_output_order_minus_d = []
       gps_output_order_minus_d = []
       ekf_output_order_minus_d = []
    # } if(len(desired_desc) == 4)..
 # } if (desired_desc == None)..

 # if command line arguments were not properly specified tell the user and exit
 if (in_file_name == None):
    print('Input file name cannot be empty')
    sys.exit()

 fin_bin = open(in_file_name, "rb")

 imu_format_dict_array = []
 gps_format_dict_array = []
 ekf_format_dict_array = []

 visible_channel_nbr_used_array = []

 imu_format_dict = {}
 gps_format_dict = {}
 gps_format_dict_tmp = {}
 ekf_format_dict = {}
 ekf_format_dict_tmp = {}

 imu_format_using_dict = IMU_format_using_dict()
 gps_format_using_dict = GPS_format_using_dict()
 ekf_format_using_dict = EKF_format_using_dict()

# --------------------------------------
 [imu_8012_struct, imu_8004_struct, imu_8005_struct, imu_8007_struct, imu_8008_struct, imu_8006_struct, imu_8017_struct, imu_8009_struct] = \
     [IMU_8012_struct(), IMU_8004_struct(), IMU_8005_struct(), IMU_8007_struct(), IMU_8008_struct(), IMU_8006_struct(), IMU_8017_struct(), IMU_8009_struct()]
 [imu_800A_struct, imu_800C_struct, imu_8010_struct, imu_8011_struct] = \
     [IMU_800A_struct(), IMU_800C_struct(), IMU_8010_struct(), IMU_8011_struct()]
# ------------------------------------------------
 [gps_8109_struct, gps_8103_struct, gps_8105_struct, gps_8104_struct, gps_8106_struct, gps_810B_struct, gps_810A_struct, gps_810D_struct] = \
     [GPS_8109_struct(), GPS_8103_struct(), GPS_8105_struct(), GPS_8104_struct(), GPS_8106_struct(), GPS_810B_struct(), GPS_810A_struct(), GPS_810D_struct()]
 [gps_8107_struct, gps_8108_struct, gps_810C_struct] = \
     [GPS_8107_struct(), GPS_8108_struct(), GPS_810C_struct()]
# ------------------------------------------------
 [ekf_8211_struct, ekf_8210_struct, ekf_8201_struct, ekf_8208_struct, ekf_8202_struct, ekf_8209_struct, ekf_8205_struct, ekf_820A_struct] = \
     [EKF_8211_struct(), EKF_8210_struct(), EKF_8201_struct(), EKF_8208_struct(), EKF_8202_struct(), EKF_8209_struct(), EKF_8205_struct(), EKF_820A_struct()]
 [ekf_8203_struct, ekf_8212_struct, ekf_8207_struct, ekf_820C_struct, ekf_8217_struct, ekf_8219_struct, ekf_8206_struct, ekf_820B_struct] = \
     [EKF_8203_struct(), EKF_8212_struct(), EKF_8207_struct(), EKF_820C_struct(), EKF_8217_struct(), EKF_8219_struct(), EKF_8206_struct(), EKF_820B_struct()]
 [ekf_8216_struct, ekf_8218_struct, ekf_820D_struct, ekf_821C_struct, ekf_820E_struct, ekf_8213_struct, ekf_820F_struct, ekf_8214_struct] = \
     [EKF_8216_struct(), EKF_8218_struct(), EKF_820D_struct(), EKF_821C_struct(), EKF_820E_struct(), EKF_8213_struct(), EKF_820F_struct(), EKF_8214_struct()]
 [ekf_8215_struct, ekf_8220_struct, ekf_8221_struct, ekf_8230_struct, ekf_8231_struct, ekf_8204_struct] = \
     [EKF_8215_struct(), EKF_8220_struct(), EKF_8221_struct(), EKF_8230_struct(), EKF_8231_struct(), EKF_8204_struct()]
 [ekf_8227_struct, ekf_821A_struct, ekf_821B_struct, ekf_8223_struct, ekf_8224_struct, ekf_8225_struct, ekf_8228_struct, ekf_8226_struct] = \
     [EKF_8227_struct(), EKF_821A_struct(), EKF_821B_struct(), EKF_8223_struct(), EKF_8224_struct(), EKF_8225_struct(), EKF_8228_struct(), EKF_8226_struct()]
 [ekf_8229_struct, ekf_822A_struct, ekf_822B_struct, ekf_822C_struct, ekf_822D_struct] = \
     [EKF_8229_struct(), EKF_822A_struct(), EKF_822B_struct(), EKF_822C_struct(), EKF_822D_struct()]

# ------------------------------------------------
 # gps_810C_dict = {}
 gps_810C_dict = OrderedDict()

 total_channel_cnt = 0
 total_nbr_of_visible_svs = 0

 sensStatus = 0
 if (destination != None):
    if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
       imu_channel_index_range_dict = {}
       gps_channel_index_range_dict = {}
       ekf_channel_index_range_dict = {}

       if(sensor_label != None):
          sensStatus = addSensor(server, token, device_id, sensor_name, "", sensor_label)
       else:
          sensStatus = addSensor(server, token, device_id, sensor_name)

       print(' ********** addSensor: status = ' + str(sensStatus))

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       (fin_filepath, fin_filename) = os.path.split(in_file_name)
       # fout_imu = open(os.path.join(fin_filepath, "IMU_Log.csv"), "w")
       # fout_gps = open(os.path.join(fin_filepath, "GPS_Log.csv"), "w")
       # fout_ekf = open(os.path.join(fin_filepath, "EKF_Log.csv"), "w")

       fout_imu = open(os.path.join(fin_filepath, fin_filename[:-4] + "_IMU_Log.csv"), "w")
       fout_gps = open(os.path.join(fin_filepath, fin_filename[:-4] + "_GPS_Log.csv"), "w")
       fout_ekf = open(os.path.join(fin_filepath, fin_filename[:-4] + "_EKF_Log.csv"), "w")

    if (destination.upper() != 'CSV' and destination.upper() != 'CLOUD' and destination.upper() != 'BOTH'):
       print(' ******* Destination must be either CSV, CLOUD or BOTH (case-insensitive) ********')
       sys.exit()
    # } if (destination.upper() != 'CSV'..
 else:
    print(' ******* Destination cannot be None; must be CSV, CLOUD or BOTH (case-insensitive) ********')
    sys.exit()
 # } if (destination != None)..
 k_start = 0

 bytes_read = fin_bin.read();

 print('\n ********** Length of all bytes read from bin file: len(bytes_read) = ' + str(len(bytes_read)) )

 for k in range(0, len(bytes_read)):
    if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
       print(' ***** Found first [0x75 0x65] MIP pair at byte index: ' + str(k) + '\n')
       k_start = k;
       break;

 payload_size = 0
 bad_packets = 0
 k = k_start

 found_imu = False
 found_gps = False
 found_ekf = False

 output_EKF = False

 ekf_packet_cnt = 0
 found_timestamp_ekf_packet_1 = False
 found_timestamp_ekf_packet_2 = False

 ekf_split_packets = False
 processed_first_EKF_packet_pair = False

 packet_cnt = 0
 imu_packet_cnt = 0
 gps_packet_cnt = 0
 gps_total_packet_cnt = 0
 ekf_total_packet_cnt = 0
 other_packet_cnt = 0

 found_timestamp_gps_packet_1 = False
 found_timestamp_gps_packet_2 = False

 gps_split_packets = False
 processed_first_GPS_packet_pair = False
 found_gps_810C_SV_Info = False

 # Look for beginning of a valid MIP packet (Bytes: 0x7565):
 while (k < len(bytes_read)):

   if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65'):
      packet_cnt = packet_cnt + 1

      desc_set = hexlify( bytearray(bytes_read[k+2]) ).upper()
      [payload_size] = unpack('<B', bytearray(bytes_read[k+3]))
      packet_bytes = bytearray( bytes_read[k:k+payload_size+6] )

      # print('****** Packet Nbr: ' + str(packet_cnt) + ' Descriptor Set = ' + hexlify( bytearray(bytes_read[k+2]) ).upper() + ' Packet size = ' + str(payload_size) )

      if (desc_set == '82'):
         ekf_total_packet_cnt = ekf_total_packet_cnt + 1
      elif (desc_set == '81'):
         gps_total_packet_cnt = gps_total_packet_cnt + 1
      elif (desc_set == '80'):
         imu_packet_cnt = imu_packet_cnt + 1
      else:
         other_packet_cnt = other_packet_cnt + 1

      mip_check_ret_code = mip_is_mip_packet(packet_bytes)

      if (mip_check_ret_code != MIP_OK):
         if (mip_check_ret_code == MIP_CHECKSUM_ERROR):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has Checksum error')
         elif (mip_check_ret_code == MIP_ERROR):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP error')
         elif (mip_check_ret_code == MIP_INVALID_PACKET):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP Invalid error')
         elif (mip_check_ret_code == MIP_PAYLOAD_LENGTH_MISMATCH_ERROR):
            print(' ********* Packet Nbr: ' + str(packet_cnt) + ' has MIP Payload length mismatch error')
            # break

         if (desc_set == '82'):
            ekf_invalid_packet_cnt = ekf_invalid_packet_cnt + 1
         elif (desc_set == '81'):
            gps_invalid_packet_cnt = gps_invalid_packet_cnt + 1
         elif (desc_set == '80'):
            imu_invalid_packet_cnt = imu_invalid_packet_cnt + 1
         else:
            other_invalid_packet_cnt = other_invalid_packet_cnt + 1
      else:
         k_field_start = 4

         # Determine if GPS packets are split in two (when user selects several GPS fields, the output gets distributed in 2 separate GPS packets; only one of them containing the timestamp):
         if (desc_set == '81'):
            gps_packet_cnt = gps_packet_cnt + 1
            
            if (0):
               is_810C_pkt = False
               
               # Check if it is an x810C packet (SV Info):
               j = k+k_field_start

               while(j < k+payload_size+4):
                  [field_size] = unpack('<B', bytearray(bytes_read[j]))
                  field_desc = hexlify( bytearray(bytes_read[j+1]) )
                  if (field_desc == '0C'):
                     is_810C_pkt = True
                     break
                  # } if (field_desc == '0C').. 
               # } while(j < k+payload_size+4)..
               
               # Skip packets with only x810C (SV Info) in them in counting GPS packets
               # because they are basically an extension of the previous GPS packet
               
               # [REMOVE: and also in determining if packets are split because x810C always comes in a
               # separate MIP packet with no timestamp, even if packet size < 255]
               # if (not is_810C_pkt):
                  # gps_packet_cnt = gps_packet_cnt + 1
               # } if (not is_810C_pkt)..
               
            if (processed_first_GPS_packet_pair == False):
               j = k+k_field_start

               while(j < k+payload_size+4):
                  [field_size] = unpack('<B', bytearray(bytes_read[j]))
                  field_desc = hexlify( bytearray(bytes_read[j+1]) )
                  if (field_desc == '09'):
                     if (gps_packet_cnt == 1):
                        found_timestamp_gps_packet_1 = True
                     else:
                        found_timestamp_gps_packet_2 = True
                     # } if (gps_packet_cnt == 1)..
                  # } if (field_desc == '09')..
                  j = j + field_size
               # } while(j < k+payload_size+4)..

               if (gps_packet_cnt == 2):
                  # If only one packet in the first GPS packet pair in the file contains a timestamp, consider it "GPS split output" (i.e. GPS packet size more than 255 char):
                  if ((found_timestamp_gps_packet_1 == True and found_timestamp_gps_packet_2 == False) or (found_timestamp_gps_packet_1 == False and found_timestamp_gps_packet_2 == True) ):
                     gps_split_packets = True
                     print('\n************ SPLIT GPS PACKETS = TRUE ************\n')

                  elif (found_timestamp_gps_packet_1 == True and found_timestamp_gps_packet_2 == True):
                     gps_split_packets = False
                     print('\n************ SPLIT GPS PACKETS = FALSE ************\n')
                  # } if ((found_timestamp_gps_packet_1 == True..
                  processed_first_GPS_packet_pair = True
               # } if (gps_packet_cnt == 2)..
            # } if (processed_first_GPS_packet_pair == False)..
            
         # Determine if EKF packets are split in two (when user selects several EKF fields, the output gets distributed in 2 separate EKF packets; only one of them containing the timestamp):
         elif (desc_set == '82'):
            ekf_packet_cnt = ekf_packet_cnt + 1
            # print('\n--------------------------------------')
            # print('************ just incremented ekf_packet_cnt = ' + str(ekf_packet_cnt))

            if (processed_first_EKF_packet_pair == False):
               j = k+k_field_start

               while(j < k+payload_size+4):
                  [field_size] = unpack('<B', bytearray(bytes_read[j]))
                  field_desc = hexlify( bytearray(bytes_read[j+1]) )

                  if (field_desc == '11'):
                     if (ekf_packet_cnt == 1):
                        found_timestamp_ekf_packet_1 = True
                     else:
                        found_timestamp_ekf_packet_2 = True

                  j = j + field_size
               # } while(j < k+payload_size+4)..

               if (ekf_packet_cnt == 2):
                  # If only one packet in the first EKF packet pair in the file contains a timestamp, consider it "EKF split output" (i.e. EKF packet size more than 255 char):
                  if ((found_timestamp_ekf_packet_1 == True and found_timestamp_ekf_packet_2 == False) or (found_timestamp_ekf_packet_1 == False and found_timestamp_ekf_packet_2 == True) ):
                     ekf_split_packets = True
                     print('\n************ SPLIT EKF PACKETS = TRUE ************\n')

                  elif (found_timestamp_ekf_packet_1 == True and found_timestamp_ekf_packet_2 == True):
                     ekf_split_packets = False
                     print('\n************ SPLIT EKF PACKETS = FALSE ************\n')

                  # } if ((found_timestamp_ekf_packet_1 == True..
                  processed_first_EKF_packet_pair = True
               # } if (ekf_packet_cnt == 2)..
            # } if (processed_first_EKF_packet_pair == False)..
         # } if (desc_set == '81')..

         # Reset 'j' back to beginning of first field in this packet
         j = k+k_field_start

         # if (packet_cnt < 20):
            # print('------------ Packet begin for packet_cnt = ' + str(packet_cnt) + ' -------------------------')

         # Get all fields in the packet, and set attributes of appropriate format object:
         while(j < k+payload_size+4):
            [field_size] = unpack('<B', bytearray(bytes_read[j]))
            field_bytes = bytes_read[j+2:j+field_size]
            field_desc = hexlify( bytearray(bytes_read[j+1]) ).upper()
            packet_field_descr = desc_set + field_desc.upper()

            # if (desc_set == '80'):
               # print(' Field size = ' + str(field_size) + ', field_desc = ' + hexlify( bytearray(bytes_read[j+1:j+2]) ) + ' and field_bytes = ' + hexlify( bytearray(field_bytes) ).upper()   )
               # print(' Field size = ' + str(field_size) + ', field_desc = ' + hexlify( bytearray(bytes_read[j+1:j+2]) ).upper() )

            if (desc_set == '82' and packet_field_descr in ekf_default_cols_dict):
               found_ekf = True
               output_column_seq = ekf_default_cols_dict[packet_field_descr]
               if (output_column_seq not in ekf_output_order_in_log):
                  ekf_output_order_in_log.append(output_column_seq)
                  # print(' ********* EKF: packet_field_descr = ' + packet_field_descr + ', added to ekf_output_order_in_log: EKF index = ' + str(output_column_seq))
               # } if (output_column_seq not in ekf_output_order_in_log)..

               if (field_desc == '11'):
                  [ekf_8211_struct.ekf_tow, ekf_8211_struct.ekf_week, ekf_8211_struct.flags_82_11] = unpack('>dHH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8211_struct
                  # if (ekf_8211_struct.ekf_week > 0):
                     # print(' ************* EKF: 8211: ekf_packet_cnt = ' + str(ekf_packet_cnt) + ', ekf_8211_struct.ekf_week = ' + str(ekf_8211_struct.ekf_week) + ', ekf_8211_struct.ekf_tow: ' + str(ekf_8211_struct.ekf_tow))

               elif (field_desc == '10'):
                  [ekf_8210_struct.ekf_state, ekf_8210_struct.ekf_mode, ekf_8210_struct.flags_82_10] = unpack('>HHH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8210_struct

               elif (field_desc == '01'):
                  [ekf_8201_struct.ekf_pos_llh_lat, ekf_8201_struct.ekf_pos_llh_lon, ekf_8201_struct.ekf_pos_llh_ht, ekf_8201_struct.flags_82_01] = unpack('>dddH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8201_struct

               elif (field_desc == '08'):
                  [ekf_8208_struct.ekf_pos_llh_UC_lat, ekf_8208_struct.ekf_pos_llh_UC_lon, ekf_8208_struct.ekf_pos_llh_UC_ht, ekf_8208_struct.flags_82_08] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8208_struct

               elif (field_desc == '02'):
                  [ekf_8202_struct.ekf_ned_vel_x, ekf_8202_struct.ekf_ned_vel_y, ekf_8202_struct.ekf_ned_vel_z, ekf_8202_struct.flags_82_02] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8202_struct

               elif (field_desc == '09'):
                  [ekf_8209_struct.ekf_ned_vel_UC_x, ekf_8209_struct.ekf_ned_vel_UC_y, ekf_8209_struct.ekf_ned_vel_UC_z, ekf_8209_struct.flags_82_09] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8209_struct

               elif (field_desc == '05'):
                  [ekf_8205_struct.euler_angle_roll, ekf_8205_struct.euler_angle_pitch, ekf_8205_struct.euler_angle_yaw, ekf_8205_struct.flags_82_05] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8205_struct

               elif (field_desc == '0A'):
                  [ekf_820A_struct.euler_angle_UC_roll, ekf_820A_struct.euler_angle_UC_pitch, ekf_820A_struct.euler_angle_UC_yaw, ekf_820A_struct.flags_82_0a] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_820A_struct

               elif (field_desc == '03'):
                  [ekf_8203_struct.quat_0, ekf_8203_struct.quat_1, ekf_8203_struct.quat_2, ekf_8203_struct.quat_3, flags_82_03] = unpack('>ffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8203_struct

               elif (field_desc == '12'):
                  [ekf_8212_struct.quat_UC_0, ekf_8212_struct.quat_UC_1, ekf_8212_struct.quat_UC_2, ekf_8212_struct.quat_UC_3, ekf_8212_struct.flags_82_12] = unpack('>ffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8212_struct

               elif (field_desc == '07'):
                  [ekf_8207_struct.accel_bias_x, ekf_8207_struct.accel_bias_y, ekf_8207_struct.accel_bias_z, ekf_8207_struct.flags_82_07] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8207_struct

               elif (field_desc == '0C'):
                  [ekf_820C_struct.accel_bias_UC_x, ekf_820C_struct.accel_bias_UC_y, ekf_820C_struct.accel_bias_UC_z, ekf_820C_struct.flags_82_0c] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_820C_struct

               elif (field_desc == '17'):
                  [ekf_8217_struct.accel_SF_x, ekf_8217_struct.accel_SF_y, ekf_8217_struct.accel_SF_z, ekf_8217_struct.flags_82_17] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8217_struct

               elif (field_desc == '19'):
                  [ekf_8219_struct.accel_SF_UC_x, ekf_8219_struct.accel_SF_UC_y, ekf_8219_struct.accel_SF_UC_z, ekf_8219_struct.flags_82_19] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8219_struct

               elif (field_desc == '06'):
                  [ekf_8206_struct.gyro_bias_x, ekf_8206_struct.gyro_bias_y, ekf_8206_struct.gyro_bias_z, ekf_8206_struct.flags_82_06] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8206_struct

               elif (field_desc == '0B'):
                  [ekf_820B_struct.gyro_bias_UC_x, ekf_820B_struct.gyro_bias_UC_y, ekf_820B_struct.gyro_bias_UC_z, ekf_820B_struct.flags_82_0b] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_820B_struct

               elif (field_desc == '16'):
                  [ekf_8216_struct.gyro_SF_x, ekf_8216_struct.gyro_SF_y, ekf_8216_struct.gyro_SF_z, ekf_8216_struct.flags_82_16] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8216_struct

               elif (field_desc == '18'):
                  [ekf_8218_struct.gyro_SF_UC_x, ekf_8218_struct.gyro_SF_UC_y, ekf_8218_struct.gyro_SF_UC_z, ekf_8218_struct.flags_82_18] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8218_struct

               elif (field_desc == '0D'):
                  [ekf_820D_struct.lin_accel_x, ekf_820D_struct.lin_accel_y, ekf_820D_struct.lin_accel_z, ekf_820D_struct.flags_82_0d] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_820D_struct

               elif (field_desc == '1C'):
                  [ekf_821C_struct.comp_accel_x, ekf_821C_struct.comp_accel_y, ekf_821C_struct.comp_accel_z, ekf_821C_struct.flags_82_1c] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_821C_struct

               elif (field_desc == '0E'):
                  [ekf_820E_struct.comp_gyro_x, ekf_820E_struct.comp_gyro_y, ekf_820E_struct.comp_gyro_z, ekf_820E_struct.flags_82_0e] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_820E_struct

               elif (field_desc == '13'):
                  [ekf_8213_struct.grav_vect_x, ekf_8213_struct.grav_vect_y, ekf_8213_struct.grav_vect_z, ekf_8213_struct.flags_82_13] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8213_struct

               elif (field_desc == '0F'):
                  [ekf_820F_struct.grav_mag, ekf_820F_struct.flags_82_0f] = unpack('>fH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_820F_struct

               elif (field_desc == '14'):
                  [ekf_8214_struct.heading, ekf_8214_struct.heading_UC, ekf_8214_struct.heading_source, ekf_8214_struct.flags_82_14] = unpack('>ffHH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8214_struct

               elif (field_desc == '15'):
                  [ekf_8215_struct.inten_N, ekf_8215_struct.inten_E, ekf_8215_struct.inten_D, ekf_8215_struct.inclination, ekf_8215_struct.declination, ekf_8215_struct.flags_82_15] = unpack('>fffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8215_struct

               elif (field_desc == '21'):
                  [ekf_8221_struct.pressure_altitude, ekf_8221_struct.flags_82_21] = unpack('>fH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8221_struct

               elif (field_desc == '20'):
                  [ekf_8220_struct.geom_alt, ekf_8220_struct.geopot_alt, ekf_8220_struct.temp, ekf_8220_struct.pressure, ekf_8220_struct.density, ekf_8220_struct.flags_82_20] = unpack('>fffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8220_struct

               elif (field_desc == '30'):
                  [ekf_8230_struct.gps_ant_offset_corr_x, ekf_8230_struct.gps_ant_offset_corr_y, ekf_8230_struct.gps_ant_offset_corr_z, ekf_8230_struct.flags_82_30] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8230_struct

               elif (field_desc == '31'):
                  [ekf_8231_struct.gps_ant_offset_corr_UC_x, ekf_8231_struct.gps_ant_offset_corr_UC_y, ekf_8231_struct.gps_ant_offset_corr_UC_z, ekf_8231_struct.flags_82_31] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8231_struct

               elif (field_desc == '04'):
                  [ekf_8204_struct.matrix_m11, ekf_8204_struct.matrix_m12, ekf_8204_struct.matrix_m13, ekf_8204_struct.matrix_m21, ekf_8204_struct.matrix_m22, ekf_8204_struct.matrix_m23, ekf_8204_struct.matrix_m31, ekf_8204_struct.matrix_m32, ekf_8204_struct.matrix_m33, ekf_8204_struct.flags_82_04] = unpack('>fffffffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8204_struct

               elif (field_desc == '27'):
                  [ekf_8227_struct.mag_comp_x, ekf_8227_struct.mag_comp_y, ekf_8227_struct.mag_comp_z, ekf_8227_struct.flags_82_27] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8227_struct

               elif (field_desc == '1A'):
                  [ekf_821A_struct.mag_bias_x, ekf_821A_struct.mag_bias_x, ekf_821A_struct.mag_bias_x, ekf_821A_struct.flags_82_1a] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_821A_struct

               elif (field_desc == '1B'):
                  [ekf_821B_struct.mag_bias_UC_x, ekf_821B_struct.mag_bias_UC_y, ekf_821B_struct.mag_bias_UC_z, ekf_821B_struct.flags_82_1b] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_821B_struct

               elif (field_desc == '23'):
                  [ekf_8223_struct.mag_SF_x, ekf_8223_struct.mag_SF_y, ekf_8223_struct.mag_SF_z, ekf_8223_struct.flags_82_23] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8223_struct

               elif (field_desc == '24'):
                  [ekf_8224_struct.mag_SF_UC_x, ekf_8224_struct.mag_SF_UC_y, ekf_8224_struct.mag_SF_UC_z, ekf_8224_struct.flags_82_24] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8224_struct

               elif (field_desc == '25'):
                  [ekf_8225_struct.mag_auto_hard_iron_offset_x, ekf_8225_struct.mag_auto_hard_iron_offset_y, ekf_8225_struct.mag_auto_hard_iron_offset_z, ekf_8225_struct.flags_82_25] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8225_struct

               elif (field_desc == '28'):
                  [ekf_8228_struct.mag_auto_hard_iron_offset_UC_x, ekf_8228_struct.mag_auto_hard_iron_offset_UC_y, ekf_8228_struct.mag_auto_hard_iron_offset_UC_z, ekf_8228_struct.flags_82_28] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8228_struct

               elif (field_desc == '26'):
                  [ekf_8226_struct.mag_auto_soft_iron_m11, ekf_8226_struct.mag_auto_soft_iron_m12, ekf_8226_struct.mag_auto_soft_iron_m13, ekf_8226_struct.mag_auto_soft_iron_m21, ekf_8226_struct.mag_auto_soft_iron_m22, ekf_8226_struct.mag_auto_soft_iron_m23, ekf_8226_struct.mag_auto_soft_iron_m31, ekf_8226_struct.matrix_m32, self.matrix_m33, self.flags_82_26] = unpack('>fffffffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8226_struct

               elif (field_desc == '29'):
                  [ekf_8229_struct.mag_auto_soft_iron_UC_m11, ekf_8229_struct.mag_auto_soft_iron_UC_m12, ekf_8229_struct.mag_auto_soft_iron_UC_m13, ekf_8229_struct.mag_auto_soft_iron_UC_m21, ekf_8229_struct.mag_auto_soft_iron_UC_m22, ekf_8229_struct.mag_auto_soft_iron_UC_m23, ekf_8229_struct.mag_auto_soft_iron_UC_m31, ekf_8229_struct.matrix_m32, self.matrix_m33, self.flags_82_29] = unpack('>fffffffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_8229_struct

               elif (field_desc == '2A'):
                  [ekf_822A_struct.mag_auto_adap_noise_m11, ekf_822A_struct.mag_auto_adap_noise_m12, ekf_822A_struct.mag_auto_adap_noise_m13, ekf_822A_struct.mag_auto_adap_noise_m21, ekf_822A_struct.mag_auto_adap_noise_m22, ekf_822A_struct.mag_auto_adap_noise_m23, ekf_822A_struct.mag_auto_adap_noise_m31, ekf_822A_struct.matrix_m32, self.matrix_m33, self.flags_82_2a] = unpack('>fffffffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_822A_struct

               elif (field_desc == '2B'):
                  [ekf_822B_struct.grav_auto_adap_noise_m11, ekf_822B_struct.grav_auto_adap_noise_m12, ekf_822B_struct.grav_auto_adap_noise_m13, ekf_822B_struct.grav_auto_adap_noise_m21, ekf_822B_struct.grav_auto_adap_noise_m22, ekf_822B_struct.grav_auto_adap_noise_m23, ekf_822B_struct.matrix_m31, ekf_822B_struct.matrix_m32, self.matrix_m33, self.flags_82_2b] = unpack('>fffffffffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_822B_struct

               elif (field_desc == '2C'):
                  [ekf_822C_struct.mag_residual_x, ekf_822C_struct.mag_residual_y, ekf_822C_struct.mag_residual_z, ekf_822C_struct.flags_82_2c] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_822C_struct

               elif (field_desc == '2D'):
                  [ekf_822D_struct.mag_filt_residual_x, ekf_822D_struct.mag_filt_residual_y, ekf_822D_struct.mag_filt_residual_z, ekf_822D_struct.flags_82_2d] = unpack('>fffH', bytearray(field_bytes) )
                  ekf_format_dict[packet_field_descr] = ekf_822D_struct

            elif (desc_set == '81' and packet_field_descr in gps_default_cols_dict):
               found_gps = True

               output_column_seq = gps_default_cols_dict[packet_field_descr]
               if (output_column_seq not in gps_output_order_in_log):
                  gps_output_order_in_log.append(output_column_seq)
               # } if (output_column_seq not in gps_output_order_in_log)..

               if (field_desc == '09'):
                  [gps_8109_struct.gps_tow, gps_8109_struct.gps_week, gps_8109_struct.flags_81_09] = unpack('>dHH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8109_struct

               elif (field_desc == '03'):
                  [gps_8103_struct.gps_lat, gps_8103_struct.gps_lon, gps_8103_struct.gps_ht_abv_ellip, gps_8103_struct.gps_ht_abv_MSL, gps_8103_struct.gps_horiz_acc, gps_8103_struct.gps_vert_acc, gps_8103_struct.flags_81_03] = unpack('>ddddffH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8103_struct

               elif (field_desc == '05'):
                  [gps_8105_struct.gps_vned_N, gps_8105_struct.gps_vned_E, gps_8105_struct.gps_vned_D, gps_8105_struct.gps_speed, gps_8105_struct.gps_grnd_speed, gps_8105_struct.gps_heading, gps_8105_struct.gps_speed_acc, gps_8105_struct.gps_heading_acc, gps_8105_struct.flags_81_05] = unpack('>ffffffffH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8105_struct

               elif (field_desc == '04'):
                  [gps_8104_struct.gps_pos_ecef_x, gps_8104_struct.gps_pos_ecef_y, gps_8104_struct.gps_pos_ecef_z, gps_8104_struct.gps_pos_ecef_UC, gps_8104_struct.flags_81_04] = unpack('>dddfH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8104_struct

               elif (field_desc == '06'):
                  [gps_8106_struct.gps_vel_ecef_x, gps_8106_struct.gps_vel_ecef_y, gps_8106_struct.gps_vel_ecef_z, gps_8106_struct.gps_vel_ecef_UC, gps_8106_struct.flags_81_06] = unpack('>ffffH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8106_struct

               elif (field_desc == '0B'):
                  [gps_810B_struct.gps_fix_type, gps_810B_struct.gps_nbr_of_svs_used, gps_810B_struct.gps_fix_flags, gps_810B_struct.flags_81_0b] = unpack('>BBHH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_810B_struct

               elif (field_desc == '0A'):
                  [gps_810A_struct.gps_clock_bias, gps_810A_struct.gps_clock_drift, gps_810A_struct.gps_clock_acc_estimate, gps_810A_struct.flags_81_0a] = unpack('>dddH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_810A_struct

               elif (field_desc == '0D'):
                  [gps_810D_struct.gps_hw_status_sensor_state, gps_810D_struct.gps_hw_status_antenna_state, gps_810D_struct.gps_hw_status_antenna_power, gps_810D_struct.flags_81_0d] = unpack('>BBBH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_810D_struct

               elif (field_desc == '07'):
                  [gps_8107_struct.geom_dop, gps_8107_struct.pos_dop, gps_8107_struct.horiz_dop, gps_8107_struct.vert_dop, gps_8107_struct.time_dop, gps_8107_struct.northing_dop, gps_8107_struct.easting_dop, gps_8107_struct.flags_81_07] = unpack('>fffffffH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8107_struct

               elif (field_desc == '08'):
                  [gps_8108_struct.utc_yr, gps_8108_struct.utc_mo, gps_8108_struct.utc_day, gps_8108_struct.utc_hr, gps_8108_struct.utc_min, gps_8108_struct.utc_sec, gps_8108_struct.utc_msec, gps_8108_struct.flags_81_08] = unpack('>HBBBBBIH', bytearray(field_bytes) )
                  gps_format_dict[packet_field_descr] = gps_8108_struct

               elif (field_desc == '0C'):
                  found_gps_810C_SV_Info = True
                  gps_810C_struct = GPS_810C_struct()
                  [gps_810C_struct.channel_nbr, gps_810C_struct.sv_id, gps_810C_struct.carrier_to_noise_ratio, gps_810C_struct.azimuth, gps_810C_struct.elevation, gps_810C_struct.sv_flags, gps_810C_struct.valid_flags_81_0c] = unpack('>BBHhhHH', bytearray(field_bytes) )
                  gps_810C_dict[gps_810C_struct.channel_nbr] = gps_810C_struct
                  if (gps_810C_struct.channel_nbr not in visible_channel_nbr_used_array):
                     visible_channel_nbr_used_array.append(gps_810C_struct.channel_nbr)
                  
               if (gps_packet_cnt < 70):
                  print('\n------------------------------------------------------------------')
                  
                  print (' ********** packet_field_descr = ' + packet_field_descr)

                  tmp_str = hexlify( bytearray(field_bytes) ).upper()
                  print(' ****** SV Info: Field size = ' + str(field_size) + ', field_desc = ' + field_desc + ' and field_bytes = '),
                  for i1 in range(0,len(tmp_str),2):
                     print(tmp_str[i1] + tmp_str[i1+1]),
                  print('\n')

                  print('****** Packet Nbr: ' + str(packet_cnt) + ', gps_packet_cnt: ' + str(gps_packet_cnt) + ', Packet size = ' + str(payload_size) )

                  tmp_str = hexlify( bytearray(packet_bytes) ).upper()
                  print(' ****** SV Info: packet_bytes = '),
                  for i1 in range(0,len(tmp_str),2):
                     print(tmp_str[i1] + tmp_str[i1+1]),
                  print('\n')
                  
                  if (field_desc == '0C'):
                     print(' ********** gps_810C_struct.channel_nbr: ' + str(gps_810C_struct.channel_nbr))
                     print(' ********** gps_810C_struct.sv_id: ' + str(gps_810C_struct.sv_id))
                     print(' ********** gps_810C_struct.azimuth: ' + str(gps_810C_struct.azimuth))
                     print(' ********** gps_810C_struct.elevation: ' + str(gps_810C_struct.elevation))
                  # } if (field_desc == '0C')..
               # else:
                  # sys.exit()
                        
            elif (desc_set == '80' and packet_field_descr in imu_default_cols_dict):
               found_imu = True

               output_column_seq = imu_default_cols_dict[packet_field_descr]
               if (output_column_seq not in imu_output_order_in_log):
                  imu_output_order_in_log.append(output_column_seq)
               # } if (output_column_seq not in gps_output_order_in_log)..

               if (field_desc == '12'):
                  [imu_8012_struct.imu_tow, imu_8012_struct.imu_week, imu_8012_struct.flags_80_12] = unpack('>dHH', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8012_struct
                  # if (imu_8012_struct.imu_week > 0):
                     # print(' ******* imu_packet_cnt: ' + str(imu_packet_cnt) + ', parsed TOW in orig packet, imu_8012_struct.imu_week = ' + str(imu_8012_struct.imu_week) + ', imu tow = ' + str(imu_8012_struct.imu_tow))

               elif (field_desc == '04'):
                  [imu_8004_struct.scaled_accel_x, imu_8004_struct.scaled_accel_y, imu_8004_struct.scaled_accel_z] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8004_struct

               elif (field_desc == '05'):
                  [imu_8005_struct.scaled_gyro_x, imu_8005_struct.scaled_gyro_y, imu_8005_struct.scaled_gyro_z] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8005_struct

               elif (field_desc == '07'):
                  [imu_8007_struct.delta_theta_roll, imu_8007_struct.delta_theta_pitch, imu_8007_struct.delta_theta_yaw] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8007_struct

               elif (field_desc == '08'):
                  [imu_8008_struct.delta_vel_x, imu_8008_struct.delta_vel_y, imu_8008_struct.delta_vel_z] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8008_struct

               elif (field_desc == '06'):
                  [imu_8006_struct.mag_x, imu_8006_struct.mag_y, imu_8006_struct.mag_z] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8006_struct

               elif (field_desc == '17'):
                  [imu_8017_struct.ambient_pr] = unpack('>f', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8017_struct

               elif (field_desc == '09'):
                  [imu_8009_struct.cf_matrix_m11, imu_8009_struct.cf_matrix_m12, imu_8009_struct.cf_matrix_m13, imu_8009_struct.cf_matrix_m21, imu_8009_struct.cf_matrix_m22, imu_8009_struct.cf_matrix_m23, imu_8009_struct.cf_matrix_m31, imu_8009_struct.cf_matrix_m32, imu_8009_struct.cf_matrix_m33] = unpack('>fffffffff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8009_struct

               elif (field_desc == '0A'):
                  [imu_800A_struct.cf_quat_0, imu_800A_struct.cf_quat_1, imu_800A_struct.cf_quat_2, imu_800A_struct.cf_quat_3] = unpack('>ffff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_800A_struct

               elif (field_desc == '0C'):
                  [imu_800C_struct.cf_euler_angle_roll, imu_800C_struct.cf_euler_angle_pitch, imu_800C_struct.cf_euler_angle_yaw] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_800C_struct

               elif (field_desc == '10'):
                  [imu_8010_struct.cf_stabilized_mag_vector_north_x, imu_8010_struct.cf_stabilized_mag_vector_north_y, imu_8010_struct.cf_stabilized_mag_vector_north_z] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8010_struct

               elif (field_desc == '11'):
                  [imu_8011_struct.cf_stabilized_accel_vector_up_x, imu_8011_struct.cf_stabilized_accel_vector_up_y, imu_8011_struct.cf_stabilized_accel_vector_up_z] = unpack('>fff', bytearray(field_bytes) )
                  imu_format_dict[packet_field_descr] = imu_8011_struct

            # } if (desc_set == '82')..

            j = j + field_size
         # } while(j < k+payload_size+4)..

         # Use fields from packet to create one row of output to 'channel_data' structure being sent to Sensor Cloud:
         # Also get dictionaries ready for next time step
         # Wipe out the content of the 3 dictionary objects
         # because we don't want to retain fields from previous timestamp that may not
         # apply for the current timestamp
         if (found_imu):
            imu_format_dict_array.append(imu_format_dict)

            imu_format_dict = {}
            [imu_8012_struct, imu_8004_struct, imu_8005_struct, imu_8007_struct, imu_8008_struct, imu_8006_struct, imu_8017_struct, imu_8009_struct] = \
               [IMU_8012_struct(), IMU_8004_struct(), IMU_8005_struct(), IMU_8007_struct(), IMU_8008_struct(), IMU_8006_struct(), IMU_8017_struct(), IMU_8009_struct()]
            [imu_800A_struct, imu_800C_struct, imu_8010_struct, imu_8011_struct] = \
               [IMU_800A_struct(), IMU_800C_struct(), IMU_8010_struct(), IMU_8011_struct()]

         # } if (found_imu)..

         if (found_gps):
            if (found_gps_810C_SV_Info):
               gps_format_dict['810C'] = gps_810C_dict

            # if (gps_split_packets == False):
               # if (gps_packet_cnt == 1):
                  # Done with 1st gps packet; will be setting 2nd gps dict shortly. Before doing so, copy contents of gps dict to tmp dict because
                  # we still don't know if GPS packets are split (will know only at the end of 2nd gps packet).  If, at the end of 2nd GPS packet,
                  # we find that GPS packets are not split, then we append this tmp dict first to the array before appending the current dict
                  # for ky in gps_format_dict.keys():
                     # gps_format_dict_tmp[ky] = gps_format_dict[ky]
                  # } for ky in gps_format_dict.keys()..
               # elif (gps_packet_cnt == 2):
                  # gps_format_dict_array.append(gps_format_dict_tmp)
               # } if (gps_packet_cnt == 1)..
            # } if (gps_split_packets == False)..
            
            if (gps_packet_cnt == 1):
               gps_format_dict_tmp = gps_format_dict
            elif (gps_packet_cnt == 2 and not gps_split_packets):
               gps_format_dict_array.append(gps_format_dict_tmp)
            # } if (gps_packet_cnt == 1)..
               
            if (gps_packet_cnt >= 2 and (gps_split_packets == False or (gps_split_packets and gps_packet_cnt % 2 == 0))):
               gps_format_dict_array.append(gps_format_dict)

               # if (gps_packet_cnt >= 2 and gps_split_packets == False or (gps_split_packets and gps_packet_cnt % 2 == 0)):
               gps_format_dict = {}

               [gps_8109_struct, gps_8103_struct, gps_8105_struct, gps_8104_struct, gps_8106_struct, gps_810B_struct, gps_810A_struct, gps_810D_struct] = \
                  [GPS_8109_struct(), GPS_8103_struct(), GPS_8105_struct(), GPS_8104_struct(), GPS_8106_struct(), GPS_810B_struct(), GPS_810A_struct(), GPS_810D_struct()]
               [gps_8107_struct, gps_8108_struct, gps_810C_struct] = \
                  [GPS_8107_struct(), GPS_8108_struct(), GPS_810C_struct()]
               # gps_810C_dict = {}
               gps_810C_dict = OrderedDict()
               # } if (gps_split_packets == False or..
         # } if (found_gps)..

         if (found_ekf):
            # First append the 'tmp' dict to array (corresponding to ekf_packet_cnt = 1), if EKF packets are not split:
            # if (ekf_split_packets == False):
               # if (ekf_packet_cnt == 1):
                  # Done with 1st ekf packet; will be setting 2nd ekf dict shortly. Before doing so, copy contents of ekf dict to tmp dict because
                  # we still don't know if EKF packets are split (will know only at the end of 2nd ekf packet).  If, at the end of 2nd EKF packet,
                  # we find that EKF packets are not split, then we append this tmp dict first to the array before appending the current dict
                  # for ky in ekf_format_dict.keys():
                     # ekf_format_dict_tmp[ky] = ekf_format_dict[ky]
                  # } for ky in ekf_format_dict.keys()..
               # elif (ekf_packet_cnt == 2):
                  # ekf_format_dict_array.append(ekf_format_dict_tmp)
                  # tmp_ekf_8211_struct = ekf_format_dict_tmp['8211']
                  # print(' ******** ekf_packet_cnt = 2, appending tmp dict with TOW: ' + str(tmp_ekf_8211_struct.ekf_tow))
               # } if (ekf_packet_cnt == 1)..
            # } if (ekf_split_packets == False)..

            if (ekf_packet_cnt == 1):
               ekf_format_dict_tmp = ekf_format_dict
            elif (ekf_packet_cnt == 2 and not ekf_split_packets):
               ekf_format_dict_array.append(ekf_format_dict_tmp)
            # } if (ekf_packet_cnt == 1)..

            # Next, append remaining (regular) dict's to array (ekf_packet_cnt = 2 and beyond)
            if (ekf_packet_cnt >= 2 and (ekf_split_packets == False or (ekf_split_packets and ekf_packet_cnt % 2 == 0))):
               ekf_format_dict_array.append(ekf_format_dict)
               # print(' ******** ekf_packet_cnt = ' + str(ekf_packet_cnt))
               # tmp_ekf_8211_struct = ekf_format_dict['8211']
               # print(' ******* appending regular dict with TOW: ' + str(tmp_ekf_8211_struct.ekf_tow))

               # print(' *********** ekf_split_packets = ' + str(ekf_split_packets) + ', ekf_packet_cnt: ' + str(ekf_packet_cnt) + ' Wiping out dict')

               ekf_format_dict = {}

               [ekf_8211_struct, ekf_8210_struct, ekf_8201_struct, ekf_8208_struct, ekf_8202_struct, ekf_8209_struct, ekf_8205_struct, ekf_820A_struct] = \
                  [EKF_8211_struct(), EKF_8210_struct(), EKF_8201_struct(), EKF_8208_struct(), EKF_8202_struct(), EKF_8209_struct(), EKF_8205_struct(), EKF_820A_struct()]
               [ekf_8203_struct, ekf_8212_struct, ekf_8207_struct, ekf_820C_struct, ekf_8217_struct, ekf_8219_struct, ekf_8206_struct, ekf_820B_struct] = \
                  [EKF_8203_struct(), EKF_8212_struct(), EKF_8207_struct(), EKF_820C_struct(), EKF_8217_struct(), EKF_8219_struct(), EKF_8206_struct(), EKF_820B_struct()]
               [ekf_8216_struct, ekf_8218_struct, ekf_820D_struct, ekf_821C_struct, ekf_820E_struct, ekf_8213_struct, ekf_820F_struct, ekf_8214_struct] = \
                  [EKF_8216_struct(), EKF_8218_struct(), EKF_820D_struct(), EKF_821C_struct(), EKF_820E_struct(), EKF_8213_struct(), EKF_820F_struct(), EKF_8214_struct()]
               [ekf_8215_struct, ekf_8220_struct, ekf_8221_struct, ekf_8230_struct, ekf_8231_struct, ekf_8204_struct] = \
                  [EKF_8215_struct(), EKF_8220_struct(), EKF_8221_struct(), EKF_8230_struct(), EKF_8231_struct(), EKF_8204_struct()]
               [ekf_8227_struct, ekf_821A_struct, ekf_821B_struct, ekf_8223_struct, ekf_8224_struct, ekf_8225_struct, ekf_8228_struct, ekf_8226_struct] = \
                   [EKF_8227_struct(), EKF_821A_struct(), EKF_821B_struct(), EKF_8223_struct(), EKF_8224_struct(), EKF_8225_struct(), EKF_8228_struct(), EKF_8226_struct()]
               [ekf_8229_struct, ekf_822A_struct, ekf_822B_struct, ekf_822C_struct, ekf_822D_struct] = \
                   [EKF_8229_struct(), EKF_822A_struct(), EKF_822B_struct(), EKF_822C_struct(), EKF_822D_struct()]

            # } if (ekf_split_packets == False or..
         # } if (found_ekf..
      # } if (mip_check_ret_code != MIP_OK)..

      k = k + payload_size + 6

      found_imu = False
      found_gps = False
      found_ekf = False
      found_gps_810C_SV_Info = False

   else:
      k = k + 1
   # } if (hexlify(bytearray(bytes_read[k])) == '75' and hexlify(bytearray(bytes_read[k+1])) == '65')..
 # } while (k < len(bytes_read))..

 total_nbr_of_visible_svs = len(visible_channel_nbr_used_array)

 print(' ********* total_nbr_of_visible_svs = ' + str(total_nbr_of_visible_svs))

 # print('\n------------------------------------------------------------------')

 print ('\n************* Total nbr of MIP packets: ' + str(packet_cnt))
 print ('************** Nbr of valid IMU packets: ' + str(imu_packet_cnt))
 print ('************** Nbr of valid GPS packets: ' + str(gps_total_packet_cnt))
 print ('************** Nbr of valid EKF packets: ' + str(ekf_total_packet_cnt))
 print ('************** Nbr of valid Other packets: ' + str(other_packet_cnt))

 print ('************** Nbr of invalid IMU packets: ' + str(imu_invalid_packet_cnt))
 print ('************** Nbr of invalid GPS packets: ' + str(gps_invalid_packet_cnt))
 print ('************** Nbr of invalid EKF packets: ' + str(ekf_invalid_packet_cnt))
 print ('************** Nbr of invalid Other packets: ' + str(other_invalid_packet_cnt))

 print(' ********** len(imu_format_dict_array) = ' + str(len(imu_format_dict_array)) )
 print(' ********** len(gps_format_dict_array) = ' + str(len(gps_format_dict_array)) )
 print(' ********** len(ekf_format_dict_array) = ' + str(len(ekf_format_dict_array)) )

 print('\n------------------------------------------------------------------')

 fin_bin.close()

 # # If different Hz are allowed for messages in each category (IMU, GPS or EKF), then scan the input file a second time
 # If different Hz are allowed for messages in each category (IMU, GPS or EKF), then loop over the object arrays and dump into the output file (or send to sensor cloud, or both)
 # after interpolating/extrapolating each column to the fastest column in that category

 imu_packet_cnt = 0
 gps_packet_cnt = 0
 ekf_packet_cnt = 0

 imu_tow_prev = 0
 imu_week_prev = 0

 gps_tow_prev = 0
 gps_week_prev = 0

 ekf_tow_prev = 0
 ekf_week_prev = 0

 imu_valid_tow_found = False
 gps_valid_tow_found = False
 ekf_valid_tow_found = False

 total_channel_cnt = 0

 if (found_d_option_in_command_line == False or bad_descriptor_supplied == True):
    imu_output_order_final = imu_output_order_in_log
    gps_output_order_final = gps_output_order_in_log
    ekf_output_order_final = ekf_output_order_in_log
 else:
    for im in imu_output_order_minus_d:
       if (im in imu_output_order_in_log):
          imu_output_order_final.append(im)
    # } for im in imu_output_order_minus_d..

    for gp in gps_output_order_minus_d:
       if (gp in gps_output_order_in_log):
          gps_output_order_final.append(gp)
    # } for gp in gps_output_order_minus_d..

    for ek in ekf_output_order_minus_d:
       if (ek in ekf_output_order_in_log):
          ekf_output_order_final.append(im)
    # } for ek in ekf_output_order_minus_d..
 # } if (found_d_option_in_command_line == False..

 imu_output_order_final.sort()
 gps_output_order_final.sort()
 ekf_output_order_final.sort()

 for i in imu_output_order_final:
    print(' ******** imu_output_order_final: i = ' + str(i))

 print('------------------------------------------------')

 for i in gps_output_order_final:
    print(' ******** gps_output_order_final: i = ' + str(i))

 print('------------------------------------------------')

 for i in ekf_output_order_final:
    print(' ******** ekf_output_order_final: i = ' + str(i))

 print('------------------------------------------------')

 # ----------------------------------------------------
 # Write IMU headers to csv / channels to sensor cloud:
 # ----------------------------------------------------

 # Write out the headers / create channels for sensor cloud upload:
 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_imu.write('DATA_START\n')

 for input_index in imu_output_order_final:
    # print(' ****** writing headers: input_index = ' + str(input_index))

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       fout_imu.write(imu_format_using_dict.format_header(input_index))

    if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
       tmp_channel_name_array = imu_format_using_dict.format_channel_name(input_index)

       index_range_array = []

       for c in tmp_channel_name_array:
          channel_names.append(c)
          chStatus = addChannel(server, token, device_id, sensor_name, c)
          channel_data[sensor_name][total_channel_cnt] = []
          index_range_array.append(total_channel_cnt)

          total_channel_cnt += 1
       # } for c in tmp_channel_name_array..

       imu_channel_index_range_dict[input_index]  = index_range_array
    # } if (destination.upper() == 'CLOUD'..
 # } for input_index in imu_output_order_final..

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_imu.write('\n')
 # } if (destination.upper() == 'CSV' or..

 imu_week = 0
 imu_tow = 0

 errorFound = False

 for idict in imu_format_dict_array:
    imu_packet_cnt += 1

    if (imu_packet_cnt > 100):
      break
      
    if ('8012' in idict):
       tmp_imu_8012_struct = idict['8012']

       imu_week = tmp_imu_8012_struct.imu_week
       imu_tow = tmp_imu_8012_struct.imu_tow

       # print(' ******* cnt: ' + str(cnt) + ', imu_packet_cnt: ' + str(imu_packet_cnt) + ' from idict: imu_tow2 = ' + str(imu_tow2))
       # print(' ******* imu_packet_cnt: ' + str(imu_packet_cnt) + ' from idict: imu_tow2 = ' + str(imu_tow2))

       if (imu_valid_tow_found == False):
          if (imu_week > 0):
             imu_week_prev = imu_week
             imu_tow_prev = imu_tow
             imu_packet_cnt_valid_start = imu_packet_cnt
             imu_valid_tow_found = True
             imu_format_dict_prev = idict
          # } if (imu_week > 0)..
       # } if (imu_valid_tow_found == False)..
    # } if ('8012' in imu_format_dict)..

    # if (imu_valid_tow_found):
    imu_format_using_dict = IMU_format_using_dict(idict)
    # print(' *********** VALID IMU GPS WEEK FOUND ************ ')
    # print(' ******* created imu_format_using_dict obj out of imu_format_dict')

    for input_index in imu_output_order_final:
       if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
          fout_imu.write(imu_format_using_dict.format(input_index))

       if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
          tmp_channel_value_array = imu_format_using_dict.format_channel_value(input_index)

          if (tmp_channel_value_array != None):
             gps_sec_from_gps_epoch = imu_week * SECONDS_IN_A_WEEK + imu_tow
             utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

             # Convert UTC sec from UTC Epoch into unix nanosecond time
             ts = utc_sec_from_utc_epoch * 1000000000

             tmp_channel_index_range_array = imu_channel_index_range_dict[input_index]

             indx = 0
             for c in tmp_channel_value_array:
                try:
                   ch = channel_data_struct()
                   ch.ts = numpy.int64(ts)
                   ch.value = float(c)
                   channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                except ValueError as err:
                   print(" ******** ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " gps_tow: " + str(gps_tow) + " 0-based column index = " + str(indx) + ", value = " + c + ", Error Msg: {0}".format(err))
                indx = indx + 1
             # } for c in tmp_channel_value_array..
          # } if (tmp_channel_value_array != None)..
       # } if (destination.upper() == 'CLOUD'..
    # } for input_index in imu_output_order_final..

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       fout_imu.write('\n')
    # } if (imu_valid_tow_found)..
 # } for imu_format_dict in imu_format_dict_array..

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_imu.close()

 # ---------------
 # Repeat for GPS:
 # ---------------
 gps_format_using_dict = GPS_format_using_dict(None, total_nbr_of_visible_svs)

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_gps.write('DATA_START\n')

 for input_index in gps_output_order_final:
    # print(' ****** writing headers: input_index = ' + str(input_index))

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       fout_gps.write(gps_format_using_dict.format_header(input_index))

    if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
       tmp_channel_name_array = gps_format_using_dict.format_channel_name(input_index)

       index_range_array = []

       for c in tmp_channel_name_array:
          channel_names.append(c)
          chStatus = addChannel(server, token, device_id, sensor_name, c)
          channel_data[sensor_name][total_channel_cnt] = []
          index_range_array.append(total_channel_cnt)

          total_channel_cnt += 1
       # } for c in tmp_channel_name_array..

       gps_channel_index_range_dict[input_index]  = index_range_array
    # } if (destination.upper() == 'CLOUD'..
 # } for input_index in gps_output_order_final..

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_gps.write('\n')
 # } if (destination.upper() == 'CSV' or..

 gps_week = 0
 gps_tow = 0

 for gps_format_dict in gps_format_dict_array:
    gps_packet_cnt += 1

    if (gps_packet_cnt > 10):
      break

    if ('8109' in gps_format_dict):
       tmp_gps_8109_struct = gps_format_dict['8109']

       gps_week = tmp_gps_8109_struct.gps_week
       gps_tow = tmp_gps_8109_struct.gps_tow

       if (gps_valid_tow_found == False):
          if (gps_week > 0):
             gps_week_prev = gps_week
             gps_tow_prev = gps_tow
             gps_packet_cnt_valid_start = gps_packet_cnt
             gps_valid_tow_found = True
             gps_format_dict_prev = gps_format_dict
          # } if (gps_week > 0)..
       # } if (gps_valid_tow_found == False)..
    # } if ('8109' in gps_format_dict)..

    if (gps_valid_tow_found):
       # print(' *********** VALID GPS GPS WEEK FOUND ************ ')
       gps_format_using_dict = GPS_format_using_dict(gps_format_dict, total_nbr_of_visible_svs)

       for input_index in gps_output_order_final:
          if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
             fout_gps.write(gps_format_using_dict.format(input_index))

          if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
             tmp_channel_value_array = gps_format_using_dict.format_channel_value(input_index)

             if (tmp_channel_value_array != None):
                gps_sec_from_gps_epoch = gps_week * SECONDS_IN_A_WEEK + gps_tow
                utc_sec_from_utc_epoch = gps_sec_from_gps_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

                # Convert UTC sec from UTC Epoch into unix nanosecond time
                ts = utc_sec_from_utc_epoch * 1000000000

                tmp_channel_index_range_array = gps_channel_index_range_dict[input_index]

                indx = 0
                for c in tmp_channel_value_array:
                   try:
                      ch = channel_data_struct()
                      ch.ts = numpy.int64(ts)
                      ch.value = float(c)
                      channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                   except ValueError as err:
                      print(" ******** ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " gps_tow: " + str(gps_tow) + " 0-based column index = " + str(indx) + ", value = " + c + ", Error Msg: {0}".format(err))
                   indx = indx + 1
                # } for c in tmp_channel_value_array..
             # } if (tmp_channel_value_array != None)..
          # } if (destination.upper() == 'CLOUD'..
       # } for input_index in gps_output_order_final..

       if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
          fout_gps.write('\n')
    # } if (gps_valid_tow_found)..
 # } for gps_format_dict in gps_format_dict_array..

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_gps.close()

 # ---------------
 # Repeat for EKF:
 # ---------------
 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_ekf.write('DATA_START\n')

 for input_index in ekf_output_order_final:
    # print(' ****** EKF writing headers: input_index = ' + str(input_index))

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       fout_ekf.write(ekf_format_using_dict.format_header(input_index))

    if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
       tmp_channel_name_array = ekf_format_using_dict.format_channel_name(input_index)

       index_range_array = []

       for c in tmp_channel_name_array:
          channel_names.append(c)
          chStatus = addChannel(server, token, device_id, sensor_name, c)
          channel_data[sensor_name][total_channel_cnt] = []
          index_range_array.append(total_channel_cnt)

          total_channel_cnt += 1
       # } for c in tmp_channel_name_array..

       ekf_channel_index_range_dict[input_index]  = index_range_array
    # } if (destination.upper() == 'CLOUD'..
 # } for input_index in ekf_output_order_final..

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_ekf.write('\n')
 # } if (destination.upper() == 'CSV' or..

 ekf_week = 0
 ekf_tow = 0

 for ekf_format_dict in ekf_format_dict_array:
    ekf_packet_cnt += 1

    if (ekf_packet_cnt > 100):
      break

    if ('8211' in ekf_format_dict):
       tmp_ekf_8211_struct = ekf_format_dict['8211']

       ekf_week = tmp_ekf_8211_struct.ekf_week
       ekf_tow = tmp_ekf_8211_struct.ekf_tow

       if (ekf_valid_tow_found == False):
          if (ekf_week > 0):
             ekf_week_prev = ekf_week
             ekf_tow_prev = ekf_tow
             ekf_packet_cnt_valid_start = ekf_packet_cnt
             ekf_valid_tow_found = True
             ekf_format_dict_prev = ekf_format_dict
          # } if (ekf_week > 0)..
       # } if (ekf_valid_tow_found == False)..
    # } if ('8211' in ekf_format_dict)..

    # if (ekf_valid_tow_found):
    # print(' *********** VALID EKF GPS WEEK FOUND ************ ')
    ekf_format_using_dict = EKF_format_using_dict(ekf_format_dict)

    for input_index in ekf_output_order_final:
       if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
          fout_ekf.write(ekf_format_using_dict.format(input_index))

       if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
          tmp_channel_value_array = ekf_format_using_dict.format_channel_value(input_index)

          if (tmp_channel_value_array != None):
             ekf_sec_from_ekf_epoch = ekf_week * SECONDS_IN_A_WEEK + ekf_tow
             utc_sec_from_utc_epoch = ekf_sec_from_ekf_epoch - NBR_OF_LEAP_SECONDS + UTC_EPOCH_TO_GPS_EPOCH_IN_SECS

             # Convert UTC sec from UTC Epoch into unix nanosecond time
             ts = utc_sec_from_utc_epoch * 1000000000

             tmp_channel_index_range_array = ekf_channel_index_range_dict[input_index]

             indx = 0
             for c in tmp_channel_value_array:
                try:
                   ch = channel_data_struct()
                   ch.ts = numpy.int64(ts)
                   ch.value = float(c)
                   channel_data[sensor_name][tmp_channel_index_range_array[indx]].append(ch)
                except ValueError as err:
                   print(" ******** ValueError: Total nbr of columns: " + str(len(tmp_channel_value_array)) + " ekf_tow: " + str(ekf_tow) + " 0-based column index = " + str(indx) + ", value = " + c + ", Error Msg: {0}".format(err))
                indx = indx + 1
             # } for c in tmp_channel_value_array..
          # } if (tmp_channel_value_array != None)..
       # } if (destination.upper() == 'CLOUD'..
    # } for input_index in ekf_output_order_final..

    if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
       fout_ekf.write('\n')
    # } if (ekf_valid_tow_found)..
 # } for ekf_format_dict in ekf_format_dict_array..

 if (destination.upper() == 'CSV' or destination.upper() == 'BOTH'):
    fout_ekf.close()

 if (destination.upper() == 'CLOUD' or destination.upper() == 'BOTH'):
    print("******* MIP Binary to Sensor Cloud: len(channel_data[sensor_name]) = " + str(len(channel_data[sensor_name])))

    # Upload one column (channel) at a time to Sensor Cloud:
    for index in range(len(channel_data[sensor_name])):
       print(' *********** index = ' + str(index) + ' channel_names[index] = ' + channel_names[index] + ' len(channel_data[sensor_name][index]) = ' + str(len(channel_data[sensor_name][index])))

       channel_data_list = channel_data[sensor_name][index]

       addTimeSeriesData(server, token, device_id, sensor_name, channel_names[index], sampleRate, sampleRateType, channel_data_list)
 # } if (destination.upper() == 'CLOUD' or..

