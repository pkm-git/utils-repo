# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

# This routine decimates the input csv file to pick only every tenth data row, keeping the headers intact
# So a 100 Hz input csv file would result in a new file that has 10 Hz data in it
# Then it takes 3 such input csv files and concatenates them side-by-side
# If GPS Week cross-over happens in any of the 3 files, it maintains the previous GPS Week and adds delta to the TOW
# in order to facilitate 'Relative Time' plotting of the data

import os
import csv
import numpy as np

class gnss_timestamp_data:
   def __init__(self):
      [self.gnss_tflags, self.gnss_week_from_rcvr, self.gnss_tow_from_rcvr, self.cumul_time] = [0,0,0,0]
      [self.lat, self.lon, self.ht, self.ht_MSL, self.ambient_pr] = [0,0,0,0,0]
      [self.vned_n, self.vned_e, self.vned_d] = [0,0,0]
      [self.horizontal_accuracy, self.vertical_accuracy, self.flags_8103] = [0,0,0]
      [self.speed, self.ground_speed, self.heading] = [0,0,0]
      [self.speed_accuracy, self.heading_accuracy, self.flags_8105] = [0,0,0]

def print_row(data_row_cnt, data_row, fout_csv_file, imu_cumul_time, gps_array, gps_cnt):
      
   i = 0
   gps_cnt_ret = gps_cnt
   
   try:
      for v in data_row:
         i += 1
	 
         if (v.strip() != '' and v.strip().lower() != 'nan'):
            if (i == len(data_row)):
	       if ('.' in v):
   	          fout_csv_file.write('%14.8f'%(float(v)))
               else:
	       	  fout_csv_file.write('%1d'%(int(v)))        
               # } if ('.' in v)..		  
	    elif ('.' in v):
               fout_csv_file.write('%14.8f,'%(float(v)))
	       
	       if (i == 3): # If column is IMU TOW, insert extra column value on right for IMU Cumul Time
	          fout_csv_file.write('%14.8f,'%(imu_cumul_time))
	       # } if (i == 3)..
   	    else:
               fout_csv_file.write('%1d,'%(int(v)))
   	    # } if (i == len(..   
         else:
            fout_csv_file.write(',')
         # } if (v.strip() != '')..
      # } for v in data_row..
      
      if (data_row_cnt < 5):
         print(' ***** data_row_cnt: ' + str(data_row_cnt) + ', gps_cnt = ' + str(gps_cnt) + ', will get next element from gps_array')
      
      if (gps_cnt >= len(gps_array)):
         return gps_cnt
         
      gnss_data = gps_array[gps_cnt]
      
      gps_cumul_time = gnss_data.cumul_time
      
      if (imu_cumul_time > gps_cumul_time): # IMU crossed GNSS TOW
	 if (data_row_cnt < 25):
            print(' ***** IMU CROSS OVER AT data_row_cnt: ' + str(data_row_cnt) + ', imu_cumul_time: ' + str(imu_cumul_time) + ', gps_cumul_time: ' + str(gps_cumul_time))
	 
	 gps_cnt_ret = gps_cnt + 1 

         # if (gps_cnt_ret < 5):
            # print(' ****** gps_cnt_ret: ' + str(gps_cnt_ret) + ', gnss_data.gnss_tflags = ' + str(gnss_data.gnss_tflags) + ', gnss_data.gnss_week_from_rcvr = ' + str(gnss_data.gnss_week_from_rcvr) + ', gnss_data.gnss_tow_from_rcvr = ' + str(gnss_data.gnss_tow_from_rcvr))

	 fout_csv_file.write(',%1d,%1d,%1d,%12.4f,%12.4f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%1d,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%14.8f,%1d'%(1, gnss_data.gnss_tflags, gnss_data.gnss_week_from_rcvr, gnss_data.gnss_tow_from_rcvr, gnss_data.cumul_time,\
	     gnss_data.lat, gnss_data.lon, gnss_data.ht, gnss_data.ht_MSL, gnss_data.ambient_pr, gnss_data.horizontal_accuracy, gnss_data.vertical_accuracy, gnss_data.flags_8103,\
	     gnss_data.vned_n, gnss_data.vned_e, gnss_data.vned_d, gnss_data.speed, gnss_data.ground_speed, gnss_data.heading, \
             gnss_data.speed_accuracy, gnss_data.heading_accuracy, gnss_data.flags_8105))
      else:
         fout_csv_file.write(',%1d'%(0))   #  GPS_Available_Flag
      # } if (imu_cumul_time > gps_cumul_time)..

      fout_csv_file.write('\n')
      
      return gps_cnt_ret
      
   except ValueError:
      print(' ******* ValueError: at data_row_cnt = ' + str(data_row_cnt) + ', column: ' + str(i) + ', value: ' + str(v))
   
   except IndexError:     																									       
      print(' ****** IndexError: at data_row_cnt = ' + str(data_row_cnt) + ', gps_cnt = ' + str(gps_cnt))
   
def process_csv_file(imu_csvreader, gps_csvreader):

   determine_headers = False
   headers_found = False
   data_row_cnt = 0
   gps_header_array = []
   gps_array = []
   prev_gps_week = 0
   prev_gps_tow = 0
   gps_cumul_time = 0
   diff_gps_tow = 0

   n_data_columns = 0

   for data_row in gps_csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False

         gps_header_array = data_row
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
         if (len(data_row) > 0 and int(data_row[1]) != 0): # GPS Week != 0

            curr_gps_week = int(data_row[1])
	    curr_gps_tow = float(data_row[2])
	    
            if (prev_gps_week != 0):
	       if (curr_gps_week != prev_gps_week):
                  diff_gps_tow = 604800.00 + curr_gps_tow - prev_gps_tow
               else:
                  diff_gps_tow = curr_gps_tow - prev_gps_tow
               # } if (curr_gps_week != prev_gps_week)..
	       
	       gps_cumul_time += diff_gps_tow
	    # } if (prev_gps_week != 0)..
	    
            gnss_data = gnss_timestamp_data()
	    
	    gnss_data.gnss_tflags = int(data_row[0])
            gnss_data.gnss_week_from_rcvr = int(data_row[1])
            gnss_data.gnss_tow_from_rcvr = float(data_row[2])
            gnss_data.cumul_time = gps_cumul_time
        
	    # if (data_row_cnt < 10):
               # print(' ****** data_row_cnt: ' + str(data_row_cnt) + ', data_row[0] = ' + data_row[0] + ', data_row[1] = ' + data_row[1] + ', data_row[2] = ' + data_row[2] + ', gnss_data.gnss_tflags = ' + str(gnss_data.gnss_tflags) + ', gnss_data.gnss_week_from_rcvr = ' + str(gnss_data.gnss_week_from_rcvr))

            gnss_data.lat = np.double(data_row[3])
            gnss_data.lon = np.double(data_row[4])
            gnss_data.ht = np.double(data_row[5])
            gnss_data.ht_MSL = float(data_row[6])
        
            gnss_data.vned_n = float(data_row[11])
            gnss_data.vned_e = float(data_row[12])
            gnss_data.vned_d = float(data_row[13])
        
            gnss_data.horizontal_accuracy = float(data_row[8])
            gnss_data.vertical_accuracy = float(data_row[9])
	    gnss_data.flags_8103 = int(data_row[10])
	    
            gnss_data.speed = float(data_row[14])
            gnss_data.ground_speed = float(data_row[15])
        
            gnss_data.speed_accuracy = float(data_row[17])
            gnss_data.heading_accuracy = float(data_row[18])
            gnss_data.ambient_pr = float(data_row[7])
	    
	    gnss_data.flags_8105 = int(data_row[19])
	    
	    gps_array.append(gnss_data)
	    
	    prev_gps_week = curr_gps_week
	    prev_gps_tow = curr_gps_tow

         # } if (len(data_row) > 0 and..

      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in gps_csvreader..

   print(' ********** LENGTH OF GPS ARRAY: ' + str(len(gps_array)))
   
   total_gps_rows = len(gps_array)
   
   determine_headers = False
   headers_found = False
   data_row_cnt = 0

   n_data_columns = 0
   
   tow_prev = 0
   tow_current = 0
   
   gps_cnt = 0
   gps_object = None

   prev_imu_week = 0
   prev_imu_tow = 0
   imu_cumul_time = 0
   gpsWeekChanged = False
   cnt = 0
   found_gps_crossover = False
   
   for data_row in imu_csvreader:

      # determined that last row in CSV indicated data start (headers are in this row)
      if (determine_headers):
         n_data_columns =  len(data_row)

         # column headers have been found
         headers_found = True

         # headers no longer need to be determined
         determine_headers = False
         i = 0
         for c in data_row:
	    i += 1
            fout_csv_file.write(c + ',')
            
            if (i == 3): # IMU TOW
     	       fout_csv_file.write('IMU Cumul Time,')
	    elif (i == 12): # Mag Z.  Need to insert GPS_Available_Flag
	       fout_csv_file.write('GPS Available Flag,')
            # } if (i == 3)..   
         # } for c in data_row..
	 
	 i = 0
         for c in gps_header_array:
	    i += 1
	    
   	    # if (i == len(data_row)):
	    if (i == 20):
   	       fout_csv_file.write(c)
   	    else:
	       fout_csv_file.write(c + ',')
	    # } if (i == len(data_row))..

	    if (i == 3):
	       fout_csv_file.write('GPS Cumul Time,')
	    
	    if (i == 20):
	       break
	 # } for c in gps_header_array..
	    
         fout_csv_file.write('\n')
	 
      elif (headers_found):
         data_row_cnt = data_row_cnt + 1
	 
         curr_imu_week = int(data_row[1])
         curr_imu_tow = float(data_row[2])
	 
         if (not found_gps_crossover and curr_imu_tow >= gps_array[0].gnss_tow_from_rcvr):
	    found_gps_crossover = True

	 # if (data_row_cnt > 56260 and data_row_cnt < 56276):
	    # print(' ***** data_row_cnt: ' + str(data_row_cnt) + ', curr_imu_week: ' + str(curr_imu_week) + ', curr_imu_tow: ' + str(curr_imu_tow) + ', prev_imu_week: ' + str(prev_imu_week) + ', prev_imu_tow: ' + str(prev_imu_tow))
	    
         # if (prev_imu_week != 0 and (found_gps_crossover or (not found_gps_crossover and curr_imu_tow >= gps_array[0].gnss_tow_from_rcvr))):
	 if (prev_imu_week != 0 and found_gps_crossover):
            if (curr_imu_week != prev_imu_week):
               diff_imu_tow = 604800.00 + curr_imu_tow - prev_imu_tow
	       gpsWeekChanged = True
	       print(' ****** GPS WEEK CHANGED: diff_imu_tow = ' + str(diff_imu_tow)) 
            else:
               diff_imu_tow = curr_imu_tow - prev_imu_tow
            # } if (curr_imu_week != prev_imu_week)..
	    
	    imu_cumul_time += diff_imu_tow
	    
	    # if (gpsWeekChanged):
	       # cnt = cnt + 1
	       # if (cnt < 10):
	          # print(' ****** GPS WEEK CHANGED: curr_imu_tow: ' + str(curr_imu_tow) + ', prev_imu_tow = ' + str(prev_imu_tow) + ', diff_imu_tow = ' + str(diff_imu_tow) + ', imu_cumul_time = ' + str(imu_cumul_time)) 

         # } if (prev_imu_week != 0)..
	 
	 gps_cnt = print_row(data_row_cnt, data_row, fout_csv_file, imu_cumul_time, gps_array, gps_cnt)
	 
	 if (gps_cnt >= total_gps_rows):
	    break
	    
	 prev_imu_week = curr_imu_week
	 prev_imu_tow = curr_imu_tow
	 
      # this row is neither column headers nor data elements
      else:
         # test for DATA_START row (column headers to follow)
         if (len(data_row) > 0 and data_row[0].strip() == 'DATA_START'):
            determine_headers = True
      # } if (determine_headers)..

   # } for data_row in imu_csvreader..
   

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM_Part1.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM_Part1.csv'

# imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM.csv'
# gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM.csv'

imu_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_IMU_Log_Orig_Data_for_NRTSIM_Part1_18300_18930.csv'
gps_in_file_name = 'C:/MP/Lord/Python_Sandbox/Vehicle_Logs/Canadian_Space_Agency/IMU_Log_V3_4_2018-08-25T22h00m24s_LORD_FORMAT_GPS_Log_Orig_Data_for_NRTSIM_Part1_18300_18930.csv'

(fin_filepath, fin_filename) = os.path.split(imu_in_file_name)

fout_csv_file = open(os.path.join(fin_filepath, fin_filename[:-4] + "_IMU_GNSS_Merged.csv"), "w")

fout_csv_file.write('DATA_START\n')

imu_in_csvfile = open(imu_in_file_name,'r')
imu_csvreader = csv.reader(imu_in_csvfile, delimiter=',')
gps_in_csvfile = open(gps_in_file_name,'r')
gps_csvreader = csv.reader(gps_in_csvfile, delimiter=',')

process_csv_file(imu_csvreader, gps_csvreader)

imu_in_csvfile.close()
gps_in_csvfile.close()
fout_csv_file.close()
