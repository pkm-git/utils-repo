# ******************************************************************************
#  Copyright (c) 2019 LORD Corporation. All rights reserved.
#
#  This software is distributed with GNU Public License version 3 (GPL v3).
#  Any modification or re-distribution is governed by GPL v3. For full details,
#  please refer to LICENSE.txt included with the distribution zip file.
# ******************************************************************************

from PyQt4 import QtCore, QtGui
# from PyQt4.QtCore import *
# from PyQt4.QtGui import *

class comp_port_data_struct:
   def __init__(self):
      self.ComPort = None
      self.port_name = ''
      self.port_baud = 0
      self.model_name = ''
      self.serial_nbr = ''
      self.fw_version = ''
      self.model_nbr = ''
      self.options = ''
      self.port_nbr = ''
      self.filter_status = ''
      self.prev_filter_status = ''
      self.prev_code = 0
      self.code = 0
      self.recording_on = False
      self.streaming_on = False
      
   def toString(self):
      return self.model_name + '\t' + self.serial_nbr + '\t' + str(self.fw_version) + '\t' + self.model_nbr + '\t' + self.options + '\t' + self.port_nbr + '\t' + self.filter_status

class MyLineEdit(QtGui.QLineEdit):

   def __init__(self):
      super(MyLineEdit, self).__init__()

# ---------------------------------------------------
class MyCheckBox(QtGui.QCheckBox):

   def __init__(self, lbl):
      super(MyCheckBox, self).__init__(lbl)

      self.initUI()

   def initUI(self):
      self.toggle()

# ---------------------------------------------------
class MyComboBox(QtGui.QComboBox):

   def __init__(self, type):
      super(MyComboBox, self).__init__()

      self.initUI(type)
      self.type = type

   def initUI(self, type):
      if (type == 'Device'):
         self.addItem("MIP")
         self.addItem("Novatel")
      
      elif (type == 'NRTSIM Device'):
         self.addItem("GX5-45")
         self.addItem("GX5-25")
      
      elif (type == 'NRTSIM FW Version'):
         self.addItem("fw1128")
         self.addItem("fw1129")
      
      elif (type == 'Pitch/Roll Aid'):
         self.addItem("None")
         self.addItem("Gravity Vector")

         index = self.findText('Gravity Vector', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..
      
      elif (type == 'Heading Aid'):
         self.addItem("None")
         self.addItem("Magnetometer")
         self.addItem("GNSS Velocity Vector")
         self.addItem("External Heading Msgs")
         self.addItem("Internal GNSS Vel Vector and Mag")
         self.addItem("Internal GNSS Vel Vector and Ext Heading Msgs")
         self.addItem("Internal Mag and Ext Heading Msgs")
         self.addItem("Internal GNSS Vel Vector and Mag and Ext Heading Msgs")
 
         index = self.findText('Magnetometer', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..
 
      elif (type == 'GNSS Source'):
         self.addItem("Internal GNSS")
         self.addItem("External GNSS")

         index = self.findText('Internal GNSS', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..

      elif (type == 'Altitude Aid'):
         self.addItem("None")
         self.addItem("Pressure Altimeter")

         index = self.findText('Pressure Altimeter', QtCore.Qt.MatchFixedString)
         if index >= 0:
            self.setCurrentIndex(index)
         # } if index >= 0..
      
      elif (type == 'Vehicle Dyn Mode'):
         self.addItem("Portable")
         self.addItem("Automotive")
         self.addItem("Airborne")
         self.addItem("Airborne (High G)")
      
      elif (type == 'Lord Internal'):
         self.addItem("Binary")
         self.addItem("CSV")
         self.addItem("VectorNav ASCII")
         self.addItem("VectorNav TSV")

      else:
         self.addItem("Binary")
         self.addItem("CSV")

      self.move(50, 50)

# ---------------------------------------------------
class MyPushButton(QtGui.QPushButton):

   def __init__(self):
      super(MyPushButton, self).__init__()
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px;");
      self.code = 0
      self.off_state_default_icon = None
      self.on_state_default_icon = None
      self.off_state_hover_icon = None
      self.on_state_hover_icon = None
      self.state = 0
      self.hover_state = 0
      
   def __init__(self, label):
      super(MyPushButton, self).__init__(label)
      # self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px 2px 3px 2px;");
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px;");
      self.code = 0

      self.off_state_icon = None
      self.on_state_icon = None
      self.off_state_hover_icon = None
      self.on_state_hover_icon = None
      self.state = 0
      self.hover_state = 0
      
   def set_off_state_icon(self, off_state_icon):
      self.off_state_icon = off_state_icon
      self.setIcon(off_state_icon)

   def set_on_state_icon(self, on_state_icon):
      self.on_state_icon = on_state_icon

   def set_off_state_hover_icon(self, off_state_hover_icon):
      self.off_state_hover_icon = off_state_hover_icon

   def set_on_state_hover_icon(self, on_state_hover_icon):
      self.on_state_hover_icon = on_state_hover_icon

   def getCode(self):
      return self.code

   def getState(self):
      return self.state

   def setCode(self, code):
      self.code = code

   def setState(self, state):
      self.state = state
   
   # def setIcon(self, default_icon):
      # super(MyPushButton, self).setIcon(default_icon)
      # print('**** in custom setIcon, default_icon = ' + str(default_icon))
      
      # if (state == 0):
	 # self.off_state_default_icon = default_icon
      # else:
         # self.on_state_default_icon = default_icon
      # } if (state == 0)..
      
   # def setHoverIcon(self, state, hover_icon):
      # self.hover_icon = hover_icon 

      # if (state == 0):
	 # self.off_state_hover_icon = hover_icon
      # else:
         # self.on_state_hover_icon = hover_icon
      # } if (state == 0)..

   
   def enterEvent(self, e):
      # self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #F3D264; border: 1px solid navy; padding: 3px;");
      # self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #F3DD93; border: 1px solid navy; padding: 3px 2px 3px 2px;");
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #F3DD93; border: 1px solid navy; padding: 3px;");
      
      self.hover_state = 1
      
      if (self.state <= 0):
         if (self.off_state_hover_icon != None):
            self.setIcon(self.off_state_hover_icon)
         # } if (self.off_state_hover_icon != None)..
      elif (self.on_state_hover_icon != None):
	 self.setIcon(self.on_state_hover_icon)
      # } if (self.state == 0)..
      
   def leaveEvent(self, e):
      # self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px 2px 3px 2px;");
      self.setStyleSheet("font-weight: bold; font-size: 12px; border-radius: 6px; color: #000033; background-color: #CFC3F0; border: 1px solid #330019; padding: 3px;");
      
      self.hover_state = 0
      
      if (self.state <= 0):
         if (self.off_state_icon != None):
            self.setIcon(self.off_state_icon)
         # } if (self.off_state_icon != None)..
      elif (self.on_state_icon != None):
	 self.setIcon(self.on_state_icon)
      # } if (self.state == 0)..

   def switchIcon(self):
      if (self.state <= 0):
         if (self.hover_state == 1):
            if (self.off_state_hover_icon != None):
               self.setIcon(self.off_state_hover_icon)
            # } if (self.off_state_hover_icon != None)..
	 else:
            if (self.off_state_icon != None):
               self.setIcon(self.off_state_icon)
            # } if (self.off_state_icon != None)..
	 # } if (self.hover_state == 1)..   
      elif (self.hover_state == 1):
         if (self.on_state_hover_icon != None):
   	    self.setIcon(self.on_state_hover_icon)
         # } if (self.on_state_hover_icon != None)..
      else:
         if (self.on_state_icon != None):
   	    self.setIcon(self.on_state_icon)
         # } if (self.state == 0)..
      # } if (self.state == 0)..
# ---------------------------------------------------

class MyListWidgetItem(QtGui.QListWidgetItem):

   def __init__(self, str, port_obj = None):
      super(MyListWidgetItem, self).__init__(str)
      self.port_obj = port_obj


class MyListModel(QtCore.QAbstractListModel): 
   def __init__(self, datain, parent=None, *args): 
      """ datain: a list where each item is a row
      """
      QtCore.QAbstractListModel.__init__(self, parent, *args) 
      self.listdata = datain

   def rowCount(self, parent=QtCore.QModelIndex()): 
      return len(self.listdata) 

   def data(self, index, role): 
      if index.isValid() and role == QtCore.Qt.DisplayRole:
          return QtCore.QVariant(self.listdata[index.row()])
      else: 
          return QtCore.QVariant()
      # } if index.isValid()..
       
class MyTabWidget(QtGui.QTabWidget):

   def __init__(self, indx):
      super(MyTabWidget, self).__init__()
      # self.init_widget = None
      self.spl_widget_indx = indx
      self.replace_mode = False
      self.new_widget = None

   def widget(self, indx):
      print('******* in MyTabWidget: widget: indx = ' + str(indx))

      if (indx == self.spl_widget_indx):
         print('******* in MyTabWidget: indx is equal to self.spl_widget_indx')
         if (self.replace_mode):
            print('******* in MyTabWidget: self.replace_mode is TRUE')
            return self.new_widget
         else:
            print('******* in MyTabWidget: self.replace_mode is FALSE')
            return super(MyTabWidget, self).widget(indx)
	 # } if (self.replace_mode)..   
      else:
         print('******* in MyTabWidget: indx is NOT equal to self.spl_widget_indx')
         return super(MyTabWidget, self).widget(indx)
      # } if (indx == self.spl_widget_indx)..
      
   def replaceTabWidget(self, widget):
      self.replace_mode = True
      self.new_widget = widget

class MyTabWidget_bad(QtGui.QTabWidget):

   # def setTabsClosable (self, bool closeable):
      # super(MyTabWidget, self).setTabsClosable(closeable)
      # self.tabBar.tabButton()

   def __init__(self):
      super(MyTabWidget, self).__init__()
      self.tabCloseRequested.connect(self.closeTab)
      self.cnt = 0

   # def addTab(self, QtGui.QWidget widget, QtCore.QString label):
   def addTab(self, widget, label):
      super(MyTabWidget, self).addTab(widget, label)
      self.cnt += 1

      if (self.tabsClosable):
         print(' ************** in addTab, tabsClosable is True, self.currentIndex() = ' + str(self.currentIndex()) + ', self.count() = ' + str(self.count()) + ' self.cnt = ' + str(self.cnt))
         # indx = self.count() - 1
         indx = self.cnt - 1
         if (indx < 2):
            self.tabBar().setTabButton(indx, QtGui.QTabBar.RightSide, None)
         else:
            closeButton = QtGui.QPushButton()
            closeButton.setIcon(QtGui.QIcon(QtGui.QPixmap("close_icon.png")))
            # closeButton.clicked.connect(lambda:self.whichbtn(closeButton))
            closeButton.setFixedWidth(15)
            closeButton.setFixedHeight(15)

            # self.tabBar().setTabText(tabIndex,"CSV Data")
            self.tabBar().setTabButton(indx, QtGui.QTabBar.RightSide, closeButton)

   def closeTab(self, i):
      if (i > 1):
         self.removeTab(i)

   def removeTab(self, index):
      super(MyTabWidget, self).removeTab(index)
      self.cnt -= 1

   def insertTab(self, index, widget, label):
      super(MyTabWidget, self).insertTab(index, widget, label)
      self.cnt += 1
